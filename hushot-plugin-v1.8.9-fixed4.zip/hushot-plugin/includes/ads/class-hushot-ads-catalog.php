<?php
/**
 * Hushot Ads Network - Product Catalog
 * Central unified catalog for all advertisers
 */

if (!defined('ABSPATH')) exit;

class Hushot_Ads_Catalog {
    
    /**
     * Initialize catalog
     */
    public static function init() {
        // Catalog is initialized via database
    }
    
    /**
     * Get daily cap for a duration type from admin settings
     */
    public static function get_daily_cap($duration) {
        $caps = array(
            '1week' => get_option('hushot_ads_daily_cap_1week', 2.43),
            '1month' => get_option('hushot_ads_daily_cap_1month', 1.83),
            '3months' => get_option('hushot_ads_daily_cap_3months', 1.44),
        );
        return floatval($caps[$duration] ?? 2.00);
    }
    
    /**
     * Get today's spend for a product
     */
    public static function get_today_spend($product_id) {
        global $wpdb;
        $today = date('Y-m-d');
        
        $spent = $wpdb->get_var($wpdb->prepare(
            "SELECT COALESCE(spent, 0) FROM {$wpdb->prefix}hushot_ads_stats 
             WHERE product_id = %d AND stat_date = %s",
            $product_id,
            $today
        ));
        
        return floatval($spent);
    }
    
    /**
     * Check if product has reached daily cap
     */
    public static function is_daily_cap_reached($product) {
        $today_spent = self::get_today_spend($product->id);
        $daily_cap = self::get_daily_cap($product->duration);
        
        return $today_spent >= $daily_cap;
    }
    
    /**
     * Record daily spend for a product
     */
    public static function record_daily_spend($product_id, $amount) {
        global $wpdb;
        $today = date('Y-m-d');
        
        // Upsert into daily stats
        $wpdb->query($wpdb->prepare(
            "INSERT INTO {$wpdb->prefix}hushot_ads_stats (product_id, stat_date, spent)
             VALUES (%d, %s, %f)
             ON DUPLICATE KEY UPDATE spent = spent + VALUES(spent)",
            $product_id,
            $today,
            $amount
        ));
    }
    
    /**
     * Create database tables
     */
    public static function create_tables() {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        
        // Main catalog table
        dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}hushot_ads_catalog (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            user_id bigint(20) NOT NULL,
            page_id bigint(20) DEFAULT NULL,
            business_name varchar(255) NOT NULL,
            product_name varchar(255) NOT NULL,
            product_description text,
            product_image_url varchar(500) NOT NULL,
            price decimal(15,2) DEFAULT NULL,
            currency varchar(10) DEFAULT 'USD',
            landing_page_url varchar(500) NOT NULL,
            country varchar(5) NOT NULL,
            state varchar(100) DEFAULT NULL,
            additional_countries text,
            category varchar(50) NOT NULL,
            duration varchar(20) NOT NULL DEFAULT 'month',
            start_date datetime DEFAULT NULL,
            end_date datetime DEFAULT NULL,
            daily_budget decimal(10,2) DEFAULT 0,
            total_budget decimal(10,2) DEFAULT 0,
            spent decimal(10,2) DEFAULT 0,
            impressions bigint(20) DEFAULT 0,
            clicks bigint(20) DEFAULT 0,
            landing_page_views bigint(20) DEFAULT 0,
            whatsapp_clicks bigint(20) DEFAULT 0,
            cta_clicks bigint(20) DEFAULT 0,
            status varchar(20) NOT NULL DEFAULT 'pending',
            rejection_reason text,
            ai_moderation_score decimal(3,2) DEFAULT NULL,
            ai_moderation_notes text,
            meta_product_id varchar(100) DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY user_id (user_id),
            KEY page_id (page_id),
            KEY status (status),
            KEY country (country),
            KEY category (category),
            KEY end_date (end_date)
        ) $charset;");
        
        // Daily stats table for detailed tracking
        dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}hushot_ads_stats (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            product_id bigint(20) NOT NULL,
            stat_date date NOT NULL,
            impressions int DEFAULT 0,
            clicks int DEFAULT 0,
            landing_page_views int DEFAULT 0,
            whatsapp_clicks int DEFAULT 0,
            cta_clicks int DEFAULT 0,
            spent decimal(10,2) DEFAULT 0,
            PRIMARY KEY (id),
            UNIQUE KEY product_date (product_id, stat_date),
            KEY stat_date (stat_date)
        ) $charset;");
        
        // Transaction/payment log
        dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}hushot_ads_transactions (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            user_id bigint(20) NOT NULL,
            product_id bigint(20) DEFAULT NULL,
            amount decimal(10,2) NOT NULL,
            currency varchar(10) DEFAULT 'USD',
            type varchar(20) NOT NULL,
            status varchar(20) DEFAULT 'pending',
            payment_ref varchar(100) DEFAULT NULL,
            notes text,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY user_id (user_id),
            KEY product_id (product_id)
        ) $charset;");
    }
    
    /**
     * Submit a new product for promotion
     */
    public static function submit_product($data) {
        global $wpdb;
        
        $user_id = get_current_user_id();
        if (!$user_id) {
            return new WP_Error('not_logged_in', 'Please log in first.');
        }
        
        $limits = Hushot_Ads::get_limits($user_id);
        
        // Check product limit
        if ($limits['products'] !== -1) {
            $current_count = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->prefix}hushot_ads_catalog WHERE user_id = %d AND status NOT IN ('rejected', 'expired', 'budget_exhausted')",
                $user_id
            ));
            
            if ($current_count >= $limits['products']) {
                return new WP_Error('limit_reached', 'You have reached your product limit. Upgrade to add more.');
            }
        }
        
        // Get page ID - REQUIRED
        $page_id = intval($data['page_id'] ?? 0);
        if (!$page_id) {
            return new WP_Error('missing_page', 'Please select a landing page to boost.');
        }
        
        // Verify page ownership
        $page = get_post($page_id);
        if (!$page || $page->post_author != $user_id || $page->post_type !== 'hushot_page') {
            return new WP_Error('invalid_page', 'Invalid landing page selected.');
        }
        
        // AUTO-FILL from landing page data
        $product_name = $page->post_title;
        $product_description = get_post_meta($page_id, '_hushot_description', true) ?: '';
        $product_image_url = get_post_meta($page_id, '_hushot_image_url', true);
        if (empty($product_image_url)) {
            $product_image_url = get_post_meta($page_id, '_hushot_logo_url', true);
        }
        // Use admin fallback image if no image found
        if (empty($product_image_url)) {
            $product_image_url = get_option('hushot_ads_fallback_image', '');
        }
        
        $price = floatval(get_post_meta($page_id, '_hushot_sale_price', true) ?: get_post_meta($page_id, '_hushot_original_price', true));
        $currency = get_post_meta($page_id, '_hushot_currency', true) ?: 'NGN';
        
        // Get landing page URL - use site URL as fallback
        $landing_page_url = get_permalink($page_id);
        if (!$landing_page_url || $landing_page_url === false) {
            $landing_page_url = home_url('/hushot-page/' . $page->post_name . '/');
        }
        
        // Validate country
        $country = sanitize_text_field($data['country'] ?? 'NG');
        if (!isset(Hushot_Ads::$countries[$country])) {
            return new WP_Error('invalid_country', 'Invalid country selected.');
        }
        
        // Validate duration
        $duration = sanitize_text_field($data['duration'] ?? '1week');
        if (!isset(Hushot_Ads::$durations[$duration])) {
            return new WP_Error('invalid_duration', 'Invalid duration selected.');
        }
        
        // Get gender
        $gender = sanitize_text_field($data['gender'] ?? 'all');
        if (!in_array($gender, array('all', 'male', 'female'))) {
            $gender = 'all';
        }
        
        // Get fixed pricing from admin settings (in USD) with service fee
        $rates = array(
            '1week' => floatval(get_option('hushot_ads_rate_1week', 15)) + floatval(get_option('hushot_ads_fee_1week', 2)),
            '1month' => floatval(get_option('hushot_ads_rate_1month', 50)) + floatval(get_option('hushot_ads_fee_1month', 5)),
            '3months' => floatval(get_option('hushot_ads_rate_3months', 120)) + floatval(get_option('hushot_ads_fee_3months', 10)),
        );
        $total_budget = $rates[$duration];
        
        // Ensure budget is not zero
        if ($total_budget <= 0) {
            $total_budget = 17; // Default fallback
        }
        
        // Calculate dates
        $duration_days = Hushot_Ads::$durations[$duration]['days'];
        $start_date = current_time('mysql');
        $end_date = date('Y-m-d H:i:s', strtotime("+{$duration_days} days"));
        
        // Daily budget (for compatibility)
        $daily_budget = $total_budget / $duration_days;
        
        // Get business name
        $business_name = get_post_meta($page_id, '_hushot_business_name', true);
        if (empty($business_name)) {
            $user = get_userdata($user_id);
            $business_name = get_user_meta($user_id, 'hushot_business_name', true) ?: $user->display_name;
        }
        
        // Auto-detect category
        $category = 'other';
        
        // Prepare data - ensure all required fields have values
        $insert_data = array(
            'user_id' => $user_id,
            'page_id' => $page_id,
            'business_name' => $business_name ?: 'Business',
            'product_name' => $product_name ?: 'Product',
            'product_description' => $product_description,
            'product_image_url' => $product_image_url,
            'price' => $price > 0 ? $price : null,
            'currency' => $currency,
            'landing_page_url' => $landing_page_url,
            'country' => $country,
            'state' => '',
            'additional_countries' => null,
            'category' => $category,
            'gender' => $gender,
            'duration' => $duration,
            'start_date' => null,
            'end_date' => null,
            'daily_budget' => $daily_budget,
            'total_budget' => $total_budget,
            'status' => 'pending_payment'
        );
        
        // Debug: Log insert data
        error_log('Hushot Ads Insert Data: ' . print_r($insert_data, true));
        
        $result = $wpdb->insert($wpdb->prefix . 'hushot_ads_catalog', $insert_data);
        
        if (!$result) {
            error_log('Hushot Ads DB Error: ' . $wpdb->last_error);
            return new WP_Error('db_error', 'Failed to save boost request: ' . $wpdb->last_error);
        }
        
        $product_id = $wpdb->insert_id;
        
        // Get currency and local amount for payment
        $currency_info = Hushot_Flutterwave::convert_usd_to_local($total_budget);
        $amount_local = $currency_info['amount_local'];
        $currency = $currency_info['currency'];
        
        // Get payment method from form
        $payment_method = sanitize_text_field($data['payment_method'] ?? 'card');
        
        // Create payment
        $payment_url = Hushot_Flutterwave::create_ads_payment($product_id, $amount_local, $currency, $payment_method);
        
        if (is_wp_error($payment_url)) {
            // Delete the product if payment creation failed
            $wpdb->delete($wpdb->prefix . 'hushot_ads_catalog', array('id' => $product_id));
            return $payment_url;
        }
        
        return array(
            'product_id' => $product_id,
            'message' => 'Redirecting to payment...',
            'status' => 'pending_payment',
            'payment_url' => $payment_url,
            'redirect' => $payment_url
        );
    }
    
    /**
     * Get product by ID
     */
    public static function get_product($product_id) {
        global $wpdb;
        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}hushot_ads_catalog WHERE id = %d",
            $product_id
        ));
    }
    
    /**
     * Get products for user
     */
    public static function get_user_products($user_id, $status = null) {
        global $wpdb;
        
        $where = "user_id = %d";
        $params = array($user_id);
        
        if ($status) {
            $where .= " AND status = %s";
            $params[] = $status;
        }
        
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}hushot_ads_catalog WHERE {$where} ORDER BY created_at DESC",
            ...$params
        ));
    }
    
    /**
     * Get active products by country (excluding daily cap reached)
     */
    public static function get_active_by_country($country) {
        global $wpdb;
        $today = date('Y-m-d');
        
        // Get all active products for this country
        $products = $wpdb->get_results($wpdb->prepare(
            "SELECT c.*, COALESCE(s.spent, 0) as today_spent
             FROM {$wpdb->prefix}hushot_ads_catalog c
             LEFT JOIN {$wpdb->prefix}hushot_ads_stats s ON c.id = s.product_id AND s.stat_date = %s
             WHERE c.status = 'active' 
             AND (c.country = %s OR c.additional_countries LIKE %s)
             AND (c.end_date IS NULL OR c.end_date > NOW())
             AND (c.total_budget = 0 OR c.spent < c.total_budget)
             ORDER BY RAND()",
            $today,
            $country,
            '%"' . $country . '"%'
        ));
        
        // Filter out products that have reached daily cap
        $filtered = array();
        foreach ($products as $product) {
            $daily_cap = self::get_daily_cap($product->duration);
            if (floatval($product->today_spent) < $daily_cap) {
                $filtered[] = $product;
            }
        }
        
        return $filtered;
    }
    
    /**
     * Get all active products for feed (excluding daily cap reached)
     */
    public static function get_active_for_feed() {
        global $wpdb;
        $today = date('Y-m-d');
        
        // Get all active products
        $products = $wpdb->get_results($wpdb->prepare(
            "SELECT c.*, COALESCE(s.spent, 0) as today_spent
             FROM {$wpdb->prefix}hushot_ads_catalog c
             LEFT JOIN {$wpdb->prefix}hushot_ads_stats s ON c.id = s.product_id AND s.stat_date = %s
             WHERE c.status = 'active'
             AND (c.end_date IS NULL OR c.end_date > NOW())
             AND (c.total_budget = 0 OR c.spent < c.total_budget)
             ORDER BY c.created_at DESC",
            $today
        ));
        
        // Filter out products that have reached daily cap
        $filtered = array();
        foreach ($products as $product) {
            $daily_cap = self::get_daily_cap($product->duration);
            if (floatval($product->today_spent) < $daily_cap) {
                $filtered[] = $product;
            }
        }
        
        return $filtered;
    }
    
    /**
     * Update product status
     */
    public static function update_status($product_id, $status, $user_id = null) {
        global $wpdb;
        
        $valid_statuses = array('pending', 'active', 'paused', 'rejected', 'expired', 'budget_exhausted');
        if (!in_array($status, $valid_statuses)) {
            return false;
        }
        
        $where = array('id' => $product_id);
        
        // If user_id provided, ensure ownership
        if ($user_id) {
            $where['user_id'] = $user_id;
        }
        
        return $wpdb->update(
            $wpdb->prefix . 'hushot_ads_catalog',
            array('status' => $status),
            $where
        );
    }
    
    /**
     * Delete product from catalog
     */
    public static function delete_product($product_id, $user_id = null) {
        global $wpdb;
        
        $where = array('id' => $product_id);
        
        // If user_id provided, ensure ownership
        if ($user_id) {
            $where['user_id'] = $user_id;
        }
        
        // Delete related daily stats first
        $wpdb->delete(
            $wpdb->prefix . 'hushot_ads_daily_stats',
            array('product_id' => $product_id)
        );
        
        // Delete the product
        return $wpdb->delete(
            $wpdb->prefix . 'hushot_ads_catalog',
            $where
        );
    }
    
    /**
     * Record impression
     */
    public static function record_impression($product_id) {
        global $wpdb;
        
        $wpdb->query($wpdb->prepare(
            "UPDATE {$wpdb->prefix}hushot_ads_catalog SET impressions = impressions + 1 WHERE id = %d",
            $product_id
        ));
        
        self::update_daily_stats($product_id, 'impressions');
    }
    
    /**
     * Record click
     */
    public static function record_click($product_id, $type = 'click') {
        global $wpdb;
        
        $field_map = array(
            'click' => 'clicks',
            'landing_page' => 'landing_page_views',
            'whatsapp' => 'whatsapp_clicks',
            'cta' => 'cta_clicks'
        );
        
        $field = $field_map[$type] ?? 'clicks';
        
        $wpdb->query($wpdb->prepare(
            "UPDATE {$wpdb->prefix}hushot_ads_catalog SET {$field} = {$field} + 1 WHERE id = %d",
            $product_id
        ));
        
        self::update_daily_stats($product_id, $field);
    }
    
    /**
     * Update daily stats
     */
    private static function update_daily_stats($product_id, $field, $value = 1) {
        global $wpdb;
        
        $today = date('Y-m-d');
        
        // Try to update existing row
        $result = $wpdb->query($wpdb->prepare(
            "UPDATE {$wpdb->prefix}hushot_ads_stats SET {$field} = {$field} + %d WHERE product_id = %d AND stat_date = %s",
            $value, $product_id, $today
        ));
        
        // If no row updated, insert new
        if ($result === 0) {
            $wpdb->insert($wpdb->prefix . 'hushot_ads_stats', array(
                'product_id' => $product_id,
                'stat_date' => $today,
                $field => $value
            ));
        }
    }
    
    /**
     * Get product stats
     */
    public static function get_product_stats($product_id, $days = 30) {
        global $wpdb;
        
        $start_date = date('Y-m-d', strtotime("-{$days} days"));
        
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}hushot_ads_stats WHERE product_id = %d AND stat_date >= %s ORDER BY stat_date ASC",
            $product_id, $start_date
        ));
    }
    
    /**
     * Admin catalog page
     */
    public static function admin_catalog_page() {
        global $wpdb;
        
        $status_filter = sanitize_text_field($_GET['status'] ?? '');
        $country_filter = sanitize_text_field($_GET['country'] ?? '');
        
        $where = "1=1";
        if ($status_filter) $where .= $wpdb->prepare(" AND status = %s", $status_filter);
        if ($country_filter) $where .= $wpdb->prepare(" AND country = %s", $country_filter);
        
        $products = $wpdb->get_results("SELECT c.*, u.display_name as user_name FROM {$wpdb->prefix}hushot_ads_catalog c LEFT JOIN {$wpdb->users} u ON c.user_id = u.ID WHERE {$where} ORDER BY c.created_at DESC LIMIT 100");
        ?>
        <div style="background:#fff;padding:20px;border-radius:8px;">
            <h2 style="margin:0 0 20px;">Product Catalog</h2>
            
            <div style="margin-bottom:20px;display:flex;gap:10px;">
                <select onchange="location.href='?page=hushot-ads&tab=catalog&status='+this.value+'&country=<?php echo $country_filter; ?>'">
                    <option value="">All Statuses</option>
                    <option value="pending" <?php selected($status_filter, 'pending'); ?>>Pending</option>
                    <option value="active" <?php selected($status_filter, 'active'); ?>>Active</option>
                    <option value="paused" <?php selected($status_filter, 'paused'); ?>>Paused</option>
                    <option value="rejected" <?php selected($status_filter, 'rejected'); ?>>Rejected</option>
                    <option value="expired" <?php selected($status_filter, 'expired'); ?>>Expired</option>
                </select>
                
                <select onchange="location.href='?page=hushot-ads&tab=catalog&status=<?php echo $status_filter; ?>&country='+this.value">
                    <option value="">All Countries</option>
                    <?php foreach (Hushot_Ads::$countries as $code => $c): ?>
                    <option value="<?php echo $code; ?>" <?php selected($country_filter, $code); ?>><?php echo $c['name']; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th width="60">Image</th>
                        <th>Product</th>
                        <th>User</th>
                        <th>Country</th>
                        <th>Budget</th>
                        <th>Stats</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($products as $p): ?>
                    <tr>
                        <td><img src="<?php echo esc_url($p->product_image_url); ?>" width="50" height="50" style="object-fit:cover;border-radius:4px;"></td>
                        <td>
                            <strong><?php echo esc_html($p->product_name); ?></strong><br>
                            <small><?php echo esc_html($p->business_name); ?></small>
                        </td>
                        <td><?php echo esc_html($p->user_name); ?></td>
                        <td><?php echo Hushot_Ads::$countries[$p->country]['name'] ?? $p->country; ?></td>
                        <td>
                            $<?php echo number_format($p->daily_budget, 2); ?>/day<br>
                            <small>Spent: $<?php echo number_format($p->spent, 2); ?></small>
                        </td>
                        <td>
                            👁️ <?php echo number_format($p->impressions); ?><br>
                            🖱️ <?php echo number_format($p->clicks); ?>
                        </td>
                        <td>
                            <?php
                            $status_colors = array(
                                'pending' => '#f59e0b',
                                'active' => '#10b981',
                                'paused' => '#6b7280',
                                'rejected' => '#ef4444',
                                'expired' => '#8b5cf6'
                            );
                            $color = $status_colors[$p->status] ?? '#666';
                            ?>
                            <span style="background:<?php echo $color; ?>;color:#fff;padding:3px 8px;border-radius:12px;font-size:11px;"><?php echo ucfirst($p->status); ?></span>
                        </td>
                        <td>
                            <?php if ($p->status === 'pending'): ?>
                            <a href="?page=hushot-ads&tab=catalog&action=approve&id=<?php echo $p->id; ?>&_wpnonce=<?php echo wp_create_nonce('approve_' . $p->id); ?>" class="button button-small">✓ Approve</a>
                            <a href="?page=hushot-ads&tab=catalog&action=reject&id=<?php echo $p->id; ?>&_wpnonce=<?php echo wp_create_nonce('reject_' . $p->id); ?>" class="button button-small">✗ Reject</a>
                            <?php elseif ($p->status === 'active'): ?>
                            <a href="?page=hushot-ads&tab=catalog&action=pause&id=<?php echo $p->id; ?>&_wpnonce=<?php echo wp_create_nonce('pause_' . $p->id); ?>" class="button button-small">⏸️ Pause</a>
                            <?php elseif ($p->status === 'paused'): ?>
                            <a href="?page=hushot-ads&tab=catalog&action=resume&id=<?php echo $p->id; ?>&_wpnonce=<?php echo wp_create_nonce('resume_' . $p->id); ?>" class="button button-small">▶️ Resume</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php
    }
}
