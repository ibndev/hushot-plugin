<?php
/**
 * Hushot Ads Network - Meta Catalog Feed Generator
 * Auto-generates Facebook/Instagram product feeds from LANDING PAGES
 */

if (!defined('ABSPATH')) exit;

class Hushot_Ads_Feed {
    
    /**
     * Initialize feed endpoints
     */
    public static function init() {
        add_action('init', array(__CLASS__, 'register_feed_endpoint'));
        add_action('template_redirect', array(__CLASS__, 'serve_feed'));
    }
    
    /**
     * Register feed URL rewrite
     */
    public static function register_feed_endpoint() {
        add_rewrite_rule('^hushot-ads-feed/?$', 'index.php?hushot_ads_feed=1', 'top');
        add_rewrite_rule('^hushot-ads-feed/([a-z]+)/?$', 'index.php?hushot_ads_feed=1&feed_format=$matches[1]', 'top');
        add_rewrite_rule('^hushot-ads-feed/country/([A-Z]+)/?$', 'index.php?hushot_ads_feed=1&feed_country=$matches[1]', 'top');
        
        add_rewrite_tag('%hushot_ads_feed%', '1');
        add_rewrite_tag('%feed_format%', '([a-z]+)');
        add_rewrite_tag('%feed_country%', '([A-Z]+)');
    }
    
    /**
     * Serve feed content
     */
    public static function serve_feed() {
        if (!get_query_var('hushot_ads_feed')) return;
        
        $format = get_query_var('feed_format') ?: 'xml';
        $country = get_query_var('feed_country') ?: '';
        
        if ($format === 'csv') {
            self::output_csv_feed($country);
        } else {
            self::output_xml_feed($country);
        }
        
        exit;
    }
    
    /**
     * Get feed URL
     */
    public static function get_feed_url($format = 'xml', $country = '') {
        $base = home_url('/hushot-ads-feed/');
        
        if ($country) {
            return $base . 'country/' . $country . '/';
        }
        
        if ($format === 'csv') {
            return $base . 'csv/';
        }
        
        return $base;
    }
    
    /**
     * Get all boosted landing pages for feed (by country if specified)
     * This pulls from ads_catalog which references landing pages
     */
    public static function get_feed_products($country = '') {
        global $wpdb;
        
        $where = "status = 'active'";
        $params = array();
        
        if ($country) {
            $where .= " AND country = %s";
            $params[] = $country;
        }
        
        $query = "SELECT c.*, 
                         p.post_title as page_title,
                         p.post_name as page_slug
                  FROM {$wpdb->prefix}hushot_ads_catalog c
                  LEFT JOIN {$wpdb->posts} p ON c.page_id = p.ID
                  WHERE {$where}
                  ORDER BY c.created_at DESC";
        
        if (!empty($params)) {
            $query = $wpdb->prepare($query, $params);
        }
        
        $products = $wpdb->get_results($query);
        
        // Enrich with landing page data
        foreach ($products as $product) {
            if ($product->page_id) {
                // Get cover image - first image on landing page
                $product->cover_image = self::get_landing_page_cover_image($product->page_id);
                
                // Get CTA type
                $product->cta_type = get_post_meta($product->page_id, '_hushot_cta_type', true) ?: 'link';
                $product->cta_url = get_post_meta($product->page_id, '_hushot_cta_url', true);
                $product->whatsapp_number = get_post_meta($product->page_id, '_hushot_whatsapp', true);
            }
        }
        
        return $products;
    }
    
    /**
     * Get cover image from landing page
     * Priority: _hushot_image_url > _hushot_logo_url > admin fallback
     */
    public static function get_landing_page_cover_image($page_id) {
        // First try the main product/cover image
        $image_url = get_post_meta($page_id, '_hushot_image_url', true);
        if (!empty($image_url)) {
            return $image_url;
        }
        
        // Then try logo
        $logo_url = get_post_meta($page_id, '_hushot_logo_url', true);
        if (!empty($logo_url)) {
            return $logo_url;
        }
        
        // Finally use admin fallback
        $fallback = get_option('hushot_ads_fallback_image', '');
        if (!empty($fallback)) {
            return $fallback;
        }
        
        // Default placeholder - use icon.svg or a generic placeholder service
        return 'https://via.placeholder.com/500x500.png?text=Product';
    }
    
    /**
     * Output XML feed (Meta/Facebook format)
     * AUTO-GENERATED FROM LANDING PAGES
     */
    public static function output_xml_feed($country = '') {
        header('Content-Type: application/xml; charset=utf-8');
        header('Cache-Control: public, max-age=3600');
        
        $products = self::get_feed_products($country);
        
        echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
        echo '<feed xmlns="http://www.w3.org/2005/Atom" xmlns:g="http://base.google.com/ns/1.0">' . "\n";
        echo '<title>Hushot Product Catalog' . ($country ? ' - ' . $country : '') . '</title>' . "\n";
        echo '<link href="' . esc_url(home_url()) . '"/>' . "\n";
        echo '<updated>' . date('c') . '</updated>' . "\n";
        
        foreach ($products as $product) {
            echo self::format_product_xml($product);
        }
        
        echo '</feed>';
    }
    
    /**
     * Format single product as XML entry
     */
    private static function format_product_xml($product) {
        $xml = '<entry>' . "\n";
        
        // Required fields for Meta
        $xml .= '  <g:id>hushot_' . esc_html($product->id) . '</g:id>' . "\n";
        $xml .= '  <g:title>' . esc_html(self::sanitize_title($product->product_name)) . '</g:title>' . "\n";
        $xml .= '  <g:description>' . esc_html(self::sanitize_description($product->product_description)) . '</g:description>' . "\n";
        $xml .= '  <g:link>' . esc_url($product->landing_page_url) . '</g:link>' . "\n";
        
        // Cover image - auto-detected from landing page
        $image_url = !empty($product->cover_image) ? $product->cover_image : $product->product_image_url;
        $xml .= '  <g:image_link>' . esc_url($image_url) . '</g:image_link>' . "\n";
        
        $xml .= '  <g:availability>in stock</g:availability>' . "\n";
        
        // Price - REQUIRED for Facebook Catalog (use 0.00 if not set)
        $price = $product->price > 0 ? $product->price : 0.00;
        $currency = !empty($product->currency) ? $product->currency : 'NGN';
        $xml .= '  <g:price>' . number_format($price, 2, '.', '') . ' ' . esc_html($currency) . '</g:price>' . "\n";
        
        // Category
        $category = isset(Hushot_Ads::$categories[$product->category]) ? Hushot_Ads::$categories[$product->category] : 'Other';
        $xml .= '  <g:product_type>' . esc_html($category) . '</g:product_type>' . "\n";
        $xml .= '  <g:google_product_category>5613</g:google_product_category>' . "\n";
        
        // Brand/Business
        $xml .= '  <g:brand>' . esc_html($product->business_name) . '</g:brand>' . "\n";
        $xml .= '  <g:condition>new</g:condition>' . "\n";
        
        // Custom labels for targeting (COUNTRY-BASED CAROUSEL GROUPING)
        $xml .= '  <g:custom_label_0>' . esc_html($product->country) . '</g:custom_label_0>' . "\n";
        if (!empty($product->state)) {
            $xml .= '  <g:custom_label_1>' . esc_html($product->state) . '</g:custom_label_1>' . "\n";
        }
        $xml .= '  <g:custom_label_2>' . esc_html($product->category) . '</g:custom_label_2>' . "\n";
        $xml .= '  <g:custom_label_3>user_' . $product->user_id . '</g:custom_label_3>' . "\n";
        
        // CTA type for carousel
        if (!empty($product->cta_type)) {
            $xml .= '  <g:custom_label_4>' . esc_html($product->cta_type) . '</g:custom_label_4>' . "\n";
        }
        
        $xml .= '</entry>' . "\n";
        
        return $xml;
    }
    
    /**
     * Output CSV feed - AUTO-GENERATED FROM LANDING PAGES
     */
    public static function output_csv_feed($country = '') {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="hushot-catalog' . ($country ? '-' . $country : '') . '.csv"');
        header('Cache-Control: public, max-age=3600');
        
        $products = self::get_feed_products($country);
        
        $output = fopen('php://output', 'w');
        
        // Header row (Facebook Product Catalog format)
        fputcsv($output, array(
            'id',
            'title',
            'description',
            'link',
            'image_link',
            'availability',
            'price',
            'brand',
            'condition',
            'product_type',
            'custom_label_0',
            'custom_label_1',
            'custom_label_2',
            'custom_label_3',
            'custom_label_4'
        ));
        
        // Data rows
        foreach ($products as $product) {
            // Price - REQUIRED for Facebook (use 0.00 NGN if not set)
            $price_value = $product->price > 0 ? $product->price : 0.00;
            $currency = !empty($product->currency) ? $product->currency : 'NGN';
            $price = number_format($price_value, 2, '.', '') . ' ' . $currency;
            $image_url = !empty($product->cover_image) ? $product->cover_image : $product->product_image_url;
            
            fputcsv($output, array(
                'hushot_' . $product->id,
                self::sanitize_title($product->product_name),
                self::sanitize_description($product->product_description),
                $product->landing_page_url,
                $image_url,
                'in stock',
                $price,
                $product->business_name,
                'new',
                isset(Hushot_Ads::$categories[$product->category]) ? Hushot_Ads::$categories[$product->category] : 'Other',
                $product->country,  // For country-based carousel grouping
                $product->state ?: '',
                $product->category,
                'user_' . $product->user_id,
                $product->cta_type ?? 'link'
            ));
        }
        
        fclose($output);
    }
    
    /**
     * Sanitize title for feed (Meta requirements)
     */
    private static function sanitize_title($title) {
        $title = strip_tags($title);
        $title = preg_replace('/[^\p{L}\p{N}\s\-\.\,\!\?]/u', '', $title);
        return mb_substr($title, 0, 150);
    }
    
    /**
     * Sanitize description for feed (Meta requirements)
     */
    private static function sanitize_description($description) {
        $description = strip_tags($description);
        $description = preg_replace('/[^\p{L}\p{N}\s\-\.\,\!\?\:\;\'\"]/u', '', $description);
        return mb_substr($description, 0, 5000);
    }
    
    /**
     * Generate static feed files for all countries (for cron)
     */
    public static function generate_feed() {
        $upload_dir = wp_upload_dir();
        $feed_dir = $upload_dir['basedir'] . '/hushot-ads-feeds/';
        
        if (!file_exists($feed_dir)) {
            wp_mkdir_p($feed_dir);
            file_put_contents($feed_dir . '.htaccess', 'Allow from all');
        }
        
        // Generate main feed (all countries)
        $products = self::get_feed_products();
        
        $xml_content = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
        $xml_content .= '<feed xmlns="http://www.w3.org/2005/Atom" xmlns:g="http://base.google.com/ns/1.0">' . "\n";
        $xml_content .= '<title>Hushot Product Catalog</title>' . "\n";
        $xml_content .= '<link href="' . esc_url(home_url()) . '"/>' . "\n";
        $xml_content .= '<updated>' . date('c') . '</updated>' . "\n";
        
        foreach ($products as $product) {
            $xml_content .= self::format_product_xml($product);
        }
        
        $xml_content .= '</feed>';
        file_put_contents($feed_dir . 'catalog.xml', $xml_content);
        
        // Generate per-country feeds for CAROUSEL AD GROUPING
        foreach (Hushot_Ads::$countries as $code => $country) {
            $country_products = self::get_feed_products($code);
            
            if (!empty($country_products)) {
                $country_xml = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
                $country_xml .= '<feed xmlns="http://www.w3.org/2005/Atom" xmlns:g="http://base.google.com/ns/1.0">' . "\n";
                $country_xml .= '<title>Hushot Catalog - ' . $country['name'] . '</title>' . "\n";
                $country_xml .= '<link href="' . esc_url(home_url()) . '"/>' . "\n";
                $country_xml .= '<updated>' . date('c') . '</updated>' . "\n";
                
                foreach ($country_products as $product) {
                    $country_xml .= self::format_product_xml($product);
                }
                
                $country_xml .= '</feed>';
                file_put_contents($feed_dir . 'catalog-' . $code . '.xml', $country_xml);
            }
        }
        
        update_option('hushot_ads_feed_last_updated', current_time('mysql'));
        
        return true;
    }
    
    /**
     * Get static feed URL
     */
    public static function get_static_feed_url($country = '') {
        $upload_dir = wp_upload_dir();
        $filename = $country ? 'catalog-' . $country . '.xml' : 'catalog.xml';
        return $upload_dir['baseurl'] . '/hushot-ads-feeds/' . $filename;
    }
    
    /**
     * Admin feed page
     */
    public static function admin_feed_page() {
        // Handle manual regeneration
        if (isset($_POST['regenerate_feed']) && wp_verify_nonce($_POST['_wpnonce'], 'regenerate_feed')) {
            self::generate_feed();
            echo '<div class="notice notice-success"><p>Feed regenerated successfully!</p></div>';
        }
        
        $last_updated = get_option('hushot_ads_feed_last_updated', 'Never');
        $products_count = count(self::get_feed_products());
        ?>
        <div style="background:#fff;padding:20px;border-radius:8px;">
            <h2 style="margin:0 0 20px;">📦 Facebook Product Feed</h2>
            <p style="color:#666;margin-bottom:20px;">Auto-generated from boosted landing pages. Use country-specific feeds for <strong>carousel ad grouping</strong>.</p>
            
            <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:20px;margin-bottom:30px;">
                <div style="background:#d1fae5;padding:15px;border-radius:8px;">
                    <h4 style="margin:0 0 8px;color:#065f46;">Active Products</h4>
                    <p style="font-size:24px;font-weight:700;margin:0;color:#10b981;"><?php echo $products_count; ?></p>
                </div>
                <div style="background:#f8fafc;padding:15px;border-radius:8px;">
                    <h4 style="margin:0 0 8px;color:#666;">Last Updated</h4>
                    <p style="font-size:14px;margin:0;color:#666;"><?php echo $last_updated; ?></p>
                </div>
                <div style="background:#fef3c7;padding:15px;border-radius:8px;">
                    <h4 style="margin:0 0 8px;color:#92400e;">Feed Source</h4>
                    <p style="font-size:14px;margin:0;color:#d97706;">Landing Pages ✓</p>
                </div>
            </div>
            
            <h3>📋 Feed URLs for Facebook Business Manager</h3>
            
            <table class="wp-list-table widefat" style="max-width:900px;margin-bottom:30px;">
                <tr>
                    <th width="150">XML Feed (All)</th>
                    <td>
                        <code style="background:#f1f5f9;padding:8px 12px;border-radius:4px;display:block;word-break:break-all;">
                            <?php echo esc_url(self::get_feed_url('xml')); ?>
                        </code>
                    </td>
                    <td width="100">
                        <button onclick="copyFeed('<?php echo esc_url(self::get_feed_url('xml')); ?>')" class="button">📋 Copy</button>
                    </td>
                </tr>
                <tr>
                    <th>CSV Feed (All)</th>
                    <td>
                        <code style="background:#f1f5f9;padding:8px 12px;border-radius:4px;display:block;word-break:break-all;">
                            <?php echo esc_url(self::get_feed_url('csv')); ?>
                        </code>
                    </td>
                    <td>
                        <button onclick="copyFeed('<?php echo esc_url(self::get_feed_url('csv')); ?>')" class="button">📋 Copy</button>
                    </td>
                </tr>
            </table>
            
            <h3>🌍 Country-Specific Feeds (For Carousel Grouping)</h3>
            <p style="color:#666;">Use these to create country-targeted carousel ads. Nigeria users see only Nigeria products, etc.</p>
            
            <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:10px;max-width:900px;">
                <?php foreach (Hushot_Ads::$countries as $code => $country): ?>
                <div style="background:#f8fafc;padding:12px;border-radius:4px;font-size:12px;">
                    <strong><?php echo $country['flag'] ?? ''; ?> <?php echo $country['name']; ?></strong><br>
                    <a href="<?php echo esc_url(self::get_feed_url('xml', $code)); ?>" target="_blank" style="color:#667eea;">XML</a> |
                    <button onclick="copyFeed('<?php echo esc_url(self::get_feed_url('xml', $code)); ?>')" style="border:none;background:none;color:#667eea;cursor:pointer;padding:0;">Copy</button>
                </div>
                <?php endforeach; ?>
            </div>
            
            <div style="margin-top:30px;padding:20px;background:#eff6ff;border-radius:8px;border:1px solid #bfdbfe;">
                <h4 style="margin:0 0 10px;color:#1e40af;">ℹ️ How Feed Generation Works</h4>
                <ul style="margin:0;padding-left:20px;color:#1e3a8a;">
                    <li>Feed is <strong>auto-generated</strong> from boosted landing pages</li>
                    <li>Each product includes: Page title, URL, CTA type, Cover image</li>
                    <li>Cover image priority: Page image → Logo → Admin fallback</li>
                    <li>Use <code>custom_label_0</code> in Facebook to filter by country</li>
                </ul>
            </div>
            
            <form method="post" style="margin-top:30px;">
                <?php wp_nonce_field('regenerate_feed'); ?>
                <input type="submit" name="regenerate_feed" class="button button-primary" value="🔄 Regenerate Feed Now">
            </form>
        </div>
        
        <script>
        function copyFeed(text) {
            navigator.clipboard.writeText(text).then(function() {
                alert('Feed URL copied!');
            });
        }
        </script>
        <?php
    }
}
