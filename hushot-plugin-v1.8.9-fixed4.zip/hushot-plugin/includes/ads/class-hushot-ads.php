<?php
/**
 * Hushot Ads Network - Main Module Loader
 * Self-contained Facebook/Instagram Catalog Ads System
 * Version: 1.0.0
 * 
 * ARCHITECTURE:
 * - Completely isolated from page builder
 * - Modular component loading
 * - Plan-gated feature access
 */

if (!defined('ABSPATH')) exit;

class Hushot_Ads {
    
    private static $instance = null;
    private static $initialized = false;
    
    // Module components
    private $catalog;
    private $feed;
    private $campaigns;
    private $ai;
    private $dashboard;
    
    // Supported African countries with regions
    public static $countries = array(
        'NG' => array('name' => 'Nigeria', 'flag' => '🇳🇬', 'currency' => 'NGN', 'states' => array('Lagos', 'Abuja', 'Kano', 'Rivers', 'Oyo', 'Kaduna', 'Ogun', 'Enugu', 'Delta', 'Edo', 'Imo', 'Anambra', 'Kwara', 'Plateau', 'Benue', 'Cross River', 'Akwa Ibom', 'Abia', 'Osun', 'Ekiti', 'Ondo', 'Kogi', 'Niger', 'Sokoto', 'Kebbi', 'Zamfara', 'Katsina', 'Jigawa', 'Bauchi', 'Gombe', 'Borno', 'Yobe', 'Adamawa', 'Taraba', 'Nasarawa', 'Ebonyi', 'Bayelsa')),
        'GH' => array('name' => 'Ghana', 'flag' => '🇬🇭', 'currency' => 'GHS', 'states' => array('Greater Accra', 'Ashanti', 'Western', 'Central', 'Eastern', 'Northern', 'Volta', 'Upper East', 'Upper West', 'Brong-Ahafo')),
        'KE' => array('name' => 'Kenya', 'flag' => '🇰🇪', 'currency' => 'KES', 'states' => array('Nairobi', 'Mombasa', 'Kisumu', 'Nakuru', 'Eldoret', 'Kiambu', 'Machakos', 'Kajiado')),
        'ZA' => array('name' => 'South Africa', 'flag' => '🇿🇦', 'currency' => 'ZAR', 'states' => array('Gauteng', 'Western Cape', 'KwaZulu-Natal', 'Eastern Cape', 'Free State', 'Mpumalanga', 'Limpopo', 'North West', 'Northern Cape')),
        'TZ' => array('name' => 'Tanzania', 'flag' => '🇹🇿', 'currency' => 'TZS', 'states' => array('Dar es Salaam', 'Arusha', 'Mwanza', 'Dodoma', 'Zanzibar')),
        'UG' => array('name' => 'Uganda', 'flag' => '🇺🇬', 'currency' => 'UGX', 'states' => array('Kampala', 'Wakiso', 'Mukono', 'Jinja', 'Mbarara', 'Gulu')),
        'RW' => array('name' => 'Rwanda', 'flag' => '🇷🇼', 'currency' => 'RWF', 'states' => array('Kigali', 'Eastern', 'Northern', 'Southern', 'Western')),
        'ET' => array('name' => 'Ethiopia', 'flag' => '🇪🇹', 'currency' => 'ETB', 'states' => array('Addis Ababa', 'Oromia', 'Amhara', 'SNNPR', 'Tigray')),
        'EG' => array('name' => 'Egypt', 'flag' => '🇪🇬', 'currency' => 'EGP', 'states' => array('Cairo', 'Alexandria', 'Giza', 'Sharm El Sheikh', 'Luxor')),
        'MA' => array('name' => 'Morocco', 'flag' => '🇲🇦', 'currency' => 'MAD', 'states' => array('Casablanca', 'Rabat', 'Marrakesh', 'Fes', 'Tangier')),
        'SN' => array('name' => 'Senegal', 'flag' => '🇸🇳', 'currency' => 'XOF', 'states' => array('Dakar', 'Thies', 'Saint-Louis', 'Kaolack')),
        'CI' => array('name' => 'Ivory Coast', 'flag' => '🇨🇮', 'currency' => 'XOF', 'states' => array('Abidjan', 'Yamoussoukro', 'Bouake', 'Daloa')),
        'CM' => array('name' => 'Cameroon', 'flag' => '🇨🇲', 'currency' => 'XAF', 'states' => array('Douala', 'Yaounde', 'Bamenda', 'Garoua')),
        'ZM' => array('name' => 'Zambia', 'flag' => '🇿🇲', 'currency' => 'ZMW', 'states' => array('Lusaka', 'Copperbelt', 'Southern', 'Eastern')),
        'ZW' => array('name' => 'Zimbabwe', 'flag' => '🇿🇼', 'currency' => 'ZWL', 'states' => array('Harare', 'Bulawayo', 'Manicaland', 'Midlands')),
        'BW' => array('name' => 'Botswana', 'flag' => '🇧🇼', 'currency' => 'BWP', 'states' => array('Gaborone', 'Francistown', 'Maun')),
        'MU' => array('name' => 'Mauritius', 'flag' => '🇲🇺', 'currency' => 'MUR', 'states' => array('Port Louis', 'Curepipe', 'Vacoas-Phoenix')),
        'AO' => array('name' => 'Angola', 'flag' => '🇦🇴', 'currency' => 'AOA', 'states' => array('Luanda', 'Huambo', 'Lobito', 'Benguela')),
    );
    
    // Ad duration options with fixed pricing (in USD)
    public static $durations = array(
        '1week' => array('days' => 7, 'label' => '1 Week'),
        '1month' => array('days' => 30, 'label' => '1 Month'),
        '3months' => array('days' => 90, 'label' => '3 Months')
    );
    
    // Product categories for catalog
    public static $categories = array(
        'fashion' => 'Fashion & Clothing',
        'electronics' => 'Electronics & Gadgets',
        'beauty' => 'Beauty & Personal Care',
        'food' => 'Food & Beverages',
        'home' => 'Home & Living',
        'health' => 'Health & Wellness',
        'services' => 'Services',
        'education' => 'Education & Courses',
        'automotive' => 'Automotive',
        'real_estate' => 'Real Estate',
        'events' => 'Events & Entertainment',
        'travel' => 'Travel & Tourism',
        'agriculture' => 'Agriculture',
        'technology' => 'Technology & Software',
        'other' => 'Other'
    );
    
    /**
     * Get singleton instance
     */
    public static function instance() {
        if (is_null(self::$instance)) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Initialize the Ads Network module
     */
    public static function init() {
        if (self::$initialized) return;
        self::$initialized = true;
        
        // Load component classes
        self::load_components();
        
        // Initialize components
        Hushot_Ads_Catalog::init();
        Hushot_Ads_Feed::init();
        Hushot_Ads_Campaigns::init();
        Hushot_Ads_AI::init();
        Hushot_Ads_Dashboard::init();
        
        // Register shortcodes
        add_shortcode('hushot_ads_promote', array(__CLASS__, 'shortcode_promote'));
        add_shortcode('hushot_ads_dashboard', array(__CLASS__, 'shortcode_dashboard'));
        
        // Admin menu - priority 20 to run after main Hushot menu (priority 10)
        add_action('admin_menu', array(__CLASS__, 'add_admin_menu'), 20);
        
        // Cron jobs for ad management
        add_action('hushot_ads_check_expiry', array(__CLASS__, 'check_ad_expiry'));
        add_action('hushot_ads_update_feed', array(__CLASS__, 'update_catalog_feed'));
        add_action('hushot_ads_ai_optimize', array(__CLASS__, 'run_ai_optimization'));
        
        // Schedule cron if not already
        if (!wp_next_scheduled('hushot_ads_check_expiry')) {
            wp_schedule_event(time(), 'hourly', 'hushot_ads_check_expiry');
        }
        if (!wp_next_scheduled('hushot_ads_update_feed')) {
            wp_schedule_event(time(), 'hourly', 'hushot_ads_update_feed');
        }
        if (!wp_next_scheduled('hushot_ads_ai_optimize')) {
            wp_schedule_event(time(), 'twicedaily', 'hushot_ads_ai_optimize');
        }
        
        // AJAX handlers
        add_action('wp_ajax_hushot_ads_submit_product', array(__CLASS__, 'ajax_submit_product'));
        add_action('wp_ajax_hushot_ads_get_states', array(__CLASS__, 'ajax_get_states'));
        add_action('wp_ajax_hushot_ads_pause_ad', array(__CLASS__, 'ajax_pause_ad'));
        add_action('wp_ajax_hushot_ads_resume_ad', array(__CLASS__, 'ajax_resume_ad'));
        add_action('wp_ajax_hushot_ads_campaign_action', array(__CLASS__, 'ajax_campaign_action'));
    }
    
    /**
     * Load component classes
     */
    private static function load_components() {
        $dir = HUSHOT_PLUGIN_DIR . 'includes/ads/';
        require_once $dir . 'class-hushot-ads-catalog.php';
        require_once $dir . 'class-hushot-ads-feed.php';
        require_once $dir . 'class-hushot-ads-campaigns.php';
        require_once $dir . 'class-hushot-ads-ai.php';
        require_once $dir . 'class-hushot-ads-dashboard.php';
    }
    
    /**
     * Check if user has ads access - ALL plans can use Ads Network (pay-per-use)
     */
    public static function has_access($user_id = null) {
        if (!$user_id) $user_id = get_current_user_id();
        if (!$user_id) return false;
        
        // All logged-in users can use Ads Network - it's optional and pay-per-use
        return true;
    }
    
    /**
     * Get user's ad limits (all plans have same access, it's pay-per-use)
     */
    public static function get_limits($user_id = null) {
        if (!$user_id) $user_id = get_current_user_id();
        
        // All plans have same limits - ads are pay-per-use, not plan-gated
        return array(
            'products' => -1, // Unlimited
            'active_ads' => -1,
            'daily_budget_max' => 500, // USD
            'countries' => 5
        );
    }
    
    /**
     * Add admin menu for Ads Network
     */
    public static function add_admin_menu() {
        add_submenu_page(
            'hushot',
            'Ads Network',
            'Ads Network',
            'manage_options',
            'hushot-ads',
            array(__CLASS__, 'admin_page')
        );
    }
    
    /**
     * Admin page for Ads Network management
     */
    public static function admin_page() {
        $tab = sanitize_text_field($_GET['tab'] ?? 'overview');
        ?>
        <div class="wrap">
            <h1>🚀 Hushot Ads Network</h1>
            <p>Multi-vendor Facebook/Instagram Catalog Ads System</p>
            
            <nav class="nav-tab-wrapper">
                <a href="?page=hushot-ads&tab=overview" class="nav-tab <?php echo $tab === 'overview' ? 'nav-tab-active' : ''; ?>">Overview</a>
                <a href="?page=hushot-ads&tab=catalog" class="nav-tab <?php echo $tab === 'catalog' ? 'nav-tab-active' : ''; ?>">Product Catalog</a>
                <a href="?page=hushot-ads&tab=campaigns" class="nav-tab <?php echo $tab === 'campaigns' ? 'nav-tab-active' : ''; ?>">Campaigns</a>
                <a href="?page=hushot-ads&tab=feed" class="nav-tab <?php echo $tab === 'feed' ? 'nav-tab-active' : ''; ?>">Meta Feed</a>
                <a href="?page=hushot-ads&tab=moderation" class="nav-tab <?php echo $tab === 'moderation' ? 'nav-tab-active' : ''; ?>">AI Moderation</a>
                <a href="?page=hushot-ads&tab=settings" class="nav-tab <?php echo $tab === 'settings' ? 'nav-tab-active' : ''; ?>">Settings</a>
            </nav>
            
            <div style="margin-top:20px;">
                <?php
                switch ($tab) {
                    case 'catalog':
                        Hushot_Ads_Catalog::admin_catalog_page();
                        break;
                    case 'campaigns':
                        Hushot_Ads_Campaigns::admin_campaigns_page();
                        break;
                    case 'feed':
                        Hushot_Ads_Feed::admin_feed_page();
                        break;
                    case 'moderation':
                        Hushot_Ads_AI::admin_moderation_page();
                        break;
                    case 'settings':
                        self::admin_settings_page();
                        break;
                    default:
                        self::admin_overview_page();
                }
                ?>
            </div>
        </div>
        <?php
    }
    
    /**
     * Admin overview page
     */
    private static function admin_overview_page() {
        global $wpdb;
        
        $total_products = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}hushot_ads_catalog");
        $active_products = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}hushot_ads_catalog WHERE status = 'active'");
        $total_impressions = $wpdb->get_var("SELECT SUM(impressions) FROM {$wpdb->prefix}hushot_ads_catalog") ?: 0;
        $total_clicks = $wpdb->get_var("SELECT SUM(clicks) FROM {$wpdb->prefix}hushot_ads_catalog") ?: 0;
        ?>
        <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:20px;">
            <div style="background:#fff;padding:20px;border-radius:8px;box-shadow:0 1px 3px rgba(0,0,0,0.1);">
                <h3 style="margin:0 0 5px;color:#666;font-size:13px;">Total Products</h3>
                <p style="font-size:32px;font-weight:700;margin:0;color:#FF553E;"><?php echo number_format($total_products); ?></p>
            </div>
            <div style="background:#fff;padding:20px;border-radius:8px;box-shadow:0 1px 3px rgba(0,0,0,0.1);">
                <h3 style="margin:0 0 5px;color:#666;font-size:13px;">Active Ads</h3>
                <p style="font-size:32px;font-weight:700;margin:0;color:#10b981;"><?php echo number_format($active_products); ?></p>
            </div>
            <div style="background:#fff;padding:20px;border-radius:8px;box-shadow:0 1px 3px rgba(0,0,0,0.1);">
                <h3 style="margin:0 0 5px;color:#666;font-size:13px;">Total Impressions</h3>
                <p style="font-size:32px;font-weight:700;margin:0;color:#3b82f6;"><?php echo number_format($total_impressions); ?></p>
            </div>
            <div style="background:#fff;padding:20px;border-radius:8px;box-shadow:0 1px 3px rgba(0,0,0,0.1);">
                <h3 style="margin:0 0 5px;color:#666;font-size:13px;">Total Clicks</h3>
                <p style="font-size:32px;font-weight:700;margin:0;color:#8b5cf6;"><?php echo number_format($total_clicks); ?></p>
            </div>
        </div>
        
        <div style="margin-top:30px;background:#fff;padding:20px;border-radius:8px;">
            <h2 style="margin:0 0 15px;">Quick Actions</h2>
            <p><a href="?page=hushot-ads&tab=feed" class="button button-primary">📄 View Meta Catalog Feed</a></p>
            <p><a href="?page=hushot-ads&tab=moderation" class="button">🤖 Review Pending Products</a></p>
        </div>
        <?php
    }
    
    /**
     * Admin settings page
     */
    private static function admin_settings_page() {
        if (isset($_POST['hushot_ads_save_settings']) && wp_verify_nonce($_POST['_wpnonce'], 'hushot_ads_settings')) {
            update_option('hushot_ads_meta_pixel_id', sanitize_text_field($_POST['meta_pixel_id']));
            update_option('hushot_ads_meta_catalog_id', sanitize_text_field($_POST['meta_catalog_id']));
            update_option('hushot_ads_meta_access_token', sanitize_text_field($_POST['meta_access_token']));
            update_option('hushot_ads_min_daily_budget', floatval($_POST['min_daily_budget']));
            update_option('hushot_ads_platform_fee', floatval($_POST['platform_fee']));
            update_option('hushot_ads_rate_1week', floatval($_POST['rate_1week']));
            update_option('hushot_ads_rate_1month', floatval($_POST['rate_1month']));
            update_option('hushot_ads_rate_3months', floatval($_POST['rate_3months']));
            update_option('hushot_ads_fee_1week', floatval($_POST['fee_1week']));
            update_option('hushot_ads_fee_1month', floatval($_POST['fee_1month']));
            update_option('hushot_ads_fee_3months', floatval($_POST['fee_3months']));
            update_option('hushot_ads_fallback_image', esc_url_raw($_POST['fallback_image']));
            // Daily spend caps
            update_option('hushot_ads_daily_cap_1week', floatval($_POST['daily_cap_1week']));
            update_option('hushot_ads_daily_cap_1month', floatval($_POST['daily_cap_1month']));
            update_option('hushot_ads_daily_cap_3months', floatval($_POST['daily_cap_3months']));
            echo '<div class="notice notice-success"><p>Settings saved!</p></div>';
        }
        
        $meta_pixel_id = get_option('hushot_ads_meta_pixel_id', '');
        $meta_catalog_id = get_option('hushot_ads_meta_catalog_id', '');
        $meta_access_token = get_option('hushot_ads_meta_access_token', '');
        $min_daily_budget = get_option('hushot_ads_min_daily_budget', 5);
        $platform_fee = get_option('hushot_ads_platform_fee', 10);
        $rate_1week = get_option('hushot_ads_rate_1week', 15);
        $rate_1month = get_option('hushot_ads_rate_1month', 50);
        $rate_3months = get_option('hushot_ads_rate_3months', 120);
        $fee_1week = get_option('hushot_ads_fee_1week', 2);
        $fee_1month = get_option('hushot_ads_fee_1month', 5);
        $fee_3months = get_option('hushot_ads_fee_3months', 10);
        $fallback_image = get_option('hushot_ads_fallback_image', '');
        // Daily spend caps - default: total budget / duration days
        $daily_cap_1week = get_option('hushot_ads_daily_cap_1week', round(($rate_1week + $fee_1week) / 7, 2));
        $daily_cap_1month = get_option('hushot_ads_daily_cap_1month', round(($rate_1month + $fee_1month) / 30, 2));
        $daily_cap_3months = get_option('hushot_ads_daily_cap_3months', round(($rate_3months + $fee_3months) / 90, 2));
        ?>
        <form method="post">
            <?php wp_nonce_field('hushot_ads_settings'); ?>
            
            <div style="background:#fff;padding:20px;border-radius:8px;max-width:800px;margin-bottom:20px;">
                <h2 style="margin:0 0 20px;">💰 Boost Pricing & Daily Spend Caps (USD)</h2>
                <p style="color:#666;margin-bottom:20px;">Set the ad spend, service fee, and daily spend cap for each duration. When daily cap is reached, the ad pauses for that day and resumes the next day.</p>
                
                <table class="wp-list-table widefat" style="margin-bottom:20px;">
                    <thead>
                        <tr>
                            <th>Duration</th>
                            <th>Ad Spend</th>
                            <th>Service Fee</th>
                            <th>Total</th>
                            <th>Daily Cap</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><strong>Weekly (7 days)</strong></td>
                            <td><input type="number" name="rate_1week" value="<?php echo esc_attr($rate_1week); ?>" step="0.01" min="0" style="width:80px;"></td>
                            <td><input type="number" name="fee_1week" value="<?php echo esc_attr($fee_1week); ?>" step="0.01" min="0" style="width:80px;"></td>
                            <td><strong>$<?php echo number_format($rate_1week + $fee_1week, 2); ?></strong></td>
                            <td><input type="number" name="daily_cap_1week" value="<?php echo esc_attr($daily_cap_1week); ?>" step="0.01" min="0.01" style="width:80px;"> /day</td>
                        </tr>
                        <tr>
                            <td><strong>Monthly (30 days)</strong></td>
                            <td><input type="number" name="rate_1month" value="<?php echo esc_attr($rate_1month); ?>" step="0.01" min="0" style="width:80px;"></td>
                            <td><input type="number" name="fee_1month" value="<?php echo esc_attr($fee_1month); ?>" step="0.01" min="0" style="width:80px;"></td>
                            <td><strong>$<?php echo number_format($rate_1month + $fee_1month, 2); ?></strong></td>
                            <td><input type="number" name="daily_cap_1month" value="<?php echo esc_attr($daily_cap_1month); ?>" step="0.01" min="0.01" style="width:80px;"> /day</td>
                        </tr>
                        <tr>
                            <td><strong>3 Months (90 days)</strong></td>
                            <td><input type="number" name="rate_3months" value="<?php echo esc_attr($rate_3months); ?>" step="0.01" min="0" style="width:80px;"></td>
                            <td><input type="number" name="fee_3months" value="<?php echo esc_attr($fee_3months); ?>" step="0.01" min="0" style="width:80px;"></td>
                            <td><strong>$<?php echo number_format($rate_3months + $fee_3months, 2); ?></strong></td>
                            <td><input type="number" name="daily_cap_3months" value="<?php echo esc_attr($daily_cap_3months); ?>" step="0.01" min="0.01" style="width:80px;"> /day</td>
                        </tr>
                    </tbody>
                </table>
                <p style="color:#888;font-size:12px;">💡 Daily cap: When an ad's daily spend reaches this limit, it pauses for that day and automatically resumes the next day.</p>
            </div>
            
            <div style="background:#fff;padding:20px;border-radius:8px;max-width:800px;margin-bottom:20px;">
                <h2 style="margin:0 0 20px;">🖼️ Feed Settings</h2>
                
                <p>
                    <label><strong>Fallback Image URL</strong></label><br>
                    <input type="url" name="fallback_image" value="<?php echo esc_attr($fallback_image); ?>" class="regular-text" style="width:100%;">
                    <br><small>Used when a landing page has no image. Recommended: 1080x1080px square image.</small>
                </p>
            </div>
            
            <div style="background:#fff;padding:20px;border-radius:8px;max-width:800px;margin-bottom:20px;">
                <h2 style="margin:0 0 20px;">⚙️ General Settings</h2>
                
                <p>
                    <label><strong>Minimum Daily Budget (USD)</strong></label><br>
                    <input type="number" name="min_daily_budget" value="<?php echo esc_attr($min_daily_budget); ?>" step="0.01" min="1" class="small-text">
                    <br><small>Legacy setting for custom budget mode</small>
                </p>
                
                <p>
                    <label><strong>Platform Fee (%)</strong></label><br>
                    <input type="number" name="platform_fee" value="<?php echo esc_attr($platform_fee); ?>" step="0.1" min="0" max="50" class="small-text">
                    <br><small>Legacy percentage fee</small>
                </p>
            </div>
            
            <div style="background:#fff;padding:20px;border-radius:8px;max-width:800px;">
                <h2 style="margin:0 0 20px;">📱 Meta (Facebook) Integration</h2>
                
                <p>
                    <label><strong>Meta Pixel ID</strong></label><br>
                    <input type="text" name="meta_pixel_id" value="<?php echo esc_attr($meta_pixel_id); ?>" class="regular-text">
                </p>
                
                <p>
                    <label><strong>Meta Catalog ID</strong></label><br>
                    <input type="text" name="meta_catalog_id" value="<?php echo esc_attr($meta_catalog_id); ?>" class="regular-text">
                    <br><small>From Facebook Business Manager</small>
                </p>
                
                <p>
                    <label><strong>Meta Access Token</strong></label><br>
                    <input type="password" name="meta_access_token" value="<?php echo esc_attr($meta_access_token); ?>" class="regular-text">
                </p>
                
                <p>
                    <input type="submit" name="hushot_ads_save_settings" class="button button-primary" value="Save Settings">
                </p>
            </div>
        </form>
        <?php
    }
    
    /**
     * Shortcode: Promote via Ads Network button
     */
    public static function shortcode_promote($atts) {
        if (!is_user_logged_in()) return '';
        
        $atts = shortcode_atts(array('page_id' => 0), $atts);
        $page_id = intval($atts['page_id']);
        
        if (!$page_id) return '';
        
        // Check access
        if (!self::has_access()) {
            return '<div style="padding:16px;background:#fef3c7;border-radius:8px;text-align:center;">
                <p>🔒 Upgrade to Essential or Premium to promote your pages via Hushot Ads Network.</p>
                <a href="' . esc_url(Hushot_Pages::get_page_url('pricing')) . '" style="color:#FF553E;font-weight:600;">View Plans →</a>
            </div>';
        }
        
        ob_start();
        ?>
        <div class="hushot-ads-promote-box">
            <a href="<?php echo esc_url(add_query_arg('page_id', $page_id, Hushot_Pages::get_page_url('ads-promote'))); ?>" class="hushot-ads-promote-btn">
                📢 Promote via Hushot Ads Network
            </a>
        </div>
        <style>
        .hushot-ads-promote-box{margin:20px 0;text-align:center;}
        .hushot-ads-promote-btn{display:inline-block;padding:14px 28px;background:linear-gradient(135deg,#667eea,#764ba2);color:#fff!important;font-weight:600;border-radius:12px;text-decoration:none;transition:all 0.3s;}
        .hushot-ads-promote-btn:hover{transform:translateY(-2px);box-shadow:0 8px 20px rgba(102,126,234,0.4);}
        </style>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Shortcode: User ads dashboard
     */
    public static function shortcode_dashboard($atts) {
        if (!is_user_logged_in()) return '<p>Please log in to view your ads dashboard.</p>';
        
        return Hushot_Ads_Dashboard::render_user_dashboard();
    }
    
    /**
     * AJAX: Submit product for promotion
     */
    public static function ajax_submit_product() {
        // Verify nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'hushot_ads_submit')) {
            wp_send_json_error(array('message' => 'Security check failed. Please refresh and try again.'));
        }
        
        if (!is_user_logged_in()) {
            wp_send_json_error(array('message' => 'Please log in first.'));
        }
        
        if (!self::has_access()) {
            wp_send_json_error(array('message' => 'Upgrade your plan to use Ads Network.'));
        }
        
        $result = Hushot_Ads_Catalog::submit_product($_POST);
        
        if (is_wp_error($result)) {
            error_log('Hushot Ads Submit Error: ' . $result->get_error_message());
            wp_send_json_error(array('message' => $result->get_error_message()));
        }
        
        wp_send_json_success($result);
    }
    
    /**
     * AJAX: Get states for country
     */
    public static function ajax_get_states() {
        $country = sanitize_text_field($_POST['country'] ?? '');
        
        if (empty($country) || !isset(self::$countries[$country])) {
            wp_send_json_error(array('message' => 'Invalid country.'));
        }
        
        wp_send_json_success(array(
            'states' => self::$countries[$country]['states']
        ));
    }
    
    /**
     * AJAX: Pause ad
     */
    public static function ajax_pause_ad() {
        if (!is_user_logged_in()) {
            wp_send_json_error(array('message' => 'Please log in.'));
        }
        
        $product_id = intval($_POST['product_id'] ?? 0);
        $user_id = get_current_user_id();
        
        $result = Hushot_Ads_Catalog::update_status($product_id, 'paused', $user_id);
        
        if ($result) {
            wp_send_json_success(array('message' => 'Ad paused.'));
        } else {
            wp_send_json_error(array('message' => 'Failed to pause ad.'));
        }
    }
    
    /**
     * AJAX: Resume ad
     */
    public static function ajax_resume_ad() {
        if (!is_user_logged_in()) {
            wp_send_json_error(array('message' => 'Please log in.'));
        }
        
        $product_id = intval($_POST['product_id'] ?? 0);
        $user_id = get_current_user_id();
        
        $result = Hushot_Ads_Catalog::update_status($product_id, 'active', $user_id);
        
        if ($result) {
            wp_send_json_success(array('message' => 'Ad resumed.'));
        } else {
            wp_send_json_error(array('message' => 'Failed to resume ad.'));
        }
    }
    
    /**
     * AJAX: Combined campaign action handler (pause/resume/delete)
     */
    public static function ajax_campaign_action() {
        if (!is_user_logged_in()) {
            wp_send_json_error(array('message' => 'Please log in.'));
        }
        
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'hushot_ads_action')) {
            wp_send_json_error(array('message' => 'Security check failed.'));
        }
        
        $product_id = intval($_POST['product_id'] ?? 0);
        $action = sanitize_text_field($_POST['campaign_action'] ?? '');
        $user_id = get_current_user_id();
        
        if (!$product_id || !$action) {
            wp_send_json_error(array('message' => 'Invalid request.'));
        }
        
        switch ($action) {
            case 'pause':
                $result = Hushot_Ads_Catalog::update_status($product_id, 'paused', $user_id);
                $message = $result ? 'Campaign paused.' : 'Failed to pause campaign.';
                break;
                
            case 'resume':
                $result = Hushot_Ads_Catalog::update_status($product_id, 'active', $user_id);
                $message = $result ? 'Campaign resumed.' : 'Failed to resume campaign.';
                break;
                
            case 'delete':
                $result = Hushot_Ads_Catalog::delete_product($product_id, $user_id);
                $message = $result ? 'Campaign deleted.' : 'Failed to delete campaign.';
                break;
                
            default:
                $result = false;
                $message = 'Unknown action.';
        }
        
        if ($result) {
            wp_send_json_success(array('message' => $message));
        } else {
            wp_send_json_error(array('message' => $message));
        }
    }
    
    /**
     * Cron: Check ad expiry
     */
    public static function check_ad_expiry() {
        global $wpdb;
        
        // Expire ads that have passed their end date
        $wpdb->query("
            UPDATE {$wpdb->prefix}hushot_ads_catalog 
            SET status = 'expired' 
            WHERE status = 'active' 
            AND end_date IS NOT NULL 
            AND end_date < NOW()
        ");
        
        // Expire ads that have exhausted their budget
        $wpdb->query("
            UPDATE {$wpdb->prefix}hushot_ads_catalog 
            SET status = 'budget_exhausted' 
            WHERE status = 'active' 
            AND total_budget > 0 
            AND spent >= total_budget
        ");
    }
    
    /**
     * Cron: Update catalog feed
     */
    public static function update_catalog_feed() {
        Hushot_Ads_Feed::generate_feed();
    }
    
    /**
     * Cron: Run AI optimization
     */
    public static function run_ai_optimization() {
        Hushot_Ads_AI::optimize_campaigns();
    }
}
