<?php
/**
 * Hushot Ads Network - Campaign Management
 * Manages shared campaigns for cost-effective multi-vendor ads
 */

if (!defined('ABSPATH')) exit;

class Hushot_Ads_Campaigns {
    
    /**
     * Initialize campaigns
     */
    public static function init() {
        // Campaign management hooks
        add_action('hushot_ads_rotate_products', array(__CLASS__, 'rotate_products'));
    }
    
    /**
     * Create database tables
     */
    public static function create_tables() {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        
        // Campaigns table
        dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}hushot_ads_campaigns (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            campaign_name varchar(255) NOT NULL,
            campaign_type varchar(50) DEFAULT 'carousel',
            country varchar(5) NOT NULL,
            state varchar(100) DEFAULT NULL,
            category varchar(50) DEFAULT NULL,
            meta_campaign_id varchar(100) DEFAULT NULL,
            meta_adset_id varchar(100) DEFAULT NULL,
            daily_budget decimal(10,2) DEFAULT 0,
            total_spent decimal(10,2) DEFAULT 0,
            status varchar(20) DEFAULT 'active',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY country (country),
            KEY status (status)
        ) $charset;");
        
        // Campaign products mapping
        dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}hushot_ads_campaign_products (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            campaign_id bigint(20) NOT NULL,
            product_id bigint(20) NOT NULL,
            weight decimal(5,2) DEFAULT 1.00,
            rotation_order int DEFAULT 0,
            added_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY campaign_id (campaign_id),
            KEY product_id (product_id),
            UNIQUE KEY campaign_product (campaign_id, product_id)
        ) $charset;");
    }
    
    /**
     * Get or create campaign for country/category
     */
    public static function get_or_create_campaign($country, $state = null, $category = null) {
        global $wpdb;
        
        // Build campaign name
        $country_name = Hushot_Ads::$countries[$country]['name'] ?? $country;
        $campaign_name = "Hushot - {$country_name}";
        if ($state) $campaign_name .= " - {$state}";
        if ($category) $campaign_name .= " - " . (Hushot_Ads::$categories[$category] ?? $category);
        
        // Check if campaign exists
        $where = "country = %s";
        $params = array($country);
        
        if ($state) {
            $where .= " AND state = %s";
            $params[] = $state;
        } else {
            $where .= " AND state IS NULL";
        }
        
        if ($category) {
            $where .= " AND category = %s";
            $params[] = $category;
        } else {
            $where .= " AND category IS NULL";
        }
        
        $campaign = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}hushot_ads_campaigns WHERE {$where} AND status = 'active' LIMIT 1",
            ...$params
        ));
        
        if ($campaign) {
            return $campaign;
        }
        
        // Create new campaign
        $wpdb->insert($wpdb->prefix . 'hushot_ads_campaigns', array(
            'campaign_name' => $campaign_name,
            'campaign_type' => 'carousel',
            'country' => $country,
            'state' => $state,
            'category' => $category,
            'status' => 'active'
        ));
        
        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}hushot_ads_campaigns WHERE id = %d",
            $wpdb->insert_id
        ));
    }
    
    /**
     * Add product to campaign
     */
    public static function add_product_to_campaign($campaign_id, $product_id, $weight = 1.0) {
        global $wpdb;
        
        // Get current max order
        $max_order = $wpdb->get_var($wpdb->prepare(
            "SELECT MAX(rotation_order) FROM {$wpdb->prefix}hushot_ads_campaign_products WHERE campaign_id = %d",
            $campaign_id
        )) ?: 0;
        
        // Insert or update
        $wpdb->replace($wpdb->prefix . 'hushot_ads_campaign_products', array(
            'campaign_id' => $campaign_id,
            'product_id' => $product_id,
            'weight' => $weight,
            'rotation_order' => $max_order + 1
        ));
        
        return true;
    }
    
    /**
     * Remove product from campaign
     */
    public static function remove_product_from_campaign($campaign_id, $product_id) {
        global $wpdb;
        
        return $wpdb->delete($wpdb->prefix . 'hushot_ads_campaign_products', array(
            'campaign_id' => $campaign_id,
            'product_id' => $product_id
        ));
    }
    
    /**
     * Get products for a campaign
     */
    public static function get_campaign_products($campaign_id, $limit = 10) {
        global $wpdb;
        
        return $wpdb->get_results($wpdb->prepare(
            "SELECT p.*, cp.weight, cp.rotation_order 
             FROM {$wpdb->prefix}hushot_ads_catalog p
             INNER JOIN {$wpdb->prefix}hushot_ads_campaign_products cp ON p.id = cp.product_id
             WHERE cp.campaign_id = %d AND p.status = 'active'
             ORDER BY cp.rotation_order ASC
             LIMIT %d",
            $campaign_id, $limit
        ));
    }
    
    /**
     * Get all active campaigns
     */
    public static function get_active_campaigns() {
        global $wpdb;
        
        return $wpdb->get_results(
            "SELECT c.*, COUNT(cp.id) as product_count 
             FROM {$wpdb->prefix}hushot_ads_campaigns c
             LEFT JOIN {$wpdb->prefix}hushot_ads_campaign_products cp ON c.id = cp.campaign_id
             WHERE c.status = 'active'
             GROUP BY c.id
             ORDER BY c.country, c.state, c.category"
        );
    }
    
    /**
     * Rotate products in campaigns (weighted rotation)
     */
    public static function rotate_products() {
        global $wpdb;
        
        $campaigns = self::get_active_campaigns();
        
        foreach ($campaigns as $campaign) {
            // Get products with their budget weights
            $products = $wpdb->get_results($wpdb->prepare(
                "SELECT p.id, p.daily_budget, p.spent, p.total_budget
                 FROM {$wpdb->prefix}hushot_ads_catalog p
                 INNER JOIN {$wpdb->prefix}hushot_ads_campaign_products cp ON p.id = cp.product_id
                 WHERE cp.campaign_id = %d AND p.status = 'active'
                 AND (p.end_date IS NULL OR p.end_date > NOW())
                 AND (p.total_budget = 0 OR p.spent < p.total_budget)",
                $campaign->id
            ));
            
            if (empty($products)) continue;
            
            // Calculate total budget weight
            $total_weight = 0;
            foreach ($products as $product) {
                $remaining = $product->total_budget - $product->spent;
                $weight = min($product->daily_budget, $remaining);
                $total_weight += max($weight, 1);
            }
            
            // Update rotation weights proportionally
            $order = 0;
            foreach ($products as $product) {
                $remaining = $product->total_budget - $product->spent;
                $weight = min($product->daily_budget, $remaining);
                $normalized_weight = ($weight / $total_weight) * 10; // Scale to 0-10
                
                $wpdb->update(
                    $wpdb->prefix . 'hushot_ads_campaign_products',
                    array(
                        'weight' => round($normalized_weight, 2),
                        'rotation_order' => $order++
                    ),
                    array(
                        'campaign_id' => $campaign->id,
                        'product_id' => $product->id
                    )
                );
            }
        }
    }
    
    /**
     * Calculate daily budget allocation across products
     */
    public static function allocate_budget($campaign_id, $total_daily_budget) {
        global $wpdb;
        
        $products = self::get_campaign_products($campaign_id);
        
        if (empty($products)) return array();
        
        $total_weight = array_sum(array_column($products, 'weight'));
        $allocations = array();
        
        foreach ($products as $product) {
            $share = ($product->weight / $total_weight) * $total_daily_budget;
            
            // Don't exceed product's daily budget
            $share = min($share, $product->daily_budget);
            
            // Don't exceed remaining budget
            $remaining = $product->total_budget - $product->spent;
            $share = min($share, $remaining);
            
            $allocations[$product->id] = round($share, 2);
        }
        
        return $allocations;
    }
    
    /**
     * Sync product to appropriate campaigns when activated
     */
    public static function sync_product_to_campaigns($product_id) {
        global $wpdb;
        
        $product = Hushot_Ads_Catalog::get_product($product_id);
        if (!$product || $product->status !== 'active') return;
        
        // Get or create primary campaign for product's country
        $campaign = self::get_or_create_campaign($product->country, $product->state);
        self::add_product_to_campaign($campaign->id, $product_id, 1.0);
        
        // Handle additional countries
        if ($product->additional_countries) {
            $countries = json_decode($product->additional_countries, true);
            if (is_array($countries)) {
                foreach ($countries as $country) {
                    $extra_campaign = self::get_or_create_campaign($country);
                    self::add_product_to_campaign($extra_campaign->id, $product_id, 0.5); // Lower weight for secondary
                }
            }
        }
    }
    
    /**
     * Remove product from all campaigns when paused/rejected
     */
    public static function remove_product_from_all_campaigns($product_id) {
        global $wpdb;
        
        return $wpdb->delete($wpdb->prefix . 'hushot_ads_campaign_products', array(
            'product_id' => $product_id
        ));
    }
    
    /**
     * Get campaign statistics
     */
    public static function get_campaign_stats($campaign_id) {
        global $wpdb;
        
        return $wpdb->get_row($wpdb->prepare(
            "SELECT 
                COUNT(DISTINCT cp.product_id) as products,
                SUM(p.impressions) as impressions,
                SUM(p.clicks) as clicks,
                SUM(p.landing_page_views) as landing_page_views,
                SUM(p.spent) as spent,
                SUM(p.daily_budget) as daily_budget
             FROM {$wpdb->prefix}hushot_ads_campaign_products cp
             INNER JOIN {$wpdb->prefix}hushot_ads_catalog p ON cp.product_id = p.id
             WHERE cp.campaign_id = %d AND p.status = 'active'",
            $campaign_id
        ));
    }
    
    /**
     * Admin campaigns page
     */
    public static function admin_campaigns_page() {
        $campaigns = self::get_active_campaigns();
        ?>
        <div style="background:#fff;padding:20px;border-radius:8px;">
            <h2 style="margin:0 0 20px;">Active Campaigns</h2>
            
            <p style="color:#666;margin-bottom:20px;">
                Campaigns are automatically created and managed based on product geo-targeting.
                Products from multiple users share campaigns for cost efficiency.
            </p>
            
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>Campaign</th>
                        <th>Country</th>
                        <th>State</th>
                        <th>Products</th>
                        <th>Impressions</th>
                        <th>Clicks</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($campaigns as $campaign): 
                        $stats = self::get_campaign_stats($campaign->id);
                    ?>
                    <tr>
                        <td>
                            <strong><?php echo esc_html($campaign->campaign_name); ?></strong>
                            <?php if ($campaign->meta_campaign_id): ?>
                            <br><small>Meta ID: <?php echo esc_html($campaign->meta_campaign_id); ?></small>
                            <?php endif; ?>
                        </td>
                        <td><?php echo Hushot_Ads::$countries[$campaign->country]['name'] ?? $campaign->country; ?></td>
                        <td><?php echo $campaign->state ?: '-'; ?></td>
                        <td><?php echo $campaign->product_count; ?></td>
                        <td><?php echo number_format($stats->impressions ?? 0); ?></td>
                        <td><?php echo number_format($stats->clicks ?? 0); ?></td>
                        <td>
                            <span style="background:#10b981;color:#fff;padding:3px 8px;border-radius:12px;font-size:11px;">
                                <?php echo ucfirst($campaign->status); ?>
                            </span>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    
                    <?php if (empty($campaigns)): ?>
                    <tr>
                        <td colspan="7" style="text-align:center;padding:40px;color:#888;">
                            No active campaigns yet. Campaigns are created automatically when products are approved.
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
            
            <div style="margin-top:30px;padding:20px;background:#f8fafc;border-radius:8px;">
                <h3 style="margin:0 0 15px;">Campaign Strategy</h3>
                <ul style="margin:0;padding-left:20px;color:#666;">
                    <li><strong>Country Isolation:</strong> Each country has its own campaign to ensure geo-accuracy</li>
                    <li><strong>Shared Carousel:</strong> Multiple user products appear in the same carousel for cost efficiency</li>
                    <li><strong>Budget Weighting:</strong> Products with higher budgets get more rotation</li>
                    <li><strong>One URL per Card:</strong> Each carousel card links ONLY to the product owner's landing page</li>
                </ul>
            </div>
        </div>
        <?php
    }
}
