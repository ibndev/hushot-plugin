<?php
/**
 * Hushot Ads Network - User Dashboard v2.2
 * Clean, mobile-first design with simplified boost flow
 */

if (!defined('ABSPATH')) exit;

class Hushot_Ads_Dashboard {
    
    // HARDCODED DEFAULT RATES - These ALWAYS work
    const DEFAULT_RATE_1WEEK = 15;
    const DEFAULT_RATE_1MONTH = 50;
    const DEFAULT_RATE_3MONTHS = 120;
    const DEFAULT_FEE_1WEEK = 2;
    const DEFAULT_FEE_1MONTH = 5;
    const DEFAULT_FEE_3MONTHS = 10;
    const DEFAULT_EXCHANGE_RATE = 1600;
    
    public static function init() {
        // Dashboard hooks
    }
    
    /**
     * Get user's currency info based on location - RELIABLE VERSION
     */
    public static function get_user_currency() {
        // Fixed exchange rates - always reliable
        $currencies = array(
            'NG' => array('code' => 'NGN', 'symbol' => '₦', 'rate' => 1600),
            'GH' => array('code' => 'GHS', 'symbol' => '₵', 'rate' => 15.5),
            'KE' => array('code' => 'KES', 'symbol' => 'KSh', 'rate' => 153),
            'ZA' => array('code' => 'ZAR', 'symbol' => 'R', 'rate' => 18.5),
            'TZ' => array('code' => 'TZS', 'symbol' => 'TSh', 'rate' => 2650),
            'UG' => array('code' => 'UGX', 'symbol' => 'USh', 'rate' => 3800),
            'EG' => array('code' => 'EGP', 'symbol' => '£E', 'rate' => 50),
            'US' => array('code' => 'USD', 'symbol' => '$', 'rate' => 1),
            'GB' => array('code' => 'GBP', 'symbol' => '£', 'rate' => 0.79),
        );
        
        // Default to Nigeria
        $country = 'NG';
        
        // Try to detect country
        if (class_exists('Hushot_Flutterwave') && method_exists('Hushot_Flutterwave', 'detect_user_country')) {
            $detected = Hushot_Flutterwave::detect_user_country();
            if (!empty($detected) && isset($currencies[$detected])) {
                $country = $detected;
            }
        }
        
        // Return currency for detected country
        return $currencies[$country];
    }
    
    /**
     * Format price in user's currency - compact format for large numbers
     */
    public static function format_price($usd_amount, $compact = false) {
        $currency = self::get_user_currency();
        $local_amount = floatval($usd_amount) * $currency['rate'];
        
        if ($compact && $local_amount >= 1000000) {
            return $currency['symbol'] . number_format($local_amount / 1000000, 1) . 'M';
        } elseif ($compact && $local_amount >= 1000) {
            return $currency['symbol'] . number_format($local_amount / 1000, 1) . 'K';
        }
        
        return $currency['symbol'] . number_format($local_amount, 0);
    }
    
    /**
     * Get fixed ad rates from admin settings
     */
    public static function get_ad_rates() {
        $currency = self::get_user_currency();
        
        // Get admin values with defaults
        $rate_1week = floatval(get_option('hushot_ads_rate_1week', self::DEFAULT_RATE_1WEEK));
        $rate_1month = floatval(get_option('hushot_ads_rate_1month', self::DEFAULT_RATE_1MONTH));
        $rate_3months = floatval(get_option('hushot_ads_rate_3months', self::DEFAULT_RATE_3MONTHS));
        $fee_1week = floatval(get_option('hushot_ads_fee_1week', self::DEFAULT_FEE_1WEEK));
        $fee_1month = floatval(get_option('hushot_ads_fee_1month', self::DEFAULT_FEE_1MONTH));
        $fee_3months = floatval(get_option('hushot_ads_fee_3months', self::DEFAULT_FEE_3MONTHS));
        
        // Use defaults if values are 0
        if ($rate_1week <= 0) $rate_1week = self::DEFAULT_RATE_1WEEK;
        if ($rate_1month <= 0) $rate_1month = self::DEFAULT_RATE_1MONTH;
        if ($rate_3months <= 0) $rate_3months = self::DEFAULT_RATE_3MONTHS;
        if ($fee_1week <= 0) $fee_1week = self::DEFAULT_FEE_1WEEK;
        if ($fee_1month <= 0) $fee_1month = self::DEFAULT_FEE_1MONTH;
        if ($fee_3months <= 0) $fee_3months = self::DEFAULT_FEE_3MONTHS;
        
        // Calculate totals
        $total_1week = $rate_1week + $fee_1week;
        $total_1month = $rate_1month + $fee_1month;
        $total_3months = $rate_3months + $fee_3months;
        
        // Get currency values directly
        $exchange_rate = $currency['rate'];
        $symbol = $currency['symbol'];
        $code = $currency['code'];
        
        // Calculate local prices
        $local_1week = round($total_1week * $exchange_rate);
        $local_1month = round($total_1month * $exchange_rate);
        $local_3months = round($total_3months * $exchange_rate);
        
        return array(
            '1week' => array(
                'label' => '1 Week',
                'days' => 7,
                'price_usd' => $rate_1week,
                'fee_usd' => $fee_1week,
                'total_usd' => $total_1week,
                'price_local' => $local_1week,
                'symbol' => $symbol,
                'currency_code' => $code
            ),
            '1month' => array(
                'label' => '1 Month',
                'days' => 30,
                'price_usd' => $rate_1month,
                'fee_usd' => $fee_1month,
                'total_usd' => $total_1month,
                'price_local' => $local_1month,
                'symbol' => $symbol,
                'currency_code' => $code
            ),
            '3months' => array(
                'label' => '3 Months',
                'days' => 90,
                'price_usd' => $rate_3months,
                'fee_usd' => $fee_3months,
                'total_usd' => $total_3months,
                'price_local' => $local_3months,
                'symbol' => $symbol,
                'currency_code' => $code
            ),
        );
    }
    
    /**
     * Render user dashboard - Clean Full Width Design
     */
    public static function render_user_dashboard() {
        if (!is_user_logged_in()) {
            return '<p style="padding:40px 20px;text-align:center;">Please log in to view your ads dashboard.</p>';
        }
        
        $user_id = get_current_user_id();
        
        if (!Hushot_Ads::has_access($user_id)) {
            return self::render_upgrade_prompt();
        }
        
        $all_products = Hushot_Ads_Catalog::get_user_products($user_id);
        // Filter out pending_payment products (not yet paid)
        $products = array_filter($all_products, function($p) {
            return $p->status !== 'pending_payment';
        });
        $currency = self::get_user_currency();
        $rates = self::get_ad_rates();
        $is_admin = current_user_can('manage_options');
        
        // Get user's pages
        $pages = get_posts(array(
            'post_type' => 'hushot_page',
            'author' => $user_id,
            'posts_per_page' => -1,
            'post_status' => array('publish', 'draft'),
            'orderby' => 'date',
            'order' => 'DESC'
        ));
        
        ob_start();
        ?>
        <style>
        .ads-wrap{width:100%;padding:0 16px 80px;}
        
        /* Admin Notice */
        .ads-admin-notice{background:linear-gradient(135deg,#fef3c7,#fde68a);border:1px solid #f59e0b;border-radius:12px;padding:16px 20px;margin-bottom:20px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;}
        .ads-admin-notice p{margin:0;font-size:14px;color:#92400e;}
        .ads-admin-notice a{background:#f59e0b;color:#fff;padding:10px 20px;border-radius:8px;text-decoration:none;font-weight:600;font-size:13px;white-space:nowrap;}
        .ads-admin-notice a:hover{background:#d97706;}
        
        /* Stats */
        .ads-stats{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:24px;}
        .ads-stat{background:#fff;padding:20px 16px;border-radius:16px;text-align:center;box-shadow:0 2px 12px rgba(0,0,0,0.06);}
        .ads-stat-value{font-size:24px;font-weight:800;color:#1a1a2e;line-height:1;}
        .ads-stat-label{font-size:11px;color:#888;text-transform:uppercase;letter-spacing:0.5px;margin-top:6px;}
        .ads-stat.green .ads-stat-value{color:#10b981;}
        .ads-stat.blue .ads-stat-value{color:#3b82f6;}
        .ads-stat.purple .ads-stat-value{color:#8b5cf6;}
        .ads-stat.orange .ads-stat-value{color:#f59e0b;}
        
        /* Sections */
        .ads-section{background:#fff;border-radius:20px;padding:24px;margin-bottom:20px;box-shadow:0 2px 12px rgba(0,0,0,0.06);}
        .ads-section-head{display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;flex-wrap:wrap;gap:12px;}
        .ads-section-head h3{margin:0;font-size:18px;font-weight:700;color:#1a1a2e;}
        
        /* Buttons */
        .ads-btn{display:inline-flex;align-items:center;gap:8px;padding:12px 24px;background:linear-gradient(135deg,#667eea,#764ba2);color:#fff!important;font-weight:600;border-radius:12px;text-decoration:none;font-size:14px;border:none;cursor:pointer;white-space:nowrap;}
        .ads-btn:hover{opacity:0.9;transform:translateY(-1px);}
        .ads-btn-sm{padding:8px 16px;font-size:13px;border-radius:10px;}
        
        /* Empty State */
        .ads-empty{text-align:center;padding:48px 20px;}
        .ads-empty-icon{font-size:64px;margin-bottom:16px;}
        .ads-empty h4{margin:0 0 8px;font-size:18px;color:#1a1a2e;}
        .ads-empty p{margin:0 0 20px;color:#888;font-size:14px;}
        
        /* Page Cards */
        .ads-pages{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:16px;}
        .ads-page-card{border:2px solid #e5e7eb;border-radius:16px;overflow:hidden;transition:all 0.2s;background:#fff;}
        .ads-page-card:hover{border-color:#667eea;box-shadow:0 8px 24px rgba(102,126,234,0.15);}
        .ads-page-card-img{height:120px;background:#f5f5f5;position:relative;overflow:hidden;}
        .ads-page-card-img img{width:100%;height:100%;object-fit:cover;}
        .ads-page-card-img .placeholder{display:flex;align-items:center;justify-content:center;height:100%;font-size:40px;background:linear-gradient(135deg,#f5f5f5,#e5e5e5);}
        .ads-page-card-body{padding:16px;}
        .ads-page-card-title{font-weight:700;font-size:15px;margin:0 0 4px;color:#1a1a2e;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
        .ads-page-card-meta{font-size:12px;color:#888;display:flex;gap:12px;align-items:center;}
        .ads-page-card-meta .status{padding:2px 8px;border-radius:4px;font-size:10px;font-weight:600;}
        .ads-page-card-meta .status.pub{background:#d1fae5;color:#065f46;}
        .ads-page-card-meta .status.draft{background:#fef3c7;color:#92400e;}
        .ads-page-card-action{padding:12px 16px;border-top:1px solid #f1f5f9;background:#fafafa;}
        .ads-page-card-action .ads-btn{width:100%;justify-content:center;}
        
        /* Campaign List - Mobile First */
        .ads-list{display:flex;flex-direction:column;gap:12px;}
        .ads-item{background:#fff;border-radius:16px;padding:16px;box-shadow:0 2px 8px rgba(0,0,0,0.06);}
        .ads-item-top{display:flex;align-items:center;gap:12px;margin-bottom:12px;}
        .ads-item-img{width:48px;height:48px;border-radius:10px;overflow:hidden;flex-shrink:0;background:#f1f5f9;}
        .ads-item-img img{width:100%;height:100%;object-fit:cover;}
        .ads-item-info{flex:1;min-width:0;}
        .ads-item-name{font-weight:600;font-size:14px;color:#1a1a2e;margin-bottom:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
        .ads-item-meta{font-size:12px;color:#64748b;}
        .ads-item-stats{display:none;gap:12px;font-size:11px;color:#64748b;margin-bottom:12px;}
        .ads-item-stats span{display:flex;align-items:center;gap:4px;}
        
        /* Action Buttons - 3 pill badges matching screenshot */
        .ads-item-actions{display:flex;flex-wrap:wrap;gap:8px;}
        .ads-action-badge{display:inline-flex;align-items:center;gap:6px;padding:6px 14px;border-radius:20px;font-size:12px;font-weight:600;text-transform:uppercase;letter-spacing:0.3px;border:none;cursor:pointer;text-decoration:none;transition:all 0.2s;}
        .ads-action-badge.active{background:#d1fae5;color:#065f46;cursor:default;}
        .ads-action-badge.paused{background:#e5e7eb;color:#374151;cursor:default;}
        .ads-action-badge.pending{background:#fef3c7;color:#92400e;cursor:default;}
        .ads-action-badge.pause{background:#fef3c7;color:#92400e;}
        .ads-action-badge.pause:hover{background:#fde68a;}
        .ads-action-badge.delete{background:#fee2e2;color:#991b1b;}
        .ads-action-badge.delete:hover{background:#fecaca;}
        
        /* Custom Modal */
        .ads-modal-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,0.5);z-index:9999;align-items:center;justify-content:center;padding:20px;}
        .ads-modal-overlay.show{display:flex;}
        .ads-modal{background:#fff;border-radius:20px;width:100%;max-width:340px;padding:24px;text-align:center;box-shadow:0 20px 60px rgba(0,0,0,0.3);animation:modalIn 0.2s ease;}
        @keyframes modalIn{from{opacity:0;transform:scale(0.95);}to{opacity:1;transform:scale(1);}}
        .ads-modal-icon{font-size:48px;margin-bottom:16px;}
        .ads-modal-title{font-size:18px;font-weight:700;color:#1a1a2e;margin-bottom:8px;}
        .ads-modal-text{font-size:14px;color:#64748b;margin-bottom:24px;line-height:1.5;}
        .ads-modal-btns{display:grid;grid-template-columns:1fr 1fr;gap:12px;}
        .ads-modal-btn{padding:12px 16px;border-radius:10px;font-size:14px;font-weight:600;border:none;cursor:pointer;transition:all 0.2s;}
        .ads-modal-btn.cancel{background:#f1f5f9;color:#64748b;}
        .ads-modal-btn.cancel:hover{background:#e2e8f0;}
        .ads-modal-btn.danger{background:#ef4444;color:#fff;}
        .ads-modal-btn.danger:hover{background:#dc2626;}
        .ads-modal-btn.warning{background:#f59e0b;color:#fff;}
        .ads-modal-btn.warning:hover{background:#d97706;}
        
        /* FIXED: Pricing Cards - responsive and accommodate any price */
        .ads-pricing-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;}
        .ads-pricing-card{text-align:center;padding:20px 12px;background:linear-gradient(135deg,#f8fafc,#f1f5f9);border-radius:16px;border:2px solid #e5e7eb;}
        .ads-pricing-card-price{font-size:18px;font-weight:800;color:#667eea;word-break:break-word;line-height:1.2;}
        .ads-pricing-card-label{font-size:12px;color:#666;margin-top:6px;}
        
        @media(min-width:640px){
            .ads-item{display:flex;align-items:center;gap:16px;padding:16px 20px;}
            .ads-item-top{margin-bottom:0;flex:1;}
            .ads-item-stats{display:flex;margin-bottom:0;}
        }
        @media(max-width:768px){
            .ads-stats{grid-template-columns:repeat(2,1fr);}
            .ads-stat{padding:16px 12px;}
            .ads-stat-value{font-size:20px;}
            .ads-pages{grid-template-columns:1fr;}
            .ads-pricing-grid{grid-template-columns:repeat(3,1fr);gap:8px;}
            .ads-pricing-card{padding:16px 8px;}
            .ads-pricing-card-price{font-size:14px;}
        }
        @media(max-width:480px){
            .ads-wrap{padding:0 12px 60px;}
            .ads-section{padding:16px;border-radius:16px;}
            .ads-pricing-card-price{font-size:13px;}
            .ads-pricing-card-label{font-size:11px;}
        }
        </style>
        
        <div class="ads-wrap">
            <?php if ($is_admin): ?>
            <div class="ads-admin-notice">
                <p>⚙️ <strong>Admin:</strong> Set boost pricing in WordPress Admin → Hushot → Ads Network → Settings tab</p>
                <a href="<?php echo admin_url('admin.php?page=hushot-ads&tab=settings'); ?>" target="_blank">Open Settings</a>
            </div>
            <?php endif; ?>
            
            <?php
            // Calculate totals
            $total_impressions = 0;
            $total_clicks = 0;
            $total_lpv = 0;
            $total_spent = 0;
            $active_count = 0;
            
            if (!empty($products)) {
                foreach ($products as $p) {
                    $total_impressions += $p->impressions;
                    $total_clicks += $p->clicks;
                    $total_lpv += $p->landing_page_views;
                    $total_spent += $p->spent;
                    if ($p->status === 'active') $active_count++;
                }
            }
            ?>
            
            <div class="ads-stats">
                <div class="ads-stat green">
                    <div class="ads-stat-value"><?php echo $active_count; ?></div>
                    <div class="ads-stat-label">Active</div>
                </div>
                <div class="ads-stat blue">
                    <div class="ads-stat-value"><?php echo number_format($total_impressions); ?></div>
                    <div class="ads-stat-label">Impressions</div>
                </div>
                <div class="ads-stat purple">
                    <div class="ads-stat-value"><?php echo number_format($total_lpv); ?></div>
                    <div class="ads-stat-label">Page Views</div>
                </div>
                <div class="ads-stat orange">
                    <div class="ads-stat-value"><?php echo self::format_price($total_spent, true); ?></div>
                    <div class="ads-stat-label">Spent</div>
                </div>
            </div>
            
            <!-- SECTION 2: Active Campaigns (moved up) -->
            <?php if (!empty($products)): ?>
            <div class="ads-section">
                <div class="ads-section-head">
                    <h3>📊 Active Campaigns</h3>
                </div>
                <div class="ads-list">
                    <?php foreach ($products as $product): 
                        $ctr = $product->impressions > 0 ? round(($product->clicks / $product->impressions) * 100, 1) : 0;
                        $status_lower = strtolower($product->status);
                    ?>
                    <div class="ads-item" data-product-id="<?php echo $product->id; ?>">
                        <div class="ads-item-top">
                            <div class="ads-item-img">
                                <?php if ($product->product_image_url): ?>
                                <img src="<?php echo esc_url($product->product_image_url); ?>" alt="">
                                <?php endif; ?>
                            </div>
                            <div class="ads-item-info">
                                <div class="ads-item-name"><?php echo esc_html($product->product_name); ?></div>
                                <div class="ads-item-meta">
                                    <?php echo Hushot_Ads::$countries[$product->country]['name'] ?? $product->country; ?>
                                    • <?php echo self::format_price($product->total_budget, true); ?>
                                </div>
                            </div>
                        </div>
                        <div class="ads-item-stats">
                            <span>👁️ <?php echo number_format($product->impressions); ?></span>
                            <span>🖱️ <?php echo number_format($product->clicks); ?></span>
                            <span>📊 <?php echo $ctr; ?>%</span>
                        </div>
                        <div class="ads-item-actions">
                            <span class="ads-action-badge <?php echo $status_lower; ?>">
                                <?php if ($status_lower === 'active'): ?>● <?php endif; ?><?php echo ucfirst($product->status); ?>
                            </span>
                            <?php if ($product->status === 'active'): ?>
                            <button class="ads-action-badge pause" onclick="showAdsModal('pause',<?php echo $product->id; ?>,'<?php echo esc_js($product->product_name); ?>')">Pause</button>
                            <?php else: ?>
                            <button class="ads-action-badge pause" onclick="showAdsModal('resume',<?php echo $product->id; ?>,'<?php echo esc_js($product->product_name); ?>')">Resume</button>
                            <?php endif; ?>
                            <button class="ads-action-badge delete" onclick="showAdsModal('delete',<?php echo $product->id; ?>,'<?php echo esc_js($product->product_name); ?>')">Delete</button>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>
            
            <!-- SECTION 3: Landing Pages to Boost (moved down) -->
            <div class="ads-section">
                <div class="ads-section-head">
                    <h3>🚀 Boost a Landing Page</h3>
                </div>
                
                <?php if (empty($pages)): ?>
                <div class="ads-empty">
                    <div class="ads-empty-icon">📄</div>
                    <h4>No Landing Pages Yet</h4>
                    <p>Create a landing page first to start boosting</p>
                    <a href="<?php echo esc_url(Hushot_Pages::get_page_url('create-page')); ?>" class="ads-btn">+ Create Page</a>
                </div>
                <?php else: ?>
                <div class="ads-pages">
                    <?php foreach ($pages as $pg): 
                        $img_url = get_post_meta($pg->ID, '_hushot_image_url', true);
                        $logo_url = get_post_meta($pg->ID, '_hushot_logo_url', true);
                        $display_img = $img_url ?: $logo_url;
                        $views = intval(get_post_meta($pg->ID, '_hushot_views', true));
                    ?>
                    <div class="ads-page-card">
                        <div class="ads-page-card-img">
                            <?php if ($display_img): ?>
                            <img src="<?php echo esc_url($display_img); ?>" alt="">
                            <?php else: ?>
                            <div class="placeholder">📄</div>
                            <?php endif; ?>
                        </div>
                        <div class="ads-page-card-body">
                            <div class="ads-page-card-title"><?php echo esc_html($pg->post_title); ?></div>
                            <div class="ads-page-card-meta">
                                <span class="status <?php echo $pg->post_status === 'publish' ? 'pub' : 'draft'; ?>">
                                    <?php echo $pg->post_status === 'publish' ? 'Live' : 'Draft'; ?>
                                </span>
                                <span>👁️ <?php echo number_format($views); ?> views</span>
                            </div>
                        </div>
                        <div class="ads-page-card-action">
                            <a href="<?php echo esc_url(add_query_arg('page_id', $pg->ID, Hushot_Pages::get_page_url('ads-promote'))); ?>" class="ads-btn ads-btn-sm">🚀 Boost This Page</a>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>
            
            <!-- Pricing Info -->
            <div class="ads-section">
                <div class="ads-section-head">
                    <h3>💰 Boost Pricing</h3>
                </div>
                <div class="ads-pricing-grid">
                    <?php foreach ($rates as $key => $rate): ?>
                    <div class="ads-pricing-card">
                        <div class="ads-pricing-card-price"><?php echo $rate['symbol'] . number_format($rate['price_local']); ?></div>
                        <div class="ads-pricing-card-label"><?php echo $rate['label']; ?></div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        
        <!-- Custom Modal for Actions -->
        <div class="ads-modal-overlay" id="ads-modal">
            <div class="ads-modal">
                <div class="ads-modal-icon" id="modal-icon">⚠️</div>
                <div class="ads-modal-title" id="modal-title">Confirm Action</div>
                <div class="ads-modal-text" id="modal-text">Are you sure?</div>
                <div class="ads-modal-btns">
                    <button class="ads-modal-btn cancel" onclick="closeAdsModal()">Cancel</button>
                    <button class="ads-modal-btn danger" id="modal-confirm" onclick="confirmAdsAction()">Confirm</button>
                </div>
            </div>
        </div>
        
        <script>
        var pendingAction = null;
        var pendingProductId = null;
        
        function showAdsModal(action, productId, productName) {
            pendingAction = action;
            pendingProductId = productId;
            
            var modal = document.getElementById('ads-modal');
            var icon = document.getElementById('modal-icon');
            var title = document.getElementById('modal-title');
            var text = document.getElementById('modal-text');
            var btn = document.getElementById('modal-confirm');
            
            if (action === 'delete') {
                icon.textContent = '🗑️';
                title.textContent = 'Delete Campaign';
                text.textContent = 'Delete "' + productName + '"? This action cannot be undone.';
                btn.className = 'ads-modal-btn danger';
                btn.textContent = 'Delete';
            } else if (action === 'pause') {
                icon.textContent = '⏸️';
                title.textContent = 'Pause Campaign';
                text.textContent = 'Pause "' + productName + '"? You can resume it anytime.';
                btn.className = 'ads-modal-btn warning';
                btn.textContent = 'Pause';
            } else {
                icon.textContent = '▶️';
                title.textContent = 'Resume Campaign';
                text.textContent = 'Resume "' + productName + '"?';
                btn.className = 'ads-modal-btn warning';
                btn.textContent = 'Resume';
            }
            
            modal.classList.add('show');
        }
        
        function closeAdsModal() {
            document.getElementById('ads-modal').classList.remove('show');
            pendingAction = null;
            pendingProductId = null;
        }
        
        function confirmAdsAction() {
            if (!pendingAction || !pendingProductId) return;
            
            var btn = document.getElementById('modal-confirm');
            btn.textContent = 'Processing...';
            btn.disabled = true;
            
            var formData = new FormData();
            formData.append('action', 'hushot_ads_campaign_action');
            formData.append('campaign_action', pendingAction);
            formData.append('product_id', pendingProductId);
            formData.append('nonce', '<?php echo wp_create_nonce('hushot_ads_action'); ?>');
            
            fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                method: 'POST',
                body: formData
            })
            .then(function(r) { return r.json(); })
            .then(function(data) {
                if (data.success) {
                    window.location.reload();
                } else {
                    closeAdsModal();
                    showErrorModal(data.data?.message || 'Action failed');
                }
            })
            .catch(function() {
                closeAdsModal();
                showErrorModal('Connection error. Please try again.');
            });
        }
        
        function showErrorModal(message) {
            var icon = document.getElementById('modal-icon');
            var title = document.getElementById('modal-title');
            var text = document.getElementById('modal-text');
            var btn = document.getElementById('modal-confirm');
            
            icon.textContent = '❌';
            title.textContent = 'Error';
            text.textContent = message;
            btn.style.display = 'none';
            document.querySelector('.ads-modal-btn.cancel').textContent = 'OK';
            document.getElementById('ads-modal').classList.add('show');
        }
        
        // Close modal on overlay click
        document.getElementById('ads-modal').addEventListener('click', function(e) {
            if (e.target === this) closeAdsModal();
        });
        </script>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Render simplified promotion form
     */
    public static function render_promotion_form($page_id = null) {
        if (!is_user_logged_in()) {
            return '<p style="padding:40px;text-align:center;">Please log in.</p>';
        }
        
        $user_id = get_current_user_id();
        
        if (!Hushot_Ads::has_access($user_id)) {
            return self::render_upgrade_prompt();
        }
        
        // Get user's landing pages
        $pages = get_posts(array(
            'post_type' => 'hushot_page',
            'author' => $user_id,
            'posts_per_page' => -1,
            'post_status' => array('publish', 'draft'),
            'orderby' => 'date',
            'order' => 'DESC'
        ));
        
        if (empty($pages)) {
            return '<div style="max-width:400px;margin:40px auto;text-align:center;padding:48px 20px;">
                <div style="font-size:64px;margin-bottom:16px;">📄</div>
                <h3 style="margin:0 0 8px;font-size:18px;">No Landing Pages</h3>
                <p style="color:#888;margin-bottom:20px;">Create a landing page first</p>
                <a href="' . esc_url(Hushot_Pages::get_page_url('create-page')) . '" style="display:inline-block;padding:14px 28px;background:linear-gradient(135deg,#667eea,#764ba2);color:#fff;font-weight:600;border-radius:12px;text-decoration:none;">Create Page</a>
            </div>';
        }
        
        // Get selected page data
        $page = null;
        $page_data = array();
        if ($page_id) {
            $page = get_post($page_id);
            if ($page && $page->post_author == $user_id) {
                $page_data = array(
                    'title' => $page->post_title,
                    'business_name' => get_post_meta($page_id, '_hushot_business_name', true),
                    'image_url' => get_post_meta($page_id, '_hushot_image_url', true),
                    'logo_url' => get_post_meta($page_id, '_hushot_logo_url', true),
                );
            } else {
                $page_id = 0;
            }
        }
        
        $currency = self::get_user_currency();
        $rates = self::get_ad_rates();
        $countries = Hushot_Ads::$countries;
        
        ob_start();
        ?>
        <style>
        .boost-wrap{width:100%;max-width:600px;margin:0 auto;padding:0 16px 80px;}
        .boost-subtext{text-align:center;color:#888;font-size:14px;margin-bottom:24px;padding:0 16px;}
        
        .boost-card{background:#fff;border-radius:20px;padding:24px;box-shadow:0 4px 20px rgba(0,0,0,0.08);margin-bottom:16px;}
        .boost-card-title{font-size:13px;font-weight:700;color:#888;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:16px;}
        
        .boost-page-preview{display:flex;align-items:center;gap:16px;padding:16px;background:#f8fafc;border-radius:14px;}
        .boost-page-img{width:64px;height:64px;border-radius:10px;overflow:hidden;flex-shrink:0;background:#e5e5e5;}
        .boost-page-img img{width:100%;height:100%;object-fit:cover;}
        .boost-page-info{flex:1;min-width:0;}
        .boost-page-name{font-weight:700;font-size:15px;color:#1a1a2e;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
        .boost-page-meta{font-size:12px;color:#888;margin-top:2px;}
        .boost-change-btn{padding:8px 14px;background:#fff;border:1px solid #e5e7eb;border-radius:8px;font-size:12px;font-weight:600;color:#667eea;cursor:pointer;}
        
        .boost-field{display:flex;align-items:center;gap:12px;padding:14px 0;border-bottom:1px solid #f1f5f9;}
        .boost-field:last-child{border-bottom:none;padding-bottom:0;}
        .boost-field-icon{font-size:20px;width:32px;text-align:center;flex-shrink:0;}
        .boost-field-label{font-size:14px;color:#1a1a2e;font-weight:500;white-space:nowrap;}
        .boost-field-input{flex:1;min-width:0;}
        .boost-field-input select{width:100%;padding:10px 14px;border:2px solid #e5e7eb;border-radius:10px;font-size:14px;font-family:inherit;background:#fff;cursor:pointer;-webkit-appearance:none;appearance:none;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23666' d='M6 8L1 3h10z'/%3E%3C/svg%3E");background-repeat:no-repeat;background-position:right 12px center;}
        .boost-field-input select:focus{outline:none;border-color:#667eea;}
        
        /* FIXED: Duration Cards - responsive pricing with !important overrides */
        .boost-durations{display:grid!important;grid-template-columns:repeat(3,1fr)!important;gap:10px!important;margin-top:8px!important;}
        .boost-dur{border:2px solid #e5e7eb!important;border-radius:12px!important;padding:16px 8px!important;text-align:center!important;cursor:pointer!important;transition:all 0.2s!important;position:relative!important;min-height:80px!important;display:flex!important;flex-direction:column!important;justify-content:center!important;background:#fff!important;}
        .boost-dur:hover{border-color:#667eea!important;}
        .boost-dur.selected{border-color:#667eea!important;background:linear-gradient(135deg,#f5f3ff,#fef3f2)!important;}
        .boost-dur input{display:none!important;}
        .boost-dur-price{font-size:16px!important;font-weight:800!important;color:#667eea!important;word-break:break-word!important;line-height:1.2!important;display:block!important;visibility:visible!important;opacity:1!important;}
        .boost-dur-label{font-size:11px!important;color:#666!important;margin-top:4px!important;display:block!important;visibility:visible!important;}
        .boost-dur-check{position:absolute!important;top:6px!important;right:6px!important;width:16px!important;height:16px!important;border:2px solid #d1d5db!important;border-radius:50%!important;background:#fff!important;display:flex!important;align-items:center!important;justify-content:center!important;font-size:8px!important;color:#fff!important;}
        .boost-dur.selected .boost-dur-check{background:#667eea!important;border-color:#667eea!important;}
        
        .boost-genders{display:flex;gap:8px;}
        .boost-gender{flex:1;padding:10px 4px;border:2px solid #e5e7eb;border-radius:10px;text-align:center;cursor:pointer;font-size:12px;font-weight:600;transition:all 0.2s;}
        .boost-gender:hover{border-color:#667eea;}
        .boost-gender.selected{border-color:#667eea;background:#f5f3ff;color:#667eea;}
        .boost-gender input{display:none;}
        
        .boost-summary{background:linear-gradient(135deg,#667eea,#764ba2);border-radius:16px;padding:20px;color:#fff;margin-top:20px;}
        .boost-summary-row{display:flex;justify-content:space-between;font-size:14px;padding:6px 0;opacity:0.9;}
        .boost-summary-total{display:flex;justify-content:space-between;font-size:18px;font-weight:700;padding-top:12px;margin-top:8px;border-top:1px solid rgba(255,255,255,0.2);}
        
        .boost-payment-methods{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-top:10px;}
        .boost-payment-option{display:flex;flex-direction:column;align-items:center;gap:6px;padding:14px 8px;border:2px solid #e5e7eb;border-radius:12px;cursor:pointer;transition:all 0.2s;text-align:center;}
        .boost-payment-option:hover{border-color:#667eea;background:#f5f3ff;}
        .boost-payment-option.selected{border-color:#667eea;background:#f5f3ff;}
        .boost-payment-option input{display:none;}
        .boost-payment-icon{font-size:24px;}
        .boost-payment-label{font-size:11px;font-weight:600;color:#374151;text-transform:uppercase;}
        
        .boost-submit{width:100%;padding:18px;background:#fff;color:#667eea;font-size:16px;font-weight:700;border:none;border-radius:14px;cursor:pointer;margin-top:16px;display:flex;align-items:center;justify-content:center;gap:8px;transition:all 0.2s;}
        .boost-submit:hover{transform:translateY(-2px);box-shadow:0 8px 24px rgba(0,0,0,0.2);}
        .boost-submit:disabled{opacity:0.6;cursor:not-allowed;transform:none;}
        
        .boost-msg{padding:14px;border-radius:12px;margin-bottom:16px;display:none;font-size:14px;}
        .boost-msg.ok{display:block;background:#d1fae5;color:#065f46;}
        .boost-msg.err{display:block;background:#fee2e2;color:#991b1b;}
        
        .boost-modal{display:none;position:fixed;inset:0;background:rgba(0,0,0,0.7);z-index:9999;align-items:flex-end;justify-content:center;padding:0;}
        .boost-modal.show{display:flex;}
        .boost-modal-content{background:#fff;border-radius:24px 24px 0 0;width:100%;max-height:80vh;overflow-y:auto;padding-bottom:env(safe-area-inset-bottom);}
        .boost-modal-head{padding:20px;border-bottom:1px solid #f1f5f9;display:flex;justify-content:space-between;align-items:center;position:sticky;top:0;background:#fff;z-index:1;}
        .boost-modal-head h3{margin:0;font-size:18px;font-weight:700;}
        .boost-modal-close{background:none;border:none;font-size:24px;cursor:pointer;color:#888;padding:4px;}
        .boost-modal-body{padding:16px;}
        .boost-modal-pages{display:flex;flex-direction:column;gap:12px;}
        .boost-modal-page{display:flex;align-items:center;gap:14px;padding:14px;border:2px solid #e5e7eb;border-radius:14px;cursor:pointer;transition:all 0.2s;}
        .boost-modal-page:hover{border-color:#667eea;background:#f5f3ff;}
        .boost-modal-page-img{width:50px;height:50px;border-radius:8px;overflow:hidden;flex-shrink:0;background:#f5f5f5;}
        .boost-modal-page-img img{width:100%;height:100%;object-fit:cover;}
        .boost-modal-page-info{flex:1;}
        .boost-modal-page-name{font-weight:600;font-size:14px;color:#1a1a2e;}
        .boost-modal-page-meta{font-size:12px;color:#888;}
        
        @media(max-width:480px){
            .boost-wrap{padding:0 12px 60px!important;}
            .boost-card{padding:20px 16px!important;border-radius:16px!important;}
            .boost-durations{gap:6px!important;}
            .boost-dur{padding:12px 6px!important;min-height:70px!important;}
            .boost-dur-price{font-size:13px!important;display:block!important;visibility:visible!important;color:#667eea!important;}
            .boost-dur-label{font-size:10px!important;display:block!important;visibility:visible!important;}
            .boost-field{flex-wrap:wrap!important;}
            .boost-field-label{width:100%!important;margin-bottom:8px!important;}
            .boost-field-input{width:100%!important;}
        }
        </style>
        
        <div class="boost-wrap">
            <p class="boost-subtext">Hushot AI assistant will help you target the right audience.</p>
            
            <div class="boost-msg" id="boost-msg"></div>
            
            <form id="boost-form">
                <input type="hidden" name="page_id" id="boost-page-id" value="<?php echo $page_id; ?>">
                
                <div class="boost-card">
                    <div class="boost-card-title">Selected Page</div>
                    <div class="boost-page-preview" id="boost-page-preview">
                        <?php if ($page): 
                            $display_img = $page_data['image_url'] ?: $page_data['logo_url'];
                        ?>
                        <div class="boost-page-img">
                            <?php if ($display_img): ?>
                            <img src="<?php echo esc_url($display_img); ?>" alt="">
                            <?php else: ?>
                            <div style="display:flex;align-items:center;justify-content:center;height:100%;font-size:24px;background:#f5f5f5;">📄</div>
                            <?php endif; ?>
                        </div>
                        <div class="boost-page-info">
                            <div class="boost-page-name"><?php echo esc_html($page_data['title']); ?></div>
                            <div class="boost-page-meta"><?php echo esc_html($page_data['business_name'] ?: 'Landing Page'); ?></div>
                        </div>
                        <?php else: ?>
                        <div class="boost-page-img">
                            <div style="display:flex;align-items:center;justify-content:center;height:100%;font-size:24px;background:#f5f5f5;">📄</div>
                        </div>
                        <div class="boost-page-info">
                            <div class="boost-page-name">Select a page</div>
                            <div class="boost-page-meta">Tap to choose</div>
                        </div>
                        <?php endif; ?>
                        <button type="button" class="boost-change-btn" id="boost-change-page">Change</button>
                    </div>
                </div>
                
                <div class="boost-card">
                    <div class="boost-card-title">Target Audience</div>
                    
                    <div class="boost-field">
                        <div class="boost-field-icon">📍</div>
                        <div class="boost-field-label">Location</div>
                        <div class="boost-field-input">
                            <select name="country" id="boost-country" required>
                                <?php foreach ($countries as $code => $country): ?>
                                <option value="<?php echo $code; ?>"><?php echo $country['flag']; ?> <?php echo $country['name']; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    
                    <div class="boost-field">
                        <div class="boost-field-icon">👤</div>
                        <div class="boost-field-label">Gender</div>
                        <div class="boost-field-input">
                            <div class="boost-genders">
                                <label class="boost-gender selected" data-value="all">
                                    <input type="radio" name="gender" value="all" checked> All
                                </label>
                                <label class="boost-gender" data-value="male">
                                    <input type="radio" name="gender" value="male"> Male
                                </label>
                                <label class="boost-gender" data-value="female">
                                    <input type="radio" name="gender" value="female"> Female
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="boost-card">
                    <div class="boost-card-title">Budget & Duration</div>
                    
                    <div class="boost-field">
                        <div class="boost-field-icon">💰</div>
                        <div class="boost-field-label">Daily Budget (<?php echo $currency['code']; ?>)</div>
                        <div class="boost-field-input">
                            <input type="number" name="daily_budget" id="boost-daily-budget" min="500" value="5000" step="500" style="width:100%;padding:10px 14px;border:2px solid #e5e7eb;border-radius:10px;font-size:14px;" required>
                        </div>
                    </div>
                    
                    <div class="boost-field">
                        <div class="boost-field-icon">📅</div>
                        <div class="boost-field-label">Duration</div>
                        <div class="boost-field-input" style="display:flex;gap:8px;">
                            <input type="number" name="duration_value" id="boost-duration-value" min="1" max="90" value="7" style="width:80px;padding:10px;border:2px solid #e5e7eb;border-radius:10px;font-size:14px;text-align:center;" required>
                            <select name="duration_unit" id="boost-duration-unit" style="flex:1;padding:10px 14px;border:2px solid #e5e7eb;border-radius:10px;font-size:14px;">
                                <option value="days">Days</option>
                                <option value="weeks">Weeks</option>
                                <option value="months">Months</option>
                            </select>
                        </div>
                    </div>
                    
                    <?php $service_fee = floatval(get_option('hushot_ads_service_fee', 10)); ?>
                    <div style="margin-top:16px;padding:14px;background:#f0fdf4;border-radius:12px;border:1px solid #bbf7d0;">
                        <div style="display:flex;justify-content:space-between;font-size:13px;color:#166534;margin-bottom:8px;">
                            <span>Ad Spend</span>
                            <span id="calc-ad-spend"><?php echo $currency['symbol']; ?>35,000</span>
                        </div>
                        <div style="display:flex;justify-content:space-between;font-size:13px;color:#166534;margin-bottom:8px;">
                            <span>Service Fee (<?php echo $service_fee; ?>%)</span>
                            <span id="calc-service-fee"><?php echo $currency['symbol']; ?>3,500</span>
                        </div>
                        <div style="display:flex;justify-content:space-between;font-size:15px;font-weight:700;color:#15803d;padding-top:8px;border-top:1px solid #bbf7d0;">
                            <span>Total</span>
                            <span id="calc-total"><?php echo $currency['symbol']; ?>38,500</span>
                        </div>
                    </div>
                    <input type="hidden" name="service_fee_percent" value="<?php echo $service_fee; ?>">
                    <input type="hidden" name="total_amount" id="boost-total-amount" value="38500">
                </div>
                
                <div class="boost-card" style="display:none;">
                    <div class="boost-card-title">Boost Duration (Legacy)</div>
                    <div class="boost-durations">
                        <?php foreach ($rates as $key => $rate): ?>
                        <label class="boost-dur <?php echo $key === '1week' ? 'selected' : ''; ?>" data-price="<?php echo $rate['price_local']; ?>" data-usd="<?php echo $rate['total_usd']; ?>">
                            <input type="radio" name="duration" value="<?php echo $key; ?>" <?php echo $key === '1week' ? 'checked' : ''; ?>>
                            <div class="boost-dur-check">✓</div>
                            <div class="boost-dur-price"><?php echo $rate['symbol'] . number_format($rate['price_local']); ?></div>
                            <div class="boost-dur-label"><?php echo $rate['label']; ?></div>
                        </label>
                        <?php endforeach; ?>
                    </div>
                </div>
                
                <div class="boost-summary">
                    <div class="boost-summary-row">
                        <span>Selected Page</span>
                        <span id="summary-page"><?php echo $page ? esc_html(substr($page_data['title'], 0, 20)) . (strlen($page_data['title']) > 20 ? '...' : '') : '-'; ?></span>
                    </div>
                    <div class="boost-summary-row">
                        <span>Duration</span>
                        <span id="summary-duration">1 Week</span>
                    </div>
                    <div class="boost-summary-row">
                        <span>Target</span>
                        <span id="summary-target">Nigeria • All</span>
                    </div>
                    <div class="boost-summary-total">
                        <span>Total</span>
                        <span id="summary-total"><?php echo $currency['symbol'] . number_format($rates['1week']['price_local']); ?></span>
                    </div>
                </div>
                
                <!-- Payment Method Selection -->
                <div class="boost-field">
                    <label class="boost-label">💳 Payment Method</label>
                    <div class="boost-payment-methods">
                        <label class="boost-payment-option selected">
                            <input type="radio" name="payment_method" value="card" checked>
                            <span class="boost-payment-icon">💳</span>
                            <span class="boost-payment-label">Card</span>
                        </label>
                        <label class="boost-payment-option">
                            <input type="radio" name="payment_method" value="mobilemoney">
                            <span class="boost-payment-icon">📱</span>
                            <span class="boost-payment-label">Mobile Money</span>
                        </label>
                        <label class="boost-payment-option">
                            <input type="radio" name="payment_method" value="ussd">
                            <span class="boost-payment-icon">🏦</span>
                            <span class="boost-payment-label">USSD/Bank</span>
                        </label>
                    </div>
                </div>
                
                <button type="submit" class="boost-submit" id="boost-submit-btn">
                    <span>🚀 Pay & Boost Now</span>
                </button>
            </form>
        </div>
        
        <div class="boost-modal" id="boost-modal">
            <div class="boost-modal-content">
                <div class="boost-modal-head">
                    <h3>Select Landing Page</h3>
                    <button type="button" class="boost-modal-close" id="boost-modal-close">✕</button>
                </div>
                <div class="boost-modal-body">
                    <div class="boost-modal-pages">
                        <?php foreach ($pages as $pg): 
                            $pg_img = get_post_meta($pg->ID, '_hushot_image_url', true) ?: get_post_meta($pg->ID, '_hushot_logo_url', true);
                            $pg_biz = get_post_meta($pg->ID, '_hushot_business_name', true);
                        ?>
                        <div class="boost-modal-page" 
                             data-id="<?php echo $pg->ID; ?>"
                             data-title="<?php echo esc_attr($pg->post_title); ?>"
                             data-business="<?php echo esc_attr($pg_biz); ?>"
                             data-image="<?php echo esc_attr($pg_img); ?>">
                            <div class="boost-modal-page-img">
                                <?php if ($pg_img): ?>
                                <img src="<?php echo esc_url($pg_img); ?>" alt="">
                                <?php else: ?>
                                <div style="display:flex;align-items:center;justify-content:center;height:100%;font-size:20px;">📄</div>
                                <?php endif; ?>
                            </div>
                            <div class="boost-modal-page-info">
                                <div class="boost-modal-page-name"><?php echo esc_html($pg->post_title); ?></div>
                                <div class="boost-modal-page-meta"><?php echo esc_html($pg_biz ?: 'Landing Page'); ?></div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
        
        <script>
        (function(){
            var form = document.getElementById('boost-form');
            var modal = document.getElementById('boost-modal');
            var pageIdInput = document.getElementById('boost-page-id');
            var rates = <?php echo json_encode($rates); ?>;
            var currencySymbol = '<?php echo $currency['symbol']; ?>';
            var serviceFeePercent = <?php echo $service_fee; ?>;
            
            // Budget Calculator
            var dailyBudgetInput = document.getElementById('boost-daily-budget');
            var durationValueInput = document.getElementById('boost-duration-value');
            var durationUnitSelect = document.getElementById('boost-duration-unit');
            
            function calculateBudget() {
                var dailyBudget = parseFloat(dailyBudgetInput.value) || 0;
                var durationValue = parseInt(durationValueInput.value) || 0;
                var durationUnit = durationUnitSelect.value;
                
                // Calculate total days
                var totalDays = durationValue;
                if (durationUnit === 'weeks') totalDays = durationValue * 7;
                if (durationUnit === 'months') totalDays = durationValue * 30;
                
                // Calculate amounts
                var adSpend = dailyBudget * totalDays;
                var serviceFee = adSpend * (serviceFeePercent / 100);
                var total = adSpend + serviceFee;
                
                // Update display
                document.getElementById('calc-ad-spend').textContent = currencySymbol + numberFormat(adSpend);
                document.getElementById('calc-service-fee').textContent = currencySymbol + numberFormat(serviceFee);
                document.getElementById('calc-total').textContent = currencySymbol + numberFormat(total);
                document.getElementById('boost-total-amount').value = total;
                document.getElementById('summary-total').textContent = currencySymbol + numberFormat(total);
                
                // Update duration summary
                var durationText = durationValue + ' ' + (durationUnit === 'days' ? 'Day' : (durationUnit === 'weeks' ? 'Week' : 'Month'));
                if (durationValue > 1) durationText += 's';
                document.getElementById('summary-duration').textContent = durationText;
            }
            
            function numberFormat(num) {
                return num.toFixed(0).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            }
            
            dailyBudgetInput.addEventListener('input', calculateBudget);
            durationValueInput.addEventListener('input', calculateBudget);
            durationUnitSelect.addEventListener('change', calculateBudget);
            
            // Initialize calculation
            calculateBudget();
            
            document.getElementById('boost-change-page').addEventListener('click', function() {
                modal.classList.add('show');
            });
            
            document.getElementById('boost-modal-close').addEventListener('click', function() {
                modal.classList.remove('show');
            });
            
            modal.addEventListener('click', function(e) {
                if (e.target === modal) modal.classList.remove('show');
            });
            
            document.querySelectorAll('.boost-modal-page').forEach(function(card) {
                card.addEventListener('click', function() {
                    var id = this.dataset.id;
                    var title = this.dataset.title;
                    var business = this.dataset.business || 'Landing Page';
                    var image = this.dataset.image;
                    
                    pageIdInput.value = id;
                    
                    var preview = document.getElementById('boost-page-preview');
                    var imgHtml = image ? '<img src="'+image+'" alt="">' : '<div style="display:flex;align-items:center;justify-content:center;height:100%;font-size:24px;background:#f5f5f5;">📄</div>';
                    
                    preview.innerHTML = '<div class="boost-page-img">'+imgHtml+'</div>' +
                        '<div class="boost-page-info"><div class="boost-page-name">'+title+'</div><div class="boost-page-meta">'+business+'</div></div>' +
                        '<button type="button" class="boost-change-btn" id="boost-change-page">Change</button>';
                    
                    document.getElementById('boost-change-page').addEventListener('click', function() {
                        modal.classList.add('show');
                    });
                    
                    document.getElementById('summary-page').textContent = title.length > 20 ? title.substring(0,20)+'...' : title;
                    
                    modal.classList.remove('show');
                });
            });
            
            document.querySelectorAll('.boost-dur').forEach(function(dur) {
                dur.addEventListener('click', function() {
                    document.querySelectorAll('.boost-dur').forEach(function(d) { d.classList.remove('selected'); });
                    this.classList.add('selected');
                    this.querySelector('input').checked = true;
                    updateSummary();
                });
            });
            
            document.querySelectorAll('.boost-gender').forEach(function(g) {
                g.addEventListener('click', function() {
                    document.querySelectorAll('.boost-gender').forEach(function(x) { x.classList.remove('selected'); });
                    this.classList.add('selected');
                    this.querySelector('input').checked = true;
                    updateSummary();
                });
            });
            
            // Payment method selection
            document.querySelectorAll('.boost-payment-option').forEach(function(opt) {
                opt.addEventListener('click', function() {
                    document.querySelectorAll('.boost-payment-option').forEach(function(x) { x.classList.remove('selected'); });
                    this.classList.add('selected');
                    this.querySelector('input').checked = true;
                });
            });
            
            document.getElementById('boost-country').addEventListener('change', updateSummary);
            
            function updateSummary() {
                var duration = document.querySelector('input[name="duration"]:checked').value;
                var gender = document.querySelector('input[name="gender"]:checked').value;
                var country = document.getElementById('boost-country');
                var countryName = country.options[country.selectedIndex].text;
                var genderLabel = gender === 'all' ? 'All' : (gender === 'male' ? 'Male' : 'Female');
                
                document.getElementById('summary-duration').textContent = rates[duration].label;
                document.getElementById('summary-target').textContent = countryName.replace(/^[^\s]+\s/, '') + ' • ' + genderLabel;
                document.getElementById('summary-total').textContent = currencySymbol + Number(rates[duration].price_local).toLocaleString();
            }
            
            form.addEventListener('submit', function(e) {
                e.preventDefault();
                
                if (!pageIdInput.value) {
                    document.getElementById('boost-msg').className = 'boost-msg err';
                    document.getElementById('boost-msg').textContent = 'Please select a landing page';
                    return;
                }
                
                var btn = document.getElementById('boost-submit-btn');
                btn.disabled = true;
                btn.innerHTML = '<span>Redirecting to payment...</span>';
                
                var formData = new FormData(form);
                formData.append('action', 'hushot_ads_submit_product');
                formData.append('nonce', '<?php echo wp_create_nonce('hushot_ads_submit'); ?>');
                
                fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                    method: 'POST',
                    body: formData
                })
                .then(function(r) { return r.json(); })
                .then(function(data) {
                    var msg = document.getElementById('boost-msg');
                    if (data.success) {
                        // Redirect to payment URL
                        if (data.data.payment_url) {
                            window.location.href = data.data.payment_url;
                        } else if (data.data.redirect) {
                            window.location.href = data.data.redirect;
                        } else {
                            msg.className = 'boost-msg ok';
                            msg.textContent = data.data.message || 'Boost request submitted!';
                            setTimeout(function() {
                                window.location.href = '<?php echo Hushot_Pages::get_page_url('ads-dashboard'); ?>';
                            }, 1500);
                        }
                    } else {
                        btn.disabled = false;
                        btn.innerHTML = '<span>🚀 Pay & Boost Now</span>';
                        msg.className = 'boost-msg err';
                        msg.textContent = data.data?.message || 'Something went wrong. Please try again.';
                    }
                })
                .catch(function(err) {
                    btn.disabled = false;
                    btn.innerHTML = '<span>🚀 Pay & Boost Now</span>';
                    document.getElementById('boost-msg').className = 'boost-msg err';
                    document.getElementById('boost-msg').textContent = 'Connection error. Please try again.';
                });
            });
        })();
        </script>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Render upgrade prompt
     */
    private static function render_upgrade_prompt() {
        return '<div style="max-width:400px;margin:40px auto;text-align:center;padding:48px 20px;background:#fff;border-radius:20px;box-shadow:0 4px 20px rgba(0,0,0,0.08);">
            <div style="font-size:64px;margin-bottom:16px;">🔒</div>
            <h3 style="margin:0 0 8px;font-size:20px;">Ads Network</h3>
            <p style="color:#888;margin-bottom:24px;">Boost your landing pages to reach thousands of potential customers.</p>
            <a href="' . esc_url(Hushot_Pages::get_page_url('pricing')) . '" style="display:inline-block;padding:14px 32px;background:linear-gradient(135deg,#667eea,#764ba2);color:#fff;font-weight:600;border-radius:12px;text-decoration:none;">Get Started</a>
        </div>';
    }
}
