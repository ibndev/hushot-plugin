<?php
/**
 * Hushot Ads Network - AI Moderation & Optimization
 * Uses OpenAI for policy compliance and performance optimization
 */

if (!defined('ABSPATH')) exit;

class Hushot_Ads_AI {
    
    // Meta prohibited policy categories
    private static $policy_categories = array(
        'prohibited_content' => 'Prohibited Content (weapons, drugs, tobacco, adult content)',
        'misleading_claims' => 'Misleading Claims (guaranteed results, miracle cures)',
        'discriminatory' => 'Discriminatory Content (hate speech, targeting protected groups)',
        'sensationalized' => 'Sensationalized Language (shocking, secret methods)',
        'health_claims' => 'Unverified Health Claims (before/after, medical advice)',
        'financial_schemes' => 'Financial Schemes (get rich quick, guaranteed income)',
        'personal_attributes' => 'Personal Attributes Assertion (assuming user conditions)',
        'low_quality' => 'Low Quality Ad (missing image, invalid URL, spam-like content)'
    );
    
    // Meta prohibited categories
    private static $prohibited_categories = array(
        'weapons', 'drugs', 'tobacco', 'adult_content', 'gambling',
        'cryptocurrency', 'mlm', 'fake_documents', 'counterfeit',
        'discrimination', 'misleading_claims', 'political_content',
        'health_claims_unverified', 'financial_schemes', 'spyware'
    );
    
    // Keywords that trigger review with policy category
    private static $flagged_keywords = array(
        // Health - health_claims
        'cure' => 'health_claims',
        'miracle' => 'misleading_claims',
        'guaranteed results' => 'misleading_claims',
        'instant weight loss' => 'health_claims',
        'permanent' => 'health_claims',
        'before and after' => 'health_claims',
        'transformation' => 'health_claims',
        'doctors hate' => 'sensationalized',
        // Financial - financial_schemes
        'get rich quick' => 'financial_schemes',
        'guaranteed income' => 'financial_schemes',
        'make money fast' => 'financial_schemes',
        'forex signals' => 'financial_schemes',
        '100% guaranteed' => 'misleading_claims',
        // Misleading - misleading_claims
        'free money' => 'misleading_claims',
        'secret method' => 'sensationalized',
        'limited time only' => 'sensationalized',
        'shocking' => 'sensationalized',
        // Prohibited - prohibited_content
        'cannabis' => 'prohibited_content',
        'cbd oil' => 'prohibited_content',
        'betting' => 'prohibited_content',
        'casino' => 'prohibited_content',
        'escort' => 'prohibited_content',
        'dating' => 'prohibited_content'
    );
    
    /**
     * Initialize AI module
     */
    public static function init() {
        // AI-related hooks
    }
    
    /**
     * Moderate a product submission - INSTANT APPROVAL/REJECTION
     * Returns clear rejection reason with policy category
     */
    public static function moderate_product($product_id) {
        global $wpdb;
        
        $product = Hushot_Ads_Catalog::get_product($product_id);
        if (!$product) {
            return array('status' => 'error', 'message' => 'Product not found');
        }
        
        $score = 1.0; // Start with perfect score
        $issues = array();
        $notes = array();
        $violated_policies = array();
        
        // Step 1: Basic validation - INSTANT REJECT for missing data
        if (empty($product->product_name) || strlen(trim($product->product_name)) < 3) {
            $score = 0;
            $issues[] = "Product name is too short or missing";
            $violated_policies[] = 'low_quality';
        }
        
        // Step 2: URL validation - INSTANT REJECT for invalid URLs
        if (!filter_var($product->landing_page_url, FILTER_VALIDATE_URL)) {
            $score -= 0.5;
            $issues[] = "Invalid landing page URL";
            $violated_policies[] = 'low_quality';
        }
        
        // Step 3: Image validation
        if (empty($product->product_image_url)) {
            $score -= 0.2;
            $issues[] = "Missing product image";
            $notes[] = "Consider adding a cover image to improve ad performance";
        } elseif (!filter_var($product->product_image_url, FILTER_VALIDATE_URL)) {
            $score -= 0.3;
            $issues[] = "Invalid image URL format";
            $violated_policies[] = 'low_quality';
        }
        
        // Step 4: Keyword scan with policy category tracking
        $text_to_scan = strtolower($product->product_name . ' ' . $product->product_description);
        
        foreach (self::$flagged_keywords as $keyword => $policy) {
            if (stripos($text_to_scan, $keyword) !== false) {
                $score -= 0.25;
                $issues[] = "Contains prohibited term: '{$keyword}'";
                if (!in_array($policy, $violated_policies)) {
                    $violated_policies[] = $policy;
                }
            }
        }
        
        // Step 5: Category risk check
        $high_risk_categories = array('health', 'finance', 'real_estate');
        if (in_array($product->category, $high_risk_categories)) {
            $notes[] = "High-risk category detected - stricter review applied";
            $score -= 0.05;
        }
        
        // Step 6: OpenAI deep moderation (if API key available and not already rejected)
        $openai_key = get_option('hushot_openai_api_key', '');
        if ($openai_key && $score > 0.3) {
            $ai_result = self::openai_moderate($product, $openai_key);
            if ($ai_result) {
                $score = min($score, $ai_result['score']);
                $issues = array_merge($issues, $ai_result['issues'] ?? array());
                $notes = array_merge($notes, $ai_result['notes'] ?? array());
                if (isset($ai_result['violated_policies'])) {
                    $violated_policies = array_merge($violated_policies, $ai_result['violated_policies']);
                }
            }
        }
        
        // INSTANT DECISION - No manual review
        $status = 'rejected';
        $rejection_reason = null;
        
        if ($score >= 0.7) {
            // AUTO-APPROVE: High-scoring products
            $status = 'active';
            Hushot_Ads_Campaigns::sync_product_to_campaigns($product_id);
        } else {
            // AUTO-REJECT: Build clear rejection reason with policy categories
            $status = 'rejected';
            
            // Build rejection reason with policy categories
            $policy_names = array();
            foreach (array_unique($violated_policies) as $policy) {
                if (isset(self::$policy_categories[$policy])) {
                    $policy_names[] = self::$policy_categories[$policy];
                }
            }
            
            if (!empty($policy_names)) {
                $rejection_reason = "Policy Violation: " . implode('; ', $policy_names);
            } elseif (!empty($issues)) {
                $rejection_reason = implode('; ', array_slice($issues, 0, 3));
            } else {
                $rejection_reason = "Content does not meet Meta Ads Policy requirements";
            }
            
            Hushot_Ads_Campaigns::remove_product_from_all_campaigns($product_id);
        }
        
        // Update product with decision
        $wpdb->update(
            $wpdb->prefix . 'hushot_ads_catalog',
            array(
                'status' => $status,
                'rejection_reason' => $rejection_reason,
                'ai_moderation_score' => round($score, 2),
                'ai_moderation_notes' => json_encode(array(
                    'issues' => $issues,
                    'notes' => $notes,
                    'violated_policies' => array_unique($violated_policies),
                    'decision' => $status === 'active' ? 'APPROVED' : 'REJECTED',
                    'timestamp' => current_time('mysql')
                ))
            ),
            array('id' => $product_id)
        );
        
        // Notify user of rejection
        if ($status === 'rejected') {
            self::notify_user_rejection($product, $rejection_reason);
        }
        
        return array(
            'status' => $status,
            'score' => $score,
            'issues' => $issues,
            'notes' => $notes,
            'rejection_reason' => $rejection_reason,
            'violated_policies' => array_unique($violated_policies)
        );
    }
    
    /**
     * OpenAI content moderation
     */
    private static function openai_moderate($product, $api_key) {
        $prompt = "You are a Meta Ads policy compliance checker. Analyze this ad content and determine if it complies with Facebook/Instagram advertising policies.

Product Name: {$product->product_name}
Description: {$product->product_description}
Category: {$product->category}
Business: {$product->business_name}

Check for violations of:
1. Prohibited content (weapons, drugs, adult content, etc.)
2. Misleading claims (guaranteed results, miracle cures, etc.)
3. Discriminatory content
4. Sensationalized language (shocking, secret, etc.)
5. Unverified health/financial claims

Respond in JSON format:
{
    \"compliant\": true/false,
    \"score\": 0.0-1.0,
    \"issues\": [\"issue1\", \"issue2\"],
    \"notes\": [\"note1\", \"note2\"]
}";
        
        $response = wp_remote_post('https://api.openai.com/v1/chat/completions', array(
            'timeout' => 30,
            'headers' => array(
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type' => 'application/json'
            ),
            'body' => json_encode(array(
                'model' => 'gpt-4o-mini',
                'messages' => array(
                    array('role' => 'system', 'content' => 'You are a Meta Ads policy compliance expert. Always respond in valid JSON.'),
                    array('role' => 'user', 'content' => $prompt)
                ),
                'temperature' => 0.3,
                'max_tokens' => 500
            ))
        ));
        
        if (is_wp_error($response)) {
            error_log('Hushot AI Moderation Error: ' . $response->get_error_message());
            return null;
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if (!isset($body['choices'][0]['message']['content'])) {
            return null;
        }
        
        $content = $body['choices'][0]['message']['content'];
        
        // Extract JSON from response
        preg_match('/\{[\s\S]*\}/', $content, $matches);
        if (empty($matches)) {
            return null;
        }
        
        $result = json_decode($matches[0], true);
        
        return array(
            'score' => floatval($result['score'] ?? 0.5),
            'issues' => $result['issues'] ?? array(),
            'notes' => $result['notes'] ?? array()
        );
    }
    
    /**
     * Notify user of rejection
     */
    private static function notify_user_rejection($product, $reason) {
        $user = get_userdata($product->user_id);
        if (!$user) return;
        
        $subject = "Your ad '{$product->product_name}' was not approved";
        
        $message = "Hi {$user->display_name},\n\n";
        $message .= "Unfortunately, your ad submission was not approved for the Hushot Ads Network.\n\n";
        $message .= "Product: {$product->product_name}\n";
        $message .= "Reason: {$reason}\n\n";
        $message .= "Common reasons for rejection include:\n";
        $message .= "- Prohibited content (weapons, drugs, adult content)\n";
        $message .= "- Misleading claims or guarantees\n";
        $message .= "- Missing or invalid landing page\n";
        $message .= "- Policy-violating keywords\n\n";
        $message .= "You can edit your product and resubmit it from your dashboard.\n\n";
        $message .= "Best regards,\nHushot Team";
        
        wp_mail($user->user_email, $subject, $message);
    }
    
    /**
     * AI-powered campaign optimization
     */
    public static function optimize_campaigns() {
        global $wpdb;
        
        $openai_key = get_option('hushot_openai_api_key', '');
        if (!$openai_key) return;
        
        // Get products with performance data
        $products = $wpdb->get_results(
            "SELECT * FROM {$wpdb->prefix}hushot_ads_catalog 
             WHERE status = 'active' 
             AND impressions > 100
             AND created_at < DATE_SUB(NOW(), INTERVAL 3 DAY)"
        );
        
        if (empty($products)) return;
        
        foreach ($products as $product) {
            $ctr = $product->impressions > 0 
                ? ($product->clicks / $product->impressions) * 100 
                : 0;
            
            $lpv_rate = $product->clicks > 0 
                ? ($product->landing_page_views / $product->clicks) * 100 
                : 0;
            
            // Auto-pause severe underperformers
            if ($ctr < 0.1 && $product->impressions > 1000) {
                self::recommend_action($product, 'pause', 'CTR below 0.1% after 1000+ impressions');
                continue;
            }
            
            // Get AI recommendations for borderline cases
            if ($ctr < 0.5 || $lpv_rate < 50) {
                self::get_ai_optimization($product, $ctr, $lpv_rate, $openai_key);
            }
        }
    }
    
    /**
     * Get AI optimization recommendations
     */
    private static function get_ai_optimization($product, $ctr, $lpv_rate, $api_key) {
        $prompt = "Analyze this ad performance and recommend optimization:

Product: {$product->product_name}
Category: {$product->category}
Country: {$product->country}
Impressions: {$product->impressions}
Clicks: {$product->clicks}
CTR: " . round($ctr, 2) . "%
Landing Page Views: {$product->landing_page_views}
LPV Rate: " . round($lpv_rate, 1) . "%
Daily Budget: \${$product->daily_budget}
Total Spent: \${$product->spent}

Recommend ONE action:
1. continue - Keep running, performance acceptable
2. reduce_budget - Lower daily budget to extend duration
3. pause - Stop temporarily, needs attention
4. optimize_rotation - Reduce weight in carousel

Respond in JSON:
{\"action\": \"...\", \"reason\": \"...\", \"new_budget\": 0}";
        
        $response = wp_remote_post('https://api.openai.com/v1/chat/completions', array(
            'timeout' => 30,
            'headers' => array(
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type' => 'application/json'
            ),
            'body' => json_encode(array(
                'model' => 'gpt-4o-mini',
                'messages' => array(
                    array('role' => 'system', 'content' => 'You are an ad optimization expert. Respond only in JSON.'),
                    array('role' => 'user', 'content' => $prompt)
                ),
                'temperature' => 0.3,
                'max_tokens' => 200
            ))
        ));
        
        if (is_wp_error($response)) return;
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if (!isset($body['choices'][0]['message']['content'])) return;
        
        preg_match('/\{[\s\S]*\}/', $body['choices'][0]['message']['content'], $matches);
        if (empty($matches)) return;
        
        $result = json_decode($matches[0], true);
        
        if (isset($result['action'])) {
            self::recommend_action($product, $result['action'], $result['reason'] ?? '', $result['new_budget'] ?? 0);
        }
    }
    
    /**
     * Apply optimization recommendation
     */
    private static function recommend_action($product, $action, $reason, $new_budget = 0) {
        global $wpdb;
        
        // Log recommendation
        $wpdb->insert($wpdb->prefix . 'hushot_ads_stats', array(
            'product_id' => $product->id,
            'stat_date' => date('Y-m-d'),
            'notes' => json_encode(array(
                'ai_action' => $action,
                'reason' => $reason,
                'timestamp' => current_time('mysql')
            ))
        ));
        
        switch ($action) {
            case 'pause':
                Hushot_Ads_Catalog::update_status($product->id, 'paused');
                Hushot_Ads_Campaigns::remove_product_from_all_campaigns($product->id);
                self::notify_user_optimization($product, 'paused', $reason);
                break;
                
            case 'reduce_budget':
                if ($new_budget > 0 && $new_budget < $product->daily_budget) {
                    $wpdb->update(
                        $wpdb->prefix . 'hushot_ads_catalog',
                        array('daily_budget' => $new_budget),
                        array('id' => $product->id)
                    );
                }
                break;
                
            case 'optimize_rotation':
                // Reduce weight in campaigns
                $wpdb->query($wpdb->prepare(
                    "UPDATE {$wpdb->prefix}hushot_ads_campaign_products 
                     SET weight = weight * 0.7 
                     WHERE product_id = %d",
                    $product->id
                ));
                break;
        }
    }
    
    /**
     * Notify user of optimization action
     */
    private static function notify_user_optimization($product, $action, $reason) {
        $user = get_userdata($product->user_id);
        if (!$user) return;
        
        $subject = "Ad Update: {$product->product_name}";
        
        $message = "Hi {$user->display_name},\n\n";
        $message .= "Our AI optimization system has made an adjustment to your ad.\n\n";
        $message .= "Product: {$product->product_name}\n";
        $message .= "Action: " . ucfirst($action) . "\n";
        $message .= "Reason: {$reason}\n\n";
        $message .= "You can review and manage your ads from your dashboard.\n\n";
        $message .= "Best regards,\nHushot Team";
        
        wp_mail($user->user_email, $subject, $message);
    }
    
    /**
     * Get moderation queue
     */
    public static function get_pending_moderation() {
        global $wpdb;
        
        return $wpdb->get_results(
            "SELECT * FROM {$wpdb->prefix}hushot_ads_catalog 
             WHERE status = 'pending' 
             ORDER BY created_at ASC"
        );
    }
    
    /**
     * Manual approve product
     */
    public static function manual_approve($product_id) {
        global $wpdb;
        
        $wpdb->update(
            $wpdb->prefix . 'hushot_ads_catalog',
            array(
                'status' => 'active',
                'ai_moderation_notes' => json_encode(array(
                    'manual_approved' => true,
                    'timestamp' => current_time('mysql')
                ))
            ),
            array('id' => $product_id)
        );
        
        Hushot_Ads_Campaigns::sync_product_to_campaigns($product_id);
        
        return true;
    }
    
    /**
     * Manual reject product
     */
    public static function manual_reject($product_id, $reason) {
        global $wpdb;
        
        $product = Hushot_Ads_Catalog::get_product($product_id);
        
        $wpdb->update(
            $wpdb->prefix . 'hushot_ads_catalog',
            array(
                'status' => 'rejected',
                'rejection_reason' => $reason,
                'ai_moderation_notes' => json_encode(array(
                    'manual_rejected' => true,
                    'timestamp' => current_time('mysql')
                ))
            ),
            array('id' => $product_id)
        );
        
        Hushot_Ads_Campaigns::remove_product_from_all_campaigns($product_id);
        
        if ($product) {
            self::notify_user_rejection($product, $reason);
        }
        
        return true;
    }
    
    /**
     * Admin moderation page
     */
    public static function admin_moderation_page() {
        // Handle actions
        if (isset($_GET['action']) && isset($_GET['id']) && wp_verify_nonce($_GET['_wpnonce'] ?? '', $_GET['action'] . '_' . $_GET['id'])) {
            $id = intval($_GET['id']);
            if ($_GET['action'] === 'approve') {
                self::manual_approve($id);
                echo '<div class="notice notice-success"><p>Product approved!</p></div>';
            } elseif ($_GET['action'] === 'reject') {
                $reason = sanitize_text_field($_GET['reason'] ?? 'Manually rejected by admin');
                self::manual_reject($id, $reason);
                echo '<div class="notice notice-success"><p>Product rejected!</p></div>';
            }
        }
        
        $pending = self::get_pending_moderation();
        ?>
        <div style="background:#fff;padding:20px;border-radius:8px;">
            <h2 style="margin:0 0 20px;">🤖 AI Moderation Queue</h2>
            
            <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:20px;margin-bottom:30px;">
                <div style="background:#fef3c7;padding:15px;border-radius:8px;">
                    <h4 style="margin:0 0 8px;color:#92400e;">Pending Review</h4>
                    <p style="font-size:24px;font-weight:700;margin:0;color:#d97706;"><?php echo count($pending); ?></p>
                </div>
                <div style="background:#f8fafc;padding:15px;border-radius:8px;">
                    <h4 style="margin:0 0 8px;color:#666;">OpenAI Status</h4>
                    <p style="font-size:14px;margin:0;color:<?php echo get_option('hushot_openai_api_key') ? '#10b981' : '#ef4444'; ?>;">
                        <?php echo get_option('hushot_openai_api_key') ? '✓ Connected' : '✗ Not configured'; ?>
                    </p>
                </div>
                <div style="background:#f8fafc;padding:15px;border-radius:8px;">
                    <h4 style="margin:0 0 8px;color:#666;">Auto-Optimization</h4>
                    <p style="font-size:14px;margin:0;color:#10b981;">Runs every 12 hours</p>
                </div>
            </div>
            
            <?php if (empty($pending)): ?>
            <div style="text-align:center;padding:60px;color:#888;">
                <p style="font-size:48px;margin-bottom:16px;">✅</p>
                <p>No products pending moderation!</p>
            </div>
            <?php else: ?>
            
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th width="60">Image</th>
                        <th>Product</th>
                        <th>AI Score</th>
                        <th>Issues</th>
                        <th>Submitted</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($pending as $product): 
                        $notes = json_decode($product->ai_moderation_notes, true);
                        $issues = $notes['issues'] ?? array();
                    ?>
                    <tr>
                        <td><img src="<?php echo esc_url($product->product_image_url); ?>" width="50" height="50" style="object-fit:cover;border-radius:4px;"></td>
                        <td>
                            <strong><?php echo esc_html($product->product_name); ?></strong><br>
                            <small><?php echo esc_html($product->business_name); ?> • <?php echo Hushot_Ads::$countries[$product->country]['name'] ?? $product->country; ?></small>
                            <?php if ($product->product_description): ?>
                            <br><small style="color:#888;"><?php echo esc_html(substr($product->product_description, 0, 100)); ?>...</small>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php 
                            $score = $product->ai_moderation_score ?? 0;
                            $color = $score >= 0.7 ? '#10b981' : ($score >= 0.4 ? '#f59e0b' : '#ef4444');
                            ?>
                            <span style="background:<?php echo $color; ?>;color:#fff;padding:4px 10px;border-radius:12px;font-size:13px;font-weight:600;">
                                <?php echo number_format($score * 100, 0); ?>%
                            </span>
                        </td>
                        <td>
                            <?php if (!empty($issues)): ?>
                            <ul style="margin:0;padding-left:16px;font-size:12px;color:#666;">
                                <?php foreach (array_slice($issues, 0, 3) as $issue): ?>
                                <li><?php echo esc_html($issue); ?></li>
                                <?php endforeach; ?>
                            </ul>
                            <?php else: ?>
                            <span style="color:#888;">—</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo human_time_diff(strtotime($product->created_at)) . ' ago'; ?></td>
                        <td>
                            <a href="<?php echo esc_url(add_query_arg(array('action' => 'approve', 'id' => $product->id, '_wpnonce' => wp_create_nonce('approve_' . $product->id)))); ?>" class="button button-primary button-small">✓ Approve</a>
                            <a href="<?php echo esc_url(add_query_arg(array('action' => 'reject', 'id' => $product->id, 'reason' => 'Policy violation', '_wpnonce' => wp_create_nonce('reject_' . $product->id)))); ?>" class="button button-small" onclick="return confirm('Reject this product?')">✗ Reject</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
            
            <div style="margin-top:30px;padding:20px;background:#fef2f2;border-radius:8px;border:1px solid #fecaca;">
                <h3 style="margin:0 0 15px;color:#991b1b;">🚫 Auto-Rejected Content</h3>
                <p style="color:#7f1d1d;margin:0;">The AI automatically rejects products containing:</p>
                <ul style="margin:10px 0 0;padding-left:20px;color:#7f1d1d;">
                    <li>Prohibited items (weapons, drugs, adult content)</li>
                    <li>Misleading claims ("guaranteed", "miracle cure", "get rich quick")</li>
                    <li>Discriminatory language</li>
                    <li>Invalid URLs or missing images</li>
                </ul>
            </div>
        </div>
        <?php
    }
}
