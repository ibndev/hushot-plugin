<?php
if (!defined('ABSPATH')) exit;

class Hushot_AI {
    
    public static function generate($business_type = '', $goal = 'leads', $product = '') {
        // Get OpenAI key from admin settings
        $openai_key = get_option('hushot_openai_api_key', '');
        
        // If OpenAI key available, use OpenAI
        if ($openai_key && strlen($openai_key) > 20) {
            $result = self::generate_with_openai($product, $goal, $openai_key);
            if ($result) return $result;
        }
        
        // Fallback to template-based generation
        return self::generate_from_template($business_type, $goal, $product);
    }
    
    private static function generate_with_openai($product, $goal, $api_key) {
        $goal_text = ($goal === 'sales') ? 'drive sales' : (($goal === 'bookings') ? 'get bookings' : 'generate leads');
        
        $prompt = "You are a marketing copywriter. Create landing page content for: {$product}. Goal: {$goal_text}.

Return ONLY valid JSON with this exact structure (no markdown, no explanation):
{
    \"headline\": \"Catchy headline under 10 words\",
    \"description\": \"Compelling 2-3 sentence description about the product/service\",
    \"features\": [\"Benefit 1\", \"Benefit 2\", \"Benefit 3\", \"Benefit 4\"],
    \"cta\": \"Call-to-action button text\"
}";

        $response = wp_remote_post('https://api.openai.com/v1/chat/completions', array(
            'timeout' => 30,
            'headers' => array(
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type' => 'application/json',
            ),
            'body' => json_encode(array(
                'model' => 'gpt-3.5-turbo',
                'messages' => array(
                    array('role' => 'user', 'content' => $prompt)
                ),
                'max_tokens' => 500,
                'temperature' => 0.7,
            )),
        ));
        
        if (is_wp_error($response)) {
            return false;
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if (isset($body['choices'][0]['message']['content'])) {
            $content = $body['choices'][0]['message']['content'];
            // Clean up potential markdown
            $content = preg_replace('/```json\s*/', '', $content);
            $content = preg_replace('/```\s*/', '', $content);
            $content = trim($content);
            
            $parsed = json_decode($content, true);
            if ($parsed && isset($parsed['headline'])) {
                return array(
                    'headline' => $parsed['headline'],
                    'subheadline' => '',
                    'description' => $parsed['description'] ?? '',
                    'features' => $parsed['features'] ?? array(),
                    'cta' => $parsed['cta'] ?? 'Contact Us'
                );
            }
        }
        
        return false;
    }
    
    private static function generate_from_template($business_type, $goal, $product) {
        // If product is provided, generate custom content
        if ($product) {
            $product = sanitize_text_field($product);
            $headline = ucwords($product);
            $description = "We offer the best {$product} services. Quality guaranteed with customer satisfaction as our priority. Contact us today to learn more.";
            
            // Detect type from keywords
            if (preg_match('/restaurant|food|amala|suya|catering/i', $product)) {
                $benefits = array('Fresh ingredients daily', 'Fast delivery', 'Affordable prices', 'Authentic taste');
            } elseif (preg_match('/repair|phone|laptop|tech/i', $product)) {
                $benefits = array('Expert technicians', 'Quick turnaround', 'Warranty included', 'Genuine parts');
            } elseif (preg_match('/fashion|cloth|boutique|dress/i', $product)) {
                $benefits = array('Trendy designs', 'Quality fabrics', 'Fast delivery', 'Easy returns');
            } elseif (preg_match('/salon|beauty|spa|hair/i', $product)) {
                $benefits = array('Professional stylists', 'Premium products', 'Clean environment', 'Affordable rates');
            } elseif (preg_match('/real estate|property|house|land/i', $product)) {
                $benefits = array('Verified listings', 'Expert agents', 'Best locations', 'Flexible payment');
            } elseif (preg_match('/travel|tour|vacation|trip/i', $product)) {
                $benefits = array('All-inclusive packages', 'Expert guides', 'Best prices', 'Safe travel');
            } else {
                $benefits = array('Quality service', 'Affordable prices', 'Fast delivery', 'Customer support');
            }
            
            $cta = ($goal === 'sales') ? 'Buy Now' : (($goal === 'bookings') ? 'Book Now' : 'Contact Us');
            
            return array(
                'headline' => $headline,
                'subheadline' => "Best {$product} in town",
                'description' => $description,
                'features' => $benefits,
                'cta' => $cta
            );
        }
        
        // Default templates
        $templates = array(
            'restaurant' => array(
                'headline' => 'Delicious Food, Delivered Fresh',
                'subheadline' => 'Experience authentic flavors',
                'description' => 'We serve the finest dishes prepared with fresh ingredients. Quality taste guaranteed.',
                'features' => array('Fresh ingredients', 'Fast delivery', 'Easy ordering', 'Special discounts'),
                'cta' => 'Order Now'
            ),
            'consulting' => array(
                'headline' => 'Grow Your Business',
                'subheadline' => 'Expert consulting services',
                'description' => 'We help businesses reach their full potential with proven strategies.',
                'features' => array('Experienced team', 'Proven strategies', 'Custom solutions', 'Ongoing support'),
                'cta' => 'Get Started'
            ),
        );
        
        return $templates[$business_type] ?? $templates['consulting'];
    }
}
