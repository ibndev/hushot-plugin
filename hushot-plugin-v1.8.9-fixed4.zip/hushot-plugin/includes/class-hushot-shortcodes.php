<?php
/**
 * Hushot Shortcodes v1.8.9 - Complete Feature Set
 */
if (!defined('ABSPATH')) exit;

class Hushot_Shortcodes {
    
    public static function init() {
        $shortcodes = array(
            'hushot_home', 'hushot_login', 'hushot_register', 'hushot_forgot_password', 'hushot_reset_password',
            'hushot_dashboard', 'hushot_my_pages', 'hushot_create_page', 'hushot_edit_page',
            'hushot_templates', 'hushot_ai_generator', 'hushot_ai_image', 'hushot_addons', 'hushot_my_account',
            'hushot_billing', 'hushot_analytics', 'hushot_cancel_subscription', 'hushot_pricing',
            'hushot_checkout', 'hushot_order_confirmation', 'hushot_leads',
            'hushot_ads_dashboard', 'hushot_ads_promote', 'hushot_support',
            'hushot_install_app', 'hushot_visual_builder',
            'hushot_seller_dashboard', 'hushot_seller_setup',
        );
        foreach ($shortcodes as $sc) {
            add_shortcode($sc, array(__CLASS__, str_replace('hushot_', 'render_', $sc)));
        }
        add_action('wp_head', array(__CLASS__, 'output_styles'), 1);
    }
    
    public static function output_styles() {
        if (!self::is_hushot_page()) return;
        $purl = HUSHOT_PLUGIN_URL;
        ?>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0, user-scalable=yes">
        <!-- PWA Support -->
        <meta name="mobile-web-app-capable" content="yes">
        <meta name="apple-mobile-web-app-capable" content="yes">
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
        <meta name="apple-mobile-web-app-title" content="Hushot">
        <meta name="application-name" content="Hushot">
        <meta name="theme-color" content="#F7931E">
        <meta name="msapplication-TileColor" content="#1a1a1a">
        <meta name="msapplication-TileImage" content="<?php echo $purl; ?>assets/images/icon-144.png">
        <link rel="manifest" href="<?php echo $purl; ?>manifest.json" crossorigin="use-credentials">
        <!-- Favicon -->
        <link rel="icon" type="image/png" sizes="32x32" href="<?php echo $purl; ?>assets/images/icon-96.png">
        <link rel="icon" type="image/png" sizes="16x16" href="<?php echo $purl; ?>assets/images/icon-72.png">
        <!-- Apple Touch Icons - iOS uses these for home screen -->
        <link rel="apple-touch-icon" href="<?php echo $purl; ?>assets/images/apple-touch-icon.png">
        <link rel="apple-touch-icon" sizes="72x72" href="<?php echo $purl; ?>assets/images/icon-72.png">
        <link rel="apple-touch-icon" sizes="96x96" href="<?php echo $purl; ?>assets/images/icon-96.png">
        <link rel="apple-touch-icon" sizes="128x128" href="<?php echo $purl; ?>assets/images/icon-128.png">
        <link rel="apple-touch-icon" sizes="144x144" href="<?php echo $purl; ?>assets/images/icon-144.png">
        <link rel="apple-touch-icon" sizes="152x152" href="<?php echo $purl; ?>assets/images/icon-152.png">
        <link rel="apple-touch-icon" sizes="180x180" href="<?php echo $purl; ?>assets/images/icon-180.png">
        <link rel="apple-touch-icon" sizes="192x192" href="<?php echo $purl; ?>assets/images/icon-192.png">
        <!-- Apple Splash Screen -->
        <link rel="apple-touch-startup-image" href="<?php echo $purl; ?>assets/images/hushot-splash.png">
        <style id="hushot-override">
        .site-header,.site-footer,#masthead,#colophon,header.header,footer.footer,.main-header,.main-footer,.page-header,.entry-header,.breadcrumb,nav#site-navigation,.main-navigation,aside.sidebar,#wpadminbar,.elementor-location-header,.elementor-location-footer,.saasplate-header,.theme-header,.page-title-section,.page-hero,.hero-section,.title-bar,.page-title-bar,.breadcrumb-area,header[class*="header"],[class*="page-title"],[class*="page-header"],[class*="hero-"]{display:none!important;height:0!important;min-height:0!important;padding:0!important;margin:0!important;visibility:hidden!important;overflow:hidden!important;}
        html,body{margin:0!important;padding:0!important;padding-top:0!important;margin-top:0!important;}
        .site-content,.main-content,#content,main,.site-main,#primary,.content-area,article.page,.entry-content,.page-content{margin:0!important;padding:0!important;max-width:100%!important;width:100%!important;float:none!important;}
        </style>
        <style id="hushot-css">
        /* === RESET & BASE === */
        *,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
        html,body{min-height:100vh;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif!important;font-size:14px;line-height:1.5;color:#1a1a2e;background:#f5f5f5!important;-webkit-font-smoothing:antialiased;-webkit-text-size-adjust:100%;}
        
        /* === AUTH PAGES === */
        .hs-auth{min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px;background:linear-gradient(135deg,#1a1a2e 0%,#2C2F3E 100%);}
        .hs-auth-box{width:100%;max-width:420px;background:#fff;border-radius:24px;padding:40px 32px;box-shadow:0 25px 80px rgba(0,0,0,0.4);}
        .hs-auth-logo{text-align:center;margin-bottom:24px;}
        .hs-auth-logo span{font-size:40px;}
        .hs-auth-box h1{font-size:28px;font-weight:800;text-align:center;margin-bottom:8px;color:#1a1a2e;letter-spacing:-0.5px;}
        .hs-auth-box .sub{font-size:15px;color:#666;text-align:center;margin-bottom:32px;}
        .hs-auth-box .foot{text-align:center;margin-top:24px;font-size:14px;color:#666;}
        .hs-auth-box .foot a{color:#F7931E;font-weight:600;text-decoration:none;}
        
        /* === MESSAGES === */
        .hs-msg{padding:14px 18px;border-radius:12px;font-size:14px;margin-bottom:16px;display:none;}
        .hs-msg.ok{display:block;background:#d1fae5;color:#065f46;border:1px solid #a7f3d0;}
        .hs-msg.err{display:block;background:#fee2e2;color:#991b1b;border:1px solid #fecaca;}
        
        /* === FORM FIELDS === */
        .hs-fld{margin-bottom:16px;}
        .hs-fld label{display:block;font-size:13px;font-weight:600;margin-bottom:6px;color:#374151;}
        .hs-fld input,.hs-fld select,.hs-fld textarea{width:100%;padding:12px 14px;font-size:14px;border:2px solid #e5e7eb;border-radius:10px;font-family:inherit;background:#fff;transition:all 0.2s;}
        .hs-fld input:focus,.hs-fld select:focus,.hs-fld textarea:focus{outline:none;border-color:#F7931E;box-shadow:0 0 0 3px rgba(247,147,30,0.1);}
        .hs-fld textarea{resize:vertical;min-height:80px;}
        .hs-row{display:flex;gap:12px;}
        .hs-row .hs-fld{flex:1;min-width:0;}
        @media(max-width:480px){.hs-row{flex-direction:column;gap:0;}}
        
        /* === BUTTONS === */
        .hs-btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;padding:12px 20px;font-size:14px;font-weight:600;border:none;border-radius:10px;cursor:pointer;text-decoration:none;background:#2C2F3E;color:#fff!important;font-family:inherit;transition:all 0.2s;-webkit-tap-highlight-color:transparent;}
        .hs-btn:hover{opacity:0.9;transform:translateY(-1px);}
        .hs-btn-p{background:linear-gradient(135deg,#F7931E 0%,#e67e00 100%);}
        .hs-btn-full{width:100%;}
        .hs-btn-sm{padding:10px 16px;font-size:13px;}
        .hs-btn-xs{padding:6px 12px;font-size:11px;border-radius:8px;}
        .hs-btn .ld{display:none;}
        .hs-btn.loading .tx{display:none;}
        .hs-btn.loading .ld{display:inline;}
        
        /* === APP LAYOUT - DESKTOP FIRST === */
        .hs-app{display:flex;min-height:100vh;background:#f5f5f5!important;}
        
        /* Sidebar - Fixed Desktop */
        .hs-nav{width:220px;background:#1a1a2e!important;position:fixed;top:0;left:0;bottom:0;z-index:1000;display:flex;flex-direction:column;overflow-y:auto;overflow-x:hidden;}
        .hs-nav-brand{padding:16px 20px;display:flex;align-items:center;gap:10px;border-bottom:1px solid rgba(255,255,255,0.08);}
        .hs-nav-brand img{width:32px;height:32px;border-radius:8px;}
        .hs-nav-brand span{font-size:18px;font-weight:700;color:#fff!important;letter-spacing:-0.5px;}
        .hs-nav-links{flex:1;padding:12px 0;}
        .hs-nav-links a{display:flex;align-items:center;gap:10px;padding:11px 20px;color:rgba(255,255,255,0.8)!important;text-decoration:none!important;font-size:13px;font-weight:500;cursor:pointer;background:transparent;transition:all 0.15s;-webkit-tap-highlight-color:transparent;}
        .hs-nav-links a:hover{background:rgba(255,255,255,0.08)!important;color:#fff!important;}
        .hs-nav-links a.on{background:rgba(247,147,30,0.15)!important;color:#F7931E!important;border-left:3px solid #F7931E;padding-left:17px;}
        .hs-nav-links .sep{height:1px;background:rgba(255,255,255,0.08);margin:8px 16px;}
        .hs-nav-links .lbl{font-size:10px;font-weight:700;color:rgba(255,255,255,0.4);padding:16px 20px 8px;text-transform:uppercase;letter-spacing:0.5px;}
        .hs-nav-foot{padding:16px 20px;border-top:1px solid rgba(255,255,255,0.08);margin-top:auto;}
        .hs-nav-user{display:flex;align-items:center;gap:10px;margin-bottom:8px;}
        .hs-nav-avatar{width:32px;height:32px;background:linear-gradient(135deg,#F7931E,#e67e00);color:#fff;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:700;}
        .hs-nav-name{color:#fff!important;font-size:13px;font-weight:600;}
        .hs-nav-plan{font-size:10px;color:rgba(255,255,255,0.5);text-transform:uppercase;}
        .hs-nav-logout{color:rgba(255,255,255,0.6)!important;font-size:12px;text-decoration:none!important;display:inline-flex;align-items:center;gap:6px;margin-top:4px;}
        .hs-nav-logout:hover{color:#F7931E!important;}
        
        /* Main Content - Desktop */
        .hs-main{flex:1;margin-left:220px!important;min-height:100vh;display:flex;flex-direction:column;background:#f5f5f5!important;width:calc(100% - 220px)!important;}
        .hs-head{padding:20px 24px 8px;background:#f5f5f5;}
        .hs-head h1{font-size:20px;font-weight:700;color:#1a1a2e;margin:0;line-height:1.3;}
        .hs-body{padding:0 24px 24px;flex:1;}
        
        /* Cards */
        .hs-card{background:#fff;border-radius:12px;padding:20px;margin-bottom:16px;box-shadow:0 1px 3px rgba(0,0,0,0.06);}
        .hs-empty{text-align:center;padding:40px 20px;color:#6b7280;font-size:14px;background:#fff;border-radius:12px;}
        
        /* Mobile Menu Button */
        #hs-menu{display:none;position:fixed;top:12px;right:12px;z-index:1100;width:44px;height:44px;background:linear-gradient(135deg,#F7931E,#e67e00);color:#fff;border:none;border-radius:12px;font-size:20px;cursor:pointer;align-items:center;justify-content:center;box-shadow:0 4px 12px rgba(247,147,30,0.3);-webkit-tap-highlight-color:transparent;}
        .hs-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,0.5);z-index:900;-webkit-tap-highlight-color:transparent;}
        .hs-overlay.show{display:block;}
        
        /* === MOBILE RESPONSIVE === */
        @media(max-width:768px){
            .hs-nav{left:-280px;width:280px;transition:left 0.3s cubic-bezier(0.4,0,0.2,1);z-index:1000;-webkit-overflow-scrolling:touch;}
            .hs-nav.open{left:0;}
            .hs-main{margin-left:0!important;width:100%!important;}
            #hs-menu{display:flex;}
            .hs-head{padding:60px 16px 8px;}
            .hs-head h1{font-size:18px;}
            .hs-body{padding:0 16px 16px;}
        }
        </style>
        <?php
    }
    
    private static function is_hushot_page() {
        global $post;
        // Ensure we have a post object
        if (!$post) {
            return false;
        }

        // Primary check: look for a Hushot shortcode in the content
        if (strpos($post->post_content, '[hushot_') !== false) {
            return true;
        }

        /*
         * Fallback: Some Hushot pages (e.g. Seller Dashboard/Setup) may not contain a shortcode in the
         * content (depending on migration or editor usage). In such cases, we treat the page as a
         * Hushot page if it has certain meta fields (builder type or sections) or matches known slugs.
         */
        $slug = $post->post_name;
        $known_slugs = array(
            'dashboard','my-pages','create-page','visual-builder','ai-builder','ai-generator','templates',
            'leads','analytics','ads-dashboard','ads-promote','seller-dashboard','seller-setup',
            'my-account','billing','pricing','support','install-app','ai-image','checkout','order-confirmation'
        );
        // Check slug match
        if (in_array($slug, $known_slugs, true)) {
            return true;
        }
        // Check meta markers for visual builder pages
        if (get_post_meta($post->ID, '_hushot_sections', true) || get_post_meta($post->ID, '_hushot_builder_type', true)) {
            return true;
        }
        return false;
    }

    public static function get_more_styles() {
        ?>
        <style>
        .hs-block{background:#fff;border-radius:10px;margin-bottom:10px;box-shadow:0 2px 6px rgba(0,0,0,0.04);overflow:hidden;}
        .hs-block-head{display:flex;align-items:center;gap:8px;padding:12px 14px;cursor:pointer;background:#fafafa;border-bottom:1px solid #eee;user-select:none;}
        .hs-block-ico{font-size:16px;}
        .hs-block-title{flex:1;font-size:13px;font-weight:600;color:#333;}
        .hs-block-body{display:none;padding:14px;}
        .hs-block.open .hs-block-body{display:block;}
        .hs-block-acts{display:flex;gap:4px;}
        .hs-block-acts button{width:26px;height:26px;border:none;background:#e5e7eb;border-radius:5px;cursor:pointer;font-size:12px;display:flex;align-items:center;justify-content:center;}
        .hs-block-acts .rem{background:#fee2e2!important;color:#dc2626!important;}
        .hs-block-acts .mv-up,.hs-block-acts .mv-dn{background:#dbeafe;color:#2563eb;font-weight:bold;}
        .hs-img-box{border:2px dashed #ddd;border-radius:8px;padding:16px;text-align:center;cursor:pointer;position:relative;min-height:70px;display:flex;align-items:center;justify-content:center;flex-direction:column;}
        .hs-img-box:hover{border-color:#FF553E;background:#fff5f4;}
        .hs-img-box input{position:absolute;inset:0;opacity:0;cursor:pointer;}
        .hs-img-box img{max-width:100%;max-height:100px;border-radius:6px;}
        .hs-img-box .ico{font-size:24px;color:#999;}
        .hs-img-box p{font-size:11px;color:#999;margin:6px 0 0;}
        .hs-picker{background:#fff;border-radius:10px;padding:14px;margin-bottom:14px;box-shadow:0 2px 6px rgba(0,0,0,0.04);}
        .hs-picker-title{font-size:10px;font-weight:600;color:#888;margin-bottom:10px;text-transform:uppercase;}
        /* Slightly smaller Add Section grid */
        .hs-picker-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(58px,1fr));gap:6px;}
        .hs-pick{background:#f8f9fa;border:2px solid #e5e7eb;border-radius:10px;padding:8px 5px;text-align:center;cursor:pointer;position:relative;transition:all 0.15s;}
        .hs-pick:hover{border-color:#FF553E;background:#fff5f4;}
        .hs-pick:active{transform:scale(0.95);}
        .hs-pick .ico{font-size:20px;display:block;margin-bottom:3px;}
        .hs-pick .txt{font-size:9px;color:#555;font-weight:500;}
        .hs-pick-num{position:absolute;top:3px;left:3px;width:16px;height:16px;background:#667eea;color:#fff;font-size:9px;font-weight:700;border-radius:50%;display:flex;align-items:center;justify-content:center;line-height:1;}
        .hs-pick.locked{opacity:0.5;cursor:not-allowed;}
        .hs-pick.locked::after{content:'🔒';position:absolute;top:2px;right:2px;font-size:8px;}
        .hs-pick.locked:hover{border-color:#e5e7eb;background:#f8f9fa;}
        .hs-price-inline{display:flex;align-items:center;gap:10px;flex-wrap:wrap;}
        .hs-price-inline .hs-fld{margin-bottom:0;flex:1;min-width:70px;}
        .hs-price-inline input,.hs-price-inline select{padding:8px 10px;font-size:12px;}
        .hs-pg{display:flex;align-items:center;gap:10px;background:#fff;padding:12px;border-radius:10px;margin-bottom:8px;box-shadow:0 2px 6px rgba(0,0,0,0.04);}
        .hs-pg-ico{font-size:20px;}
        .hs-pg-info{flex:1;min-width:0;}
        .hs-pg-info strong{display:block;font-size:13px;font-weight:600;color:#1a1a1a;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
        .hs-pg-info small{color:#888;font-size:11px;}
        .hs-pg-btns{display:flex;gap:6px;flex-shrink:0;}
        .hs-pg-btns a,.hs-pg-btns button{padding:6px 10px;font-size:11px;border-radius:6px;text-decoration:none;border:none;cursor:pointer;font-weight:500;}
        .hs-pg-btns a{background:#e5e7eb;color:#333!important;}
        .hs-pg-btns button{background:#fee2e2;color:#dc2626;}
        .hs-tpls{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:12px;}
        .hs-tpl{background:#fff;border-radius:10px;overflow:hidden;box-shadow:0 2px 6px rgba(0,0,0,0.04);}
        .hs-tpl-img{height:90px;background-size:cover;background-position:center;}
        .hs-tpl-body{padding:10px 12px;}
        .hs-tpl-info{margin-bottom:8px;}
        .hs-tpl-info strong{display:block;font-size:12px;font-weight:600;margin-bottom:2px;}
        .hs-tpl-info small{font-size:10px;color:#888;}
        .hs-tpl-badge{display:inline-block;font-size:8px;padding:2px 5px;border-radius:8px;margin-top:2px;font-weight:600;}
        .hs-tpl-badge.free{background:#d1fae5;color:#065f46;}
        .hs-tpl-badge.essential{background:#dbeafe;color:#1e40af;}
        .hs-tpl-badge.premium{background:#fef3c7;color:#92400e;}
        .hs-tpl-use{display:inline-block;padding:5px 10px;font-size:10px;background:#FF553E;color:#fff!important;border:none;border-radius:5px;cursor:pointer;font-weight:500;text-decoration:none;}
        .hs-tpl.locked .hs-tpl-use{background:#e5e7eb!important;color:#666!important;}
        @media(max-width:480px){.hs-tpls{grid-template-columns:repeat(2,1fr);gap:8px;}.hs-tpl-img{height:70px;}}
        .hs-stats{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-bottom:12px;}
        .hs-stats-4{grid-template-columns:repeat(4,1fr);}
        @media(max-width:480px){.hs-stats-4{grid-template-columns:repeat(2,1fr);}}
        .hs-stat{background:#fff;padding:14px 10px;border-radius:10px;text-align:center;box-shadow:0 2px 6px rgba(0,0,0,0.04);}
        .hs-stat-link{text-decoration:none!important;transition:transform 0.2s,box-shadow 0.2s;cursor:pointer;display:block;}
        .hs-stat-link:hover{transform:translateY(-2px);box-shadow:0 4px 12px rgba(0,0,0,0.1);}
        .hs-stat-num{font-size:24px;font-weight:700;color:#FF553E;line-height:1;}
        .hs-stat-lbl{font-size:10px;color:#888;margin-top:3px;}
        .hs-quick{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;}
        .hs-quick a{display:flex;flex-direction:column;align-items:center;gap:4px;background:#fff;padding:12px 6px;border-radius:10px;text-decoration:none!important;color:#333!important;font-size:10px;font-weight:500;box-shadow:0 2px 6px rgba(0,0,0,0.04);}
        .hs-quick a .ico{font-size:20px;}
        .hs-recent-pages{margin-top:14px;}
        .hs-recent-pages h4{font-size:11px;color:#888;font-weight:600;margin-bottom:8px;text-transform:uppercase;}
        .hs-recent-item{display:flex;align-items:center;gap:8px;padding:8px 10px;background:#f9fafb;border-radius:6px;margin-bottom:6px;}
        .hs-recent-item>span{flex:1;font-size:12px;font-weight:500;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
        .hs-recent-btns{display:flex;gap:4px;flex-shrink:0;}
        .hs-rbtn{width:28px;height:28px;border:none;background:#e5e7eb;border-radius:6px;cursor:pointer;font-size:12px;display:flex;align-items:center;justify-content:center;text-decoration:none!important;color:#333!important;}
        .hs-rbtn:hover{background:#d1d5db;}
        .hs-pricing{padding:24px 16px;text-align:center;max-width:900px;margin:0 auto;}
        .hs-pricing h1{font-size:28px;font-weight:800;margin-bottom:8px;color:#1a1a1a;}
        .hs-pricing>p{color:#666;margin-bottom:24px;font-size:14px;}
        .hs-pricing-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:16px;}
        .hs-price-card{background:#fff;border-radius:16px;padding:24px 20px;text-align:left;box-shadow:0 4px 20px rgba(0,0,0,0.08);border:2px solid transparent;position:relative;}
        .hs-price-card.feat{border-color:#FF553E;}
        .hs-price-card.feat::before{content:'POPULAR';position:absolute;top:-12px;left:50%;transform:translateX(-50%);background:#FF553E;color:#fff;font-size:10px;font-weight:700;padding:4px 12px;border-radius:20px;}
        .hs-price-card h3{font-size:18px;font-weight:700;margin-bottom:4px;color:#1a1a1a;}
        .hs-price-amt{font-size:32px;font-weight:800;color:#1a1a1a;margin:8px 0;}
        .hs-price-amt span{font-size:14px;color:#888;font-weight:400;}
        .hs-price-card>p{font-size:13px;color:#666;margin:0 0 16px;}
        .hs-price-card ul{list-style:none;padding:0;margin:0 0 20px;}
        .hs-price-card li{font-size:13px;padding:8px 0;color:#555;display:flex;align-items:center;gap:8px;border-bottom:1px solid #f3f4f6;}
        .hs-price-card li::before{content:'✓';color:#10b981;font-weight:bold;font-size:12px;}
        .hs-bar-inputs{margin-top:10px;padding-top:10px;border-top:1px solid #eee;}
        .hs-leads{background:#fff;border-radius:10px;overflow:hidden;}
        .hs-leads table{width:100%;border-collapse:collapse;font-size:12px;}
        .hs-leads th,.hs-leads td{padding:10px 12px;text-align:left;border-bottom:1px solid #eee;}
        .hs-leads th{background:#fafafa;font-weight:600;font-size:11px;color:#666;text-transform:uppercase;}
        .hs-products-section{margin-top:12px;}
        .hs-product-item{background:#f9fafb;border-radius:8px;padding:12px;margin-bottom:10px;border:1px solid #e5e7eb;}
        .hs-product-row{display:flex;gap:10px;margin-bottom:8px;}
        .hs-product-img-box{width:80px;height:80px;border:2px dashed #ddd;border-radius:6px;display:flex;align-items:center;justify-content:center;cursor:pointer;position:relative;overflow:hidden;flex-shrink:0;}
        .hs-product-img-box img{width:100%;height:100%;object-fit:cover;}
        .hs-product-img-box input{position:absolute;inset:0;opacity:0;cursor:pointer;}
        .hs-product-fields{flex:1;min-width:0;}
        .hs-product-fields input,.hs-product-fields textarea,.hs-product-fields select{width:100%;padding:8px 10px;font-size:12px;border:1px solid #ddd;border-radius:6px;margin-bottom:6px;}
        .hs-product-prices{display:flex;gap:8px;}
        .hs-product-prices input{flex:1;}
        .hs-product-cta{display:flex;gap:6px;margin-top:4px;}
        .hs-product-cta select{width:auto;flex-shrink:0;}
        .hs-product-cta input{flex:1;}
        .hs-product-remove{background:#fee2e2;color:#dc2626;border:none;padding:4px 10px;border-radius:4px;font-size:10px;cursor:pointer;}
        .hs-product-limit{font-size:11px;color:#888;margin-top:8px;}
        .hs-ai-write{background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);color:#fff;border:none;padding:3px 8px;border-radius:4px;font-size:9px;cursor:pointer;margin-left:6px;font-weight:500;}
        .hs-ai-write:hover{opacity:0.9;}
        .hs-ai-write:disabled{opacity:0.5;cursor:wait;}
        .hs-ai-section{background:#f8f9fa;border-radius:10px;padding:14px;margin-bottom:14px;}
        .hs-ai-section h4{margin:0 0 10px;font-size:13px;color:#333;}
        .hs-ai-section input{width:100%;padding:10px;border:1px solid #ddd;border-radius:6px;margin-bottom:8px;}
        .hs-ai-section .hs-btn{width:100%;}
        </style>
        <?php
    }

    public static function render_login() {
        if (is_user_logged_in()) return '<script>window.location.href="'.esc_url(Hushot_Pages::get_page_url('dashboard')).'";</script>';
        ob_start();
        ?>
        <style>
        *{box-sizing:border-box;margin:0;padding:0;}
        html,body{min-height:100vh;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;background:linear-gradient(160deg,#0f0f23 0%,#1a1a2e 40%,#16213e 100%);overflow-x:hidden;}
        .auth-wrap{min-height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:20px;position:relative;}
        .auth-bg{position:absolute;top:0;left:0;right:0;bottom:0;overflow:hidden;pointer-events:none;}
        .auth-bg::before{content:'';position:absolute;top:-50%;left:-50%;width:200%;height:200%;background:radial-gradient(ellipse at 20% 80%,rgba(255,85,62,0.15) 0%,transparent 50%),radial-gradient(ellipse at 80% 20%,rgba(99,102,241,0.1) 0%,transparent 50%);}
        .auth-card{width:100%;max-width:400px;background:rgba(255,255,255,0.98);border-radius:28px;padding:44px 36px;position:relative;box-shadow:0 30px 60px rgba(0,0,0,0.4),0 0 0 1px rgba(255,255,255,0.1);backdrop-filter:blur(20px);}
        .auth-header{text-align:center;margin-bottom:36px;}
        .auth-logo{width:72px;height:72px;background:linear-gradient(135deg,#FF553E 0%,#ff7b5a 100%);border-radius:20px;display:flex;align-items:center;justify-content:center;margin:0 auto 20px;font-size:32px;box-shadow:0 12px 28px rgba(255,85,62,0.35);}
        .auth-title{font-size:26px;font-weight:800;color:#1a1a2e;margin-bottom:8px;letter-spacing:-0.5px;}
        .auth-sub{font-size:15px;color:#6b7280;line-height:1.5;}
        .auth-form .field{margin-bottom:20px;}
        .auth-form label{display:block;font-size:13px;font-weight:600;color:#374151;margin-bottom:8px;padding-left:4px;}
        .auth-form input{width:100%;padding:16px 18px;font-size:15px;border:2px solid #e5e7eb;border-radius:14px;background:#f9fafb;transition:all 0.25s ease;font-family:inherit;}
        .auth-form input:focus{outline:none;border-color:#FF553E;background:#fff;box-shadow:0 0 0 4px rgba(255,85,62,0.12);}
        .auth-form input::placeholder{color:#9ca3af;}
        .auth-btn{width:100%;padding:16px;font-size:16px;font-weight:700;color:#fff;background:linear-gradient(135deg,#FF553E 0%,#ff6b4a 100%);border:none;border-radius:14px;cursor:pointer;transition:all 0.25s ease;font-family:inherit;box-shadow:0 8px 24px rgba(255,85,62,0.35);margin-top:8px;}
        .auth-btn:hover{transform:translateY(-2px);box-shadow:0 12px 32px rgba(255,85,62,0.4);}
        .auth-btn:active{transform:translateY(0);}
        .auth-btn .ld{display:none;}
        .auth-btn.loading .tx{display:none;}
        .auth-btn.loading .ld{display:inline;}
        .auth-btn.loading{opacity:0.8;pointer-events:none;}
        .auth-msg{padding:14px 16px;border-radius:12px;font-size:14px;margin-bottom:20px;display:none;text-align:center;}
        .auth-msg.ok{display:block;background:linear-gradient(135deg,#d1fae5,#ecfdf5);color:#065f46;border:1px solid #a7f3d0;}
        .auth-msg.err{display:block;background:linear-gradient(135deg,#fee2e2,#fef2f2);color:#991b1b;border:1px solid #fecaca;}
        .auth-link{display:block;text-align:center;margin-top:16px;font-size:14px;color:#6b7280;}
        .auth-link a{color:#FF553E;font-weight:600;text-decoration:none;transition:color 0.2s;}
        .auth-link a:hover{color:#e04835;}
        .auth-divider{display:flex;align-items:center;margin:28px 0;color:#9ca3af;font-size:13px;}
        .auth-divider::before,.auth-divider::after{content:'';flex:1;height:1px;background:#e5e7eb;}
        .auth-divider span{padding:0 16px;font-weight:500;}
        .auth-footer{text-align:center;margin-top:28px;padding-top:24px;border-top:1px solid #f3f4f6;}
        .auth-footer p{font-size:14px;color:#6b7280;}
        .auth-footer a{color:#FF553E;font-weight:600;text-decoration:none;}
        @media(max-width:480px){
            .auth-card{padding:36px 24px;border-radius:24px;}
            .auth-logo{width:64px;height:64px;font-size:28px;}
            .auth-title{font-size:24px;}
        }
        </style>
        <div class="auth-wrap">
            <div class="auth-bg"></div>
            <div class="auth-card">
                <div class="auth-header">
                    <div class="auth-logo">🚀</div>
                    <h1 class="auth-title">Welcome Back</h1>
                    <p class="auth-sub">Sign in to your Hushot account</p>
                </div>
                <form class="auth-form" id="hs-login">
                    <div class="auth-msg hs-msg"></div>
                    <div class="field">
                        <label>Email Address</label>
                        <input type="text" name="login" required placeholder="you@example.com" autocomplete="email">
                    </div>
                    <div class="field">
                        <label>Password</label>
                        <input type="password" name="password" required placeholder="Enter your password" autocomplete="current-password">
                    </div>
                    <button type="submit" class="auth-btn"><span class="tx">Sign In</span><span class="ld">Signing in...</span></button>
                </form>
                <p class="auth-link"><a href="<?php echo esc_url(Hushot_Pages::get_page_url('forgot-password')); ?>">Forgot your password?</a></p>
                <div class="auth-divider"><span>New here?</span></div>
                <div class="auth-footer">
                    <p>Don't have an account? <a href="<?php echo esc_url(Hushot_Pages::get_page_url('register')); ?>">Create one free</a></p>
                </div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
    
    public static function render_register() {
        if (is_user_logged_in()) return '<script>window.location.href="'.esc_url(Hushot_Pages::get_page_url('dashboard')).'";</script>';
        ob_start();
        ?>
        <style>
        *{box-sizing:border-box;margin:0;padding:0;}
        html,body{min-height:100vh;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;background:linear-gradient(160deg,#0f0f23 0%,#1a1a2e 40%,#16213e 100%);overflow-x:hidden;}
        .auth-wrap{min-height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:20px;position:relative;}
        .auth-bg{position:absolute;top:0;left:0;right:0;bottom:0;overflow:hidden;pointer-events:none;}
        .auth-bg::before{content:'';position:absolute;top:-50%;left:-50%;width:200%;height:200%;background:radial-gradient(ellipse at 20% 80%,rgba(255,85,62,0.15) 0%,transparent 50%),radial-gradient(ellipse at 80% 20%,rgba(99,102,241,0.1) 0%,transparent 50%);}
        .auth-card{width:100%;max-width:440px;background:rgba(255,255,255,0.98);border-radius:28px;padding:40px 36px;position:relative;box-shadow:0 30px 60px rgba(0,0,0,0.4),0 0 0 1px rgba(255,255,255,0.1);backdrop-filter:blur(20px);}
        .auth-header{text-align:center;margin-bottom:32px;}
        .auth-logo{width:72px;height:72px;background:linear-gradient(135deg,#FF553E 0%,#ff7b5a 100%);border-radius:20px;display:flex;align-items:center;justify-content:center;margin:0 auto 20px;font-size:32px;box-shadow:0 12px 28px rgba(255,85,62,0.35);}
        .auth-title{font-size:26px;font-weight:800;color:#1a1a2e;margin-bottom:8px;letter-spacing:-0.5px;}
        .auth-sub{font-size:15px;color:#6b7280;line-height:1.5;}
        .auth-form .field{margin-bottom:18px;}
        .auth-form .field-row{display:flex;gap:12px;}
        .auth-form .field-row .field{flex:1;margin-bottom:18px;}
        .auth-form label{display:block;font-size:13px;font-weight:600;color:#374151;margin-bottom:8px;padding-left:4px;}
        .auth-form input{width:100%;padding:14px 16px;font-size:15px;border:2px solid #e5e7eb;border-radius:14px;background:#f9fafb;transition:all 0.25s ease;font-family:inherit;}
        .auth-form input:focus{outline:none;border-color:#FF553E;background:#fff;box-shadow:0 0 0 4px rgba(255,85,62,0.12);}
        .auth-form input::placeholder{color:#9ca3af;}
        .auth-btn{width:100%;padding:16px;font-size:16px;font-weight:700;color:#fff;background:linear-gradient(135deg,#FF553E 0%,#ff6b4a 100%);border:none;border-radius:14px;cursor:pointer;transition:all 0.25s ease;font-family:inherit;box-shadow:0 8px 24px rgba(255,85,62,0.35);margin-top:4px;}
        .auth-btn:hover{transform:translateY(-2px);box-shadow:0 12px 32px rgba(255,85,62,0.4);}
        .auth-btn:active{transform:translateY(0);}
        .auth-btn .ld{display:none;}
        .auth-btn.loading .tx{display:none;}
        .auth-btn.loading .ld{display:inline;}
        .auth-btn.loading{opacity:0.8;pointer-events:none;}
        .auth-btn-outline{background:transparent;border:2px solid #e5e7eb;color:#374151;box-shadow:none;}
        .auth-btn-outline:hover{background:#f9fafb;border-color:#d1d5db;transform:none;box-shadow:none;}
        .auth-msg{padding:14px 16px;border-radius:12px;font-size:14px;margin-bottom:20px;display:none;text-align:center;}
        .auth-msg.ok{display:block;background:linear-gradient(135deg,#d1fae5,#ecfdf5);color:#065f46;border:1px solid #a7f3d0;}
        .auth-msg.err{display:block;background:linear-gradient(135deg,#fee2e2,#fef2f2);color:#991b1b;border:1px solid #fecaca;}
        .auth-divider{display:flex;align-items:center;margin:24px 0;color:#9ca3af;font-size:13px;}
        .auth-divider::before,.auth-divider::after{content:'';flex:1;height:1px;background:#e5e7eb;}
        .auth-divider span{padding:0 16px;font-weight:500;}
        .auth-footer{text-align:center;margin-top:24px;}
        .auth-footer p{font-size:14px;color:#6b7280;}
        .auth-footer a{color:#FF553E;font-weight:600;text-decoration:none;}
        .otp-step{display:none;}
        .otp-step.active{display:block;}
        .otp-inputs{display:flex;gap:12px;justify-content:center;margin:24px 0;}
        .otp-inputs input{width:52px;height:60px;text-align:center;font-size:24px;font-weight:700;border:2px solid #e5e7eb;border-radius:14px;background:#f9fafb;transition:all 0.2s;}
        .otp-inputs input:focus{outline:none;border-color:#FF553E;background:#fff;box-shadow:0 0 0 4px rgba(255,85,62,0.12);}
        .otp-info{text-align:center;margin-bottom:20px;}
        .otp-info p{font-size:14px;color:#6b7280;margin-bottom:8px;}
        .otp-info strong{color:#1a1a2e;}
        .resend-link{text-align:center;margin-top:16px;font-size:13px;color:#6b7280;}
        .resend-link a{color:#FF553E;font-weight:600;text-decoration:none;cursor:pointer;}
        .resend-link a.disabled{color:#9ca3af;pointer-events:none;}
        @media(max-width:480px){
            .auth-card{padding:32px 20px;border-radius:24px;}
            .auth-logo{width:64px;height:64px;font-size:28px;}
            .auth-title{font-size:22px;}
            .auth-form .field-row{flex-direction:column;gap:0;}
            .otp-inputs input{width:44px;height:52px;font-size:20px;}
        }
        </style>
        <div class="auth-wrap">
            <div class="auth-bg"></div>
            <div class="auth-card">
                <!-- Step 1: Registration Form -->
                <div class="otp-step active" id="step-register">
                    <div class="auth-header">
                        <div class="auth-logo">🚀</div>
                        <h1 class="auth-title">Create Account</h1>
                        <p class="auth-sub">Start building landing pages in minutes</p>
                    </div>
                    <form class="auth-form" id="hs-register-form">
                        <div class="auth-msg hs-msg" id="reg-msg"></div>
                        <div class="field-row">
                            <div class="field">
                                <label>First Name</label>
                                <input type="text" name="first_name" id="reg-first" required placeholder="John">
                            </div>
                            <div class="field">
                                <label>Last Name</label>
                                <input type="text" name="last_name" id="reg-last" required placeholder="Doe">
                            </div>
                        </div>
                        <div class="field">
                            <label>Email Address</label>
                            <input type="email" name="email" id="reg-email" required placeholder="john@example.com">
                        </div>
                        <div class="field">
                            <label>WhatsApp Number</label>
                            <input type="tel" name="phone" id="reg-phone" required placeholder="+234 800 000 0000">
                        </div>
                        <div class="field">
                            <label>Password</label>
                            <input type="password" name="password" id="reg-pass" required minlength="6" placeholder="Min 6 characters">
                        </div>
                        <button type="submit" class="auth-btn" id="reg-btn"><span class="tx">Continue</span><span class="ld">Sending code...</span></button>
                    </form>
                    <div class="auth-divider"><span>Already have an account?</span></div>
                    <div class="auth-footer">
                        <p><a href="<?php echo esc_url(Hushot_Pages::get_page_url('login')); ?>">Sign in instead</a></p>
                    </div>
                </div>
                
                <!-- Step 2: OTP Verification -->
                <div class="otp-step" id="step-otp">
                    <div class="auth-header">
                        <div class="auth-logo">🔐</div>
                        <h1 class="auth-title">Verify Email</h1>
                        <p class="auth-sub">We sent a 6-digit code to your email</p>
                    </div>
                    <div class="otp-info">
                        <p>Enter the code sent to</p>
                        <strong id="otp-email-display"></strong>
                    </div>
                    <div class="auth-msg hs-msg" id="otp-msg"></div>
                    <form class="auth-form" id="hs-otp-form">
                        <div class="otp-inputs">
                            <input type="text" maxlength="1" class="otp-input" data-index="0" inputmode="numeric" pattern="[0-9]">
                            <input type="text" maxlength="1" class="otp-input" data-index="1" inputmode="numeric" pattern="[0-9]">
                            <input type="text" maxlength="1" class="otp-input" data-index="2" inputmode="numeric" pattern="[0-9]">
                            <input type="text" maxlength="1" class="otp-input" data-index="3" inputmode="numeric" pattern="[0-9]">
                            <input type="text" maxlength="1" class="otp-input" data-index="4" inputmode="numeric" pattern="[0-9]">
                            <input type="text" maxlength="1" class="otp-input" data-index="5" inputmode="numeric" pattern="[0-9]">
                        </div>
                        <button type="submit" class="auth-btn" id="otp-btn"><span class="tx">Verify & Create Account</span><span class="ld">Verifying...</span></button>
                    </form>
                    <div class="resend-link">
                        <span>Didn't receive the code? </span>
                        <a id="resend-otp" class="disabled">Resend (<span id="resend-timer">60</span>s)</a>
                    </div>
                    <div style="margin-top:20px;text-align:center;">
                        <button type="button" class="auth-btn auth-btn-outline" onclick="document.getElementById('step-register').classList.add('active');document.getElementById('step-otp').classList.remove('active');" style="padding:12px 20px;font-size:14px;">← Back to form</button>
                    </div>
                </div>
            </div>
        </div>
        <script>
        (function(){
            var regData = {};
            var otpToken = '';
            var resendTimer = null;
            
            // OTP input handling
            document.querySelectorAll('.otp-input').forEach(function(input, idx, inputs) {
                input.addEventListener('input', function(e) {
                    this.value = this.value.replace(/[^0-9]/g, '');
                    if (this.value && idx < 5) inputs[idx + 1].focus();
                    if (idx === 5 && this.value) checkOtpComplete();
                });
                input.addEventListener('keydown', function(e) {
                    if (e.key === 'Backspace' && !this.value && idx > 0) inputs[idx - 1].focus();
                });
                input.addEventListener('paste', function(e) {
                    e.preventDefault();
                    var paste = (e.clipboardData || window.clipboardData).getData('text').replace(/[^0-9]/g, '').slice(0, 6);
                    paste.split('').forEach(function(char, i) { if (inputs[i]) inputs[i].value = char; });
                    if (paste.length === 6) checkOtpComplete();
                });
            });
            
            function checkOtpComplete() {
                var otp = '';
                document.querySelectorAll('.otp-input').forEach(function(i) { otp += i.value; });
                if (otp.length === 6) document.getElementById('hs-otp-form').dispatchEvent(new Event('submit'));
            }
            
            // Step 1: Register form
            document.getElementById('hs-register-form').addEventListener('submit', function(e) {
                e.preventDefault();
                var btn = document.getElementById('reg-btn');
                var msg = document.getElementById('reg-msg');
                btn.classList.add('loading');
                msg.className = 'auth-msg hs-msg';
                
                regData = {
                    first_name: document.getElementById('reg-first').value,
                    last_name: document.getElementById('reg-last').value,
                    email: document.getElementById('reg-email').value,
                    phone: document.getElementById('reg-phone').value,
                    password: document.getElementById('reg-pass').value
                };
                
                // Send OTP
                fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: 'action=hushot_send_otp&email=' + encodeURIComponent(regData.email) + '&phone=' + encodeURIComponent(regData.phone)
                }).then(r => r.json()).then(function(res) {
                    btn.classList.remove('loading');
                    if (res.success) {
                        otpToken = res.data.token;
                        document.getElementById('otp-email-display').textContent = regData.email;
                        document.getElementById('step-register').classList.remove('active');
                        document.getElementById('step-otp').classList.add('active');
                        startResendTimer();
                        document.querySelector('.otp-input').focus();
                    } else {
                        msg.className = 'auth-msg hs-msg err';
                        msg.textContent = res.data?.message || 'Failed to send code';
                    }
                }).catch(function() {
                    btn.classList.remove('loading');
                    msg.className = 'auth-msg hs-msg err';
                    msg.textContent = 'Connection error. Please try again.';
                });
            });
            
            // Step 2: OTP verification
            document.getElementById('hs-otp-form').addEventListener('submit', function(e) {
                e.preventDefault();
                var btn = document.getElementById('otp-btn');
                var msg = document.getElementById('otp-msg');
                var otp = '';
                document.querySelectorAll('.otp-input').forEach(function(i) { otp += i.value; });
                
                if (otp.length !== 6) {
                    msg.className = 'auth-msg hs-msg err';
                    msg.textContent = 'Please enter all 6 digits';
                    return;
                }
                
                btn.classList.add('loading');
                msg.className = 'auth-msg hs-msg';
                
                // Verify OTP and register
                fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: 'action=hushot_register&otp=' + otp + '&otp_token=' + otpToken + 
                          '&first_name=' + encodeURIComponent(regData.first_name) +
                          '&last_name=' + encodeURIComponent(regData.last_name) +
                          '&email=' + encodeURIComponent(regData.email) +
                          '&phone=' + encodeURIComponent(regData.phone) +
                          '&password=' + encodeURIComponent(regData.password)
                }).then(r => r.json()).then(function(res) {
                    btn.classList.remove('loading');
                    if (res.success) {
                        msg.className = 'auth-msg hs-msg ok';
                        msg.textContent = res.data?.message || 'Account created!';
                        setTimeout(function() {
                            window.location.href = res.data?.redirect || '<?php echo esc_url(Hushot_Pages::get_page_url('dashboard')); ?>';
                        }, 1000);
                    } else {
                        msg.className = 'auth-msg hs-msg err';
                        msg.textContent = res.data?.message || 'Invalid code';
                    }
                }).catch(function() {
                    btn.classList.remove('loading');
                    msg.className = 'auth-msg hs-msg err';
                    msg.textContent = 'Connection error. Please try again.';
                });
            });
            
            // Resend OTP
            function startResendTimer() {
                var seconds = 60;
                var timerEl = document.getElementById('resend-timer');
                var linkEl = document.getElementById('resend-otp');
                linkEl.classList.add('disabled');
                
                clearInterval(resendTimer);
                resendTimer = setInterval(function() {
                    seconds--;
                    timerEl.textContent = seconds;
                    if (seconds <= 0) {
                        clearInterval(resendTimer);
                        linkEl.classList.remove('disabled');
                        linkEl.innerHTML = 'Resend code';
                    }
                }, 1000);
            }
            
            document.getElementById('resend-otp').addEventListener('click', function(e) {
                if (this.classList.contains('disabled')) return;
                var self = this;
                self.innerHTML = 'Sending...';
                
                fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: 'action=hushot_send_otp&email=' + encodeURIComponent(regData.email) + '&phone=' + encodeURIComponent(regData.phone)
                }).then(r => r.json()).then(function(res) {
                    if (res.success) {
                        otpToken = res.data.token;
                        document.getElementById('otp-msg').className = 'auth-msg hs-msg ok';
                        document.getElementById('otp-msg').textContent = 'New code sent!';
                        self.innerHTML = 'Resend (<span id="resend-timer">60</span>s)';
                        startResendTimer();
                    } else {
                        self.innerHTML = 'Resend code';
                        document.getElementById('otp-msg').className = 'auth-msg hs-msg err';
                        document.getElementById('otp-msg').textContent = res.data?.message || 'Failed to send';
                    }
                });
            });
        })();
        </script>
        <?php
        return ob_get_clean();
    }
    
    public static function render_forgot_password() {
        ob_start();
        ?>
        <style>
        *{box-sizing:border-box;margin:0;padding:0;}
        html,body{min-height:100vh;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;background:linear-gradient(160deg,#0f0f23 0%,#1a1a2e 40%,#16213e 100%);overflow-x:hidden;}
        .auth-wrap{min-height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:20px;position:relative;}
        .auth-bg{position:absolute;top:0;left:0;right:0;bottom:0;overflow:hidden;pointer-events:none;}
        .auth-bg::before{content:'';position:absolute;top:-50%;left:-50%;width:200%;height:200%;background:radial-gradient(ellipse at 20% 80%,rgba(255,85,62,0.15) 0%,transparent 50%),radial-gradient(ellipse at 80% 20%,rgba(99,102,241,0.1) 0%,transparent 50%);}
        .auth-card{width:100%;max-width:400px;background:rgba(255,255,255,0.98);border-radius:28px;padding:44px 36px;position:relative;box-shadow:0 30px 60px rgba(0,0,0,0.4),0 0 0 1px rgba(255,255,255,0.1);backdrop-filter:blur(20px);}
        .auth-header{text-align:center;margin-bottom:36px;}
        .auth-logo{width:72px;height:72px;background:linear-gradient(135deg,#6366f1 0%,#8b5cf6 100%);border-radius:20px;display:flex;align-items:center;justify-content:center;margin:0 auto 20px;font-size:32px;box-shadow:0 12px 28px rgba(99,102,241,0.35);}
        .auth-title{font-size:26px;font-weight:800;color:#1a1a2e;margin-bottom:8px;letter-spacing:-0.5px;}
        .auth-sub{font-size:15px;color:#6b7280;line-height:1.5;}
        .auth-form .field{margin-bottom:20px;}
        .auth-form label{display:block;font-size:13px;font-weight:600;color:#374151;margin-bottom:8px;padding-left:4px;}
        .auth-form input{width:100%;padding:16px 18px;font-size:15px;border:2px solid #e5e7eb;border-radius:14px;background:#f9fafb;transition:all 0.25s ease;font-family:inherit;}
        .auth-form input:focus{outline:none;border-color:#6366f1;background:#fff;box-shadow:0 0 0 4px rgba(99,102,241,0.12);}
        .auth-form input::placeholder{color:#9ca3af;}
        .auth-btn{width:100%;padding:16px;font-size:16px;font-weight:700;color:#fff;background:linear-gradient(135deg,#6366f1 0%,#8b5cf6 100%);border:none;border-radius:14px;cursor:pointer;transition:all 0.25s ease;font-family:inherit;box-shadow:0 8px 24px rgba(99,102,241,0.35);margin-top:8px;}
        .auth-btn:hover{transform:translateY(-2px);box-shadow:0 12px 32px rgba(99,102,241,0.4);}
        .auth-btn:active{transform:translateY(0);}
        .auth-btn .ld{display:none;}
        .auth-btn.loading .tx{display:none;}
        .auth-btn.loading .ld{display:inline;}
        .auth-btn.loading{opacity:0.8;pointer-events:none;}
        .auth-msg{padding:14px 16px;border-radius:12px;font-size:14px;margin-bottom:20px;display:none;text-align:center;}
        .auth-msg.ok{display:block;background:linear-gradient(135deg,#d1fae5,#ecfdf5);color:#065f46;border:1px solid #a7f3d0;}
        .auth-msg.err{display:block;background:linear-gradient(135deg,#fee2e2,#fef2f2);color:#991b1b;border:1px solid #fecaca;}
        .auth-back{display:flex;align-items:center;justify-content:center;gap:8px;margin-top:24px;font-size:14px;color:#6b7280;text-decoration:none;transition:color 0.2s;}
        .auth-back:hover{color:#374151;}
        .auth-back svg{width:18px;height:18px;}
        @media(max-width:480px){
            .auth-card{padding:36px 24px;border-radius:24px;}
            .auth-logo{width:64px;height:64px;font-size:28px;}
            .auth-title{font-size:24px;}
        }
        </style>
        <div class="auth-wrap">
            <div class="auth-bg"></div>
            <div class="auth-card">
                <div class="auth-header">
                    <div class="auth-logo">🔐</div>
                    <h1 class="auth-title">Forgot Password?</h1>
                    <p class="auth-sub">No worries! Enter your email and we'll send you a reset link.</p>
                </div>
                <form class="auth-form" id="hs-forgot">
                    <div class="auth-msg hs-msg"></div>
                    <div class="field">
                        <label>Email Address</label>
                        <input type="email" name="email" required placeholder="Enter your email address" autocomplete="email">
                    </div>
                    <button type="submit" class="auth-btn"><span class="tx">Send Reset Link</span><span class="ld">Sending...</span></button>
                </form>
                <a href="<?php echo esc_url(Hushot_Pages::get_page_url('login')); ?>" class="auth-back">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/></svg>
                    Back to Sign In
                </a>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
    
    public static function render_reset_password() {
        $key = sanitize_text_field($_GET['key'] ?? '');
        $login = sanitize_text_field($_GET['login'] ?? '');
        if (!$key || !$login) {
            ob_start();
            ?>
            <style>
            *{box-sizing:border-box;margin:0;padding:0;}
            html,body{min-height:100vh;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;background:linear-gradient(160deg,#0f0f23 0%,#1a1a2e 40%,#16213e 100%);}
            .auth-wrap{min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px;}
            .auth-card{width:100%;max-width:400px;background:#fff;border-radius:28px;padding:44px 36px;text-align:center;box-shadow:0 30px 60px rgba(0,0,0,0.4);}
            .auth-logo{width:72px;height:72px;background:linear-gradient(135deg,#ef4444,#f87171);border-radius:20px;display:flex;align-items:center;justify-content:center;margin:0 auto 20px;font-size:32px;}
            .auth-title{font-size:24px;font-weight:800;color:#1a1a2e;margin-bottom:12px;}
            .auth-sub{font-size:15px;color:#6b7280;margin-bottom:24px;}
            .auth-btn{display:inline-block;padding:14px 28px;font-size:15px;font-weight:600;color:#fff;background:#FF553E;border-radius:12px;text-decoration:none;}
            </style>
            <div class="auth-wrap">
                <div class="auth-card">
                    <div class="auth-logo">❌</div>
                    <h1 class="auth-title">Invalid Link</h1>
                    <p class="auth-sub">This reset link is invalid or has expired.</p>
                    <a href="<?php echo esc_url(Hushot_Pages::get_page_url('forgot-password')); ?>" class="auth-btn">Request New Link</a>
                </div>
            </div>
            <?php
            return ob_get_clean();
        }
        ob_start();
        ?>
        <style>
        *{box-sizing:border-box;margin:0;padding:0;}
        html,body{min-height:100vh;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;background:linear-gradient(160deg,#0f0f23 0%,#1a1a2e 40%,#16213e 100%);overflow-x:hidden;}
        .auth-wrap{min-height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:20px;position:relative;}
        .auth-bg{position:absolute;top:0;left:0;right:0;bottom:0;overflow:hidden;pointer-events:none;}
        .auth-bg::before{content:'';position:absolute;top:-50%;left:-50%;width:200%;height:200%;background:radial-gradient(ellipse at 20% 80%,rgba(16,185,129,0.15) 0%,transparent 50%),radial-gradient(ellipse at 80% 20%,rgba(99,102,241,0.1) 0%,transparent 50%);}
        .auth-card{width:100%;max-width:400px;background:rgba(255,255,255,0.98);border-radius:28px;padding:44px 36px;position:relative;box-shadow:0 30px 60px rgba(0,0,0,0.4),0 0 0 1px rgba(255,255,255,0.1);backdrop-filter:blur(20px);}
        .auth-header{text-align:center;margin-bottom:36px;}
        .auth-logo{width:72px;height:72px;background:linear-gradient(135deg,#10b981 0%,#34d399 100%);border-radius:20px;display:flex;align-items:center;justify-content:center;margin:0 auto 20px;font-size:32px;box-shadow:0 12px 28px rgba(16,185,129,0.35);}
        .auth-title{font-size:26px;font-weight:800;color:#1a1a2e;margin-bottom:8px;letter-spacing:-0.5px;}
        .auth-sub{font-size:15px;color:#6b7280;line-height:1.5;}
        .auth-form .field{margin-bottom:20px;}
        .auth-form label{display:block;font-size:13px;font-weight:600;color:#374151;margin-bottom:8px;padding-left:4px;}
        .auth-form input{width:100%;padding:16px 18px;font-size:15px;border:2px solid #e5e7eb;border-radius:14px;background:#f9fafb;transition:all 0.25s ease;font-family:inherit;}
        .auth-form input:focus{outline:none;border-color:#10b981;background:#fff;box-shadow:0 0 0 4px rgba(16,185,129,0.12);}
        .auth-btn{width:100%;padding:16px;font-size:16px;font-weight:700;color:#fff;background:linear-gradient(135deg,#10b981 0%,#34d399 100%);border:none;border-radius:14px;cursor:pointer;transition:all 0.25s ease;font-family:inherit;box-shadow:0 8px 24px rgba(16,185,129,0.35);margin-top:8px;}
        .auth-btn:hover{transform:translateY(-2px);box-shadow:0 12px 32px rgba(16,185,129,0.4);}
        .auth-btn .ld{display:none;}
        .auth-btn.loading .tx{display:none;}
        .auth-btn.loading .ld{display:inline;}
        .auth-msg{padding:14px 16px;border-radius:12px;font-size:14px;margin-bottom:20px;display:none;text-align:center;}
        .auth-msg.ok{display:block;background:linear-gradient(135deg,#d1fae5,#ecfdf5);color:#065f46;border:1px solid #a7f3d0;}
        .auth-msg.err{display:block;background:linear-gradient(135deg,#fee2e2,#fef2f2);color:#991b1b;border:1px solid #fecaca;}
        @media(max-width:480px){.auth-card{padding:36px 24px;border-radius:24px;}}
        </style>
        <div class="auth-wrap">
            <div class="auth-bg"></div>
            <div class="auth-card">
                <div class="auth-header">
                    <div class="auth-logo">🔑</div>
                    <h1 class="auth-title">Set New Password</h1>
                    <p class="auth-sub">Create a strong password for your account</p>
                </div>
                <form class="auth-form" id="hs-reset">
                    <div class="auth-msg hs-msg"></div>
                    <input type="hidden" name="key" value="<?php echo esc_attr($key); ?>">
                    <input type="hidden" name="login" value="<?php echo esc_attr($login); ?>">
                    <div class="field">
                        <label>New Password</label>
                        <input type="password" name="password" required minlength="6" placeholder="Min 6 characters" autocomplete="new-password">
                    </div>
                    <button type="submit" class="auth-btn"><span class="tx">Reset Password</span><span class="ld">Resetting...</span></button>
                </form>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    public static function render_dashboard() {
        if (!is_user_logged_in()) return '<script>window.location.href="'.esc_url(Hushot_Pages::get_page_url('login')).'";</script>';
        $user = wp_get_current_user();
        $plan = Hushot_Membership::get_user_plan();
        $pages = get_posts(array('post_type'=>'hushot_page','author'=>$user->ID,'posts_per_page'=>-1));
        $recent = get_posts(array('post_type'=>'hushot_page','author'=>$user->ID,'posts_per_page'=>5,'orderby'=>'date','order'=>'DESC'));
        $views = 0;
        $clicks = 0;
        foreach ($pages as $p) {
            $views += (int)get_post_meta($p->ID,'_hushot_views',true);
            $clicks += (int)get_post_meta($p->ID,'_hushot_clicks',true);
        }
        global $wpdb;
        $leads = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}hushot_leads WHERE user_id=%d", $user->ID));
        
        ob_start();
        self::get_more_styles();
        echo self::render_sidebar($user, $plan, 'dashboard');
        ?>
        <main class="hs-main"><button id="hs-menu">☰</button><div class="hs-overlay"></div>
            <div class="hs-head"><h1>Welcome, <?php echo esc_html($user->first_name ?: $user->display_name); ?>!</h1></div>
            <div class="hs-body">
                <div class="hs-stats hs-stats-4">
                    <a href="<?php echo esc_url(Hushot_Pages::get_page_url('my-pages')); ?>" class="hs-stat hs-stat-link"><div class="hs-stat-num"><?php echo count($pages); ?></div><div class="hs-stat-lbl">Pages</div></a>
                    <a href="<?php echo esc_url(add_query_arg('tab', 'views', Hushot_Pages::get_page_url('analytics'))); ?>" class="hs-stat hs-stat-link"><div class="hs-stat-num"><?php echo number_format($views); ?></div><div class="hs-stat-lbl">Views</div></a>
                    <a href="<?php echo esc_url(Hushot_Pages::get_page_url('leads')); ?>" class="hs-stat hs-stat-link"><div class="hs-stat-num"><?php echo $leads ?: 0; ?></div><div class="hs-stat-lbl">Leads</div></a>
                    <a href="<?php echo esc_url(add_query_arg('tab', 'clicks', Hushot_Pages::get_page_url('analytics'))); ?>" class="hs-stat hs-stat-link"><div class="hs-stat-num"><?php echo number_format($clicks); ?></div><div class="hs-stat-lbl">Clicks</div></a>
                </div>
                <div class="hs-card">
                    <div class="hs-quick">
                        <a href="<?php echo esc_url(Hushot_Pages::get_page_url('create-page')); ?>"><span class="ico">➕</span>Create</a>
                        <a href="<?php echo esc_url(Hushot_Pages::get_page_url('ai-image')); ?>"><span class="ico">🖼️</span>AI Image</a>
                        <a href="<?php echo esc_url(Hushot_Pages::get_page_url('ai-generator')); ?>"><span class="ico">✨</span>AI</a>
                        <a href="<?php echo esc_url(Hushot_Pages::get_page_url('leads')); ?>"><span class="ico">👥</span>Leads</a>
                    </div>
                    <?php if (!empty($recent)): ?>
                    <div class="hs-recent-pages"><h4>Recent Pages</h4>
                    <?php foreach ($recent as $pg): ?>
                    <div class="hs-recent-item">
                        <span><?php echo esc_html($pg->post_title); ?></span>
                        <div class="hs-recent-btns">
                            <a href="<?php echo get_permalink($pg->ID); ?>" target="_blank" class="hs-rbtn">👁️</a>
                            <a href="<?php echo esc_url(Hushot_Pages::get_page_url('create-page') . '?mode=visual&page_id=' . $pg->ID); ?>" class="hs-rbtn">✏️</a>
                            <button type="button" class="hs-rbtn hs-copy-url" data-url="<?php echo esc_url(get_permalink($pg->ID)); ?>" title="Copy URL">🔗</button>
                            <button class="hs-rbtn hs-dup" data-id="<?php echo $pg->ID; ?>">⧉</button>
                            <button class="hs-rbtn hs-del" data-id="<?php echo $pg->ID; ?>">✕</button>
                        </div>
                    </div>
                    <?php endforeach; ?>
                    </div><?php endif; ?>
                </div>
            </div>
        </main></div>
        <?php
        return ob_get_clean();
    }

    public static function render_my_pages() {
        if (!is_user_logged_in()) return '<script>window.location.href="'.esc_url(Hushot_Pages::get_page_url('login')).'";</script>';
        $user = wp_get_current_user();
        $plan = Hushot_Membership::get_user_plan();
        $pages = get_posts(array('post_type'=>'hushot_page','author'=>$user->ID,'posts_per_page'=>-1,'orderby'=>'date','order'=>'DESC'));
        
        ob_start();
        self::get_more_styles();
        echo self::render_sidebar($user, $plan, 'my-pages');
        ?>
        <main class="hs-main"><button id="hs-menu">☰</button><div class="hs-overlay"></div>
            <div class="hs-head"><h1>My Pages</h1></div>
            <div class="hs-body">
                <div style="margin-bottom:12px;display:flex;gap:8px;flex-wrap:wrap;">
                    <a href="<?php echo esc_url(Hushot_Pages::get_page_url('create-page')); ?>" class="hs-btn hs-btn-p hs-btn-xs">+ Create</a>
                </div>
                <?php if (empty($pages)): ?>
                <div class="hs-empty">No pages yet.</div>
                <?php else: foreach ($pages as $pg): ?>
                <div class="hs-pg">
                    <span class="hs-pg-ico">📄</span>
                    <div class="hs-pg-info"><strong><?php echo esc_html($pg->post_title); ?></strong><small><?php echo (int)get_post_meta($pg->ID,'_hushot_views',true); ?> views</small></div>
                    <div class="hs-pg-btns">
                        <a href="<?php echo get_permalink($pg->ID); ?>" target="_blank" class="hs-rbtn" title="View">👁️</a>
                        <a href="<?php echo esc_url(Hushot_Pages::get_page_url('create-page') . '?mode=visual&page_id=' . $pg->ID); ?>" class="hs-rbtn" title="Edit">✏️</a>
                        <button type="button" class="hs-rbtn hs-copy-url" data-url="<?php echo esc_url(get_permalink($pg->ID)); ?>" title="Copy URL">🔗</button>
                        <button class="hs-rbtn hs-dup" data-id="<?php echo $pg->ID; ?>" title="Duplicate">⧉</button>
                        <button class="hs-rbtn hs-del" data-id="<?php echo $pg->ID; ?>" title="Delete">✕</button>
                    </div>
                </div>
                <?php endforeach; endif; ?>
            </div>
        </main></div>
        <?php
        return ob_get_clean();
    }

    public static function render_create_page() {
        if (!is_user_logged_in()) return '<script>window.location.href="'.esc_url(Hushot_Pages::get_page_url('login')).'";</script>';
        $user = wp_get_current_user();
        $plan = Hushot_Membership::get_user_plan();
        $is_paid = ($plan !== 'free');
        $wa = get_user_meta($user->ID, 'hushot_whatsapp', true);
        $builder_mode = isset($_GET['mode']) ? sanitize_text_field($_GET['mode']) : 'choose';
        
        ob_start();
        self::get_more_styles();
        echo self::render_sidebar($user, $plan, 'create-page');
        ?>
        <style>
        /* Builder Choice Styles - Fixed Typography */
        .builder-choice{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:24px;}
        .builder-option{display:block;padding:28px 20px;background:#fff;border:2px solid #e5e7eb;border-radius:16px;cursor:pointer;text-align:center;transition:all 0.2s;-webkit-tap-highlight-color:transparent;text-decoration:none!important;}
        .builder-option:hover{border-color:#F7931E;background:#fff9f5;transform:translateY(-2px);box-shadow:0 8px 24px rgba(0,0,0,0.08);}
        .builder-option.active{border-color:#F7931E;background:linear-gradient(135deg,rgba(247,147,30,0.08),rgba(247,147,30,0.02));}
        .builder-option .icon{font-size:40px;margin-bottom:12px;display:block;}
        .builder-option strong{font-size:17px;color:#1a1a2e;display:block;margin-bottom:8px;text-decoration:none!important;}
        .builder-option small{font-size:13px;color:#6b7280;line-height:1.5;display:block;text-decoration:none!important;}
        .builder-option .badge{display:inline-block;padding:4px 10px;background:#F7931E;color:#fff;border-radius:12px;font-size:10px;font-weight:700;margin-top:12px;}
        @media(max-width:500px){.builder-choice{grid-template-columns:1fr;gap:12px;}.builder-option{padding:24px 18px;}}
        
        /* Component Builder Styles */
        .hs-color-row{display:flex;align-items:center;gap:10px;}
        .hs-color-box{width:36px;height:36px;border-radius:8px;border:2px solid #e5e7eb;flex-shrink:0;}
        .hs-hex-row{display:flex;gap:6px;margin-top:6px;}
        .hs-hex-row input{width:80px;padding:5px 8px;font-size:11px;font-family:monospace;border:1px solid #e5e7eb;border-radius:6px;}
        .hs-hex-row button{padding:5px 10px!important;font-size:10px!important;height:auto!important;}
        .hs-btns-row{display:flex;gap:8px;}
        .hs-add-field{display:flex;gap:6px;margin-top:8px;}
        .hs-add-field input{flex:1;padding:6px 10px;font-size:12px;border:1px solid #e5e7eb;border-radius:6px;}
        .hs-add-field button{padding:6px 12px!important;font-size:10px!important;white-space:nowrap;}
        .hs-btn-gray{background:#6b7280!important;}
        #hs-preview-modal{display:none;position:fixed;inset:0;background:rgba(0,0,0,0.9);z-index:9999;flex-direction:column;padding:15px;}
        #hs-preview-modal.show{display:flex;}
        #hs-preview-modal .pm-top{display:flex;justify-content:space-between;align-items:center;color:#fff;padding-bottom:10px;}
        #hs-preview-modal .pm-x{background:#ef4444;color:#fff;border:none;padding:8px 16px;border-radius:6px;cursor:pointer;}
        #hs-preview-modal iframe{flex:1;border:none;border-radius:8px;background:#fff;}
        .hs-form-checks{display:flex;flex-wrap:wrap;gap:12px;margin:8px 0;}
        .hs-form-checks label{display:flex;align-items:center;gap:6px;font-size:13px;cursor:pointer;padding:8px 12px;background:#f5f5f5;border-radius:6px;border:1px solid #e5e7eb;}
        .hs-form-checks label:hover{background:#eee;}
        .hs-form-checks input[type="checkbox"]{width:16px;height:16px;margin:0;cursor:pointer;accent-color:#FF553E;}
        .hs-add-field{display:flex;gap:6px;margin-top:12px;}
        .hs-add-field input{flex:1;padding:8px 12px;border:1px solid #ddd;border-radius:6px;font-size:13px;}
        .hs-add-field button{padding:8px 14px;background:#FF553E;color:#fff;border:none;border-radius:6px;cursor:pointer;font-size:13px;}
        .hs-custom-fields{margin-top:10px;}
        .hs-custom-field{display:flex;align-items:center;gap:8px;margin:6px 0;font-size:13px;padding:8px 12px;background:#f9f9f9;border-radius:6px;}
        .hs-custom-field input[type="checkbox"]{width:16px;height:16px;margin:0;cursor:pointer;accent-color:#FF553E;}
        .hs-custom-field .rem-cf{color:#ef4444;cursor:pointer;border:none;background:none;font-size:18px;padding:0 4px;}
        </style>
        <main class="hs-main"><button id="hs-menu">☰</button><div class="hs-overlay"></div>
            <div class="hs-head"><h1>Create Page</h1></div>
            <div class="hs-body">
                
                <?php if ($builder_mode === 'choose' || $builder_mode === ''): ?>
                <!-- Builder Type Choice -->
                <div style="max-width:520px;margin:0 auto;">
                    <p style="text-align:center;color:#6b7280;margin-bottom:24px;font-size:16px;">Choose how you want to build your page</p>
                    <div class="builder-choice">
                        <a href="?mode=visual" class="builder-option">
                            <span class="icon">🎨</span>
                            <strong>Visual Builder</strong>
                            <small>Drag sections, see live preview. Best for quick pages.</small>
                            <span class="badge">RECOMMENDED</span>
                        </a>
                        <a href="?mode=component" class="builder-option">
                            <span class="icon">🔧</span>
                            <strong>Component Builder</strong>
                            <small>Full control with detailed settings for each section.</small>
                        </a>
                    </div>
                    <div style="text-align:center;margin-top:28px;">
                        <a href="<?php echo esc_url(Hushot_Pages::get_page_url('ai-generator')); ?>" style="display:inline-flex;align-items:center;gap:10px;padding:14px 28px;background:linear-gradient(135deg,#667eea,#764ba2);color:#fff;border-radius:12px;text-decoration:none;font-size:15px;font-weight:600;box-shadow:0 4px 16px rgba(102,126,234,0.3);">
                            ✨ Or let AI create your page
                        </a>
                    </div>
                </div>
                <?php elseif ($builder_mode === 'visual'): ?>
                <!-- Visual Builder Inline -->
                <?php echo self::render_visual_builder_inline($user, $plan); ?>
                <?php else: ?>
                <!-- Component Builder -->
                <form id="hs-create"><div class="hs-msg"></div>
                    <div style="margin-bottom:12px;"><a href="?mode=choose" style="color:#666;font-size:13px;text-decoration:none;">← Back to builder choice</a></div>
                    <div class="hs-block open"><div class="hs-block-head"><span class="hs-block-ico">📝</span><span class="hs-block-title">Title</span></div><div class="hs-block-body">
                        <div class="hs-fld"><label>Page Title *</label><input type="text" name="page_title" required placeholder="e.g. Premium Skincare Products"></div>
                        <div class="hs-fld"><label>Business Name</label><input type="text" name="business_name" placeholder="e.g. Glow Beauty Store"></div>
                        <div class="hs-row">
                            <div class="hs-fld"><label>Logo</label><div class="hs-img-box" id="logo-box"><span class="ico">🖼️</span><input type="file" id="logo-file" accept="image/*"></div><input type="hidden" name="logo_url" id="logo_url"></div>
                            <div class="hs-fld"><label>Brand Color</label>
                                <div class="hs-color-row">
                                    <div class="hs-color-box" id="clr-box" style="background:#000000;"></div>
                                    <select name="primary_color" id="clr-sel">
                                        <option value="#000000">⬛ Black</option>
                                        <option value="#FF553E">🟠 Orange</option>
                                        <option value="#dc2626">🔴 Red</option>
                                        <option value="#059669">🟢 Green</option>
                                        <option value="#2563eb">🔵 Blue</option>
                                        <option value="#7c3aed">🟣 Purple</option>
                                        <option value="#0891b2">🔷 Cyan</option>
                                        <option value="#ea580c">🟧 Amber</option>
                                        <option value="#db2777">💗 Pink</option>
                                        <option value="#0d9488">🌊 Teal</option>
                                        <option value="#4f46e5">💜 Indigo</option>
                                        <option value="#ca8a04">🟡 Gold</option>
                                    </select>
                                </div>
                                <div class="hs-hex-row">
                                    <input type="text" id="hex-in" placeholder="#000000" maxlength="7">
                                    <button type="button" class="hs-btn hs-btn-xs" id="hex-btn">Apply</button>
                                </div>
                            </div>
                        </div>
                    </div></div>
                    <!-- Page Customization Controls -->
                    <div class="hs-block"><div class="hs-block-head"><span class="hs-block-ico">🎨</span><span class="hs-block-title">Page Settings</span></div><div class="hs-block-body">
                        <div class="hs-row">
                            <div class="hs-fld">
                                <label>Page Background</label>
                                <div class="hs-color-row">
                                    <input type="color" name="page_bg_color" value="#ffffff" style="width:40px;height:36px;border:1px solid #ddd;border-radius:6px;cursor:pointer;">
                                    <select name="page_bg_preset" class="page-bg-select" style="flex:1;padding:8px;border:1px solid #ddd;border-radius:6px;">
                                        <option value="#ffffff">White</option>
                                        <option value="#f8fafc">Light Gray</option>
                                        <option value="#f0fdf4">Soft Green</option>
                                        <option value="#fef3c7">Warm Cream</option>
                                        <option value="#0f172a">Dark</option>
                                        <option value="custom">Custom</option>
                                    </select>
                                </div>
                            </div>
                            <div class="hs-fld">
                                <label>Header Background</label>
                                <div class="hs-color-row">
                                    <input type="color" name="header_bg_color" value="#ffffff" style="width:40px;height:36px;border:1px solid #ddd;border-radius:6px;cursor:pointer;">
                                    <select name="header_bg_preset" style="flex:1;padding:8px;border:1px solid #ddd;border-radius:6px;">
                                        <option value="#ffffff">White</option>
                                        <option value="transparent">Transparent</option>
                                        <option value="#000000">Black</option>
                                        <option value="custom">Custom</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="hs-fld" style="margin-top:12px;">
                            <label style="display:flex;align-items:center;gap:8px;cursor:pointer;">
                                <input type="checkbox" name="show_header" value="1" checked style="width:18px;height:18px;accent-color:#FF553E;">
                                <span>Show sticky header</span>
                            </label>
                        </div>
                        <hr style="margin:16px 0;border:none;border-top:1px solid #eee;">
                        <label style="font-weight:600;margin-bottom:10px;display:block;">Button Styling</label>
                        <div class="hs-row">
                            <div class="hs-fld">
                                <label>Size</label>
                                <select name="btn_size" style="width:100%;padding:8px;border:1px solid #ddd;border-radius:6px;">
                                    <option value="small">Small</option>
                                    <option value="medium" selected>Medium</option>
                                    <option value="large">Large</option>
                                </select>
                            </div>
                            <div class="hs-fld">
                                <label>Style</label>
                                <select name="btn_style" style="width:100%;padding:8px;border:1px solid #ddd;border-radius:6px;">
                                    <option value="rounded" selected>Rounded</option>
                                    <option value="pill">Pill</option>
                                    <option value="square">Square</option>
                                    <option value="outline">Outline</option>
                                </select>
                            </div>
                        </div>
                        <div class="hs-row" style="margin-top:10px;">
                            <div class="hs-fld">
                                <label>Width</label>
                                <select name="btn_width" style="width:100%;padding:8px;border:1px solid #ddd;border-radius:6px;">
                                    <option value="auto" selected>Auto</option>
                                    <option value="full">Full Width</option>
                                </select>
                            </div>
                            <div class="hs-fld">
                                <label>Position</label>
                                <select name="btn_position" style="width:100%;padding:8px;border:1px solid #ddd;border-radius:6px;">
                                    <option value="center" selected>Center</option>
                                    <option value="left">Left</option>
                                    <option value="right">Right</option>
                                </select>
                            </div>
                        </div>
                    </div></div>
                    <div id="components-area"></div>
                    <div class="hs-picker"><div class="hs-picker-title">Tap to Add Sections</div><div class="hs-picker-hint" style="font-size:12px;color:#6b7280;margin:-8px 0 16px;padding:10px 12px;background:#f0f9ff;border-radius:8px;border-left:3px solid #667eea;">💡 <strong>Hint:</strong> Create a high-converting landing page by following this order: 1, 2, 3, 4, 5, 6, 7</div><div class="hs-picker-grid">
                        <div class="hs-pick" data-comp="header"><span class="hs-pick-num">1</span><span class="ico">🏷️</span><span class="txt">Title/Sub</span></div>
                        <div class="hs-pick" data-comp="image"><span class="hs-pick-num">2</span><span class="ico">🖼️</span><span class="txt">Image</span></div>
                        <div class="hs-pick" data-comp="description"><span class="hs-pick-num">3</span><span class="ico">📄</span><span class="txt">Details</span></div>
                        <div class="hs-pick" data-comp="features"><span class="hs-pick-num">4</span><span class="ico">✅</span><span class="txt">Features</span></div>
                        <div class="hs-pick" data-comp="pricing"><span class="hs-pick-num">5</span><span class="ico">💰</span><span class="txt">Price</span></div>
                        <div class="hs-pick" data-comp="whatsapp"><span class="hs-pick-num">6</span><span class="ico">💬</span><span class="txt">WhatsApp</span></div>
                        <div class="hs-pick" data-comp="contact"><span class="hs-pick-num">7</span><span class="ico">📞</span><span class="txt">Footer</span></div>
                        <div class="hs-pick <?php echo !$is_paid?'locked':''; ?>" data-comp="video" <?php echo !$is_paid?'data-locked="1"':''; ?>><span class="hs-pick-num">8</span><span class="ico">🎬</span><span class="txt">Video</span></div>
                        <div class="hs-pick <?php echo !$is_paid?'locked':''; ?>" data-comp="form" <?php echo !$is_paid?'data-locked="1"':''; ?>><span class="hs-pick-num">9</span><span class="ico">📋</span><span class="txt">Form</span></div>
                        <div class="hs-pick <?php echo !$is_paid?'locked':''; ?>" data-comp="link" <?php echo !$is_paid?'data-locked="1"':''; ?>><span class="hs-pick-num">10</span><span class="ico">🔗</span><span class="txt">Link</span></div>
                        <div class="hs-pick <?php echo !$is_paid?'locked':''; ?>" data-comp="bottombar" <?php echo !$is_paid?'data-locked="1"':''; ?>><span class="hs-pick-num">11</span><span class="ico">📱</span><span class="txt">Sticky Bar</span></div>
                        <div class="hs-pick <?php echo !$is_paid?'locked':''; ?>" data-comp="products" <?php echo !$is_paid?'data-locked="1"':''; ?>><span class="hs-pick-num">12</span><span class="ico">🛍️</span><span class="txt">Products</span></div>
                    </div></div>
                    <?php echo self::render_component_templates($is_paid, $wa, $plan); ?>
                    <div class="hs-card">
                        <div style="margin-bottom:16px;padding:16px;background:linear-gradient(135deg,rgba(102,126,234,0.1),rgba(118,75,162,0.1));border-radius:12px;border:1px solid rgba(102,126,234,0.2);">
                            <label style="display:flex;align-items:center;gap:12px;cursor:pointer;">
                                <input type="checkbox" name="promote_after_save" id="promote-checkbox" style="width:20px;height:20px;accent-color:#667eea;">
                                <div>
                                    <strong style="display:block;font-size:14px;color:#374151;">📢 Promote via Ads Network</strong>
                                    <span style="font-size:12px;color:#6b7280;">After publishing, set up Facebook/Instagram ads for this page</span>
                                </div>
                            </label>
                        </div>
                        <div class="hs-btns-row">
                            <button type="button" class="hs-btn hs-btn-gray hs-btn-xs" id="prev-btn">👁️ Preview</button>
                            <button type="submit" class="hs-btn hs-btn-p hs-btn-xs" id="submit-btn" style="flex:1;"><span class="tx" id="submit-text">Publish</span><span class="ld">...</span></button>
                        </div>
                    </div>
                </form>
            </div>
        </main></div>
        <div id="hs-preview-modal">
            <div class="pm-top"><span>Preview</span><button class="pm-x" id="prev-close">✕ Close</button></div>
            <iframe id="prev-frame"></iframe>
        </div>
        <script>
        (function(){
            // Promote checkbox toggle button text
            var promoteCheckbox = document.getElementById('promote-checkbox');
            var submitText = document.getElementById('submit-text');
            var submitBtn = document.getElementById('submit-btn');
            if (promoteCheckbox && submitText) {
                promoteCheckbox.addEventListener('change', function() {
                    if (this.checked) {
                        submitText.textContent = '🚀 Boost Now';
                        submitBtn.style.background = 'linear-gradient(135deg, #667eea, #764ba2)';
                    } else {
                        submitText.textContent = 'Publish';
                        submitBtn.style.background = '';
                    }
                });
            }
            
            // Page background preset sync
            var pageBgPreset = document.querySelector('[name="page_bg_preset"]');
            var pageBgColor = document.querySelector('[name="page_bg_color"]');
            if (pageBgPreset && pageBgColor) {
                pageBgPreset.addEventListener('change', function() {
                    if (this.value !== 'custom') {
                        pageBgColor.value = this.value;
                    }
                });
                pageBgColor.addEventListener('input', function() {
                    pageBgPreset.value = 'custom';
                });
            }
            
            var clrSel=document.getElementById('clr-sel'),clrBox=document.getElementById('clr-box'),hexIn=document.getElementById('hex-in');
            clrSel.onchange=function(){clrBox.style.background=this.value;hexIn.value=this.value;};
            document.getElementById('hex-btn').onclick=function(){
                var h=hexIn.value.trim();
                if(/^#[0-9A-Fa-f]{6}$/.test(h)){
                    clrBox.style.background=h;
                    var found=false;
                    for(var i=0;i<clrSel.options.length;i++){if(clrSel.options[i].value===h){clrSel.selectedIndex=i;found=true;break;}}
                    if(!found){var o=document.createElement('option');o.value=h;o.text='🎨 '+h;clrSel.add(o);clrSel.value=h;}
                }else{alert('Enter valid hex like #FF5500');}
            };
            document.getElementById('prev-btn').onclick=function(){
                var fd=new FormData(document.getElementById('hs-create'));
                fd.append('action','hushot_preview_page');
                fetch('<?php echo admin_url("admin-ajax.php"); ?>',{method:'POST',body:fd})
                .then(function(r){return r.json();})
                .then(function(d){
                    if(d.success&&d.data.html){
                        document.getElementById('prev-frame').srcdoc=d.data.html;
                        document.getElementById('hs-preview-modal').classList.add('show');
                    }else{alert(d.data&&d.data.message?d.data.message:'Preview failed');}
                });
            };
            document.getElementById('prev-close').onclick=function(){
                document.getElementById('hs-preview-modal').classList.remove('show');
            };
        })();
        </script>
        <?php endif; // end component mode ?>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Render Visual Builder Inline (within Create Page)
     * Mobile-first live preview editor
     */
    /**
     * Visual Builder with Templates & Section Management
     */
    /**
     * Visual Builder with All Sections & Improved UX
     */
    private static function render_visual_builder_inline($user, $plan) {
        $is_paid = ($plan !== 'free');
        $page_id = isset($_GET['page_id']) ? intval($_GET['page_id']) : 0;
        $template = isset($_GET['template']) ? sanitize_text_field($_GET['template']) : '';
        $wa = get_user_meta($user->ID, 'hushot_whatsapp', true);
        $phone = get_user_meta($user->ID, 'hushot_phone', true);
        
        // Show template picker if no template selected and not editing
        if (empty($template) && !$page_id) {
            return self::render_template_picker($plan);
        }
        
        // Load existing page data
        $sections_json = '';
        $page_title = '';
        $primary_color = '#F7931E';
        $sticky_bar = '';
        
        if ($page_id) {
            $page = get_post($page_id);
            if ($page && $page->post_author == $user->ID) {
                $page_title = $page->post_title;
                $sections_json = get_post_meta($page_id, '_hushot_sections', true);
                $primary_color = get_post_meta($page_id, '_hushot_primary_color', true) ?: '#F7931E';
                $sticky_bar = get_post_meta($page_id, '_hushot_sticky_bar', true);
                $template = get_post_meta($page_id, '_hushot_template', true) ?: 'starter';
            }
        }
        
        if (empty($template)) $template = 'starter';
        
        // Default sections
        $default_sections = self::get_template_sections($template, $wa);
        
        ob_start();
        ?>
        <style>
        /* Visual Builder v1.8.0 - Fixed Panel Position */
        .vb-wrap{display:flex;flex-direction:column;min-height:100vh;background:#e5e7eb;margin:-20px;position:relative;}
        
        /* Top Bar */
        .vb-topbar{position:sticky;top:0;z-index:100;background:#fff;padding:12px 16px;display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid #e5e7eb;gap:12px;}
        .vb-topbar-left{display:flex;align-items:center;gap:12px;flex:1;min-width:0;}
        .vb-topbar-left a{color:#666;font-size:22px;text-decoration:none;padding:4px;}
        .vb-topbar-title{flex:1;font-size:15px;font-weight:600;color:#1a1a2e;border:none;background:transparent;min-width:0;padding:8px 0;}
        .vb-topbar-title:focus{outline:none;border-bottom:2px solid #F7931E;}
        .vb-topbar-actions{display:flex;gap:8px;}
        .vb-topbar-actions button{padding:10px 16px;border:none;border-radius:10px;font-size:13px;font-weight:600;cursor:pointer;}
        .vb-btn-save{background:#f0f0f0;color:#374151;}
        .vb-btn-publish{background:#F7931E;color:#fff;}
        
        /* Preview Area */
        .vb-preview{flex:1;padding:16px;overflow-y:auto;-webkit-overflow-scrolling:touch;}
        .vb-preview-inner{max-width:400px;margin:0 auto;background:#fff;border-radius:20px;box-shadow:0 4px 24px rgba(0,0,0,0.12);overflow:hidden;min-height:300px;}
        
        /* Section */
        .vb-section{position:relative;min-height:60px;transition:all 0.2s;cursor:pointer;}
        .vb-section:hover{outline:2px dashed rgba(247,147,30,0.5);outline-offset:-2px;}
        .vb-section.editing{outline:3px solid #F7931E;outline-offset:-3px;}
        .vb-section-tools{position:absolute;top:8px;right:8px;display:none;gap:4px;background:rgba(0,0,0,0.85);border-radius:8px;padding:4px;z-index:10;}
        .vb-section:hover .vb-section-tools,.vb-section.editing .vb-section-tools{display:flex;}
        .vb-section-tools button{width:30px;height:30px;border:none;background:transparent;color:#fff;cursor:pointer;font-size:15px;border-radius:6px;}
        .vb-section-tools button:hover{background:rgba(255,255,255,0.2);}
        
        /* Section Types Preview */
        .vb-s-hero{padding:36px 20px;text-align:center;background:linear-gradient(135deg,var(--vb-color,#F7931E) 0%,#1a1a2e 100%);color:#fff;}
        .vb-s-hero.style-bold{background:#1a1a2e;}
        .vb-s-hero.style-minimal{background:#fff;color:#1a1a2e;}
        .vb-s-hero h1{font-size:20px;font-weight:800;margin:0 0 8px;line-height:1.3;}
        .vb-s-hero p{font-size:13px;opacity:0.9;margin:0;}
        .vb-s-hero img,.vb-s-hero video{max-width:100%;border-radius:10px;margin-top:12px;}
        
        .vb-s-banner{padding:32px 20px;text-align:center;background:linear-gradient(135deg,var(--vb-color,#F7931E),#1a1a2e);color:#fff;}
        .vb-s-banner.style-light{background:#f9fafb;color:#1a1a2e;}
        .vb-s-banner.style-dark{background:#1a1a2e;color:#fff;}
        .vb-s-banner h2{font-size:18px;font-weight:800;margin:0 0 6px;}
        .vb-s-banner p{font-size:13px;opacity:0.9;margin:0 0 12px;}
        .vb-s-banner img{max-width:100%;border-radius:10px;margin:12px 0;}
        .vb-s-banner .btn{display:inline-block;padding:12px 24px;background:#fff;color:var(--vb-color,#F7931E);border-radius:10px;font-weight:700;font-size:14px;}
        .vb-s-banner.style-light .btn{background:var(--vb-color,#F7931E);color:#fff;}
        
        .vb-s-features{padding:24px 20px;background:#f9fafb;}
        .vb-s-features{color:#1a1a2e;}
        .vb-s-features.style-dark{background:#1a1a2e;color:#fff;}
        .vb-s-features h3{font-size:15px;font-weight:700;margin:0 0 14px;}
        .vb-s-features ul{list-style:none;padding:0;margin:0;}
        .vb-s-features li{display:flex;align-items:flex-start;gap:8px;padding:8px 0;font-size:13px;border-bottom:1px solid rgba(0,0,0,0.06);}
        .vb-s-features li:last-child{border:none;}
        .vb-s-features li::before{content:'✓';color:var(--vb-color,#F7931E);font-weight:bold;}
        
        .vb-s-cta{padding:18px 16px;text-align:center;background:#fff;}
            .vb-s-cta.style-light{background:#fff;}
            .vb-s-cta.style-gradient{background:linear-gradient(135deg,var(--vb-color),#1a1a2e);color:#fff;}
            .vb-s-cta.style-dark{background:#1a1a2e;color:#fff;}

        .vb-s-cta.style-full{background:var(--vb-color,#F7931E);color:#fff;}
        .vb-s-cta.style-dark{background:#1a1a2e;color:#fff;}
        .vb-s-cta p{font-size:13px;color:#6b7280;margin:0 0 14px;}
        .vb-s-cta.style-full p,.vb-s-cta.style-dark p{color:rgba(255,255,255,0.9);}
        .vb-s-cta .cta-btn{display:inline-block;padding:12px 28px;background:var(--vb-color,#F7931E);color:#fff;border-radius:10px;font-weight:700;font-size:14px;}
        .vb-s-cta.style-full .cta-btn{background:#fff;color:var(--vb-color,#F7931E);}
        
        .vb-s-media{padding:16px;}
        .vb-s-media.style-full{padding:0;}
        .vb-s-media img,.vb-s-media video{width:100%;border-radius:10px;}
        .vb-s-media.style-full img,.vb-s-media.style-full video{border-radius:0;}
        
        .vb-s-text{padding:20px;color:#1a1a2e;}
        .vb-s-text h3{font-size:16px;font-weight:800;margin:0 0 10px;}
            .vb-big-title{font-size:22px;font-weight:900;margin:0 0 10px;line-height:1.2;}

        .vb-s-text p{font-size:13px;line-height:1.7;color:#374151;margin:0;}

        /* WhatsApp icon (SVG) */
        .wa-icon{display:inline-block;width:16px;height:16px;margin-right:6px;vertical-align:-2px;background-repeat:no-repeat;background-size:contain;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Cpath fill='%23fff' d='M19.11 17.3c-.27-.14-1.6-.79-1.85-.88-.25-.09-.43-.14-.6.14-.18.27-.69.88-.84 1.06-.16.18-.31.2-.58.07-.27-.14-1.12-.41-2.14-1.32-.79-.7-1.33-1.56-1.49-1.83-.16-.27-.02-.41.12-.55.12-.12.27-.31.41-.47.14-.16.18-.27.27-.45.09-.18.05-.34-.02-.48-.07-.14-.6-1.45-.82-1.99-.22-.53-.44-.46-.6-.47h-.51c-.18 0-.47.07-.71.34-.25.27-.93.91-.93 2.22 0 1.31.95 2.58 1.08 2.76.14.18 1.87 2.86 4.54 4.01.64.28 1.14.44 1.53.56.64.2 1.22.17 1.68.1.51-.08 1.6-.65 1.83-1.28.23-.63.23-1.17.16-1.28-.07-.11-.25-.18-.52-.32z'/%3E%3Cpath fill='%23fff' d='M16.01 3C9.39 3 4 8.39 4 15.01c0 2.33.66 4.51 1.8 6.36L4 29l7.85-1.75c1.78.97 3.82 1.52 5.99 1.52 6.62 0 12.01-5.39 12.01-12.01S22.63 3 16.01 3zm0 21.76c-2.06 0-3.98-.6-5.6-1.62l-.4-.25-4.66 1.04.99-4.54-.26-.43a9.73 9.73 0 0 1-1.5-5.21c0-5.37 4.37-9.74 9.74-9.74 5.37 0 9.74 4.37 9.74 9.74 0 5.37-4.37 9.74-9.74 9.74z'/%3E%3C/svg%3E");}
        
        .vb-s-form{padding:24px 20px;background:#f9fafb;}
        .vb-s-form h3{font-size:15px;font-weight:700;margin:0 0 14px;text-align:center;}
        .vb-s-form .form-preview{background:#fff;padding:16px;border-radius:10px;}
        .vb-s-form .field{margin-bottom:10px;padding:10px 12px;background:#f5f5f5;border-radius:8px;font-size:12px;color:#666;}
        .vb-s-form .btn{display:block;padding:12px;background:var(--vb-color,#F7931E);color:#fff;border-radius:8px;text-align:center;font-weight:600;font-size:13px;}
        
        .vb-s-footer{padding:16px;background:#1a1a2e;color:#fff;text-align:center;}
        .vb-s-footer p{margin:0;font-size:11px;opacity:0.7;}
        
        /* Sticky Bar Preview */
        .vb-sticky-preview{position:relative;background:#fff;border-top:1px solid #e5e7eb;padding:10px 16px;display:flex;gap:8px;}
        .vb-sticky-preview.bar-light{background:#fff;}
        .vb-sticky-preview.bar-dark{background:#0b1220;border-top:1px solid rgba(255,255,255,0.10);} 
        .vb-sticky-preview.bar-gradient{background:linear-gradient(135deg,#0f172a,#1e293b);border-top:1px solid rgba(255,255,255,0.10);} 
        .vb-sticky-preview .bar-btn{flex:1;padding:10px;text-align:center;border-radius:8px;font-size:11px;font-weight:600;color:#fff;}
        .vb-sticky-preview .btn-wa{background:#25D366;}
        .vb-sticky-preview .btn-call{background:var(--vb-color,#F7931E);} .vb-sticky-preview .btn-link{background:#1a1a2e;}
        
        /* Add Section Button */
        .vb-add-section{margin:16px;padding:20px;border:2px dashed #ccc;border-radius:14px;text-align:center;cursor:pointer;color:#666;font-size:14px;font-weight:500;transition:all 0.2s;}
        .vb-add-section:hover{border-color:#F7931E;color:#F7931E;background:#fff9f5;}
        
        /* Floating Edit Button - Mobile */
        .vb-edit-fab{position:fixed;bottom:24px;right:24px;width:56px;height:56px;background:#F7931E;color:#fff;border:none;border-radius:50%;font-size:24px;cursor:pointer;box-shadow:0 4px 20px rgba(247,147,30,0.4);z-index:150;display:none;align-items:center;justify-content:center;}
        .vb-edit-fab.show{display:flex;}
        
        /* Edit Panel - Side Panel on Mobile */
        .vb-panel{position:fixed;top:0;right:-100%;bottom:0;width:100%;max-width:360px;background:#fff;z-index:200;transition:right 0.3s ease;display:flex;flex-direction:column;box-shadow:-4px 0 30px rgba(0,0,0,0.15);}
        .vb-panel.open{right:0;}
        .vb-panel-header{padding:16px;border-bottom:1px solid #e5e7eb;display:flex;align-items:center;justify-content:space-between;}
        .vb-panel-header h4{margin:0;font-size:16px;font-weight:700;color:#1a1a2e;}
        .vb-panel-close{width:36px;height:36px;border:none;background:#f0f0f0;border-radius:50%;font-size:20px;cursor:pointer;color:#666;}
        .vb-panel-body{flex:1;padding:16px;overflow-y:auto;-webkit-overflow-scrolling:touch;}
        
        /* Panel Overlay */
        .vb-panel-overlay{position:fixed;inset:0;background:rgba(0,0,0,0.4);z-index:190;display:none;}
        .vb-panel-overlay.show{display:block;}
        
        /* Form Elements */
        .vb-form-group{margin-bottom:18px;}
        .vb-form-group label{display:block;font-size:12px;font-weight:600;color:#374151;margin-bottom:8px;}
        .vb-form-group input,.vb-form-group textarea,.vb-form-group select{width:100%;padding:12px 14px;border:2px solid #e5e7eb;border-radius:10px;font-size:14px;font-family:inherit;box-sizing:border-box;background:#fff;}
        .vb-form-group input:focus,.vb-form-group textarea:focus{outline:none;border-color:#F7931E;}
        .vb-form-group textarea{min-height:100px;resize:vertical;}
        
        /* Upload Box */
        .vb-upload{border:2px dashed #ddd;border-radius:12px;padding:24px;text-align:center;cursor:pointer;transition:all 0.2s;background:#fafafa;}
        .vb-upload:hover{border-color:#F7931E;background:#fff9f5;}
        .vb-upload input{display:none;}
        .vb-upload-icon{font-size:36px;margin-bottom:8px;}
        .vb-upload-text{font-size:13px;color:#666;}
        .vb-upload-preview{max-width:100%;max-height:120px;border-radius:8px;margin-top:10px;}
        
        /* Grid Options */
        .vb-grid-3{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-bottom:16px;}
        .vb-grid-2{display:grid;grid-template-columns:repeat(2,1fr);gap:10px;margin-bottom:16px;}
        .vb-opt{padding:14px 10px;background:#f5f5f5;border:2px solid #e5e7eb;border-radius:12px;text-align:center;cursor:pointer;transition:all 0.15s;}
        .vb-opt:hover{border-color:#F7931E;}
        .vb-opt.active{border-color:#F7931E;background:#fff9f5;}
        .vb-opt span{font-size:20px;display:block;margin-bottom:4px;}
        .vb-opt small{font-size:10px;color:#666;}
        
        /* Color Picker */
        .vb-colors{display:flex;gap:10px;flex-wrap:wrap;}
        .vb-color{width:40px;height:40px;border-radius:12px;cursor:pointer;border:3px solid transparent;transition:all 0.15s;}
        .vb-color:hover,.vb-color.active{transform:scale(1.1);border-color:#1a1a2e;}
        
        /* Add Menu Modal */
        .vb-add-menu{position:fixed;bottom:0;left:0;right:0;background:#fff;border-radius:24px 24px 0 0;box-shadow:0 -8px 40px rgba(0,0,0,0.2);z-index:300;padding:24px;transform:translateY(100%);transition:transform 0.3s ease;}
        .vb-add-menu.open{transform:translateY(0);}
        .vb-add-menu h4{margin:0 0 20px;font-size:18px;font-weight:700;color:#1a1a2e;text-align:center;}
        .vb-add-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;}
        .vb-add-item{padding:12px 6px;background:#f5f5f5;border-radius:12px;text-align:center;cursor:pointer;transition:all 0.15s;}
        .vb-add-item:hover{background:#fff9f5;transform:translateY(-2px);}
        .vb-add-item span{font-size:26px;display:block;margin-bottom:5px;}
        .vb-add-item small{font-size:11px;color:#666;font-weight:500;}
        .vb-add-close{margin-top:20px;width:100%;padding:16px;background:#f0f0f0;border:none;border-radius:12px;font-size:15px;font-weight:600;cursor:pointer;}
        
        /* Form Fields Manager */
        .vb-field-list{margin:12px 0;}
        .vb-field-item{display:flex;align-items:center;gap:8px;padding:10px 12px;background:#f5f5f5;border-radius:8px;margin-bottom:8px;font-size:13px;}
        .vb-field-item input{flex:1;border:none;background:transparent;font-size:13px;}
        .vb-field-item .rem{color:#ef4444;cursor:pointer;font-size:18px;border:none;background:none;padding:0 4px;}
        .vb-add-field-btn{padding:10px;background:#F7931E;color:#fff;border:none;border-radius:8px;font-size:13px;font-weight:600;cursor:pointer;width:100%;}
        
        /* Desktop Layout */
        @media(min-width:768px){
            .vb-wrap{flex-direction:row;}
            .vb-topbar{position:fixed;top:0;left:0;right:0;z-index:100;}
            .vb-preview{width:55%;padding:80px 24px 24px;margin:0;}
            .vb-preview-inner{max-width:380px;}
            .vb-panel{top:60px;width:380px;max-width:380px;}
            .vb-edit-fab{display:none!important;}
            .vb-add-menu{left:auto;right:0;width:380px;border-radius:0;}
        }
        @media(max-width:767px){
            .vb-preview{padding-bottom:100px;}
        }
        </style>
        
        <div class="vb-wrap" style="--vb-color:<?php echo esc_attr($primary_color); ?>">
            <div class="vb-topbar">
                <div class="vb-topbar-left">
                    <a href="?mode=choose" title="Back">←</a>
                    <input type="text" id="vb-title" class="vb-topbar-title" value="<?php echo esc_attr($page_title); ?>" placeholder="Enter page title...">
                </div>
                <div class="vb-topbar-actions">
                    <label class="vb-promote-check" title="After publishing, run ads for this page">
                        <input type="checkbox" id="vb-promote">
                        <span>📢 Promote</span>
                    </label>
                    <button type="button" class="vb-btn-save" id="vb-save">Save</button>
                    <button type="button" class="vb-btn-publish" id="vb-publish">Publish</button>
                </div>
            </div>
            <style>
            .vb-promote-check{display:flex;align-items:center;gap:6px;padding:8px 12px;background:#f5f5f5;border-radius:8px;cursor:pointer;font-size:12px;font-weight:600;color:#374151;white-space:nowrap;}
            .vb-promote-check input{width:16px;height:16px;accent-color:#F7931E;}
            .vb-promote-check:has(input:checked){background:#fff9f0;color:#F7931E;}
            .vb-btn-publish.boost{background:linear-gradient(135deg,#ef4444,#dc2626);}
            </style>
            
            <div class="vb-preview" id="vb-preview-area">
                <div class="vb-preview-inner" id="vb-sections-container"></div>
                <div id="vb-sticky-bar-preview"></div>
                <div class="vb-add-section" id="vb-add-section-btn">+ Add Section</div>
            </div>
            
            <!-- Floating Edit Button (Mobile) -->
            <button class="vb-edit-fab" id="vb-edit-fab">✏️</button>
            
            <!-- Panel Overlay -->
            <div class="vb-panel-overlay" id="vb-panel-overlay"></div>
            
            <!-- Edit Panel (Side) -->
            <div class="vb-panel" id="vb-panel">
                <div class="vb-panel-header">
                    <h4 id="vb-panel-title">Edit Section</h4>
                    <button class="vb-panel-close" id="vb-panel-close">×</button>
                </div>
                <div class="vb-panel-body" id="vb-panel-body"></div>
            </div>
            
            <!-- Add Section Menu -->
            <div class="vb-add-menu" id="vb-add-menu">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;">
                    <h4 style="margin:0;font-size:16px;font-weight:700;color:#1a1a2e;">Add Section</h4>
                    <button type="button" id="vb-add-close-x" style="width:32px;height:32px;border:none;background:#f0f0f0;border-radius:50%;font-size:18px;cursor:pointer;color:#666;">×</button>
                </div>
                <div class="vb-add-grid" style="grid-template-columns:repeat(4,1fr);gap:8px;">
                    <div class="vb-add-item" data-type="hero"><span>🎯</span><small>Hero</small></div>
                    <div class="vb-add-item" data-type="banner"><span>🏷️</span><small>Banner</small></div>
                    <div class="vb-add-item" data-type="features"><span>✅</span><small>Features</small></div>
                    <div class="vb-add-item" data-type="text"><span>📝</span><small>Text</small></div>
                    <div class="vb-add-item" data-type="media"><span>🖼️</span><small>Media</small></div>
                    <div class="vb-add-item" data-type="cta"><span>📲</span><small>Button</small></div>
                    <div class="vb-add-item" data-type="payment"><span>💳</span><small>Payment</small></div>
                    <div class="vb-add-item" data-type="products"><span>🛍️</span><small>Products</small></div>
                    <div class="vb-add-item" data-type="separator"><span>➖</span><small>Divider</small></div>
                    <div class="vb-add-item <?php echo !$is_paid ? 'locked' : ''; ?>" data-type="form" <?php echo !$is_paid ? 'data-locked="1"' : ''; ?>><span>📋</span><small>Form<?php echo !$is_paid ? ' 🔒' : ''; ?></small></div>
                    <div class="vb-add-item" data-type="footer"><span>📍</span><small>Footer</small></div>
                </div>
                <div style="margin-top:14px;padding-top:14px;border-top:1px solid #e5e7eb;">
                    <h5 style="font-size:12px;margin:0 0 10px;color:#6b7280;">Sticky Bottom Bar</h5>
                    <div class="vb-add-grid" style="grid-template-columns:repeat(2,1fr);gap:8px;">
                        <div class="vb-add-item" id="toggle-sticky-bar" style="padding:12px;background:<?php echo !empty($sticky_bar) ? '#d1fae5' : '#f5f5f5'; ?>"><span>📱</span><small>Toggle</small></div>
                        <div class="vb-add-item" id="edit-sticky-bar" style="padding:12px;"><span>⚙️</span><small>Edit</small></div>
                    </div>
                </div>
                <?php if (!$is_paid): ?>
                <p style="font-size:10px;color:#6b7280;text-align:center;margin:10px 0 0;">🔒 = Paid plan required</p>
                <?php endif; ?>
                <button class="vb-add-close" id="vb-add-close" style="margin-top:14px;">Done</button>
            </div>
        </div>
        <style>
        .vb-add-item.locked{opacity:0.5;}
        .vb-upload-progress{width:100%;height:6px;background:#e5e7eb;border-radius:3px;margin-top:10px;overflow:hidden;display:none;}
        .vb-upload-progress.active{display:block;}
        .vb-upload-progress-bar{height:100%;background:linear-gradient(90deg,#F7931E,#fbbf24);width:0%;transition:width 0.3s;}
        /* Products Section */
        .vb-s-products{padding:24px 20px;background:#fff;}
        .vb-s-products.style-gradient{background:linear-gradient(135deg,var(--vb-color,#F7931E),#1a1a2e);}
        .vb-s-products.style-gradient h3{color:#fff;}
        .vb-s-products.style-dark{background:#1a1a2e;}
        .vb-s-products.style-dark h3{color:#fff;}
        .vb-s-products h3{font-size:16px;font-weight:700;margin:0 0 16px;text-align:center;}
        .vb-s-products .products-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:12px;}
        .vb-s-products .product-item{background:#fff;border-radius:10px;overflow:hidden;text-align:center;box-shadow:0 2px 8px rgba(0,0,0,0.06);}
        .vb-s-products .product-img{height:80px;background:#e5e7eb;display:flex;align-items:center;justify-content:center;font-size:24px;}
        .vb-s-products .product-img img{width:100%;height:100%;object-fit:cover;}
        .vb-s-products .product-info{padding:10px;}
        .vb-s-products .product-name{font-size:12px;font-weight:600;color:#1a1a2e;margin:0 0 4px;}
        .vb-s-products .product-price{font-size:14px;font-weight:700;color:var(--vb-color,#F7931E);}
        /* Text Section Styles */
        .vb-s-text{padding:20px;background:#fff;}
        .vb-s-text.style-gradient{background:linear-gradient(135deg,var(--vb-color,#F7931E),#1a1a2e);color:#fff;}
        .vb-s-text.style-gradient p{color:#fff;}
        .vb-s-text.style-dark{background:#1a1a2e;color:#fff;}
        .vb-s-text.style-dark p{color:#fff;}
        /* Separator Section */
        /* Divider should be a straight line with no extra whitespace */
        .vb-s-separator{padding:0;background:transparent;}
        .vb-s-separator .sep-line{height:1px;background:#e5e7eb;margin:0;max-width:100%;}
        .vb-s-separator.style-thick .sep-line{height:3px;background:#d1d5db;}
        .vb-s-separator.style-dotted .sep-line{height:0;border-bottom:2px dotted #d1d5db;background:none;}
        /* Payment Button Section */
        .vb-s-payment{padding:18px 16px;text-align:center;background:#fff;}
            .vb-s-payment.style-light{background:#fff;}
            .vb-s-payment.style-gradient{background:linear-gradient(135deg,var(--vb-color),#1a1a2e);color:#fff;}
            .vb-s-payment.style-dark{background:#1a1a2e;color:#fff;}

        .vb-s-payment .pay-btn{display:inline-block;padding:14px 34px;background:var(--vb-color,#F7931E);color:#fff;border-radius:10px;font-weight:700;font-size:16px;}
        .vb-s-payment .pay-price{font-size:13px;color:#6b7280;margin-top:8px;}
        /* Form Section Styles */
        .vb-s-form.style-gradient{background:linear-gradient(135deg,var(--vb-color,#F7931E),#1a1a2e);color:#fff;}
        .vb-s-form.style-gradient h3{color:#fff;}
        .vb-s-form.style-dark{background:#1a1a2e;color:#fff;}
        .vb-s-form.style-dark h3{color:#fff;}
        /* Footer Styles */
        .vb-s-footer.style-modern{padding:32px 20px;background:linear-gradient(135deg,#1a1a2e,#0f172a);}
        .vb-s-footer.style-modern p{font-size:13px;opacity:1;margin:0 0 8px;}
        .vb-s-footer.style-modern .footer-links{display:flex;justify-content:center;gap:16px;margin-top:12px;}
        .vb-s-footer.style-modern .footer-links a{color:rgba(255,255,255,0.7);font-size:12px;text-decoration:none;}
        .vb-s-footer.style-light{background:#f9fafb;color:#1a1a2e;}
        .vb-s-footer.style-light p{color:#6b7280;opacity:1;}
        /* CTA Button Styles */
        .vb-s-cta .cta-btn{display:inline-block;padding:14px 32px;background:var(--vb-color,#F7931E);color:#fff;border-radius:10px;font-weight:700;font-size:15px;}
        .vb-s-cta .cta-btn.btn-full{display:block;width:100%;text-align:center;box-sizing:border-box;}
        .vb-s-cta .cta-btn.whatsapp-btn{background:#25D366!important;color:#fff!important;}
        /* WhatsApp Icon */
        .wa-icon{display:inline-block;width:18px;height:18px;margin-right:6px;vertical-align:middle;background:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='white'%3E%3Cpath d='M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z'/%3E%3C/svg%3E") no-repeat center/contain;}
        .vb-sticky-preview .btn-wa .wa-icon{background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='white'%3E%3Cpath d='M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z'/%3E%3C/svg%3E");}
        </style>
        
        <input type="hidden" id="vb-page-id" value="<?php echo $page_id; ?>">
        <input type="hidden" id="vb-template" value="<?php echo esc_attr($template); ?>">
        <input type="hidden" id="vb-primary-color" value="<?php echo esc_attr($primary_color); ?>">
        <input type="hidden" id="vb-whatsapp" value="<?php echo esc_attr($wa); ?>">
        <input type="hidden" id="vb-phone" value="<?php echo esc_attr($phone); ?>">
        <input type="hidden" id="vb-sticky-bar" value="<?php echo esc_attr($sticky_bar); ?>">
        <input type="hidden" id="vb-is-paid" value="<?php echo $is_paid ? '1' : '0'; ?>">
        
        <script>
        var vbSections = <?php echo $sections_json ?: json_encode($default_sections); ?>;
        var vbStickyBar = <?php echo $sticky_bar ?: 'null'; ?>;
        var vbIsPaid = <?php echo $is_paid ? 'true' : 'false'; ?>;
        (function(){
            var container = document.getElementById('vb-sections-container');
            var panel = document.getElementById('vb-panel');
            var panelBody = document.getElementById('vb-panel-body');
            var panelOverlay = document.getElementById('vb-panel-overlay');
            var addMenu = document.getElementById('vb-add-menu');
            var editFab = document.getElementById('vb-edit-fab');
            var currentIdx = null;

            function decodeUnicodeEscapes(str){
                if(!str) return '';
                // Convert literal "\\u20a6" or "u20a6" to "₦" etc.
                return String(str).replace(/\\?u([0-9a-fA-F]{4})/g, function(_, hex){
                    try { return String.fromCharCode(parseInt(hex, 16)); } catch(e){ return _; }
                });
            }

            function getCurrencySymbol(code){
                var map = {
                    // West Africa
                    'NGN':'₦','GHS':'₵','XOF':'CFA','XAF':'CFA','GMD':'D','SLL':'Le','LRD':'$','GNF':'FG','CVE':'$','STN':'Db',
                    // East Africa
                    'KES':'KSh','UGX':'USh','TZS':'TSh','RWF':'RF','BIF':'FBu','ETB':'Br','SOS':'Sh',
                    // Southern Africa
                    'ZAR':'R','NAD':'$','BWP':'P','ZMW':'ZK','MWK':'MK','MZN':'MT','AOA':'Kz','LSL':'L','SZL':'E',
                    // North Africa
                    'EGP':'E£','MAD':'د.م.','DZD':'دج','TND':'د.ت','LYD':'ل.د','SDG':'ج.س',
                    // Central Africa
                    'CDF':'FC','XAF':'CFA','XOF':'CFA',
                    // Islands
                    'MGA':'Ar','SCR':'₨','KMF':'CF','DJF':'Fdj','ERN':'Nfk',
                    // International
                    'USD':'$','EUR':'€','GBP':'£','CAD':'$','AUD':'$'
                };
                return map[String(code||'').toUpperCase()] || '';
            }

            
            function currencyOptionsHtml(){
                // Keep it short but cover major African currencies
                return ''
                  + '<option value="USD">USD ($)</option>'
                  + '<option value="NGN">NGN (₦)</option>'
                  + '<option value="GHS">GHS (₵)</option>'
                  + '<option value="KES">KES (KSh)</option>'
                  + '<option value="UGX">UGX (USh)</option>'
                  + '<option value="TZS">TZS (TSh)</option>'
                  + '<option value="ZAR">ZAR (R)</option>'
                  + '<option value="RWF">RWF (RF)</option>'
                  + '<option value="XOF">XOF (CFA)</option>'
                  + '<option value="XAF">XAF (CFA)</option>'
                  + '<option value="ETB">ETB (Br)</option>'
                  + '<option value="EGP">EGP (E£)</option>'
                  + '<option value="MAD">MAD (د.م.)</option>'
                  + '<option value="DZD">DZD (دج)</option>'
                  + '<option value="TND">TND (د.ت)</option>'
                  + '<option value="LYD">LYD (ل.د)</option>'
                  + '<option value="ZMW">ZMW (ZK)</option>'
                  + '<option value="BWP">BWP (P)</option>'
                  + '<option value="NAD">NAD ($)</option>'
                  + '<option value="AOA">AOA (Kz)</option>'
                  + '<option value="MZN">MZN (MT)</option>'
                  + '<option value="MWK">MWK (MK)</option>'
                  + '<option value="GMD">GMD (D)</option>'
                  + '<option value="SLL">SLL (Le)</option>'
                  + '<option value="LRD">LRD ($)</option>'
                  + '<option value="GNF">GNF (FG)</option>'
                  + '<option value="CDF">CDF (FC)</option>';
            }
function formatPrice(raw, currencyCode){
                raw = decodeUnicodeEscapes(raw||'').trim();
                if(!raw) return '';
                // If user already provided a currency sign or code, keep it.
                if(/[A-Za-z]{2,}|[₦₵£€$¥]|CFA|KSh|USh|TSh|RF|د\./.test(raw)) return raw;
                var num = raw.replace(/[^0-9.]/g,'');
                if(!num) return raw;
                var parts = num.split('.');
                parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',');
                var symbol = getCurrencySymbol(currencyCode);
                return (symbol ? (symbol + parts.join('.')) : parts.join('.'));
            }
            
            function renderSections(){
                container.innerHTML = '';
                vbSections.forEach(function(sec, idx){
                    var div = document.createElement('div');
                    div.className = 'vb-section vb-s-' + sec.type + (sec.style ? ' style-' + sec.style : '');
                    div.dataset.idx = idx;
                    div.innerHTML = getSectionHTML(sec) + getSectionTools();
                    container.appendChild(div);
                });
                renderStickyBar();
                bindSectionEvents();
            }
            
            function getSectionHTML(sec){
                switch(sec.type){
                    case 'hero':
                        var media = sec.video ? '<video src="'+sec.video+'" autoplay muted loop playsinline></video>' : (sec.image ? '<img src="'+sec.image+'">' : '');
                        return '<h1>'+(sec.headline||'Your Headline')+'</h1><p>'+(sec.subheadline||'Subheadline text')+'</p>'+media;
                    case 'banner':
                        var img = sec.image ? '<img src="'+sec.image+'">' : '';
                        var btn = sec.button ? '<div class="btn">'+sec.button+'</div>' : '';
                        return '<h2>'+(sec.headline||'Banner Title')+'</h2><p>'+(sec.subheadline||'Supporting text')+'</p>'+img+btn;
                    case 'features':
                        var raw = (sec.items||'Feature 1\nFeature 2\nFeature 3'); raw = String(raw).replace(/\\r\\n/g,'\n').replace(/\\n/g,'\n'); raw = raw.replace(/(\w)n([A-Z0-9])/g,'$1\n$2'); var items = raw.split('\n').filter(function(i){return i.trim();});
                        return '<h3>'+(sec.title||'Features')+'</h3><ul>'+items.map(function(i){return '<li>'+i.trim()+'</li>';}).join('')+'</ul>';
                    case 'cta':
                        var action = sec.action || 'whatsapp';
                        var btnClass = 'cta-btn' + (action === 'whatsapp' ? ' whatsapp-btn' : '') + (sec.btnWidth === 'full' ? ' btn-full' : '');
                        var btnIcon = action === 'whatsapp' ? '<span class="wa-icon"></span>' : '';
                        var btnText = action === 'whatsapp' ? 'WhatsApp' : (sec.button||'Get Started');
                        var textHtml = sec.text ? '<p>'+sec.text+'</p>' : '';
                        return textHtml+'<div class="'+btnClass+'">'+btnIcon+btnText+'</div>';
                    case 'payment':
                        var cur = sec.currency || 'NGN';
                        var amt = (sec.amount!==undefined && sec.amount!==null && sec.amount!=='') ? sec.amount : (sec.price||'');
                        var priceTxt = amt ? formatPrice(amt, cur) : '';
                        var label = (sec.button||'Pay Now') + (priceTxt ? ': ' + priceTxt : '');
                        return '<div class="pay-btn">'+label+'</div>';
                    case 'separator':
                        return '<div class="sep-line"></div>';
                    case 'products':
                        var products = sec.products || [{name:'Product 1',price:'5000'},{name:'Product 2',price:'3000'}];
                        var cur = sec.currency || 'NGN';
                        var html = '<h3>'+(sec.title||'Our Products')+'</h3><div class="products-grid">';
                        products.forEach(function(p){
                            html += '<div class="product-item"><div class="product-img">'+(p.image?'<img src="'+p.image+'">':'🛍️')+'</div><div class="product-info"><div class="product-name">'+(p.name||'Product')+'</div><div class="product-price">'+formatPrice(p.price||'', cur)+'</div></div></div>';
                        });
                        return html+'</div>';
                    case 'media':
                        if(sec.video) return '<video src="'+sec.video+'" controls playsinline></video>';
                        if(sec.image) return '<img src="'+sec.image+'">';
                        return '<div style="padding:40px;text-align:center;color:#999;">📷 Add media</div>';
                    case 'text':
                        var big = sec.bigTitle ? '<h2 class="vb-big-title">'+sec.bigTitle+'</h2>' : '';
                        var small = sec.title ? '<h3>'+sec.title+'</h3>' : '';
                        return big + small + '<p>'+(sec.content||'Your text here...')+'</p>';
                    case 'form':
                        var fields = sec.fields || ['name','email','phone'];
                        if(typeof fields === 'string') fields = fields.split(',');
                        var fieldsHtml = fields.map(function(f){return '<div class="field">'+f.trim()+'</div>';}).join('');
                        return '<h3>'+(sec.title||'Contact Us')+'</h3><div class="form-preview">'+fieldsHtml+'<div class="btn">'+(sec.button||'Submit')+'</div></div>';
                    case 'footer':
                        var html = '';
                        if(sec.tagline) html += '<p class="ft-tagline">'+sec.tagline+'</p>';
                        if(sec.address) html += '<p class="ft-address">'+sec.address+'</p>';
                        html += '<p>'+(sec.text||'© 2025 Your Business')+'</p>';
                        if(sec.disclaimer) html += '<p class="ft-disclaimer">'+sec.disclaimer+'</p>';
                        if(sec.showSocial){
                            html += '<div class="footer-links">';
                            if(sec.facebook) html += '<a href="#">Facebook</a>';
                            if(sec.instagram) html += '<a href="#">Instagram</a>';
                            if(sec.x) html += '<a href="#">X</a>';
                            if(sec.waurl) html += '<a href="#">WhatsApp</a>';
                            html += '</div>';
                        }
                        return html;
                    default: return '<p>Section</p>';
                }
            }
            
            function getSectionTools(){
                return '<div class="vb-section-tools"><button type="button" data-action="up">↑</button><button type="button" data-action="down">↓</button><button type="button" data-action="dup">⧉</button><button type="button" data-action="del">×</button></div>';
            }
            
            function renderStickyBar(){
                var preview = document.getElementById('vb-sticky-bar-preview');
                if(vbStickyBar && vbStickyBar.enabled){
                    var style = vbStickyBar.barStyle || vbStickyBar.style || 'light';
                    var html = '<div class="vb-sticky-preview bar-' + style + '">';
                    if(vbStickyBar.whatsapp) html += '<div class="bar-btn btn-wa"><span class="wa-icon"></span> WhatsApp</div>';
                    if(vbStickyBar.phone) html += '<div class="bar-btn btn-call">📞 Call</div>';
                    var linkUrl = vbStickyBar.link_url || vbStickyBar.link || vbStickyBar.linkUrl || '';
                    if((vbStickyBar.showLink || linkUrl) && linkUrl) html += '<div class="bar-btn btn-link">🔗 Link</div>';
                    html += '</div>';
                    preview.innerHTML = html;
                } else {
                    preview.innerHTML = '';
                }
            }

            function bindSectionEvents(){
                var lastTap = 0;
                var lastTapSection = null;
                
                document.querySelectorAll('.vb-section').forEach(function(el){
                    // Single tap: select section (show tools)
                    // Double tap: open edit panel
                    el.addEventListener('click', function(e){
                        if(e.target.closest('.vb-section-tools')) return;
                        var idx = parseInt(this.dataset.idx);
                        // If edit panel is open, switch immediately to the tapped section
                        if(panel.classList.contains('open')){ editSection(idx); return; }
                        
                        var now = Date.now();
                        
                        // Check for double tap
                        if(lastTapSection === idx && now - lastTap < 300) {
                            // Double tap - open edit panel
                            editSection(idx);
                            lastTap = 0;
                            lastTapSection = null;
                        } else {
                            // Single tap - just select (show tools)
                            currentIdx = idx;
                            document.querySelectorAll('.vb-section').forEach(function(s,i){
                                s.classList.toggle('editing', i===idx);
                            });
                            editFab.classList.add('show');
                            lastTap = now;
                            lastTapSection = idx;
                        }
                    });
                });
                document.querySelectorAll('.vb-section-tools button').forEach(function(btn){
                    btn.addEventListener('click', function(e){
                        e.stopPropagation();
                        var idx = parseInt(this.closest('.vb-section').dataset.idx);
                        var action = this.dataset.action;
                        if(action === 'up' && idx > 0){
                            var temp = vbSections[idx]; vbSections[idx] = vbSections[idx-1]; vbSections[idx-1] = temp;
                        } else if(action === 'down' && idx < vbSections.length-1){
                            var temp = vbSections[idx]; vbSections[idx] = vbSections[idx+1]; vbSections[idx+1] = temp;
                        } else if(action === 'dup'){
                            vbSections.splice(idx+1, 0, JSON.parse(JSON.stringify(vbSections[idx])));
                        } else if(action === 'del'){
                            if(confirm('Delete this section?')) vbSections.splice(idx, 1);
                        }
                        renderSections();
                    });
                });
            }
            
            function editSection(idx){
                currentIdx = idx;
                var sec = vbSections[idx];
                document.querySelectorAll('.vb-section').forEach(function(el,i){
                    el.classList.toggle('editing', i===idx);
                });
                document.getElementById('vb-panel-title').textContent = 'Edit ' + sec.type.charAt(0).toUpperCase() + sec.type.slice(1);
                panelBody.innerHTML = getEditForm(sec);
                bindEditForm(idx);
                // Set select defaults
                var curSel = document.getElementById('edit-currency');
                if(curSel) curSel.value = (sec.currency || 'NGN');
                openPanel();
                editFab.classList.add('show');
            }
            
            function getEditForm(sec){
                var html = '';
                // Style selector
                var styles = getStyles(sec.type);
                if(styles.length > 1){
                    html += '<div class="vb-form-group"><label>Style</label><div class="vb-grid-3">';
                    styles.forEach(function(s){
                        html += '<div class="vb-opt compact'+(sec.style===s.id?' active':'')+'" data-style="'+s.id+'"><span>'+s.icon+'</span><small>'+s.name+'</small></div>';
                    });
                    html += '</div></div>';
                }
                
                // Type-specific fields
                switch(sec.type){
                    case 'hero':
                    case 'banner':
                        html += '<div class="vb-form-group"><label>Headline</label><input type="text" id="edit-headline" value="'+(sec.headline||'')+'"></div>';
                        html += '<div class="vb-form-group"><label>Subheadline</label><input type="text" id="edit-subheadline" value="'+(sec.subheadline||'')+'"></div>';
                        html += '<div class="vb-form-group"><label>Image</label><div class="vb-upload" id="edit-image-upload"><div class="vb-upload-icon">📷</div><div class="vb-upload-text">Upload image</div><input type="file" accept="image/*">'+(sec.image?'<img src="'+sec.image+'" class="vb-upload-preview">':'')+'<div class="vb-upload-progress"><div class="vb-upload-progress-bar"></div></div></div></div>';
                        if(sec.type === 'hero'){
                            html += '<div class="vb-form-group"><label>Video (optional)</label><div class="vb-upload" id="edit-video-upload"><div class="vb-upload-icon">🎬</div><div class="vb-upload-text">Upload video</div><input type="file" accept="video/*">'+(sec.video?'<video src="'+sec.video+'" class="vb-upload-preview" style="max-height:80px"></video>':'')+'<div class="vb-upload-progress"><div class="vb-upload-progress-bar"></div></div></div></div>';
                        }
                        if(sec.type === 'banner'){
                            html += '<div class="vb-form-group"><label>Button Text</label><input type="text" id="edit-button" value="'+(sec.button||'')+'"></div>';
                            html += getActionFields(sec);
                        }
                        break;
                    case 'features':
                        html += '<div class="vb-form-group"><label>Title</label><input type="text" id="edit-title" value="'+(sec.title||'Features')+'"></div>';
                        html += '<div class="vb-form-group"><label>Features (one per line)</label><textarea id="edit-items">'+(sec.items||'Feature 1\nFeature 2\nFeature 3')+'</textarea></div>';
                        break;
                    case 'cta':
                        html += '<div class="vb-form-group"><label>Text Above Button</label><input type="text" id="edit-text" value="'+(sec.text||'')+'"></div>';
                        html += '<div class="vb-form-group"><label>Button Text</label><input type="text" id="edit-button" value="'+(sec.button||'Get Started')+'"></div>';
                        html += '<div class="vb-form-group"><label>Button Width</label><div class="vb-grid-2 vb-compact-grid"><div class="vb-opt compact'+(sec.btnWidth!=='full'?' active':'')+'" data-width="inline"><span>↔️</span><small>Inline</small></div><div class="vb-opt compact'+(sec.btnWidth==='full'?' active':'')+'" data-width="full"><span>⬛</span><small>Full</small></div></div></div>';
                        html += getActionFields(sec);
                        break;
                    case 'payment':
                        html += '<div class="vb-form-group"><label>Button Text</label><input type="text" id="edit-button" value="'+(sec.button||'Pay Now')+'"></div>';
                        html += '<div class="vb-form-group"><label>Amount</label><input type="number" id="edit-amount" value="'+(sec.amount||'')+'" placeholder="5000" min="0" step="0.01"></div>';
                        html += '<div class="vb-form-group"><label>Currency</label><select id="edit-currency" style="width:100%;padding:12px;border:2px solid #e5e7eb;border-radius:12px;font-size:14px;">'
                          + currencyOptionsHtml()
                          + '</select></div>';
                        break;
                    case 'separator':
                        html += '<div class="vb-form-group"><label>Divider Width</label>'
                          + '<select id="edit-sep-width" style="width:100%;padding:10px;border:2px solid #e5e7eb;border-radius:12px;font-size:14px;">'
                          + '<option value="full">Full</option>'
                          + '<option value="content">Content</option>'
                          + '</select></div>';
                        html += '<div class="vb-form-group"><label>Divider Color</label>'
                          + '<input id="edit-sep-color" type="color" value="'+(sec.color||'#e5e7eb')+'" style="width:100%;height:44px;border:2px solid #e5e7eb;border-radius:12px;padding:6px;background:#fff;">'
                          + '</div>';
                        break;
                    case 'products':
                        html += '<div class="vb-form-group"><label>Section Title</label><input type="text" id="edit-title" value="'+(sec.title||'Our Products')+'"></div>';
                        html += '<div class="vb-form-group"><label>Currency</label><select id="edit-currency" style="width:100%;padding:12px;border:2px solid #e5e7eb;border-radius:12px;font-size:14px;">'
                          + currencyOptionsHtml()
                          + '</select></div>';
                        html += '<div class="vb-form-group"><label>Products</label><div id="edit-products-list">';
                        var prods = sec.products || [{name:'Product 1',price:'₦5,000'},{name:'Product 2',price:'₦3,000'}];
                        prods.forEach(function(p,i){
                            html += '<div class="vb-product-item" data-idx="'+i+'" style="background:#f5f5f5;padding:12px;border-radius:8px;margin-bottom:8px;"><input type="text" placeholder="Name" value="'+(p.name||'')+'" class="prod-name" style="margin-bottom:6px;"><input type="text" placeholder="Price" value="'+(p.price||'')+'" class="prod-price" style="margin-bottom:6px;"><div class="vb-upload prod-img-upload" style="padding:12px;"><span style="font-size:20px;">📷</span><input type="file" accept="image/*">'+(p.image?'<img src="'+p.image+'" style="max-height:60px;border-radius:6px;">':'')+'</div><button type="button" class="rem-product" style="color:#ef4444;border:none;background:none;cursor:pointer;">× Remove</button></div>';
                        });
                        html += '</div><button type="button" id="add-product-btn" style="padding:10px;background:#F7931E;color:#fff;border:none;border-radius:8px;width:100%;font-weight:600;cursor:pointer;margin-top:8px;">+ Add Product</button></div>';
                        break;
                    case 'media':
                        html += '<div class="vb-form-group"><label>Image</label><div class="vb-upload" id="edit-image-upload"><div class="vb-upload-icon">📷</div><div class="vb-upload-text">Upload image</div><input type="file" accept="image/*">'+(sec.image?'<img src="'+sec.image+'" class="vb-upload-preview">':'')+'<div class="vb-upload-progress"><div class="vb-upload-progress-bar"></div></div></div></div>';
                        html += '<div class="vb-form-group"><label>Or Video</label><div class="vb-upload" id="edit-video-upload"><div class="vb-upload-icon">🎬</div><div class="vb-upload-text">Upload video</div><input type="file" accept="video/*">'+(sec.video?'<video src="'+sec.video+'" class="vb-upload-preview" controls style="max-height:80px"></video>':'')+'<div class="vb-upload-progress"><div class="vb-upload-progress-bar"></div></div></div></div>';
                        break;
                    case 'text':
                        html += '<div class="vb-form-group"><label>Big Title</label><input type="text" id="edit-bigTitle" value="'+(sec.bigTitle||'')+'" placeholder="Big heading"></div>';
                        html += '<div class="vb-form-group"><label>Big Title Weight</label><select id="edit-bigTitleWeight" style="width:100%;padding:10px;border:2px solid #e5e7eb;border-radius:12px;font-size:14px;">'
                          + '<option value="600">Semi Bold</option><option value="700">Bold</option><option value="800">Extra Bold</option><option value="900">Black</option>'
                          + '</select></div>';
                        html += '<div class="vb-form-group"><label>Title</label><input type="text" id="edit-title" value="'+(sec.title||'')+'" placeholder="Section title"></div>';
                        html += '<div class="vb-form-group"><label>Title Weight</label><select id="edit-titleWeight" style="width:100%;padding:10px;border:2px solid #e5e7eb;border-radius:12px;font-size:14px;">'
                          + '<option value="500">Medium</option><option value="600">Semi Bold</option><option value="700">Bold</option><option value="800">Extra Bold</option>'
                          + '</select></div>';
                        html += '<div class="vb-form-group"><label>Content</label><textarea id="edit-content">'+(sec.content||'')+'</textarea></div>';
                        break;
                    case 'form':
                        html += '<div class="vb-form-group"><label>Form Title</label><input type="text" id="edit-title" value="'+(sec.title||'Contact Us')+'"></div>';
                        html += '<div class="vb-form-group"><label>Fields</label><div class="vb-field-list" id="edit-fields">';
                        var fields = sec.fields || ['name','email','phone'];
                        if(typeof fields === 'string') fields = fields.split(',');
                        fields.forEach(function(f,i){
                            html += '<div class="vb-field-item"><input type="text" value="'+f.trim()+'" data-idx="'+i+'"><button type="button" class="rem">×</button></div>';
                        });
                        html += '</div><button type="button" class="vb-add-field-btn" id="add-field-btn">+ Add Field</button></div>';
                        html += '<div class="vb-form-group"><label>Submit Button</label><input type="text" id="edit-button" value="'+(sec.button||'Submit')+'"></div>';
                        break;
                    case 'footer':
                        // Footer text
                        html += '<div class="vb-form-group"><label>Footer Text</label><input type="text" id="edit-text" value="'+(sec.text||'© 2025 Your Business')+'"></div>';
                        // Additional fields: tagline, address, disclaimer
                        html += '<div class="vb-form-group"><label>Tagline</label><input type="text" id="edit-tagline" value="'+(sec.tagline||'')+'" placeholder="Optional tagline"></div>';
                        html += '<div class="vb-form-group"><label>Address</label><input type="text" id="edit-address" value="'+(sec.address||'')+'" placeholder="Optional address"></div>';
                        html += '<div class="vb-form-group"><label>Disclaimer</label><textarea id="edit-disclaimer" placeholder="Optional disclaimer">'+(sec.disclaimer||'')+'</textarea></div>';
                        // Social link fields
                        html += '<div class="vb-form-group"><label>Facebook URL</label><input type="url" id="edit-facebook" value="'+(sec.facebook||'')+'" placeholder="https://facebook.com/..." ></div>';
                        html += '<div class="vb-form-group"><label>Instagram URL</label><input type="url" id="edit-instagram" value="'+(sec.instagram||'')+'" placeholder="https://instagram.com/..." ></div>';
                        html += '<div class="vb-form-group"><label>X URL</label><input type="url" id="edit-x" value="'+(sec.x||'')+'" placeholder="https://x.com/..." ></div>';
                        html += '<div class="vb-form-group"><label>WhatsApp URL</label><input type="url" id="edit-waurl" value="'+(sec.whatsapp_url||'')+'" placeholder="https://wa.me/..." ></div>';
                        // Toggle for showing social links
                        html += '<div class="vb-form-group"><label>Show Social Links</label><div class="vb-grid-2 vb-compact-grid"><div class="vb-opt compact'+(sec.showSocial?' active':'')+'" data-social="1"><span>✅</span><small>Show</small></div><div class="vb-opt compact'+(!sec.showSocial?' active':'')+'" data-social="0"><span>❌</span><small>Hide</small></div></div></div>';
                        break;
                }
                
                // Color picker for hero/banner/cta/form/payment
                if(['hero','banner','cta','form','payment'].includes(sec.type)){
                    html += '<div class="vb-form-group"><label>Theme Color</label><div class="vb-colors">';
                    ['#F7931E','#ef4444','#10b981','#3b82f6','#8b5cf6','#1a1a2e','#db2777'].forEach(function(c){
                        html += '<div class="vb-color'+(document.getElementById('vb-primary-color').value===c?' active':'')+'" data-color="'+c+'" style="background:'+c+'"></div>';
                    });
                    html += '</div></div>';
                }
                
                return html;
            }
            
            function getActionFields(sec){
                var html = '<div class="vb-form-group"><label>Button Action</label><div class="vb-grid-3">';
                html += '<div class="vb-opt compact'+(sec.action==='whatsapp'||!sec.action?' active':'')+'" data-action="whatsapp"><span>💬</span><small>WhatsApp</small></div>';
                html += '<div class="vb-opt compact'+(sec.action==='phone'?' active':'')+'" data-action="phone"><span>📞</span><small>Call</small></div>';
                html += '<div class="vb-opt compact'+(sec.action==='link'?' active':'')+'" data-action="link"><span>🔗</span><small>Link</small></div>';
                html += '</div></div>';
                var action = sec.action || 'whatsapp';
                if(action==='whatsapp') html += '<div class="vb-form-group"><label>WhatsApp Number</label><input type="text" id="edit-whatsapp" value="'+(sec.whatsapp||document.getElementById('vb-whatsapp').value)+'" placeholder="2348012345678"></div>';
                if(action==='phone') html += '<div class="vb-form-group"><label>Phone Number</label><input type="text" id="edit-phone" value="'+(sec.phone||document.getElementById('vb-phone').value)+'" placeholder="+234..."></div>';
                if(action==='link') html += '<div class="vb-form-group"><label>Bar Background</label><select id="bar-style" style="width:100%;padding:10px;border:2px solid #e5e7eb;border-radius:12px;font-size:14px;">'
                  + '<option value="light">Light</option><option value="gradient">Gradient</option><option value="dark">Dark</option></select></div>';
                html += '<div class="vb-form-group"><label>WhatsApp Number</label><input type="text" id="bar-wa-number" value="'+(vbStickyBar.whatsapp||'')+'" placeholder="2348012345678"></div>';
                html += '<div class="vb-form-group"><label>Call Number</label><input type="text" id="bar-call-number" value="'+(vbStickyBar.phone||'')+'" placeholder="+2348012345678"></div>';
                html += '<div class="vb-form-group"><label>Link URL</label><input type="url" id="edit-link" value="'+(sec.link||'')+'" placeholder="https://..."></div>';
                return html;
            }
            
            function getStyles(type){
                switch(type){
                    case 'hero': return [{id:'gradient',icon:'🌈',name:'Gradient'},{id:'bold',icon:'⬛',name:'Bold'},{id:'minimal',icon:'⬜',name:'Light'}];
                    case 'banner': return [{id:'gradient',icon:'🌈',name:'Gradient'},{id:'light',icon:'⬜',name:'Light'},{id:'dark',icon:'⬛',name:'Dark'}];
                    case 'features': return [{id:'list',icon:'📋',name:'List'},{id:'dark',icon:'🌙',name:'Dark'}];
                    case 'cta': return [{id:'light',icon:'⬜',name:'Light'},{id:'gradient',icon:'🌈',name:'Gradient'},{id:'dark',icon:'⬛',name:'Dark'}];
                    case 'media': return [{id:'padded',icon:'📐',name:'Padded'},{id:'full',icon:'⬜',name:'Full'}];
                    case 'form': return [{id:'light',icon:'⬜',name:'Light'},{id:'gradient',icon:'🌈',name:'Gradient'},{id:'dark',icon:'⬛',name:'Dark'}];
                    case 'text': return [{id:'light',icon:'⬜',name:'Light'},{id:'gradient',icon:'🌈',name:'Gradient'},{id:'dark',icon:'⬛',name:'Dark'}];
                    case 'products': return [{id:'light',icon:'⬜',name:'Light'},{id:'gradient',icon:'🌈',name:'Gradient'},{id:'dark',icon:'⬛',name:'Dark'}];
                    case 'separator': return [{id:'thin',icon:'─',name:'Thin'},{id:'thick',icon:'━',name:'Thick'},{id:'dotted',icon:'┈',name:'Dotted'}];
                    case 'payment': return [{id:'light',icon:'⬜',name:'Light'},{id:'gradient',icon:'🌈',name:'Gradient'},{id:'dark',icon:'⬛',name:'Dark'}];
                    case 'footer': return [{id:'default',icon:'📄',name:'Simple'},{id:'modern',icon:'✨',name:'Modern'},{id:'light',icon:'⬜',name:'Light'}];
                    default: return [{id:'default',icon:'📄',name:'Default'}];
                }
            }
            
            function bindEditForm(idx){
                // Style options
                document.querySelectorAll('.vb-opt[data-style]').forEach(function(el){
                    el.addEventListener('click', function(){
                        document.querySelectorAll('.vb-opt[data-style]').forEach(function(x){x.classList.remove('active');});
                        this.classList.add('active');
                        vbSections[idx].style = this.dataset.style;
                        renderSections();
                        editSection(idx);
                    });
                });
                
                // Action options
                document.querySelectorAll('.vb-opt[data-action]').forEach(function(el){
                    el.addEventListener('click', function(){
                        document.querySelectorAll('.vb-opt[data-action]').forEach(function(x){x.classList.remove('active');});
                        this.classList.add('active');
                        vbSections[idx].action = this.dataset.action;
                        editSection(idx);
                    });
                });
                
                // Social toggle for footer
                document.querySelectorAll('.vb-opt[data-social]').forEach(function(el){
                    el.addEventListener('click', function(){
                        document.querySelectorAll('.vb-opt[data-social]').forEach(function(x){x.classList.remove('active');});
                        this.classList.add('active');
                        vbSections[idx].showSocial = this.dataset.social === '1';
                        renderSections();
                    });
                });
                
                // Button width toggle for CTA
                document.querySelectorAll('.vb-opt[data-width]').forEach(function(el){
                    el.addEventListener('click', function(){
                        document.querySelectorAll('.vb-opt[data-width]').forEach(function(x){x.classList.remove('active');});
                        this.classList.add('active');
                        vbSections[idx].btnWidth = this.dataset.width;
                        renderSections();
                    });
                });
                
                // Color options
                document.querySelectorAll('.vb-color').forEach(function(el){
                    el.addEventListener('click', function(){
                        document.querySelectorAll('.vb-color').forEach(function(x){x.classList.remove('active');});
                        this.classList.add('active');
                        document.getElementById('vb-primary-color').value = this.dataset.color;
                        document.querySelector('.vb-wrap').style.setProperty('--vb-color', this.dataset.color);
                        renderSections();
                    });
                });
                
                // Text inputs
                ['headline','subheadline','bigTitle','bigTitleWeight','title','titleWeight','items','text','button','content','whatsapp','phone','link','description','amount','currency',
                 // Footer extras
                 'tagline','address','disclaimer','facebook','instagram','x','waurl'
                ].forEach(function(field){
                    var el = document.getElementById('edit-'+field);
                    if(el){
                        var handler = function(){
                            vbSections[idx][field] = this.value;
                            renderSections();
                        };
                        el.addEventListener('input', handler);
                        el.addEventListener('change', handler);
                    }
                });

                // Selects (text weight)
                var bw = document.getElementById('edit-bigTitleWeight');
                if(bw){ bw.value = vbSections[idx].bigTitleWeight || '800'; bw.addEventListener('change', function(){ vbSections[idx].bigTitleWeight = this.value; renderSections(); }); }
                var tw = document.getElementById('edit-titleWeight');
                if(tw){ tw.value = vbSections[idx].titleWeight || '700'; tw.addEventListener('change', function(){ vbSections[idx].titleWeight = this.value; renderSections(); }); }

                // Selects (currency)
                var curSel = document.getElementById('edit-currency');
                if(curSel){
                    try { curSel.value = vbSections[idx].currency || 'NGN'; } catch(e) {}
                    curSel.addEventListener('change', function(){
                        vbSections[idx].currency = this.value;
                        renderSections();
                    });
                }
                
                // Divider controls
                var sepW = document.getElementById('edit-sep-width');
                if(sepW){
                    sepW.value = vbSections[idx].width || 'full';
                    sepW.addEventListener('change', function(){
                        vbSections[idx].width = this.value;
                        renderSections();
                    });
                }
                var sepC = document.getElementById('edit-sep-color');
                if(sepC){
                    sepC.value = vbSections[idx].color || '#e5e7eb';
                    sepC.addEventListener('input', function(){
                        vbSections[idx].color = this.value;
                        renderSections();
                    });
                }

                // Image upload with progress
                var imgUpload = document.getElementById('edit-image-upload');
                if(imgUpload){
                    imgUpload.addEventListener('click', function(e){if(e.target.tagName!=='INPUT')this.querySelector('input').click();});
                    imgUpload.querySelector('input').addEventListener('change', function(){
                        if(this.files && this.files[0]) uploadFile(this.files[0], 'image', function(url){
                            vbSections[idx].image = url;
                            renderSections();
                            editSection(idx);
                        }, imgUpload);
                    });
                }
                
                // Video upload with progress
                var vidUpload = document.getElementById('edit-video-upload');
                if(vidUpload){
                    vidUpload.addEventListener('click', function(e){if(e.target.tagName!=='INPUT')this.querySelector('input').click();});
                    vidUpload.querySelector('input').addEventListener('change', function(){
                        if(this.files && this.files[0]) uploadFile(this.files[0], 'video', function(url){
                            vbSections[idx].video = url;
                            renderSections();
                            editSection(idx);
                        }, vidUpload);
                    });
                }
                
                // Ebook upload
                var ebookUpload = document.getElementById('edit-ebook-upload');
                if(ebookUpload){
                    ebookUpload.addEventListener('click', function(e){if(e.target.tagName!=='INPUT')this.querySelector('input').click();});
                    ebookUpload.querySelector('input').addEventListener('change', function(){
                        if(this.files && this.files[0]) uploadFile(this.files[0], 'ebook', function(url){
                            vbSections[idx].file = url;
                            editSection(idx);
                        }, ebookUpload);
                    });
                }
                
                // Products management
                var addProductBtn = document.getElementById('add-product-btn');
                if(addProductBtn){
                    addProductBtn.addEventListener('click', function(){
                        var prods = vbSections[idx].products || [];
                        prods.push({name:'New Product',price:'₦0'});
                        vbSections[idx].products = prods;
                        editSection(idx);
                    });
                }
                document.querySelectorAll('.vb-product-item').forEach(function(item){
                    var pidx = parseInt(item.dataset.idx);
                    item.querySelector('.prod-name').addEventListener('input', function(){
                        vbSections[idx].products[pidx].name = this.value;
                        renderSections();
                    });
                    item.querySelector('.prod-price').addEventListener('input', function(){
                        vbSections[idx].products[pidx].price = this.value;
                        renderSections();
                    });
                    var prodImgUpload = item.querySelector('.prod-img-upload');
                    if(prodImgUpload){
                        prodImgUpload.addEventListener('click', function(e){if(e.target.tagName!=='INPUT')this.querySelector('input').click();});
                        prodImgUpload.querySelector('input').addEventListener('change', function(){
                            var self = this;
                            if(self.files && self.files[0]){
                                uploadFile(self.files[0], 'image', function(url){
                                    vbSections[idx].products[pidx].image = url;
                                    renderSections();
                                    editSection(idx);
                                }, prodImgUpload);
                            }
                        });
                    }
                    item.querySelector('.rem-product').addEventListener('click', function(){
                        vbSections[idx].products.splice(pidx, 1);
                        editSection(idx);
                        renderSections();
                    });
                });
                
                // Form fields management
                var addFieldBtn = document.getElementById('add-field-btn');
                if(addFieldBtn){
                    addFieldBtn.addEventListener('click', function(){
                        var fields = vbSections[idx].fields || ['name','email','phone'];
                        if(typeof fields === 'string') fields = fields.split(',');
                        fields.push('New Field');
                        vbSections[idx].fields = fields;
                        editSection(idx);
                    });
                }
                document.querySelectorAll('.vb-field-item input').forEach(function(el){
                    el.addEventListener('input', function(){
                        var fields = [];
                        document.querySelectorAll('.vb-field-item input').forEach(function(inp){
                            if(inp.value.trim()) fields.push(inp.value.trim());
                        });
                        vbSections[idx].fields = fields;
                        renderSections();
                    });
                });
                document.querySelectorAll('.vb-field-item .rem').forEach(function(btn){
                    btn.addEventListener('click', function(){
                        var item = this.closest('.vb-field-item');
                        var fields = [];
                        document.querySelectorAll('.vb-field-item input').forEach(function(inp){
                            if(inp !== item.querySelector('input') && inp.value.trim()) fields.push(inp.value.trim());
                        });
                        vbSections[idx].fields = fields;
                        editSection(idx);
                    });
                });
            }
            
            function uploadFile(file, type, callback, uploadEl){
                var fd = new FormData();
                fd.append('action', type === 'video' ? 'hushot_upload_video' : (type === 'ebook' ? 'hushot_upload_ebook' : 'hushot_upload_image'));
                fd.append(type === 'ebook' ? 'ebook' : type, file);
                fd.append('_wpnonce','<?php echo wp_create_nonce("hushot_upload"); ?>');
                
                // Show progress bar
                var progressWrap = uploadEl ? uploadEl.querySelector('.vb-upload-progress') : null;
                var progressBar = progressWrap ? progressWrap.querySelector('.vb-upload-progress-bar') : null;
                if(progressWrap) progressWrap.classList.add('active');
                if(progressBar) progressBar.style.width = '10%';
                
                var xhr = new XMLHttpRequest();
                xhr.open('POST', '<?php echo admin_url("admin-ajax.php"); ?>', true);
                
                xhr.upload.onprogress = function(e){
                    if(e.lengthComputable && progressBar){
                        var pct = Math.round((e.loaded / e.total) * 90);
                        progressBar.style.width = pct + '%';
                    }
                };
                
                xhr.onload = function(){
                    if(progressBar) progressBar.style.width = '100%';
                    setTimeout(function(){
                        if(progressWrap) progressWrap.classList.remove('active');
                        if(progressBar) progressBar.style.width = '0%';
                    }, 500);
                    
                    try {
                        var d = JSON.parse(xhr.responseText);
                        if(d.success && d.data.url) callback(d.data.url);
                        else alert('Upload failed: ' + (d.data || 'Unknown error'));
                    } catch(e){
                        alert('Upload failed');
                    }
                };
                
                xhr.onerror = function(){
                    if(progressWrap) progressWrap.classList.remove('active');
                    alert('Upload failed');
                };
                
                xhr.send(fd);
            }
            
            function openPanel(){ panel.classList.add('open'); panelOverlay.classList.add('show'); }
            function closePanel(){ panel.classList.remove('open'); panelOverlay.classList.remove('show'); document.querySelectorAll('.vb-section').forEach(function(el){el.classList.remove('editing');}); currentIdx = null; editFab.classList.remove('show'); }
            
            // Event listeners
            document.getElementById('vb-panel-close').addEventListener('click', closePanel);
            panelOverlay.addEventListener('click', closePanel);
            document.getElementById('vb-add-section-btn').addEventListener('click', function(){ addMenu.classList.add('open'); });
            document.getElementById('vb-add-close').addEventListener('click', function(){ addMenu.classList.remove('open'); });
            document.getElementById('vb-add-close-x').addEventListener('click', function(){ addMenu.classList.remove('open'); });
            
            document.querySelectorAll('.vb-add-item[data-type]').forEach(function(el){
                el.addEventListener('click', function(){
                    // Check if locked (requires paid plan)
                    if(this.dataset.locked === '1'){
                        alert('Form sections require an Essential or Premium plan. Upgrade to unlock this feature!');
                        return;
                    }
                    var type = this.dataset.type;
                    var newSec = {type:type, style:getStyles(type)[0].id};
                    if(type==='cta' || type==='banner') newSec.action = 'whatsapp';
                    if(type==='form') newSec.fields = ['name','email','phone'];
                    if(type==='products') newSec.products = [{name:'Product 1',price:'₦5,000'},{name:'Product 2',price:'₦3,000'}];
                    if(type==='payment') { newSec.button = 'Pay Now'; newSec.amount = '5000'; newSec.currency = 'NGN'; }
                    if(type==='separator') newSec.style = 'thin';
                    if(type==='footer') newSec.showSocial = true;
                    vbSections.push(newSec);
                    renderSections();
                    addMenu.classList.remove('open');
                    editSection(vbSections.length - 1);
                });
            });
            
            // Sticky bar toggle
            document.getElementById('toggle-sticky-bar').addEventListener('click', function(){
                if(!vbStickyBar) vbStickyBar = {enabled:true, whatsapp:'', phone:'', link:false, linkUrl:''};
                else vbStickyBar.enabled = !vbStickyBar.enabled;
                this.style.background = vbStickyBar && vbStickyBar.enabled ? '#d1fae5' : '#f5f5f5';
                renderStickyBar();
                addMenu.classList.remove('open');
            });
            
            // Sticky bar edit
            document.getElementById('edit-sticky-bar').addEventListener('click', function(){
                if(!vbStickyBar) vbStickyBar = {enabled:true, whatsapp:'', phone:'', link:false, linkUrl:''};
                if(typeof vbStickyBar.link === 'undefined') vbStickyBar.link = false;
                if(typeof vbStickyBar.linkUrl === 'undefined') vbStickyBar.linkUrl = '';
                addMenu.classList.remove('open');
                document.getElementById('vb-panel-title').textContent = 'Edit Sticky Bar';
                // Build a compact sticky bar editor. Each action includes a show/hide toggle
                // with its input field directly below. The background style selector is at
                // the top. This layout reduces scrolling and groups related options.
                var html = '';
                // Enable bar toggle
                html += '<div class="vb-form-group"><label>Enable Sticky Bar</label><div class="vb-grid-2 vb-compact-grid">';
                html += '<div class="vb-opt compact'+(vbStickyBar.enabled?' active':'')+'" data-bar-enabled="1"><span>✅</span><small>Enabled</small></div>';
                html += '<div class="vb-opt compact'+(!vbStickyBar.enabled?' active':'')+'" data-bar-enabled="0"><span>❌</span><small>Disabled</small></div>';
                html += '</div></div>';
                // Background style selector
                html += '<div class="vb-form-group"><label>Bar Background</label><select id="bar-style" style="width:100%;padding:10px;border:2px solid #e5e7eb;border-radius:12px;font-size:14px;">'
                  + '<option value="light">Light</option><option value="gradient">Gradient</option><option value="dark">Dark</option></select></div>';
                // WhatsApp row
                html += '<div class="vb-form-group"><label>WhatsApp</label><div class="vb-grid-2 vb-compact-grid">';
                html += '<div class="vb-opt compact'+(vbStickyBar.whatsapp?' active':'')+'" data-bar-wa="1"><span>🟢</span><small>Show</small></div>';
                html += '<div class="vb-opt compact'+(!vbStickyBar.whatsapp?' active':'')+'" data-bar-wa="0"><span>❌</span><small>Hide</small></div>';
                html += '</div><input type="text" id="bar-wa-number" value="'+(typeof vbStickyBar.whatsapp==='string'?vbStickyBar.whatsapp:'')+'" placeholder="2348012345678" style="margin-top:8px;width:100%;padding:10px;border:2px solid #e5e7eb;border-radius:12px;font-size:14px;"></div>';
                // Call row
                html += '<div class="vb-form-group"><label>Call</label><div class="vb-grid-2 vb-compact-grid">';
                html += '<div class="vb-opt compact'+(vbStickyBar.phone?' active':'')+'" data-bar-phone="1"><span>📞</span><small>Show</small></div>';
                html += '<div class="vb-opt compact'+(!vbStickyBar.phone?' active':'')+'" data-bar-phone="0"><span>❌</span><small>Hide</small></div>';
                html += '</div><input type="text" id="bar-call-number" value="'+(typeof vbStickyBar.phone==='string'?vbStickyBar.phone:'')+'" placeholder="+2348012345678" style="margin-top:8px;width:100%;padding:10px;border:2px solid #e5e7eb;border-radius:12px;font-size:14px;"></div>';
                // Link row
                html += '<div class="vb-form-group"><label>Link</label><div class="vb-grid-2 vb-compact-grid">';
                html += '<div class="vb-opt compact'+(vbStickyBar.link?' active':'')+'" data-bar-link="1"><span>🔗</span><small>Show</small></div>';
                html += '<div class="vb-opt compact'+(!vbStickyBar.link?' active':'')+'" data-bar-link="0"><span>❌</span><small>Hide</small></div>';
                html += '</div><input type="url" id="bar-link-url" value="'+(vbStickyBar.linkUrl||'')+'" placeholder="https://..." style="margin-top:8px;width:100%;padding:10px;border:2px solid #e5e7eb;border-radius:12px;font-size:14px;"></div>';
                panelBody.innerHTML = html;
                openPanel();
                function syncBarOptStates(){
                    // whatsapp
                    document.querySelectorAll('.vb-opt[data-bar-wa]').forEach(function(x){x.classList.remove('active');});
                    var waSel = document.querySelector('.vb-opt[data-bar-wa="'+(vbStickyBar.whatsapp?'1':'0')+'"]');
                    if(waSel) waSel.classList.add('active');
                    // phone
                    document.querySelectorAll('.vb-opt[data-bar-phone]').forEach(function(x){x.classList.remove('active');});
                    var phSel = document.querySelector('.vb-opt[data-bar-phone="'+(vbStickyBar.phone?'1':'0')+'"]');
                    if(phSel) phSel.classList.add('active');
                    // link
                    document.querySelectorAll('.vb-opt[data-bar-link]').forEach(function(x){x.classList.remove('active');});
                    var liSel = document.querySelector('.vb-opt[data-bar-link="'+(vbStickyBar.link?'1':'0')+'"]');
                    if(liSel) liSel.classList.add('active');
                }
                
                // Bind sticky bar options
                document.querySelectorAll('.vb-opt[data-bar-enabled]').forEach(function(el){
                    el.addEventListener('click', function(){
                        document.querySelectorAll('.vb-opt[data-bar-enabled]').forEach(function(x){x.classList.remove('active');});
                        this.classList.add('active');
                        vbStickyBar.enabled = this.dataset.barEnabled === '1';
                        document.getElementById('toggle-sticky-bar').style.background = vbStickyBar.enabled ? '#d1fae5' : '#f5f5f5';
                        renderStickyBar();
                    });
                });
                document.querySelectorAll('.vb-opt[data-bar-wa]').forEach(function(el){
                    el.addEventListener('click', function(){
                        document.querySelectorAll('.vb-opt[data-bar-wa]').forEach(function(x){x.classList.remove('active');});
                        this.classList.add('active');
                        var next = (this.dataset.barWa === '1');
                        // When hiding, clear the WhatsApp number; when showing, ensure the value is a string (not boolean)
                        if(!next){
                            vbStickyBar.whatsapp = '';
                        } else {
                            vbStickyBar.whatsapp = (typeof vbStickyBar.whatsapp === 'string' ? vbStickyBar.whatsapp : '');
                        }
                        renderStickyBar();
                    });
                });
                document.querySelectorAll('.vb-opt[data-bar-phone]').forEach(function(el){
                    el.addEventListener('click', function(){
                        document.querySelectorAll('.vb-opt[data-bar-phone]').forEach(function(x){x.classList.remove('active');});
                        this.classList.add('active');
                        var next = (this.dataset.barPhone === '1');
                        if(!next){
                            vbStickyBar.phone = '';
                        } else {
                            vbStickyBar.phone = (typeof vbStickyBar.phone === 'string' ? vbStickyBar.phone : '');
                        }
                        renderStickyBar();
                    });
                });
                document.querySelectorAll('.vb-opt[data-bar-link]').forEach(function(el){
                    el.addEventListener('click', function(){
                        document.querySelectorAll('.vb-opt[data-bar-link]').forEach(function(x){x.classList.remove('active');});
                        this.classList.add('active');
                        var next = (this.dataset.barLink === '1');
                        var prev = vbStickyBar.link;
                        vbStickyBar.link = next;
                        renderStickyBar();
                    });
                });

                var linkUrlInput = document.getElementById('bar-link-url');
                if(linkUrlInput){
                    linkUrlInput.addEventListener('input', function(){
                        vbStickyBar.linkUrl = this.value;
                        renderStickyBar();
                    });
                }

                var styleSel = document.getElementById('bar-style');
                if(styleSel){
                    styleSel.value = vbStickyBar.barStyle || vbStickyBar.style || 'light';
                    styleSel.addEventListener('change', function(){
                        vbStickyBar.barStyle = this.value;
                        renderStickyBar();
                    });
                }
                var waInput = document.getElementById('bar-wa-number');
                if(waInput){
                    waInput.addEventListener('input', function(){
                        vbStickyBar.whatsapp = this.value;
                        renderStickyBar();
                    });
                }
                var callInput = document.getElementById('bar-call-number');
                if(callInput){
                    callInput.addEventListener('input', function(){
                        vbStickyBar.phone = this.value;
                        renderStickyBar();
                    });
                }

                // (handlers already bound above)
            });
            
            editFab.addEventListener('click', function(){
                if(currentIdx !== null) editSection(currentIdx);
            });
            
            // Save/Publish
            function savePage(status){
                var btn = document.getElementById(status === 'publish' ? 'vb-publish' : 'vb-save');
                var orig = btn.textContent;
                var promoteChecked = document.getElementById('vb-promote').checked;
                btn.textContent = '...';
                btn.disabled = true;
                
                var fd = new FormData();
                fd.append('action','hushot_visual_save');
                fd.append('page_id', document.getElementById('vb-page-id').value);
                fd.append('title', document.getElementById('vb-title').value || 'My Page');
                fd.append('template', document.getElementById('vb-template').value);
                fd.append('sections', JSON.stringify(vbSections));
                fd.append('primary_color', document.getElementById('vb-primary-color').value);
                fd.append('sticky_bar', JSON.stringify(vbStickyBar));
                fd.append('status', status);
                fd.append('_wpnonce','<?php echo wp_create_nonce("hushot_visual"); ?>');
                
                fetch('<?php echo admin_url("admin-ajax.php"); ?>',{method:'POST',body:fd})
                .then(function(r){return r.json();})
                .then(function(d){
                    btn.disabled = false;
                    if(d.success){
                        if(d.data.page_id) document.getElementById('vb-page-id').value = d.data.page_id;
                        if(status === 'publish'){
                            if(promoteChecked && d.data.page_id){
                                // Redirect to boost page
                                window.location.href = '<?php echo esc_url(Hushot_Pages::get_page_url("ads-promote")); ?>?page_id=' + d.data.page_id;
                            } else if(d.data.permalink){
                                if(confirm('Page published! View it now?')) window.open(d.data.permalink, '_blank');
                                btn.textContent = orig;
                            }
                        } else {
                            btn.textContent = '✓ Saved!';
                            setTimeout(function(){btn.textContent = orig;}, 2000);
                        }
                    } else {
                        alert(d.data && d.data.message ? d.data.message : 'Save failed');
                        btn.textContent = orig;
                    }
                }).catch(function(){
                    btn.disabled = false;
                    btn.textContent = orig;
                    alert('Connection error');
                });
            }
            
            document.getElementById('vb-save').addEventListener('click', function(){savePage('draft');});
            document.getElementById('vb-publish').addEventListener('click', function(){savePage('publish');});
            
            // Promote checkbox - change button text
            var promoteCheck = document.getElementById('vb-promote');
            var publishBtn = document.getElementById('vb-publish');
            promoteCheck.addEventListener('change', function(){
                if(this.checked){
                    publishBtn.textContent = '🚀 Boost Now';
                    publishBtn.classList.add('boost');
                } else {
                    publishBtn.textContent = 'Publish';
                    publishBtn.classList.remove('boost');
                }
            });
            
            // Initial render
            renderSections();
        })();
        </script>
        <?php
        return ob_get_clean();
    }
    private static function render_template_picker($plan = 'free') {
        $is_paid = in_array($plan, array('essential', 'premium'));
        ob_start();
        ?>
        <style>
        .tpl-picker{max-width:600px;margin:0 auto;}
        .tpl-picker h2{font-size:20px;font-weight:700;margin:0 0 8px;color:#1a1a2e;}
        .tpl-picker p{font-size:14px;color:#666;margin:0 0 24px;}
        .tpl-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:16px;}
        .tpl-card{background:#fff;border:2px solid #e5e7eb;border-radius:16px;overflow:hidden;cursor:pointer;transition:all 0.2s;text-decoration:none!important;position:relative;}
        .tpl-card:hover{border-color:#F7931E;transform:translateY(-2px);box-shadow:0 8px 24px rgba(0,0,0,0.1);}
        .tpl-card.locked{opacity:0.7;pointer-events:none;}
        .tpl-card.locked::after{content:'🔒 Essential+';position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);background:#1a1a2e;color:#fff;padding:8px 16px;border-radius:8px;font-size:11px;font-weight:700;z-index:5;}
        .tpl-preview{height:160px;background:#f5f5f5;position:relative;overflow:hidden;}
        .tpl-mock{height:100%;display:flex;flex-direction:column;}
        .tpl-mock-hero{flex:1;display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:700;color:#fff;}
        .tpl-mock-section{padding:8px;background:#f9fafb;}
        .tpl-mock-section span{display:block;height:5px;background:#e5e7eb;border-radius:3px;margin:3px 0;}
        .tpl-mock-cta{padding:8px;text-align:center;}
        .tpl-mock-cta span{display:inline-block;padding:5px 14px;border-radius:5px;font-size:8px;color:#fff;}
        .tpl-info{padding:14px;}
        .tpl-info h3{font-size:14px;font-weight:700;margin:0 0 4px;color:#1a1a2e;}
        .tpl-info p{font-size:11px;color:#666;margin:0;}
        .tpl-badge{position:absolute;top:8px;right:8px;padding:3px 8px;background:#F7931E;color:#fff;font-size:9px;font-weight:700;border-radius:5px;}
        @media(max-width:500px){.tpl-grid{grid-template-columns:1fr;}}
        </style>
        <div class="tpl-picker">
            <a href="?mode=choose" style="color:#666;font-size:13px;text-decoration:none;display:inline-block;margin-bottom:16px;">← Back</a>
            <h2>Choose a Template</h2>
            <p>Pick a starting layout. You can customize everything.</p>
            <div class="tpl-grid">
                <!-- Starter - Free for all -->
                <a href="?mode=visual&template=starter" class="tpl-card">
                    <div class="tpl-preview"><div class="tpl-mock">
                        <div class="tpl-mock-hero" style="background:linear-gradient(135deg,#F7931E,#1a1a2e);">HEADLINE</div>
                        <div class="tpl-mock-section"><span></span><span style="width:80%;"></span></div>
                        <div class="tpl-mock-cta"><span style="background:#F7931E;">Get Started</span></div>
                    </div><span class="tpl-badge">Free</span></div>
                    <div class="tpl-info"><h3>Starter</h3><p>Hero + features + CTA</p></div>
                </a>
                <!-- Product - Paid only -->
                <a href="<?php echo $is_paid ? '?mode=visual&template=product' : '#'; ?>" class="tpl-card <?php echo !$is_paid ? 'locked' : ''; ?>">
                    <div class="tpl-preview"><div class="tpl-mock">
                        <div style="height:50%;background:linear-gradient(135deg,#F7931E,#1a1a2e);display:flex;align-items:center;justify-content:center;color:#fff;font-size:9px;font-weight:700;">PRODUCT</div>
                        <div class="tpl-mock-section"><span></span><span style="width:70%;"></span></div>
                        <div class="tpl-mock-cta"><span style="background:#F7931E;width:100%;display:block;">Buy Now</span></div>
                    </div></div>
                    <div class="tpl-info"><h3>Product</h3><p>Banner + features + buy</p></div>
                </a>
                <!-- Service - Paid only -->
                <a href="<?php echo $is_paid ? '?mode=visual&template=service' : '#'; ?>" class="tpl-card <?php echo !$is_paid ? 'locked' : ''; ?>">
                    <div class="tpl-preview"><div class="tpl-mock">
                        <div class="tpl-mock-hero" style="background:#1a1a2e;font-size:10px;">SERVICES</div>
                        <div class="tpl-mock-section" style="flex:1;"><span></span><span style="width:70%;"></span><span style="width:90%;"></span></div>
                    </div></div>
                    <div class="tpl-info"><h3>Service</h3><p>Hero + features + form</p></div>
                </a>
                <!-- Lead Gen - Paid only -->
                <a href="<?php echo $is_paid ? '?mode=visual&template=lead' : '#'; ?>" class="tpl-card <?php echo !$is_paid ? 'locked' : ''; ?>">
                    <div class="tpl-preview"><div class="tpl-mock">
                        <div style="height:40%;background:linear-gradient(135deg,#667eea,#764ba2);display:flex;align-items:center;justify-content:center;color:#fff;font-size:9px;font-weight:700;">FREE GUIDE</div>
                        <div style="padding:8px;background:#f9fafb;flex:1;">
                            <div style="height:8px;background:#e5e7eb;border-radius:3px;margin:4px 0;"></div>
                            <div style="height:8px;background:#e5e7eb;border-radius:3px;margin:4px 0;"></div>
                            <div style="height:24px;background:#667eea;border-radius:5px;margin-top:8px;"></div>
                        </div>
                    </div></div>
                    <div class="tpl-info"><h3>Lead Gen</h3><p>Banner + form capture</p></div>
                </a>
                <!-- Minimal - Paid only -->
                <a href="<?php echo $is_paid ? '?mode=visual&template=minimal' : '#'; ?>" class="tpl-card <?php echo !$is_paid ? 'locked' : ''; ?>">
                    <div class="tpl-preview"><div class="tpl-mock" style="background:#fff;">
                        <div style="flex:1;display:flex;align-items:center;justify-content:center;flex-direction:column;">
                            <div style="font-size:10px;font-weight:700;color:#1a1a2e;">Clean & Simple</div>
                        </div>
                        <div class="tpl-mock-cta"><span style="background:#1a1a2e;">Contact</span></div>
                    </div></div>
                    <div class="tpl-info"><h3>Minimal</h3><p>Simple & clean</p></div>
                </a>
            </div>
            <?php if (!$is_paid): ?>
            <div style="margin-top:24px;padding:16px;background:#fff9f0;border-radius:12px;text-align:center;">
                <p style="margin:0 0 12px;font-size:14px;color:#1a1a2e;"><strong>🔓 Unlock All Templates</strong></p>
                <a href="<?php echo esc_url(Hushot_Pages::get_page_url('pricing')); ?>" style="display:inline-block;padding:12px 24px;background:#F7931E;color:#fff;border-radius:10px;text-decoration:none;font-weight:700;font-size:14px;">Upgrade to Essential</a>
            </div>
            <?php endif; ?>
        </div>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Get Template Sections
     */
    private static function get_template_sections($template, $wa = '') {
        switch ($template) {
            case 'product':
                return array(
                    array('type' => 'banner', 'style' => 'gradient', 'headline' => 'Product Name', 'subheadline' => 'Amazing product for your needs', 'button' => 'Order Now', 'action' => 'whatsapp', 'whatsapp' => $wa),
                    array('type' => 'features', 'style' => 'list', 'title' => 'Features', 'items' => "High Quality Materials\nFast & Free Shipping\n30-Day Money Back Guarantee"),
                    array('type' => 'cta', 'style' => 'full', 'text' => 'Limited stock available!', 'button' => 'Buy Now', 'action' => 'whatsapp', 'whatsapp' => $wa),
                    array('type' => 'footer', 'text' => '© 2025 Your Business'),
                );
            case 'service':
                return array(
                    array('type' => 'hero', 'style' => 'bold', 'headline' => 'Professional Services', 'subheadline' => 'Quality you can trust'),
                    array('type' => 'features', 'style' => 'list', 'title' => 'What We Offer', 'items' => "Consultation Services\nProject Management\nOngoing Support\nCustom Solutions"),
                    array('type' => 'form', 'title' => 'Request a Quote', 'fields' => array('name', 'email', 'phone', 'message'), 'button' => 'Send Request'),
                    array('type' => 'footer', 'text' => '© 2025 Your Business'),
                );
            case 'minimal':
                return array(
                    array('type' => 'hero', 'style' => 'minimal', 'headline' => 'Simple & Clean', 'subheadline' => 'Less is more'),
                    array('type' => 'text', 'content' => 'Your message here. Keep it simple and focused.'),
                    array('type' => 'cta', 'style' => 'simple', 'button' => 'Contact', 'action' => 'whatsapp', 'whatsapp' => $wa),
                );
            case 'lead':
                return array(
                    array('type' => 'banner', 'style' => 'gradient', 'headline' => 'Get Your Free Guide', 'subheadline' => 'Learn the secrets to success'),
                    array('type' => 'features', 'style' => 'list', 'title' => 'What You\'ll Learn', 'items' => "Step-by-step strategies\nProven techniques\nExpert insights"),
                    array('type' => 'form', 'title' => 'Get Instant Access', 'fields' => array('name', 'email', 'phone'), 'button' => 'Download Free'),
                    array('type' => 'footer', 'text' => '© 2025 Your Business'),
                );
            case 'starter':
            default:
                return array(
                    array('type' => 'hero', 'style' => 'gradient', 'headline' => 'Your Amazing Headline', 'subheadline' => 'A compelling subheadline that grabs attention'),
                    array('type' => 'features', 'style' => 'list', 'title' => 'What You Get', 'items' => "Feature One - Main benefit\nFeature Two - Key advantage\nFeature Three - Important point"),
                    array('type' => 'cta', 'style' => 'simple', 'text' => 'Ready to get started?', 'button' => 'Get Started Now', 'action' => 'whatsapp', 'whatsapp' => $wa),
                    array('type' => 'footer', 'text' => '© 2025 Your Business'),
                );
        }
    }

    private static function render_component_templates($is_paid, $wa, $plan) {
        $product_limit = ($plan === 'premium') ? 'Unlimited' : (($plan === 'essential') ? '3' : '0');
        ob_start();
        ?>
        <template id="tpl-header"><div class="hs-block open" data-b="header"><div class="hs-block-head"><span class="hs-block-ico">🏷️</span><span class="hs-block-title">Title/Sub</span><div class="hs-block-acts"><button type="button" class="mv-up">↑</button><button type="button" class="mv-dn">↓</button><button type="button" class="rem">×</button></div></div><div class="hs-block-body"><div class="hs-fld"><label>Headline</label><input type="text" class="header-title-input" placeholder="e.g. Transform Your Business Today"></div><div class="hs-fld"><label>Subtitle</label><input type="text" class="header-subtitle-input" placeholder="e.g. Professional services at affordable prices"></div></div></div></template>
        <template id="tpl-image"><div class="hs-block open" data-b="image"><div class="hs-block-head"><span class="hs-block-ico">🖼️</span><span class="hs-block-title">Image</span><div class="hs-block-acts"><button type="button" class="mv-up">↑</button><button type="button" class="mv-dn">↓</button><button type="button" class="rem">×</button></div></div><div class="hs-block-body"><div class="hs-img-box" id="img-box"><span class="ico">📷</span><input type="file" id="img-file" accept="image/*"></div><input type="hidden" name="image_url" id="image_url"></div></div></template>
        <template id="tpl-video"><div class="hs-block open" data-b="video"><div class="hs-block-head"><span class="hs-block-ico">🎬</span><span class="hs-block-title">Video</span><div class="hs-block-acts"><button type="button" class="mv-up">↑</button><button type="button" class="mv-dn">↓</button><button type="button" class="rem">×</button></div></div><div class="hs-block-body"><div class="hs-fld"><label>Video Source</label><div style="display:flex;gap:12px;margin-bottom:12px;"><label style="display:flex;align-items:center;gap:6px;cursor:pointer;"><input type="radio" name="video_source" value="upload" checked class="video-source-radio"> Upload Video</label><label style="display:flex;align-items:center;gap:6px;cursor:pointer;"><input type="radio" name="video_source" value="url" class="video-source-radio"> URL (YouTube/Vimeo)</label></div></div><div class="hs-video-upload-field"><div class="hs-fld"><label>Upload Video (MP4, max 50MB)</label><div class="hs-video-upload-box" style="border:2px dashed #ddd;border-radius:10px;padding:20px;text-align:center;cursor:pointer;background:#fafafa;position:relative;"><span style="font-size:32px;">📹</span><p style="margin:8px 0 0;font-size:12px;color:#666;">Click to upload video</p><input type="file" class="video-file-input" accept="video/mp4,video/webm" style="position:absolute;inset:0;opacity:0;cursor:pointer;"><input type="hidden" name="video_file_url"></div></div></div><div class="hs-video-url-field" style="display:none;"><div class="hs-fld"><label>YouTube/Vimeo URL (optional)</label><input type="url" name="video_url" placeholder="e.g. https://youtube.com/watch?v=..."></div></div><div class="hs-fld"><label style="display:flex;align-items:center;gap:6px;cursor:pointer;"><input type="checkbox" name="video_autoplay" value="1" checked> Auto-play video with sound</label></div></div></div></template>
        <template id="tpl-description"><div class="hs-block open" data-b="description"><div class="hs-block-head"><span class="hs-block-ico">📄</span><span class="hs-block-title">Details</span><div class="hs-block-acts"><button type="button" class="mv-up">↑</button><button type="button" class="mv-dn">↓</button><button type="button" class="rem">×</button></div></div><div class="hs-block-body"><div class="hs-fld"><label>Description</label><div style="display:flex;gap:6px;margin-bottom:8px;"><input type="text" class="hs-ai-context" placeholder="Your business (e.g. Lagos bakery)" style="flex:1;padding:6px 10px;font-size:12px;border:1px solid #ddd;border-radius:6px;"><button type="button" class="hs-ai-write" data-field="description" style="padding:6px 12px;white-space:nowrap;">✨ AI Write</button></div><textarea name="description" rows="3" placeholder="Describe your product or service. What makes it special? Why should customers choose you?"></textarea></div></div></div></template>
        <template id="tpl-features"><div class="hs-block open" data-b="features"><div class="hs-block-head"><span class="hs-block-ico">✅</span><span class="hs-block-title">Features</span><div class="hs-block-acts"><button type="button" class="mv-up">↑</button><button type="button" class="mv-dn">↓</button><button type="button" class="rem">×</button></div></div><div class="hs-block-body"><div class="hs-fld"><label>List (one per line) <button type="button" class="hs-ai-write" data-field="features">✨ AI Write</button></label><textarea name="features" rows="4" placeholder="Free Delivery&#10;24/7 Support&#10;Money Back Guarantee&#10;Premium Quality"></textarea></div></div></div></template>
        <template id="tpl-pricing"><div class="hs-block open" data-b="pricing"><div class="hs-block-head"><span class="hs-block-ico">💰</span><span class="hs-block-title">Price</span><div class="hs-block-acts"><button type="button" class="mv-up">↑</button><button type="button" class="mv-dn">↓</button><button type="button" class="rem">×</button></div></div><div class="hs-block-body"><div class="hs-price-inline"><div class="hs-fld"><label>Currency</label><select name="currency"><option value="NGN">₦ NGN</option><option value="GHS">₵ GHS</option><option value="KES">KSh KES</option><option value="ZAR">R ZAR</option><option value="UGX">USh UGX</option><option value="TZS">TSh TZS</option><option value="XOF">CFA XOF</option><option value="XAF">FCFA XAF</option><option value="EGP">E£ EGP</option><option value="MAD">DH MAD</option><option value="BWP">P BWP</option><option value="MUR">₨ MUR</option><option value="ZMW">ZK ZMW</option><option value="RWF">FRw RWF</option><option value="ETB">Br ETB</option><option value="AOA">Kz AOA</option><option value="USD">$ USD</option><option value="EUR">€ EUR</option><option value="GBP">£ GBP</option></select></div><div class="hs-fld"><label>Original</label><input type="number" name="original_price" placeholder="50000"></div><div class="hs-fld"><label>Sale</label><input type="number" name="sale_price" placeholder="35000"></div></div></div></div></template>
        <template id="tpl-whatsapp"><div class="hs-block open" data-b="whatsapp"><div class="hs-block-head"><span class="hs-block-ico">💬</span><span class="hs-block-title">WhatsApp</span><div class="hs-block-acts"><button type="button" class="mv-up">↑</button><button type="button" class="mv-dn">↓</button><button type="button" class="rem">×</button></div></div><div class="hs-block-body"><input type="hidden" name="cta_type" value="whatsapp"><div class="hs-fld"><label>WhatsApp Number</label><input type="text" name="whatsapp" value="<?php echo esc_attr($wa); ?>" placeholder="e.g. 2348012345678 (include country code)"></div><p style="font-size:11px;color:#666;margin:-10px 0 12px;">Include your country code: 🇳🇬 234, 🇬🇭 233, 🇰🇪 254, 🇿🇦 27, 🇺🇸/🇨🇦 1, 🇬🇧 44</p><div class="hs-fld"><label>Button Text</label><input type="text" name="cta_text" value="Chat on WhatsApp" placeholder="e.g. Order Now"></div></div></div></template>
        <template id="tpl-contact"><div class="hs-block open" data-b="contact"><div class="hs-block-head"><span class="hs-block-ico">📞</span><span class="hs-block-title">Footer</span><div class="hs-block-acts"><button type="button" class="mv-up">↑</button><button type="button" class="mv-dn">↓</button><button type="button" class="rem">×</button></div></div><div class="hs-block-body"><div class="hs-fld"><label>Phone</label><input type="text" name="phone" placeholder="e.g. +234 801 234 5678"></div><div class="hs-fld"><label>Email</label><input type="email" name="email" placeholder="e.g. hello@business.com"></div><div class="hs-fld"><label>Location</label><input type="text" name="location" placeholder="e.g. Lagos, Nigeria"></div></div></div></template>
        <template id="tpl-form"><div class="hs-block open" data-b="form"><div class="hs-block-head"><span class="hs-block-ico">📋</span><span class="hs-block-title">Lead Form</span><div class="hs-block-acts"><button type="button" class="mv-up">↑</button><button type="button" class="mv-dn">↓</button><button type="button" class="rem">×</button></div></div><div class="hs-block-body">
            <input type="hidden" name="cta_type" value="lead_form">
            <div class="hs-fld"><label>Form Title</label><input type="text" name="form_title" value="Get Started Today"></div>
            <div class="hs-fld"><label>Button Text</label><input type="text" name="form_button" value="Submit"></div>
            <div class="hs-fld"><label>Form Fields</label>
                <div class="hs-form-checks" id="ff-checks">
                    <label><input type="checkbox" data-ff="name" checked> Name</label>
                    <label><input type="checkbox" data-ff="email" checked> Email</label>
                    <label><input type="checkbox" data-ff="phone" checked> Phone</label>
                    <label><input type="checkbox" data-ff="message"> Message</label>
                </div>
                <div class="hs-custom-fields" id="ff-custom"></div>
                <div class="hs-add-field">
                    <input type="text" id="ff-new" placeholder="Custom field name">
                    <button type="button" class="hs-btn hs-btn-xs" id="ff-add">+ Add</button>
                </div>
            </div>
            <input type="hidden" name="form_fields" id="ff-val" value="name,email,phone">
        </div></div></template>
        <template id="tpl-link"><div class="hs-block open" data-b="link"><div class="hs-block-head"><span class="hs-block-ico">🔗</span><span class="hs-block-title">Link</span><div class="hs-block-acts"><button type="button" class="mv-up">↑</button><button type="button" class="mv-dn">↓</button><button type="button" class="rem">×</button></div></div><div class="hs-block-body"><input type="hidden" name="cta_type" value="link"><div class="hs-fld"><label>URL</label><input type="url" name="link_url" placeholder="e.g. https://yourwebsite.com"></div><div class="hs-fld"><label>Text</label><input type="text" name="link_text" value="Learn More" placeholder="e.g. Visit Website"></div></div></div></template>
        <template id="tpl-bottombar"><div class="hs-block open" data-b="bottombar"><div class="hs-block-head"><span class="hs-block-ico">📱</span><span class="hs-block-title">Sticky Bar</span><div class="hs-block-acts"><button type="button" class="mv-up">↑</button><button type="button" class="mv-dn">↓</button><button type="button" class="rem">×</button></div></div><div class="hs-block-body"><div class="hs-fld"><label>Style</label><select name="bottom_bar_style" id="bar-style-select"><option value="disabled">Disabled</option><option value="call_whatsapp">Call | WhatsApp</option><option value="call_link">Call | Link</option><option value="whatsapp_link">WhatsApp | Link</option><option value="call_only">Call Only</option><option value="whatsapp_only">WhatsApp Only</option><option value="link_only">Link Only</option></select></div><div class="hs-bar-inputs"><div class="hs-fld" id="bar-phone-fld"><label>Phone</label><input type="text" name="bar_phone" placeholder="e.g. +234 801 234 5678"></div><div class="hs-fld" id="bar-wa-fld"><label>WhatsApp</label><input type="text" name="bar_whatsapp" value="<?php echo esc_attr($wa); ?>" placeholder="e.g. 2348012345678"></div><div class="hs-fld" id="bar-link-fld"><label>Link URL</label><input type="url" name="bar_link_url" placeholder="e.g. https://yourwebsite.com"></div></div></div></div></template>
        <template id="tpl-products"><div class="hs-block open" data-b="products"><div class="hs-block-head"><span class="hs-block-ico">🛍️</span><span class="hs-block-title">Products</span><div class="hs-block-acts"><button type="button" class="mv-up">↑</button><button type="button" class="mv-dn">↓</button><button type="button" class="rem">×</button></div></div><div class="hs-block-body"><div class="hs-fld"><label>Section Title</label><input type="text" name="products_title" value="More Products" placeholder="e.g. Our Products, Menu Items"></div><div class="hs-products-tpl-row" style="display:flex;gap:8px;margin-bottom:12px;flex-wrap:wrap;"><select class="load-products-tpl" style="flex:1;min-width:120px;padding:8px;border:1px solid #ddd;border-radius:6px;font-size:12px;"><option value="">-- Load Saved Products --</option></select><button type="button" class="hs-btn hs-btn-xs save-products-tpl" style="white-space:nowrap;">💾 Save</button></div><div class="hs-products-section" id="products-list"></div><button type="button" class="hs-btn hs-btn-xs" id="add-product-btn">+ Add Product</button><p class="hs-product-limit">Limit: <?php echo $product_limit; ?></p><input type="hidden" name="products_json" id="products_json"></div></div></template>
        <?php
        return ob_get_clean();
    }

    public static function render_edit_page() {
        if (!is_user_logged_in()) return '<script>window.location.href="'.esc_url(Hushot_Pages::get_page_url('login')).'";</script>';
        $user = wp_get_current_user();
        $plan = Hushot_Membership::get_user_plan();
        $page_id = intval($_GET['page_id'] ?? 0);
        if (!$page_id) return '<script>window.location.href="'.esc_url(Hushot_Pages::get_page_url('my-pages')).'";</script>';
        $page = get_post($page_id);
        if (!$page || $page->post_type !== 'hushot_page' || (int)$page->post_author !== (int)$user->ID) {
            return '<script>window.location.href="'.esc_url(Hushot_Pages::get_page_url('my-pages')).'";</script>';
        }
        
        // Check if this page was created with visual builder
        $sections = get_post_meta($page_id, '_hushot_sections', true);
        if (!empty($sections)) {
            // Redirect to visual builder for editing
            $vb_url = Hushot_Pages::get_page_url('create-page') . '?mode=visual&page_id=' . $page_id;
            return '<script>window.location.href="'.esc_url($vb_url).'";</script>';
        }
        
        $m = array();
        $fields = array('business_name','logo_url','header_title','header_subtitle','primary_color','image_url','video_url','video_file_url','video_autoplay','description','features','original_price','sale_price','currency','cta_text','cta_type','whatsapp','whatsapp_message','phone','email','location','link_url','link_text','bottom_bar_style','bar_phone','bar_whatsapp','bar_link_url','products_title','products_json','seo_title','seo_description','seo_image','collection','component_order');
        foreach ($fields as $f) $m[$f] = get_post_meta($page_id, '_hushot_'.$f, true);
        
        $wa = $m['whatsapp'] ?: '';
        $is_paid = in_array($plan, array('essential', 'premium'));
        
        ob_start();
        self::get_more_styles();
        echo self::render_sidebar($user, $plan, 'my-pages');
        ?>
        <main class="hs-main"><button id="hs-menu">☰</button><div class="hs-overlay"></div>
            <div class="hs-head"><h1>Edit Page</h1></div>
            <div class="hs-body">
                <div style="margin-bottom:10px;display:flex;gap:8px;">
                    <a href="<?php echo get_permalink($page_id); ?>" target="_blank" class="hs-btn hs-btn-xs">👁️ View Live</a>
                    <a href="<?php echo esc_url(Hushot_Pages::get_page_url('my-pages')); ?>" class="hs-btn hs-btn-xs">← Back</a>
                </div>
                <form id="hs-edit"><input type="hidden" name="page_id" value="<?php echo $page_id; ?>"><div class="hs-msg"></div>
                    <div class="hs-block open"><div class="hs-block-head"><span class="hs-block-ico">📝</span><span class="hs-block-title">Page Settings</span></div><div class="hs-block-body">
                        <div class="hs-fld"><label>Page Title</label><input type="text" name="title" value="<?php echo esc_attr($page->post_title); ?>" required></div>
                        <div class="hs-fld"><label>Business Name</label><input type="text" name="business_name" value="<?php echo esc_attr($m['business_name']); ?>" placeholder="e.g. Acme Corp"></div>
                        <div class="hs-row">
                            <div class="hs-fld">
                                <label>Logo</label>
                                <div class="hs-img-box" id="logo-box">
                                    <?php if($m['logo_url']): ?><img src="<?php echo esc_url($m['logo_url']); ?>"><?php else: ?><span class="ico">🖼️</span><?php endif; ?>
                                    <input type="file" id="logo-file" accept="image/*">
                                </div>
                                <input type="hidden" name="logo_url" id="logo_url" value="<?php echo esc_attr($m['logo_url']); ?>">
                            </div>
                            <div class="hs-fld">
                                <label>Brand Color</label>
                                <div style="display:flex;align-items:center;gap:10px;">
                                    <div id="clr-box" style="width:36px;height:36px;border-radius:8px;background:<?php echo esc_attr($m['primary_color']?:$m['primary_color']?:'#000000'); ?>;border:2px solid #eee;"></div>
                                    <select id="clr-sel" name="primary_color" style="flex:1;">
                                        <option value="#000000" <?php selected($m['primary_color'],'#000000'); ?>>⚫ Black</option>
                                        <option value="#FF553E" <?php selected($m['primary_color'],'#FF553E'); ?>>🔶 Orange</option>
                                        <option value="#dc2626" <?php selected($m['primary_color'],'#dc2626'); ?>>🔴 Red</option>
                                        <option value="#059669" <?php selected($m['primary_color'],'#059669'); ?>>🟢 Green</option>
                                        <option value="#2563eb" <?php selected($m['primary_color'],'#2563eb'); ?>>🔵 Blue</option>
                                        <option value="#7c3aed" <?php selected($m['primary_color'],'#7c3aed'); ?>>🟣 Purple</option>
                                        <option value="#0891b2" <?php selected($m['primary_color'],'#0891b2'); ?>>🔷 Cyan</option>
                                        <option value="#ea580c" <?php selected($m['primary_color'],'#ea580c'); ?>>🟧 Amber</option>
                                        <option value="#db2777" <?php selected($m['primary_color'],'#db2777'); ?>>💗 Pink</option>
                                        <option value="#0d9488" <?php selected($m['primary_color'],'#0d9488'); ?>>🌊 Teal</option>
                                    </select>
                                </div>
                                <div class="hs-hex-row">
                                    <input type="text" id="hex-in" placeholder="#000000" maxlength="7" value="<?php echo esc_attr($m['primary_color']); ?>">
                                    <button type="button" class="hs-btn hs-btn-xs" id="hex-btn">Apply</button>
                                </div>
                            </div>
                        </div>
                    </div></div>
                    <div id="components-area">
                        <?php /* Pre-populate existing components */ ?>
                    </div>
                    <div class="hs-picker"><div class="hs-picker-title">Tap to Add Sections</div><div class="hs-picker-hint" style="font-size:12px;color:#6b7280;margin:-8px 0 16px;padding:10px 12px;background:#f0f9ff;border-radius:8px;border-left:3px solid #667eea;">💡 <strong>Hint:</strong> Create a high-converting landing page by following this order: 1, 2, 3, 4, 5, 6, 7</div><div class="hs-picker-grid">
                        <div class="hs-pick" data-comp="header"><span class="hs-pick-num">1</span><span class="ico">🏷️</span><span class="txt">Title/Sub</span></div>
                        <div class="hs-pick" data-comp="image"><span class="hs-pick-num">2</span><span class="ico">🖼️</span><span class="txt">Image</span></div>
                        <div class="hs-pick" data-comp="description"><span class="hs-pick-num">3</span><span class="ico">📄</span><span class="txt">Details</span></div>
                        <div class="hs-pick" data-comp="features"><span class="hs-pick-num">4</span><span class="ico">✅</span><span class="txt">Features</span></div>
                        <div class="hs-pick" data-comp="pricing"><span class="hs-pick-num">5</span><span class="ico">💰</span><span class="txt">Price</span></div>
                        <div class="hs-pick" data-comp="whatsapp"><span class="hs-pick-num">6</span><span class="ico">💬</span><span class="txt">WhatsApp</span></div>
                        <div class="hs-pick" data-comp="contact"><span class="hs-pick-num">7</span><span class="ico">📞</span><span class="txt">Footer</span></div>
                        <div class="hs-pick <?php echo !$is_paid?'locked':''; ?>" data-comp="video" <?php echo !$is_paid?'data-locked="1"':''; ?>><span class="hs-pick-num">8</span><span class="ico">🎬</span><span class="txt">Video</span></div>
                        <div class="hs-pick <?php echo !$is_paid?'locked':''; ?>" data-comp="form" <?php echo !$is_paid?'data-locked="1"':''; ?>><span class="hs-pick-num">9</span><span class="ico">📋</span><span class="txt">Form</span></div>
                        <div class="hs-pick <?php echo !$is_paid?'locked':''; ?>" data-comp="link" <?php echo !$is_paid?'data-locked="1"':''; ?>><span class="hs-pick-num">10</span><span class="ico">🔗</span><span class="txt">Link</span></div>
                        <div class="hs-pick <?php echo !$is_paid?'locked':''; ?>" data-comp="bottombar" <?php echo !$is_paid?'data-locked="1"':''; ?>><span class="hs-pick-num">11</span><span class="ico">📱</span><span class="txt">Sticky Bar</span></div>
                        <div class="hs-pick <?php echo !$is_paid?'locked':''; ?>" data-comp="products" <?php echo !$is_paid?'data-locked="1"':''; ?>><span class="hs-pick-num">12</span><span class="ico">🛍️</span><span class="txt">Products</span></div>
                    </div></div>
                    <?php echo self::render_component_templates($is_paid, $wa, $plan); ?>
                    <div class="hs-card">
                        <div style="margin-bottom:16px;padding:16px;background:linear-gradient(135deg,rgba(102,126,234,0.1),rgba(118,75,162,0.1));border-radius:12px;border:1px solid rgba(102,126,234,0.2);">
                            <label style="display:flex;align-items:center;gap:12px;cursor:pointer;">
                                <input type="checkbox" name="promote_after_save" id="promote-checkbox" style="width:20px;height:20px;accent-color:#667eea;">
                                <div>
                                    <strong style="display:block;font-size:14px;color:#374151;">📢 Promote via Ads Network</strong>
                                    <span style="font-size:12px;color:#6b7280;">After saving, set up Facebook/Instagram ads for this page</span>
                                </div>
                            </label>
                        </div>
                        <div class="hs-btns-row">
                            <button type="submit" class="hs-btn hs-btn-p hs-btn-xs" style="flex:1;" id="save-changes-btn"><span class="tx">Save Changes</span><span class="ld">...</span></button>
                        </div>
                        <div id="save-success" style="display:none;text-align:center;padding:12px;margin-top:12px;background:#ecfdf5;border-radius:8px;color:#059669;font-size:13px;">
                            ✅ Changes saved successfully! <a href="<?php echo get_permalink($page_id); ?>" target="_blank" style="color:#059669;text-decoration:underline;">View Live Page</a>
                        </div>
                    </div>
                </form>
            </div>
        </main></div>
        <script>
        (function(){
            // Pre-populate saved data
            var savedData = <?php echo json_encode($m); ?>;
            window.hushotSavedProducts = [];
            window.hushotSavedHeaders = [];
            if (savedData.products_json) {
                try { window.hushotSavedProducts = JSON.parse(savedData.products_json); } catch(e) {}
            }
            if (savedData.headers_json) {
                try { window.hushotSavedHeaders = JSON.parse(savedData.headers_json); } catch(e) {}
            }
            // Backward compat: if no headers_json but has header_title, create array
            if (window.hushotSavedHeaders.length === 0 && (savedData.header_title || savedData.header_subtitle)) {
                window.hushotSavedHeaders = [{title: savedData.header_title || '', subtitle: savedData.header_subtitle || ''}];
            }
            
            // Track which header index to populate
            var headerIndex = 0;
            
            // Auto-add components based on saved data
            function addComponent(comp) {
                var tpl = document.getElementById('tpl-' + comp);
                if (tpl) {
                    var html = tpl.innerHTML;
                    document.getElementById('components-area').insertAdjacentHTML('beforeend', html);
                    
                    // For header, populate with corresponding data
                    if (comp === 'header' && window.hushotSavedHeaders[headerIndex]) {
                        var blocks = document.querySelectorAll('.hs-block[data-b="header"]');
                        var lastBlock = blocks[blocks.length - 1];
                        if (lastBlock) {
                            var h = window.hushotSavedHeaders[headerIndex];
                            lastBlock.querySelector('.header-title-input').value = h.title || '';
                            lastBlock.querySelector('.header-subtitle-input').value = h.subtitle || '';
                        }
                        headerIndex++;
                    }
                }
            }
            
            // Component data mapping - used for fallback when no order saved
            var componentHasData = {
                'header': savedData.headers_json || savedData.header_title || savedData.header_subtitle,
                'image': savedData.image_url,
                'video': savedData.video_url || savedData.video_file_url,
                'description': savedData.description,
                'features': savedData.features,
                'pricing': savedData.original_price || savedData.sale_price,
                'whatsapp': savedData.whatsapp || savedData.cta_type === 'whatsapp',
                'contact': savedData.phone || savedData.email || savedData.location,
                'link': savedData.link_url || savedData.cta_type === 'link',
                'form': savedData.cta_type === 'lead_form',
                'bottombar': savedData.bottom_bar_style && savedData.bottom_bar_style !== 'disabled',
                'products': savedData.products_json
            };
            
            // Load components in saved order if available
            if (savedData.component_order) {
                var order = savedData.component_order.split(',');
                order.forEach(function(comp) {
                    comp = comp.trim();
                    if (comp) {
                        // Always add component if it's in the saved order
                        addComponent(comp);
                    }
                });
            } else {
                // Fallback: add components that have data in default order
                if (componentHasData.header) addComponent('header');
                if (componentHasData.image) addComponent('image');
                if (componentHasData.video) addComponent('video');
                if (componentHasData.description) addComponent('description');
                if (componentHasData.features) addComponent('features');
                if (componentHasData.pricing) addComponent('pricing');
                if (componentHasData.whatsapp) addComponent('whatsapp');
                if (componentHasData.link) addComponent('link');
                if (componentHasData.form) addComponent('form');
                if (componentHasData.products) addComponent('products');
                if (componentHasData.contact) addComponent('contact');
                if (componentHasData.bottombar) addComponent('bottombar');
            }
            
            // Populate values after components are added
            setTimeout(function(){
                // Headers already populated above
                if (savedData.image_url) { 
                    var imgBox = document.getElementById('img-box');
                    if (imgBox) imgBox.innerHTML = '<img src="'+savedData.image_url+'"><input type="file" id="img-file" accept="image/*">';
                    var imgInput = document.getElementById('image_url');
                    if (imgInput) imgInput.value = savedData.image_url;
                }
                if (savedData.video_url) document.querySelector('[name="video_url"]') && (document.querySelector('[name="video_url"]').value = savedData.video_url);
                if (savedData.description) document.querySelector('[name="description"]') && (document.querySelector('[name="description"]').value = savedData.description);
                if (savedData.features) document.querySelector('[name="features"]') && (document.querySelector('[name="features"]').value = savedData.features);
                if (savedData.currency) document.querySelector('[name="currency"]') && (document.querySelector('[name="currency"]').value = savedData.currency);
                if (savedData.original_price) document.querySelector('[name="original_price"]') && (document.querySelector('[name="original_price"]').value = savedData.original_price);
                if (savedData.sale_price) document.querySelector('[name="sale_price"]') && (document.querySelector('[name="sale_price"]').value = savedData.sale_price);
                if (savedData.whatsapp) document.querySelector('[name="whatsapp"]') && (document.querySelector('[name="whatsapp"]').value = savedData.whatsapp);
                if (savedData.cta_text) document.querySelector('[name="cta_text"]') && (document.querySelector('[name="cta_text"]').value = savedData.cta_text);
                if (savedData.phone) document.querySelector('[name="phone"]') && (document.querySelector('[name="phone"]').value = savedData.phone);
                if (savedData.email) document.querySelector('[name="email"]') && (document.querySelector('[name="email"]').value = savedData.email);
                if (savedData.location) document.querySelector('[name="location"]') && (document.querySelector('[name="location"]').value = savedData.location);
                if (savedData.link_url) document.querySelector('[name="link_url"]') && (document.querySelector('[name="link_url"]').value = savedData.link_url);
                if (savedData.link_text) document.querySelector('[name="link_text"]') && (document.querySelector('[name="link_text"]').value = savedData.link_text);
                if (savedData.bottom_bar_style) document.querySelector('[name="bottom_bar_style"]') && (document.querySelector('[name="bottom_bar_style"]').value = savedData.bottom_bar_style);
                if (savedData.bar_phone) document.querySelector('[name="bar_phone"]') && (document.querySelector('[name="bar_phone"]').value = savedData.bar_phone);
                if (savedData.bar_whatsapp) document.querySelector('[name="bar_whatsapp"]') && (document.querySelector('[name="bar_whatsapp"]').value = savedData.bar_whatsapp);
                if (savedData.bar_link_url) document.querySelector('[name="bar_link_url"]') && (document.querySelector('[name="bar_link_url"]').value = savedData.bar_link_url);
                if (savedData.products_title) document.querySelector('[name="products_title"]') && (document.querySelector('[name="products_title"]').value = savedData.products_title);
                if (savedData.products_json) document.getElementById('products_json') && (document.getElementById('products_json').value = savedData.products_json);
                
                // Form fields
                if (savedData.form_title) document.querySelector('[name="form_title"]') && (document.querySelector('[name="form_title"]').value = savedData.form_title);
                if (savedData.form_button) document.querySelector('[name="form_button"]') && (document.querySelector('[name="form_button"]').value = savedData.form_button);
                if (savedData.form_fields) {
                    var fields = savedData.form_fields.split(',');
                    document.querySelectorAll('[data-ff]').forEach(function(cb) {
                        cb.checked = fields.indexOf(cb.getAttribute('data-ff')) > -1;
                    });
                }
                
                // Video file URL
                if (savedData.video_file_url) document.querySelector('[name="video_file_url"]') && (document.querySelector('[name="video_file_url"]').value = savedData.video_file_url);
                if (savedData.video_autoplay) document.querySelector('[name="video_autoplay"]') && (document.querySelector('[name="video_autoplay"]').checked = savedData.video_autoplay === '1' || savedData.video_autoplay === 'on');
                
                // Trigger events to update UI
                jQuery(document).trigger('hushot_edit_loaded');
            }, 100);
            
            // Color picker
            var clrSel=document.getElementById('clr-sel'),clrBox=document.getElementById('clr-box'),hexIn=document.getElementById('hex-in');
            if (clrSel) clrSel.onchange=function(){clrBox.style.background=this.value;hexIn.value=this.value;};
            if (document.getElementById('hex-btn')) document.getElementById('hex-btn').onclick=function(){
                var h=hexIn.value.trim();
                if(/^#[0-9A-Fa-f]{6}$/.test(h)){
                    clrBox.style.background=h;
                    var found=false;
                    for(var i=0;i<clrSel.options.length;i++){if(clrSel.options[i].value===h){clrSel.selectedIndex=i;found=true;break;}}
                    if(!found){var o=document.createElement('option');o.value=h;o.text='🎨 '+h;clrSel.add(o);clrSel.value=h;}
                }else{alert('Enter valid hex like #FF5500');}
            };
        })();
        </script>
        <?php
        return ob_get_clean();
    }

    public static function render_templates() {
        if (!is_user_logged_in()) return '<script>window.location.href="'.esc_url(Hushot_Pages::get_page_url('login')).'";</script>';
        $user = wp_get_current_user();
        $plan = Hushot_Membership::get_user_plan();
        
        // 6 Professional Templates
        // Free: 1 | Essential: 3 (includes free) | Premium: all 6
        $tpls = array(
            // FREE (1 template)
            array(
                'n' => 'Classic Business',
                'c' => '#1a1a2e',
                't' => 'free',
                'img' => 'https://images.unsplash.com/photo-1497366216548-37526070297c?w=600&h=300&fit=crop',
                'h' => 'Professional Solutions for Your Business',
                'desc' => 'We deliver excellence in every project. Trust our team of experts to help you achieve your goals with proven strategies and personalized service.',
                'f' => "Expert Team of Professionals\nFast & Reliable Service\n24/7 Customer Support\n100% Satisfaction Guaranteed"
            ),
            // ESSENTIAL (2 more = 3 total)
            array(
                'n' => 'Modern E-Commerce',
                'c' => '#dc2626',
                't' => 'essential',
                'img' => 'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=600&h=300&fit=crop',
                'h' => 'Shop the Latest Collection',
                'desc' => 'Discover premium quality products at unbeatable prices. Fast shipping, easy returns, and exceptional customer service.',
                'f' => "Free Delivery Nationwide\n100% Original Products\n30-Day Easy Returns\nSecure Payment Options"
            ),
            array(
                'n' => 'Creative Agency',
                'c' => '#7c3aed',
                't' => 'essential',
                'img' => 'https://images.unsplash.com/photo-1552664730-d307ca884978?w=600&h=300&fit=crop',
                'h' => 'Bringing Your Ideas to Life',
                'desc' => 'Award-winning creative team ready to transform your vision into reality. From concept to execution, we deliver stunning results.',
                'f' => "Creative Strategy & Design\nBrand Identity Development\nDigital Marketing Solutions\nMeasurable Results"
            ),
            // PREMIUM (3 more = 6 total)
            array(
                'n' => 'Luxury Beauty',
                'c' => '#be185d',
                't' => 'premium',
                'img' => 'https://images.unsplash.com/photo-1560066984-138dadb4c035?w=600&h=300&fit=crop',
                'h' => 'Elevate Your Beauty Experience',
                'desc' => 'Indulge in premium beauty treatments by certified professionals. Experience luxury and transformation like never before.',
                'f' => "Expert Beauty Specialists\nOrganic & Premium Products\nPersonalized Consultations\nVIP Treatment Experience"
            ),
            array(
                'n' => 'Tech Startup',
                'c' => '#0891b2',
                't' => 'premium',
                'img' => 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=600&h=300&fit=crop',
                'h' => 'Supercharge Your Productivity',
                'desc' => 'Powerful tools designed to help you work smarter, not harder. Join thousands of businesses already transforming their workflow.',
                'f' => "Easy Setup in Minutes\nCloud-Based Platform\nTeam Collaboration Tools\n24/7 Technical Support"
            ),
            array(
                'n' => 'Real Estate',
                'c' => '#059669',
                't' => 'premium',
                'img' => 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=600&h=300&fit=crop',
                'h' => 'Find Your Dream Property',
                'desc' => 'Premium real estate services with exclusive listings. Let our expert agents guide you to the perfect home or investment.',
                'f' => "Exclusive Property Listings\nExpert Market Analysis\nVirtual Tours Available\nNegotiation Specialists"
            ),
        );
        
        ob_start();
        self::get_more_styles();
        echo self::render_sidebar($user, $plan, 'templates');
        ?>
        <style>
        .hs-templates-wrap{padding:0;}
        .hs-templates-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:20px;}
        .hs-template-card{background:#fff;border-radius:16px;overflow:hidden;box-shadow:0 4px 20px rgba(0,0,0,0.08);transition:all 0.3s;position:relative;}
        .hs-template-card:hover{transform:translateY(-4px);box-shadow:0 12px 40px rgba(0,0,0,0.15);}
        .hs-template-card.locked{opacity:0.85;}
        .hs-template-card.locked:hover{transform:none;}
        .hs-template-img{height:160px;background-size:cover;background-position:center;position:relative;}
        .hs-template-img::after{content:'';position:absolute;inset:0;background:linear-gradient(to bottom,transparent 50%,rgba(0,0,0,0.4) 100%);}
        .hs-template-badge{position:absolute;top:12px;right:12px;padding:6px 12px;border-radius:20px;font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:0.5px;z-index:1;}
        .hs-template-badge.free{background:#d1fae5;color:#065f46;}
        .hs-template-badge.essential{background:#dbeafe;color:#1e40af;}
        .hs-template-badge.premium{background:#fef3c7;color:#92400e;}
        .hs-template-body{padding:20px;}
        .hs-template-name{font-size:18px;font-weight:700;color:#1a1a2e;margin:0 0 8px;}
        .hs-template-preview{font-size:13px;color:#666;line-height:1.5;margin:0 0 16px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;}
        .hs-template-btn{display:block;width:100%;padding:14px;border:none;border-radius:12px;font-size:14px;font-weight:600;cursor:pointer;text-align:center;text-decoration:none;transition:all 0.2s;}
        .hs-template-btn.use{background:linear-gradient(135deg,#667eea,#764ba2);color:#fff;}
        .hs-template-btn.use:hover{opacity:0.9;}
        .hs-template-btn.locked{background:#f1f5f9;color:#667eea;border:2px solid #e5e7eb;}
        .hs-template-btn.locked:hover{border-color:#667eea;background:#f5f3ff;}
        .hs-template-lock{position:absolute;inset:0;background:rgba(255,255,255,0.8);display:flex;align-items:center;justify-content:center;z-index:2;}
        .hs-template-lock-icon{font-size:40px;opacity:0.5;}
        @media(max-width:768px){
            .hs-templates-grid{grid-template-columns:1fr;}
            .hs-template-img{height:140px;}
        }
        </style>
        <main class="hs-main"><button id="hs-menu">☰</button><div class="hs-overlay"></div>
            <div class="hs-head"><h1>🎨 Templates</h1></div>
            <div class="hs-body hs-templates-wrap">
                <p style="color:#666;margin:0 0 20px;font-size:14px;">Choose a professional template to get started. <?php if ($plan === 'free'): ?>Upgrade to unlock more designs.<?php endif; ?></p>
                <div class="hs-templates-grid">
                    <?php foreach ($tpls as $i => $t): 
                        $locked = ($t['t'] === 'essential' && $plan === 'free') || ($t['t'] === 'premium' && $plan !== 'premium');
                    ?>
                    <div class="hs-template-card <?php echo $locked ? 'locked' : ''; ?>">
                        <div class="hs-template-img" style="background-image:url('<?php echo esc_url($t['img']); ?>');">
                            <span class="hs-template-badge <?php echo $t['t']; ?>"><?php echo ucfirst($t['t']); ?></span>
                        </div>
                        <div class="hs-template-body">
                            <h3 class="hs-template-name"><?php echo esc_html($t['n']); ?></h3>
                            <p class="hs-template-preview"><?php echo esc_html($t['desc']); ?></p>
                            <?php if ($locked): ?>
                            <a href="<?php echo esc_url(Hushot_Pages::get_page_url('pricing')); ?>" class="hs-template-btn locked">🔒 Upgrade to Unlock</a>
                            <?php else: ?>
                            <button class="hs-template-btn use hs-use-tpl" 
                                data-id="<?php echo $i; ?>" 
                                data-color="<?php echo esc_attr($t['c']); ?>" 
                                data-img="<?php echo esc_url($t['img']); ?>" 
                                data-headline="<?php echo esc_attr($t['h']); ?>" 
                                data-desc="<?php echo esc_attr($t['desc']); ?>" 
                                data-features="<?php echo esc_attr($t['f']); ?>">
                                ✨ Use This Template
                            </button>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </main></div>
        <?php
        return ob_get_clean();
    }

    public static function render_leads() {
        if (!is_user_logged_in()) return '<script>window.location.href="'.esc_url(Hushot_Pages::get_page_url('login')).'";</script>';
        $user = wp_get_current_user();
        $plan = Hushot_Membership::get_user_plan();
        global $wpdb;
        $leads = $wpdb->get_results($wpdb->prepare("SELECT l.*, p.post_title as page_title FROM {$wpdb->prefix}hushot_leads l LEFT JOIN {$wpdb->posts} p ON l.page_id = p.ID WHERE l.user_id=%d ORDER BY l.created_at DESC LIMIT 100", $user->ID));
        
        ob_start();
        self::get_more_styles();
        echo self::render_sidebar($user, $plan, 'leads');
        ?>
        <style>
        .hs-leads-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;}
        .hs-leads-header h2{margin:0;font-size:18px;color:#333;}
        .hs-export-btn{background:#10b981;color:#fff;border:none;padding:10px 16px;border-radius:8px;font-size:13px;font-weight:500;cursor:pointer;display:flex;align-items:center;gap:6px;}
        .hs-export-btn:hover{background:#059669;}
        </style>
        <main class="hs-main"><button id="hs-menu">☰</button><div class="hs-overlay"></div>
            <div class="hs-head"><h1>Leads</h1></div>
            <div class="hs-body">
                <?php if (empty($leads)): ?>
                <div class="hs-empty">No leads yet. Share your landing pages to start collecting leads!</div>
                <?php else: ?>
                <div class="hs-leads-header">
                    <h2><?php echo count($leads); ?> Lead<?php echo count($leads) !== 1 ? 's' : ''; ?></h2>
                    <button type="button" class="hs-export-btn" id="export-leads-btn">📥 Export CSV</button>
                </div>
                <div class="hs-leads"><table><thead><tr><th>Name</th><th>Phone</th><th>Email</th><th>Page</th><th>Date</th></tr></thead><tbody>
                <?php foreach ($leads as $lead): ?>
                <tr>
                    <td><?php echo esc_html($lead->name?:'-'); ?></td>
                    <td><?php echo esc_html($lead->phone?:'-'); ?></td>
                    <td><?php echo esc_html($lead->email?:'-'); ?></td>
                    <td><?php echo esc_html($lead->page_title?:'-'); ?></td>
                    <td><?php echo date('M j', strtotime($lead->created_at)); ?></td>
                </tr>
                <?php endforeach; ?>
                </tbody></table></div>
                <script>
                document.getElementById('export-leads-btn').addEventListener('click', function() {
                    window.location.href = '<?php echo admin_url('admin-ajax.php'); ?>?action=hushot_export_leads&nonce=<?php echo wp_create_nonce('hushot_nonce'); ?>';
                });
                </script>
                <?php endif; ?>
            </div>
        </main></div>
        <?php
        return ob_get_clean();
    }

    public static function render_ai_generator() {
        if (!is_user_logged_in()) return '<script>window.location.href="'.esc_url(Hushot_Pages::get_page_url('login')).'";</script>';
        $user = wp_get_current_user();
        $plan = Hushot_Membership::get_user_plan();
        $is_paid = in_array($plan, array('essential', 'premium'));
        
        // Get user's recent AI-generated pages
        $recent_pages = get_posts(array(
            'post_type' => 'hushot_page',
            'author' => $user->ID,
            'posts_per_page' => 5,
            'meta_query' => array(
                array('key' => '_hushot_ai_generated', 'value' => '1')
            )
        ));
        
        ob_start();
        self::get_more_styles();
        echo self::render_sidebar($user, $plan, 'ai-generator');
        ?>
        <style>
        .ai-wrap{max-width:600px;margin:0 auto;overflow-x:hidden;}
        .ai-card{background:#fff;border-radius:16px;padding:20px;margin-bottom:16px;box-shadow:0 2px 12px rgba(0,0,0,0.06);}
        .ai-card h3{margin:0 0 6px;font-size:16px;font-weight:700;color:#1a1a2e;display:flex;align-items:center;gap:8px;}
        .ai-card .sub{color:#6b7280;font-size:13px;margin-bottom:16px;}
        .ai-field{margin-bottom:16px;}
        .ai-field label{display:block;font-size:13px;font-weight:600;color:#374151;margin-bottom:6px;}
        .ai-field textarea{width:100%;padding:14px;border:2px solid #e5e7eb;border-radius:12px;font-size:14px;font-family:inherit;min-height:120px;resize:vertical;background:#f9fafb;transition:all 0.2s;box-sizing:border-box;}
        .ai-field textarea:focus{outline:none;border-color:#667eea;background:#fff;box-shadow:0 0 0 3px rgba(102,126,234,0.1);}
        .ai-field textarea::placeholder{color:#9ca3af;}
        .ai-url-row{display:flex;gap:8px;}
        .ai-url-row input{flex:1;min-width:0;padding:12px;border:2px solid #e5e7eb;border-radius:10px;font-size:14px;box-sizing:border-box;}
        .ai-url-row button{padding:12px 16px;background:linear-gradient(135deg,#3b82f6,#2563eb);color:#fff;border:none;border-radius:10px;font-size:13px;font-weight:600;cursor:pointer;white-space:nowrap;flex-shrink:0;}
        .ai-options{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-bottom:16px;}
        .ai-option{padding:10px 6px;background:#f8fafc;border:2px solid #e5e7eb;border-radius:10px;cursor:pointer;transition:all 0.15s;text-align:center;}
        .ai-option:hover{border-color:#667eea;background:#f5f3ff;}
        .ai-option.selected{border-color:#667eea;background:#f5f3ff;}
        .ai-option span{display:block;font-size:20px;margin-bottom:4px;}
        .ai-option strong{display:block;font-size:11px;color:#1a1a2e;}
        .ai-btn{width:100%;padding:14px;background:linear-gradient(135deg,#667eea,#764ba2);color:#fff;border:none;border-radius:12px;font-size:15px;font-weight:700;cursor:pointer;transition:all 0.2s;display:flex;align-items:center;justify-content:center;gap:8px;}
        .ai-btn:hover{transform:translateY(-1px);box-shadow:0 8px 20px rgba(102,126,234,0.3);}
        .ai-btn:disabled{opacity:0.6;cursor:not-allowed;transform:none;}
        .ai-locked{position:relative;}
        .ai-locked::before{content:'';position:absolute;inset:0;background:rgba(255,255,255,0.9);z-index:5;border-radius:16px;backdrop-filter:blur(4px);}
        .ai-locked::after{content:'🔒 Premium Feature';position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);background:linear-gradient(135deg,#667eea,#764ba2);color:#fff;padding:14px 24px;border-radius:12px;font-size:14px;font-weight:700;z-index:6;box-shadow:0 8px 20px rgba(102,126,234,0.3);}
        .ai-upgrade{text-align:center;padding:16px;background:linear-gradient(135deg,#fef3c7,#fef9c3);border-radius:10px;margin-top:16px;}
        .ai-upgrade a{color:#764ba2;font-weight:700;text-decoration:none;}
        .ai-recent{margin-top:8px;}
        .ai-recent-item{display:flex;align-items:center;justify-content:space-between;padding:12px;background:#f8fafc;border-radius:10px;margin-bottom:8px;gap:12px;overflow:hidden;max-width:100%;}
        .ai-recent-item>div{flex:1;min-width:0;overflow:hidden;}
        .ai-recent-item h4{margin:0;font-size:13px;color:#1a1a2e;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
        .ai-recent-item p{margin:2px 0 0;font-size:11px;color:#6b7280;}
        .ai-recent-item a{padding:6px 12px;background:#667eea;color:#fff;border-radius:6px;font-size:11px;font-weight:600;text-decoration:none;flex-shrink:0;white-space:nowrap;}
        .ai-loading{display:none;align-items:center;justify-content:center;gap:10px;padding:30px;text-align:center;}
        .ai-loading.show{display:flex;flex-direction:column;}
        .ai-spinner{width:40px;height:40px;border:3px solid #e5e7eb;border-top-color:#667eea;border-radius:50%;animation:spin 1s linear infinite;}
        @keyframes spin{to{transform:rotate(360deg);}}
        .ai-img-check{display:flex;align-items:flex-start;gap:10px;padding:12px;background:linear-gradient(135deg,rgba(16,185,129,0.08),rgba(5,150,105,0.08));border-radius:10px;border:1px solid rgba(16,185,129,0.2);margin-bottom:16px;}
        .ai-img-check input{width:18px;height:18px;accent-color:#10b981;margin-top:2px;flex-shrink:0;}
        .ai-img-check strong{font-size:13px;color:#065f46;display:block;}
        .ai-img-check span{font-size:11px;color:#047857;}
        @media(max-width:480px){
            .ai-options{grid-template-columns:repeat(2,1fr);}
            .ai-url-row{flex-direction:column;}
            .ai-url-row button{width:100%;}
            .ai-card{padding:16px;}
        }
        </style>
        <main class="hs-main"><button id="hs-menu">☰</button><div class="hs-overlay"></div>
            <div class="hs-head"><h1>✨ AI Builder</h1></div>
            <div class="hs-body">
                <div class="ai-wrap">
                    <!-- Website URL Import Card -->
                    <div class="ai-card <?php echo !$is_paid ? 'ai-locked' : ''; ?>">
                        <h3>🌐 Import from Website</h3>
                        <p class="sub">Paste your website URL and AI will extract business info.</p>
                        
                        <div class="ai-field">
                            <label>Website URL</label>
                            <div class="ai-url-row">
                                <input type="url" id="ai-website-url" placeholder="https://yourbusiness.com" <?php echo !$is_paid ? 'disabled' : ''; ?>>
                                <button type="button" id="ai-import-btn" <?php echo !$is_paid ? 'disabled' : ''; ?>>🔍 Import</button>
                            </div>
                        </div>
                        
                        <div id="ai-import-loading" style="display:none;text-align:center;padding:16px;">
                            <div class="ai-spinner" style="margin:0 auto;"></div>
                            <p style="margin:10px 0 0;color:#6b7280;font-size:13px;">Analyzing website...</p>
                        </div>
                    </div>
                    
                    <div style="text-align:center;margin-bottom:16px;">
                        <span style="background:#e5e7eb;padding:6px 14px;border-radius:16px;font-size:11px;color:#6b7280;font-weight:500;">— OR describe manually —</span>
                    </div>
                    
                    <!-- Main Form Card -->
                    <div class="ai-card <?php echo !$is_paid ? 'ai-locked' : ''; ?>">
                        <h3>📝 Describe Your Business</h3>
                        <p class="sub">Tell us about your offer and target audience.</p>
                        
                        <div class="ai-field">
                            <label>Business Description *</label>
                            <textarea id="ai-prompt" placeholder="Example: Photography studio in Lagos. Wedding packages from ₦150,000. Couples should book via WhatsApp." <?php echo !$is_paid ? 'disabled' : ''; ?>></textarea>
                        </div>
                        
                        <label style="font-size:13px;font-weight:600;color:#374151;margin-bottom:8px;display:block;">Style</label>
                        <div class="ai-options" id="ai-style-options">
                            <div class="ai-option selected" data-style="modern">
                                <span>🎨</span>
                                <strong>Modern</strong>
                            </div>
                            <div class="ai-option" data-style="bold">
                                <span>💪</span>
                                <strong>Bold</strong>
                            </div>
                            <div class="ai-option" data-style="elegant">
                                <span>✨</span>
                                <strong>Elegant</strong>
                            </div>
                            <div class="ai-option" data-style="playful">
                                <span>🎉</span>
                                <strong>Playful</strong>
                            </div>
                        </div>
                        
                        <!-- AI Image Generation Option -->
                        <div class="ai-img-check">
                            <input type="checkbox" id="ai-generate-image" <?php echo !$is_paid ? 'disabled' : ''; ?>>
                            <div>
                                <strong>🖼️ Generate AI image</strong>
                                <span>Create a relevant banner image automatically</span>
                            </div>
                        </div>
                        
                        <button type="button" class="ai-btn" id="ai-generate-btn" <?php echo !$is_paid ? 'disabled' : ''; ?>>
                            <span>✨</span> Generate Landing Page
                        </button>
                        
                        <div class="ai-loading" id="ai-loading">
                            <div class="ai-spinner"></div>
                            <p style="margin:12px 0 0;color:#6b7280;font-size:14px;">Creating your page...</p>
                        </div>
                        
                        <?php if (!$is_paid): ?>
                        <div class="ai-upgrade">
                            <p style="margin:0;font-size:13px;color:#92400e;">
                                🔓 <a href="<?php echo esc_url(Hushot_Pages::get_page_url('pricing')); ?>">Upgrade to Premium</a> to unlock AI Builder
                            </p>
                        </div>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Recent AI Pages -->
                    <?php if (!empty($recent_pages)): ?>
                    <div class="ai-card">
                        <h3>📋 Recent AI-Generated Pages</h3>
                        <p class="sub">Your recently created pages using AI Builder.</p>
                        <div class="ai-recent">
                            <?php foreach ($recent_pages as $page): ?>
                            <div class="ai-recent-item">
                                <div>
                                    <h4><?php echo esc_html($page->post_title); ?></h4>
                                    <p>Created <?php echo human_time_diff(strtotime($page->post_date)); ?> ago</p>
                                </div>
                                <a href="<?php echo esc_url(add_query_arg('page_id', $page->ID, Hushot_Pages::get_page_url('edit-page'))); ?>">Edit</a>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </main></div>
        
        <?php if ($is_paid): ?>
        <script>
        (function(){
            var options = document.querySelectorAll('.ai-option');
            var selectedStyle = 'modern';
            
            options.forEach(function(opt){
                opt.addEventListener('click', function(){
                    options.forEach(function(o){ o.classList.remove('selected'); });
                    this.classList.add('selected');
                    selectedStyle = this.dataset.style;
                });
            });
            
            // Website URL Import Handler
            document.getElementById('ai-import-btn').addEventListener('click', function(){
                var url = document.getElementById('ai-website-url').value.trim();
                if (!url) {
                    alert('Please enter a website URL');
                    return;
                }
                if (!url.startsWith('http')) {
                    url = 'https://' + url;
                    document.getElementById('ai-website-url').value = url;
                }
                
                this.disabled = true;
                this.innerHTML = '⏳ Analyzing...';
                document.getElementById('ai-import-loading').style.display = 'block';
                
                var formData = new FormData();
                formData.append('action', 'hushot_crawl_website');
                formData.append('url', url);
                formData.append('_wpnonce', '<?php echo wp_create_nonce('hushot_ai_generate'); ?>');
                
                fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                    method: 'POST',
                    body: formData
                })
                .then(function(r){ return r.json(); })
                .then(function(data){
                    document.getElementById('ai-import-btn').disabled = false;
                    document.getElementById('ai-import-btn').innerHTML = '🔍 Import';
                    document.getElementById('ai-import-loading').style.display = 'none';
                    
                    if (data.success && data.data) {
                        // Auto-fill the description with extracted content
                        var desc = '';
                        if (data.data.headline) desc += data.data.headline + '\n\n';
                        if (data.data.subheadline) desc += data.data.subheadline + '\n\n';
                        if (data.data.description) desc += data.data.description + '\n\n';
                        if (data.data.features) desc += 'Key Features:\n' + data.data.features + '\n\n';
                        if (data.data.cta) desc += 'Call to action: ' + data.data.cta;
                        
                        document.getElementById('ai-prompt').value = desc.trim();
                        
                        // Show success message
                        alert('✅ Website analyzed! The business info has been added to the description field. You can edit it or click "Generate Landing Page" to continue.');
                        
                        // Scroll to description
                        document.getElementById('ai-prompt').focus();
                        document.getElementById('ai-prompt').scrollIntoView({behavior:'smooth', block:'center'});
                    } else {
                        alert(data.data?.message || 'Could not analyze website. Please enter your business info manually.');
                    }
                })
                .catch(function(){
                    document.getElementById('ai-import-btn').disabled = false;
                    document.getElementById('ai-import-btn').innerHTML = '🔍 Import';
                    document.getElementById('ai-import-loading').style.display = 'none';
                    alert('Network error. Please try again.');
                });
            });
            
            document.getElementById('ai-generate-btn').addEventListener('click', function(){
                var prompt = document.getElementById('ai-prompt').value.trim();
                if (!prompt) {
                    alert('Please describe your business first');
                    return;
                }
                
                this.disabled = true;
                this.innerHTML = '<span>⏳</span> Generating...';
                document.getElementById('ai-loading').classList.add('show');
                
                // Check if image generation is enabled
                var generateImage = document.getElementById('ai-generate-image').checked;
                
                // Send AJAX request to generate page
                var formData = new FormData();
                formData.append('action', 'hushot_ai_generate_page');
                formData.append('prompt', prompt);
                formData.append('style', selectedStyle);
                formData.append('generate_image', generateImage ? '1' : '0');
                formData.append('_wpnonce', '<?php echo wp_create_nonce('hushot_ai_generate'); ?>');
                
                fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                    method: 'POST',
                    body: formData
                })
                .then(function(r){ return r.json(); })
                .then(function(data){
                    if (data.success && data.data.edit_url) {
                        window.location.href = data.data.edit_url;
                    } else {
                        alert(data.data?.message || 'Error generating page. Please try again.');
                        document.getElementById('ai-generate-btn').disabled = false;
                        document.getElementById('ai-generate-btn').innerHTML = '<span>✨</span> Generate Landing Page';
                        document.getElementById('ai-loading').classList.remove('show');
                    }
                })
                .catch(function(err){
                    alert('Network error. Please try again.');
                    document.getElementById('ai-generate-btn').disabled = false;
                    document.getElementById('ai-generate-btn').innerHTML = '<span>✨</span> Generate Landing Page';
                    document.getElementById('ai-loading').classList.remove('show');
                });
            });
        })();
        </script>
        <?php endif; ?>
        <?php
        return ob_get_clean();
    }

    public static function render_analytics() {
        if (!is_user_logged_in()) return '<script>window.location.href="'.esc_url(Hushot_Pages::get_page_url('login')).'";</script>';
        $user = wp_get_current_user();
        $plan = Hushot_Membership::get_user_plan();
        $pages = get_posts(array('post_type'=>'hushot_page','author'=>$user->ID,'posts_per_page'=>-1));
        $tab = sanitize_text_field($_GET['tab'] ?? 'overview');
        
        global $wpdb;
        $page_ids = wp_list_pluck($pages, 'ID');
        
        // Get click breakdown by type
        $click_breakdown = array();
        if (!empty($page_ids)) {
            $results = $wpdb->get_results("SELECT button_type, COUNT(*) as count FROM {$wpdb->prefix}hushot_clicks WHERE page_id IN (" . implode(',', array_map('intval', $page_ids)) . ") GROUP BY button_type");
            foreach ($results as $r) {
                $click_breakdown[$r->button_type] = $r->count;
            }
        }
        
        ob_start();
        self::get_more_styles();
        echo self::render_sidebar($user, $plan, 'analytics');
        ?>
        <style>
        .hs-tabs{display:flex;gap:8px;margin-bottom:16px;flex-wrap:wrap;}
        .hs-tab{padding:8px 16px;border-radius:8px;font-size:13px;font-weight:500;text-decoration:none!important;background:#f3f4f6;color:#374151!important;transition:all 0.2s;}
        .hs-tab:hover{background:#e5e7eb;}
        .hs-tab.active{background:#FF553E;color:#fff!important;}
        .hs-click-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:12px;margin-bottom:16px;}
        .hs-click-card{background:#fff;padding:16px;border-radius:10px;text-align:center;box-shadow:0 2px 6px rgba(0,0,0,0.04);}
        .hs-click-icon{font-size:28px;margin-bottom:8px;}
        .hs-click-num{font-size:24px;font-weight:700;color:#FF553E;}
        .hs-click-lbl{font-size:11px;color:#888;margin-top:4px;}
        </style>
        <main class="hs-main"><button id="hs-menu">☰</button><div class="hs-overlay"></div>
            <div class="hs-head"><h1>Analytics</h1></div>
            <div class="hs-body">
                <div class="hs-tabs">
                    <a href="<?php echo esc_url(add_query_arg('tab', 'overview', Hushot_Pages::get_page_url('analytics'))); ?>" class="hs-tab <?php echo $tab==='overview'?'active':''; ?>">📊 Overview</a>
                    <a href="<?php echo esc_url(add_query_arg('tab', 'views', Hushot_Pages::get_page_url('analytics'))); ?>" class="hs-tab <?php echo $tab==='views'?'active':''; ?>">👁️ Views</a>
                    <a href="<?php echo esc_url(add_query_arg('tab', 'clicks', Hushot_Pages::get_page_url('analytics'))); ?>" class="hs-tab <?php echo $tab==='clicks'?'active':''; ?>">🖱️ Clicks</a>
                </div>
                
                <?php if ($tab === 'clicks'): ?>
                <div class="hs-card" style="margin-bottom:16px;">
                    <h4 style="margin:0 0 12px;font-size:14px;">Click Breakdown by Type</h4>
                    <div class="hs-click-grid">
                        <div class="hs-click-card">
                            <div class="hs-click-icon">💬</div>
                            <div class="hs-click-num"><?php echo number_format($click_breakdown['whatsapp'] ?? 0); ?></div>
                            <div class="hs-click-lbl">WhatsApp</div>
                        </div>
                        <div class="hs-click-card">
                            <div class="hs-click-icon">🔗</div>
                            <div class="hs-click-num"><?php echo number_format($click_breakdown['link'] ?? 0); ?></div>
                            <div class="hs-click-lbl">Links</div>
                        </div>
                        <div class="hs-click-card">
                            <div class="hs-click-icon">📞</div>
                            <div class="hs-click-num"><?php echo number_format($click_breakdown['call'] ?? 0); ?></div>
                            <div class="hs-click-lbl">Calls</div>
                        </div>
                        <div class="hs-click-card">
                            <div class="hs-click-icon">📋</div>
                            <div class="hs-click-num"><?php echo number_format($click_breakdown['form'] ?? 0); ?></div>
                            <div class="hs-click-lbl">Forms</div>
                        </div>
                    </div>
                </div>
                <h4 style="margin:0 0 12px;font-size:14px;">Clicks by Page</h4>
                <?php if (empty($pages)): ?><div class="hs-empty">Create pages to see analytics.</div>
                <?php else: foreach ($pages as $p): $pclicks = (int)get_post_meta($p->ID,'_hushot_clicks',true); ?>
                <div class="hs-pg"><span class="hs-pg-ico">🖱️</span><div class="hs-pg-info"><strong><?php echo esc_html($p->post_title); ?></strong><small><?php echo $pclicks; ?> clicks</small></div></div>
                <?php endforeach; endif; ?>
                
                <?php elseif ($tab === 'views'): ?>
                <h4 style="margin:0 0 12px;font-size:14px;">Views by Page</h4>
                <?php if (empty($pages)): ?><div class="hs-empty">Create pages to see analytics.</div>
                <?php else: foreach ($pages as $p): $pviews = (int)get_post_meta($p->ID,'_hushot_views',true); ?>
                <div class="hs-pg"><span class="hs-pg-ico">👁️</span><div class="hs-pg-info"><strong><?php echo esc_html($p->post_title); ?></strong><small><?php echo number_format($pviews); ?> views</small></div></div>
                <?php endforeach; endif; ?>
                
                <?php else: ?>
                <?php if (empty($pages)): ?><div class="hs-empty">Create pages to see analytics.</div>
                <?php else: foreach ($pages as $p): 
                    $pviews = (int)get_post_meta($p->ID,'_hushot_views',true);
                    $pclicks = (int)get_post_meta($p->ID,'_hushot_clicks',true);
                ?>
                <div class="hs-pg"><span class="hs-pg-ico">📊</span><div class="hs-pg-info"><strong><?php echo esc_html($p->post_title); ?></strong><small><?php echo number_format($pviews); ?> views • <?php echo $pclicks; ?> clicks</small></div></div>
                <?php endforeach; endif; ?>
                <?php endif; ?>
            </div>
        </main></div>
        <?php
        return ob_get_clean();
    }

    public static function render_addons() {
        if (!is_user_logged_in()) return '<script>window.location.href="'.esc_url(Hushot_Pages::get_page_url('login')).'";</script>';
        $user = wp_get_current_user();
        $plan = Hushot_Membership::get_user_plan();
        ob_start();
        self::get_more_styles();
        echo self::render_sidebar($user, $plan, 'addons');
        ?>
        <main class="hs-main"><button id="hs-menu">☰</button><div class="hs-overlay"></div>
            <div class="hs-head"><h1>Marketing</h1></div>
            <div class="hs-body"><div class="hs-empty">Coming soon</div></div>
        </main></div>
        <?php
        return ob_get_clean();
    }

    public static function render_my_account() {
        if (!is_user_logged_in()) return '<script>window.location.href="'.esc_url(Hushot_Pages::get_page_url('login')).'";</script>';
        $user = wp_get_current_user();
        $plan = Hushot_Membership::get_user_plan();
        ob_start();
        self::get_more_styles();
        echo self::render_sidebar($user, $plan, 'my-account');
        ?>
        <main class="hs-main"><button id="hs-menu">☰</button><div class="hs-overlay"></div>
            <div class="hs-head"><h1>Account</h1></div>
            <div class="hs-body">
                <div class="hs-card">
                    <form id="hs-profile"><div class="hs-msg"></div>
                        <div class="hs-row"><div class="hs-fld"><label>First</label><input type="text" name="first_name" value="<?php echo esc_attr($user->first_name); ?>"></div><div class="hs-fld"><label>Last</label><input type="text" name="last_name" value="<?php echo esc_attr($user->last_name); ?>"></div></div>
                        <div class="hs-fld"><label>Email</label><input type="email" value="<?php echo esc_attr($user->user_email); ?>" disabled></div>
                        <div class="hs-fld"><label>Phone</label><input type="tel" name="phone" value="<?php echo esc_attr(get_user_meta($user->ID,'hushot_phone',true)); ?>"></div>
                        <button type="submit" class="hs-btn hs-btn-p hs-btn-xs">Save</button>
                    </form>
                </div>
            </div>
        </main></div>
        <?php
        return ob_get_clean();
    }

    public static function render_billing() {
        if (!is_user_logged_in()) return '<script>window.location.href="'.esc_url(Hushot_Pages::get_page_url('login')).'";</script>';
        $user = wp_get_current_user();
        $plan = Hushot_Membership::get_user_plan();
        $plans = Hushot_Membership::get_plans();
        $exp = get_user_meta($user->ID, 'hushot_plan_expiry', true);
        $pages_count = count(get_posts(array('post_type' => 'hushot_page', 'author' => $user->ID, 'post_status' => 'publish', 'numberposts' => -1)));
        $page_limit = $plans[$plan]['features']['pages'] ?? 3;
        
        ob_start();
        self::get_more_styles();
        echo self::render_sidebar($user, $plan, 'billing');
        ?>
        <style>
        .hs-sub-card{background:#fff;border-radius:12px;padding:16px;margin-bottom:12px;box-shadow:0 2px 8px rgba(0,0,0,0.04);}
        .hs-sub-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;}
        .hs-sub-badge{padding:4px 10px;border-radius:12px;font-size:11px;font-weight:600;text-transform:uppercase;}
        .hs-sub-badge.free{background:#e5e7eb;color:#374151;}
        .hs-sub-badge.essential{background:#dbeafe;color:#1d4ed8;}
        .hs-sub-badge.premium{background:#fef3c7;color:#b45309;}
        .hs-sub-row{display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid #f3f4f6;font-size:13px;}
        .hs-sub-row:last-child{border-bottom:none;}
        .hs-sub-label{color:#6b7280;}
        .hs-sub-value{font-weight:500;color:#1f2937;}
        .hs-usage-bar{height:8px;background:#e5e7eb;border-radius:4px;margin-top:4px;overflow:hidden;}
        .hs-usage-fill{height:100%;background:#10b981;border-radius:4px;transition:width 0.3s;}
        .hs-usage-fill.warn{background:#f59e0b;}
        .hs-usage-fill.danger{background:#ef4444;}
        </style>
        <main class="hs-main"><button id="hs-menu">☰</button><div class="hs-overlay"></div>
            <div class="hs-head"><h1>Billing & Subscription</h1></div>
            <div class="hs-body">
                <div class="hs-sub-card">
                    <div class="hs-sub-header">
                        <h3 style="font-size:16px;font-weight:600;margin:0;">Current Plan</h3>
                        <span class="hs-sub-badge <?php echo esc_attr($plan); ?>"><?php echo esc_html($plans[$plan]['name'] ?? 'Free'); ?></span>
                    </div>
                    <div class="hs-sub-row">
                        <span class="hs-sub-label">Status</span>
                        <span class="hs-sub-value" style="color:#10b981;">Active</span>
                    </div>
                    <?php if ($exp && $plan !== 'free'): ?>
                    <div class="hs-sub-row">
                        <span class="hs-sub-label">Renews</span>
                        <span class="hs-sub-value"><?php echo date('M j, Y', strtotime($exp)); ?></span>
                    </div>
                    <?php endif; ?>
                    <div class="hs-sub-row">
                        <span class="hs-sub-label">Price</span>
                        <span class="hs-sub-value"><?php echo $plan === 'free' ? 'Free' : '$' . ($plans[$plan]['pricing']['monthly'] ?? 0) . '/mo'; ?></span>
                    </div>
                </div>
                
                <div class="hs-sub-card">
                    <h3 style="font-size:14px;font-weight:600;margin:0 0 12px;">Usage</h3>
                    <div class="hs-sub-row" style="flex-direction:column;align-items:stretch;">
                        <div style="display:flex;justify-content:space-between;">
                            <span class="hs-sub-label">Landing Pages</span>
                            <span class="hs-sub-value"><?php echo $pages_count; ?> / <?php echo $page_limit === 999 ? '∞' : $page_limit; ?></span>
                        </div>
                        <?php if ($page_limit !== 999): 
                            $pct = ($pages_count / $page_limit) * 100;
                            $cls = $pct > 90 ? 'danger' : ($pct > 70 ? 'warn' : '');
                        ?>
                        <div class="hs-usage-bar"><div class="hs-usage-fill <?php echo $cls; ?>" style="width:<?php echo min(100, $pct); ?>%;"></div></div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="hs-sub-card" style="display:flex;gap:8px;">
                    <?php if ($plan !== 'premium'): ?>
                    <a href="<?php echo esc_url(Hushot_Pages::get_page_url('pricing')); ?>" class="hs-btn hs-btn-p hs-btn-xs" style="flex:1;text-align:center;">Upgrade Plan</a>
                    <?php endif; ?>
                    <?php if ($plan !== 'free'): ?>
                    <a href="<?php echo esc_url(Hushot_Pages::get_page_url('cancel-subscription')); ?>" class="hs-btn hs-btn-xs" style="background:#fee2e2;color:#dc2626;">Cancel</a>
                    <?php endif; ?>
                </div>
                
                <div class="hs-sub-card">
                    <h3 style="font-size:14px;font-weight:600;margin:0 0 12px;">Plan Features</h3>
                    <?php 
                    $features = $plans[$plan]['features'] ?? array();
                    $feature_labels = array(
                        'pages' => 'Landing Pages',
                        'products' => 'Products per Page',
                        'video' => 'Video Section',
                        'form' => 'Lead Forms',
                        'analytics' => 'Analytics',
                        'ai' => 'AI Content',
                        'custom_domain' => 'Custom Domain',
                        'remove_watermark' => 'Remove Branding',
                    );
                    foreach ($feature_labels as $key => $label):
                        $val = $features[$key] ?? false;
                    ?>
                    <div class="hs-sub-row">
                        <span class="hs-sub-label"><?php echo $label; ?></span>
                        <span class="hs-sub-value">
                            <?php 
                            if ($val === true) echo '✓';
                            elseif ($val === false) echo '✗';
                            elseif ($val === 999) echo '∞';
                            else echo $val;
                            ?>
                        </span>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </main></div>
        <?php
        return ob_get_clean();
    }

    public static function render_cancel_subscription() {
        if (!is_user_logged_in()) return '<script>window.location.href="'.esc_url(Hushot_Pages::get_page_url('login')).'";</script>';
        $user = wp_get_current_user();
        $plan = Hushot_Membership::get_user_plan();
        ob_start();
        self::get_more_styles();
        echo self::render_sidebar($user, $plan, 'billing');
        ?>
        <main class="hs-main"><button id="hs-menu">☰</button><div class="hs-overlay"></div>
            <div class="hs-head"><h1>Cancel</h1></div>
            <div class="hs-body">
                <div class="hs-card" style="text-align:center;">
                    <p>Cancel subscription?</p>
                    <form id="hs-cancel"><div class="hs-msg"></div><button type="submit" class="hs-btn hs-btn-xs" style="background:#ef4444;">Cancel</button></form>
                </div>
            </div>
        </main></div>
        <?php
        return ob_get_clean();
    }

    public static function render_pricing() {
        $all_plans = Hushot_Membership::get_plans();
        $current = is_user_logged_in() ? Hushot_Membership::get_user_plan() : null;
        
        // REORDER: Free first, Essential second, Premium last
        $plan_order = array('free', 'essential', 'premium');
        $plans = array();
        foreach ($plan_order as $key) {
            if (isset($all_plans[$key])) {
                $plans[$key] = $all_plans[$key];
            }
        }
        
        // Get local currency info
        $currency_info = Hushot_Flutterwave::convert_usd_to_local(1);
        $currency_symbol = Hushot_Flutterwave::get_currency_symbol($currency_info['currency']);
        $rate = $currency_info['exchange_rate'];
        $is_local = ($currency_info['currency'] !== 'USD');
        
        ob_start();
        ?>
        <style>
        /* PRICING PAGE - FULL OVERRIDE STYLES */
        html,body{margin:0!important;padding:0!important;}
        body.hushot-system-page{background:#0f172a!important;min-height:100vh!important;}
        .pricing-wrap{min-height:100vh!important;padding:60px 20px 80px!important;position:relative!important;background:linear-gradient(135deg,#0f172a 0%,#1e293b 50%,#0f172a 100%)!important;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif!important;box-sizing:border-box!important;}
        .pricing-wrap *{box-sizing:border-box!important;}
        .pricing-wrap::before{content:''!important;position:absolute!important;top:0!important;left:0!important;right:0!important;bottom:0!important;background:radial-gradient(ellipse at 30% 0%,rgba(99,102,241,0.2) 0%,transparent 50%),radial-gradient(ellipse at 70% 100%,rgba(255,85,62,0.15) 0%,transparent 50%)!important;pointer-events:none!important;}
        .pricing-header{text-align:center!important;margin-bottom:50px!important;position:relative!important;z-index:1!important;}
        .pricing-badge{display:inline-block!important;background:linear-gradient(135deg,#FF553E,#f97316)!important;color:#fff!important;font-size:13px!important;font-weight:700!important;padding:8px 20px!important;border-radius:30px!important;margin-bottom:20px!important;text-transform:uppercase!important;letter-spacing:1px!important;}
        .pricing-title{font-size:48px!important;font-weight:900!important;color:#ffffff!important;margin:0 0 16px 0!important;letter-spacing:-1px!important;line-height:1.1!important;text-shadow:0 2px 20px rgba(0,0,0,0.5)!important;}
        .pricing-subtitle{font-size:20px!important;color:#94a3b8!important;max-width:600px!important;margin:0 auto!important;line-height:1.6!important;font-weight:400!important;}
        .pricing-toggle{display:flex!important;justify-content:center!important;margin-bottom:50px!important;position:relative!important;z-index:1!important;}
        .pricing-toggle-inner{display:inline-flex!important;background:rgba(30,41,59,0.9)!important;border-radius:16px!important;padding:6px!important;border:1px solid rgba(148,163,184,0.3)!important;}
        .pricing-toggle button{padding:14px 28px!important;font-size:15px!important;font-weight:600!important;border:none!important;background:transparent!important;border-radius:12px!important;cursor:pointer!important;color:#94a3b8!important;transition:all 0.3s ease!important;font-family:inherit!important;}
        .pricing-toggle button.active{background:linear-gradient(135deg,#6366f1,#8b5cf6)!important;color:#ffffff!important;box-shadow:0 4px 15px rgba(99,102,241,0.4)!important;}
        .pricing-toggle button:hover:not(.active){color:#e2e8f0!important;background:rgba(148,163,184,0.15)!important;}
        .pricing-save{background:#10b981!important;color:#fff!important;font-size:11px!important;padding:4px 10px!important;border-radius:12px!important;margin-left:8px!important;font-weight:700!important;}
        .pricing-grid{display:grid!important;grid-template-columns:repeat(3,1fr)!important;gap:28px!important;max-width:1100px!important;margin:0 auto!important;position:relative!important;z-index:1!important;}
        .pricing-card{background:#ffffff!important;border-radius:24px!important;padding:36px 32px!important;position:relative!important;transition:all 0.4s ease!important;border:2px solid transparent!important;box-shadow:0 20px 50px rgba(0,0,0,0.3)!important;}
        .pricing-card:hover{transform:translateY(-10px)!important;box-shadow:0 40px 80px rgba(0,0,0,0.4)!important;}
        .pricing-card.popular{background:linear-gradient(180deg,#ffffff 0%,#fefce8 100%)!important;border:3px solid #FF553E!important;transform:scale(1.08)!important;}
        .pricing-card.popular:hover{transform:scale(1.08) translateY(-10px)!important;}
        .popular-badge{position:absolute!important;top:-16px!important;left:50%!important;transform:translateX(-50%)!important;background:linear-gradient(135deg,#FF553E,#f97316)!important;color:#fff!important;font-size:12px!important;font-weight:800!important;padding:8px 24px!important;border-radius:30px!important;white-space:nowrap!important;box-shadow:0 4px 15px rgba(255,85,62,0.4)!important;}
        .pricing-plan-name{font-size:24px!important;font-weight:800!important;color:#0f172a!important;margin:0 0 8px 0!important;}
        .pricing-plan-desc{font-size:15px!important;color:#64748b!important;margin:0 0 28px 0!important;line-height:1.5!important;font-weight:500!important;}
        .pricing-amount{margin-bottom:20px!important;}
        .pricing-currency{font-size:22px!important;font-weight:700!important;color:#0f172a!important;vertical-align:top!important;}
        .pricing-value{font-size:56px!important;font-weight:900!important;color:#0f172a!important;line-height:1!important;letter-spacing:-3px!important;}
        .pricing-period{font-size:17px!important;color:#64748b!important;margin-left:4px!important;font-weight:600!important;}
        .pricing-billed{font-size:14px!important;color:#94a3b8!important;margin-top:8px!important;font-weight:500!important;}
        .pricing-features{margin:0 0 32px 0!important;list-style:none!important;padding:0!important;}
        .pricing-features li{display:flex!important;align-items:flex-start!important;gap:14px!important;padding:12px 0!important;font-size:15px!important;color:#334155!important;border-bottom:1px solid #e2e8f0!important;font-weight:500!important;}
        .pricing-features li:last-child{border-bottom:none!important;}
        .pricing-features li::before{content:'✓'!important;width:22px!important;height:22px!important;background:linear-gradient(135deg,#10b981,#059669)!important;color:#fff!important;border-radius:50%!important;display:flex!important;align-items:center!important;justify-content:center!important;font-size:12px!important;font-weight:700!important;flex-shrink:0!important;}
        .pricing-btn{display:block!important;width:100%!important;padding:18px!important;font-size:16px!important;font-weight:700!important;text-align:center!important;text-decoration:none!important;border-radius:14px!important;transition:all 0.3s ease!important;font-family:inherit!important;border:none!important;cursor:pointer!important;}
        .pricing-btn-primary{background:linear-gradient(135deg,#FF553E 0%,#f97316 100%)!important;color:#fff!important;box-shadow:0 10px 30px rgba(255,85,62,0.4)!important;}
        .pricing-btn-primary:hover{transform:translateY(-3px)!important;box-shadow:0 15px 40px rgba(255,85,62,0.5)!important;}
        .pricing-btn-outline{background:#f1f5f9!important;border:2px solid #e2e8f0!important;color:#334155!important;}
        .pricing-btn-outline:hover{background:#e2e8f0!important;border-color:#cbd5e1!important;}
        .pricing-btn-disabled{background:#e2e8f0!important;color:#94a3b8!important;cursor:default!important;}
        .price-monthly,.price-6months{display:none;}
        @media(max-width:1024px){
            .pricing-grid{grid-template-columns:1fr 1fr!important;max-width:700px!important;}
            .pricing-card.popular{transform:scale(1.02)!important;}
        }
        @media(max-width:700px){
            .pricing-grid{grid-template-columns:1fr!important;max-width:420px!important;}
            .pricing-card.popular{transform:none!important;}
            .pricing-card.popular:hover{transform:translateY(-10px)!important;}
            .pricing-title{font-size:36px!important;}
            .pricing-subtitle{font-size:17px!important;}
        }
        @media(max-width:480px){
            .pricing-wrap{padding:40px 16px 60px!important;}
            .pricing-title{font-size:30px!important;}
            .pricing-toggle button{padding:12px 18px!important;font-size:13px!important;}
            .pricing-card{padding:28px 24px!important;}
            .pricing-value{font-size:48px!important;}
        }
        </style>
        <div class="pricing-wrap">
            <div class="pricing-header">
                <span class="pricing-badge">💰 Simple Pricing</span>
                <h1 class="pricing-title">Choose Your Plan</h1>
                <p class="pricing-subtitle">Start free and scale as you grow. No hidden fees, cancel anytime.</p>
            </div>
            <div class="pricing-toggle">
                <div class="pricing-toggle-inner" id="plan-toggle">
                    <button data-cycle="monthly">Monthly</button>
                    <button data-cycle="6months">6 Months <span class="pricing-save">-10%</span></button>
                    <button class="active" data-cycle="yearly">Yearly <span class="pricing-save">-20%</span></button>
                </div>
            </div>
            <div class="pricing-grid">
                <?php foreach ($plans as $key => $plan): 
                    // Read exact prices from database - NO hardcoded defaults
                    $monthly_usd = floatval($plan['pricing']['monthly'] ?? 0);
                    $biannual_usd = floatval($plan['pricing']['biannual'] ?? 0);
                    $yearly_usd = floatval($plan['pricing']['yearly'] ?? 0);
                    
                    // Calculate per-month display for each cycle
                    $monthly_per_month = $monthly_usd;
                    $biannual_per_month = $biannual_usd > 0 ? round($biannual_usd / 6, 2) : 0;
                    $yearly_per_month = $yearly_usd > 0 ? round($yearly_usd / 12, 2) : 0;
                    
                    // Convert to local currency
                    $monthly_local = $monthly_per_month > 0 ? round($monthly_per_month * $rate, 0) : 0;
                    $biannual_local = $biannual_per_month > 0 ? round($biannual_per_month * $rate, 0) : 0;
                    $yearly_local = $yearly_per_month > 0 ? round($yearly_per_month * $rate, 0) : 0;
                    
                    $is_popular = $key === 'premium';
                    $is_free = $key === 'free';
                    $is_premium = $key === 'premium';
                    
                    // Activation fee from database or default
                    $plan_activation_fee = floatval($plan['activation_fee'] ?? 0);
                    $activation_local = $plan_activation_fee > 0 ? round($plan_activation_fee * $rate, 2) : 0;
                ?>
                <div class="pricing-card <?php echo $is_popular ? 'popular' : ''; ?>">
                    <?php if ($is_popular): ?>
                    <span class="popular-badge">⭐ Best Value</span>
                    <?php endif; ?>
                    <div class="pricing-plan-name"><?php echo esc_html($plan['name']); ?></div>
                    <div class="pricing-plan-desc"><?php echo esc_html($plan['description']); ?></div>
                    <div class="pricing-amount">
                        <?php if ($is_free): ?>
                        <span class="pricing-value">Free</span>
                        <?php else: ?>
                        <?php if ($monthly_local > 0): ?>
                        <span class="pricing-currency price-monthly"><?php echo esc_html($currency_symbol); ?></span>
                        <span class="pricing-value price-monthly"><?php echo number_format($monthly_local, 0); ?></span>
                        <?php else: ?>
                        <span class="pricing-value price-monthly">—</span>
                        <?php endif; ?>
                        <?php if ($biannual_local > 0): ?>
                        <span class="pricing-currency price-6months"><?php echo esc_html($currency_symbol); ?></span>
                        <span class="pricing-value price-6months"><?php echo number_format($biannual_local, 0); ?></span>
                        <?php else: ?>
                        <span class="pricing-value price-6months">—</span>
                        <?php endif; ?>
                        <?php if ($yearly_local > 0): ?>
                        <span class="pricing-currency price-yearly"><?php echo esc_html($currency_symbol); ?></span>
                        <span class="pricing-value price-yearly"><?php echo number_format($yearly_local, 0); ?></span>
                        <?php else: ?>
                        <span class="pricing-value price-yearly">—</span>
                        <?php endif; ?>
                        <span class="pricing-period cycle-label">/mo</span>
                        <div class="pricing-billed cycle-billed" style="display:block;">Billed yearly</div>
                        <?php endif; ?>
                    </div>
                    <ul class="pricing-features">
                        <?php foreach (array_slice($plan['feature_list'], 0, 5) as $f): ?>
                        <li><?php echo esc_html($f); ?></li>
                        <?php endforeach; ?>
                    </ul>
                    <?php if ($current === $key): ?>
                        <span class="pricing-btn pricing-btn-disabled">Current Plan</span>
                    <?php elseif ($is_free): ?>
                        <a href="<?php echo esc_url(Hushot_Pages::get_page_url('register')); ?>" class="pricing-btn pricing-btn-outline">Get Started Free</a>
                    <?php else: ?>
                        <?php if (is_user_logged_in()): ?>
                        <a href="<?php echo esc_url(add_query_arg(array('plan'=>$key,'cycle'=>'yearly'),Hushot_Pages::get_page_url('checkout'))); ?>" class="pricing-btn pricing-btn-primary hs-checkout-btn" data-plan="<?php echo $key; ?>">Try for <?php echo $currency_symbol . number_format($activation_local, 2); ?></a>
                        <?php else: ?>
                        <a href="<?php echo esc_url(add_query_arg('redirect', urlencode(add_query_arg(array('plan'=>$key,'cycle'=>'yearly'),Hushot_Pages::get_page_url('checkout'))), Hushot_Pages::get_page_url('login'))); ?>" class="pricing-btn pricing-btn-primary hs-checkout-btn" data-plan="<?php echo $key; ?>">Try for <?php echo $currency_symbol . number_format($activation_local, 2); ?></a>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <script>
        (function(){
            // Set yearly as default - already active in HTML
            var toggleBtns = document.querySelectorAll('#plan-toggle button');
            var activeCycle = 'yearly';
            
            function updatePricing(cycle) {
                document.querySelectorAll('.price-monthly,.price-6months,.price-yearly').forEach(function(el){el.style.display='none';});
                document.querySelectorAll('.price-'+cycle).forEach(function(el){el.style.display='inline';});
                document.querySelectorAll('.cycle-label').forEach(function(el){
                    el.textContent='/mo';
                });
                document.querySelectorAll('.cycle-billed').forEach(function(el){
                    if(cycle==='yearly') el.textContent='Billed yearly';
                    else if(cycle==='6months') el.textContent='Billed every 6 months';
                    else el.textContent='Billed monthly';
                });
                document.querySelectorAll('.hs-checkout-btn').forEach(function(a){
                    var url=new URL(a.href);
                    url.searchParams.set('cycle',cycle==='6months'?'biannual':cycle);
                    a.href=url.toString();
                });
            }
            
            toggleBtns.forEach(function(btn){
                btn.addEventListener('click',function(){
                    toggleBtns.forEach(function(b){b.classList.remove('active');});
                    this.classList.add('active');
                    updatePricing(this.dataset.cycle);
                });
            });
            
            // Initialize with yearly
            updatePricing('yearly');
        })();
        </script>
        <?php
        return ob_get_clean();
    }

    public static function render_checkout() {
        if (!is_user_logged_in()) return '<script>window.location.href="'.esc_url(Hushot_Pages::get_page_url('login')).'";</script>';
        $user = wp_get_current_user();
        $plan_key = sanitize_text_field($_GET['plan'] ?? 'essential');
        $cycle = sanitize_text_field($_GET['cycle'] ?? 'monthly');
        $plans = Hushot_Membership::get_plans();
        $plan = $plans[$plan_key] ?? $plans['essential'];
        
        // Get local currency info
        $currency_info = Hushot_Flutterwave::convert_usd_to_local(1);
        $currency_symbol = Hushot_Flutterwave::get_currency_symbol($currency_info['currency']);
        $rate = $currency_info['exchange_rate'];
        
        $monthly_usd = floatval($plan['pricing']['monthly'] ?? 0);
        $price_usd = $monthly_usd;
        $cycle_label = '/mo';
        if ($cycle === 'biannual' || $cycle === '6months') {
            $price_usd = isset($plan['pricing']['biannual']) ? floatval($plan['pricing']['biannual']) : round($monthly_usd * 6 * 0.9, 2);
            $cycle_label = '/6 months';
            $cycle = 'biannual';
        } elseif ($cycle === 'quarterly' || $cycle === '3months') {
            // Backward compat - treat as biannual
            $price_usd = isset($plan['pricing']['biannual']) ? floatval($plan['pricing']['biannual']) : round($monthly_usd * 6 * 0.9, 2);
            $cycle_label = '/6 months';
            $cycle = 'biannual';
        } elseif ($cycle === 'yearly') {
            $price_usd = isset($plan['pricing']['yearly']) ? floatval($plan['pricing']['yearly']) : round($monthly_usd * 12 * 0.8, 2);
            $cycle_label = '/year';
        }
        
        // Convert to local currency
        $price = round($price_usd * $rate, 0);
        
        // Check if user already used trial
        $used_trial = get_user_meta($user->ID, 'hushot_used_trial', true);
        $show_trial = !$used_trial && $plan_key !== 'free';
        
        // Flutterwave plan IDs
        $fw_plan_ids = array(
            'essential' => '152406',
            'premium' => '152407'
        );
        $fw_plan_id = $fw_plan_ids[$plan_key] ?? '';
        
        ob_start();
        self::get_more_styles();
        ?>
        <style>
        .hs-trial-badge{background:linear-gradient(135deg,#10b981,#059669);color:#fff;padding:8px 16px;border-radius:20px;font-size:13px;font-weight:600;display:inline-block;margin-bottom:16px;}
        .hs-trial-info{background:#f0fdf4;border:1px solid #bbf7d0;border-radius:8px;padding:12px;margin-bottom:16px;font-size:13px;color:#166534;}
        .hs-payment-methods{margin:16px 0;}
        .hs-payment-method{display:flex;align-items:center;gap:12px;padding:12px;border:2px solid #e5e7eb;border-radius:8px;cursor:pointer;margin-bottom:8px;transition:all 0.2s;}
        .hs-payment-method:hover{border-color:#FF553E;}
        .hs-payment-method.selected{border-color:#FF553E;background:#fff5f4;}
        .hs-payment-method input{display:none;}
        .hs-pm-radio{width:20px;height:20px;border:2px solid #d1d5db;border-radius:50%;display:flex;align-items:center;justify-content:center;}
        .hs-payment-method.selected .hs-pm-radio{border-color:#FF553E;}
        .hs-payment-method.selected .hs-pm-radio::after{content:'';width:10px;height:10px;background:#FF553E;border-radius:50%;}
        .hs-pm-info{flex:1;}
        .hs-pm-name{font-weight:600;font-size:14px;}
        .hs-pm-desc{font-size:11px;color:#888;}
        .hs-pm-icon{font-size:24px;}
        </style>
        <div class="hs-pricing">
            <h1>Checkout</h1>
            <div class="hs-card" style="max-width:380px;margin:16px auto;">
                <div style="text-align:center;">
                    <h3><?php echo esc_html($plan['name']); ?> Plan</h3>
                    <?php if ($show_trial): ?>
                    <div class="hs-trial-badge">🎉 1 Month FREE Trial</div>
                    <p style="font-size:24px;font-weight:700;margin:8px 0;">
                        <span style="text-decoration:line-through;color:#999;font-size:18px;"><?php echo esc_html($currency_symbol) . number_format($price, 2); ?></span>
                        <?php echo esc_html($currency_symbol); ?>0 <span style="font-size:14px;font-weight:400;">first month</span>
                    </p>
                    <p style="font-size:13px;color:#666;">Then <?php echo esc_html($currency_symbol) . number_format($price, 2) . $cycle_label; ?> after trial</p>
                    <?php else: ?>
                    <p style="font-size:24px;font-weight:700;"><?php echo esc_html($currency_symbol) . number_format($price, 2) . $cycle_label; ?></p>
                    <?php endif; ?>
                </div>
                
                <?php if ($show_trial): ?>
                <div class="hs-trial-info">
                    ✓ Full access for 30 days<br>
                    ✓ Cancel anytime before trial ends<br>
                    ✓ Card required to start trial
                </div>
                <?php endif; ?>
                
                <div class="hs-payment-methods">
                    <label class="hs-payment-method selected" onclick="selectPayment(this)">
                        <input type="radio" name="payment_method" value="card" checked>
                        <div class="hs-pm-radio"></div>
                        <div class="hs-pm-info">
                            <div class="hs-pm-name">💳 Card Payment</div>
                            <div class="hs-pm-desc">Visa, Mastercard, Verve</div>
                        </div>
                    </label>
                    <label class="hs-payment-method" onclick="selectPayment(this)">
                        <input type="radio" name="payment_method" value="mobilemoney">
                        <div class="hs-pm-radio"></div>
                        <div class="hs-pm-info">
                            <div class="hs-pm-name">📱 Mobile Money</div>
                            <div class="hs-pm-desc">MTN, Airtel, M-Pesa</div>
                        </div>
                    </label>
                    <label class="hs-payment-method" onclick="selectPayment(this)">
                        <input type="radio" name="payment_method" value="ussd">
                        <div class="hs-pm-radio"></div>
                        <div class="hs-pm-info">
                            <div class="hs-pm-name">📞 USSD / Bank Transfer</div>
                            <div class="hs-pm-desc">Nigerian banks</div>
                        </div>
                    </label>
                </div>
                
                <form id="hs-checkout">
                    <input type="hidden" name="plan" value="<?php echo esc_attr($plan_key); ?>">
                    <input type="hidden" name="cycle" value="<?php echo esc_attr($cycle); ?>">
                    <input type="hidden" name="payment_method" id="selected_payment" value="card">
                    <input type="hidden" name="trial" value="<?php echo $show_trial ? '1' : '0'; ?>">
                    <input type="hidden" name="fw_plan_id" value="<?php echo esc_attr($fw_plan_id); ?>">
                    <div class="hs-msg"></div>
                    <button type="submit" class="hs-btn hs-btn-p hs-btn-xs hs-btn-full">
                        <span class="tx"><?php echo $show_trial ? 'Start Free Trial' : 'Pay Now'; ?></span>
                        <span class="ld">...</span>
                    </button>
                </form>
                <p style="text-align:center;font-size:11px;color:#888;margin-top:12px;">🔒 Secured by Flutterwave</p>
            </div>
        </div>
        <script>
        function selectPayment(el) {
            document.querySelectorAll('.hs-payment-method').forEach(function(m){ m.classList.remove('selected'); });
            el.classList.add('selected');
            document.getElementById('selected_payment').value = el.querySelector('input').value;
        }
        </script>
        <?php
        return ob_get_clean();
    }

    public static function render_order_confirmation() {
        $status = $_GET['status'] ?? 'success';
        ob_start();
        self::get_more_styles();
        ?>
        <div class="hs-pricing">
            <?php if ($status === 'success'): ?>
            <h1>🎉 Success!</h1>
            <p>Subscription active.</p>
            <a href="<?php echo esc_url(Hushot_Pages::get_page_url('dashboard')); ?>" class="hs-btn hs-btn-p hs-btn-xs">Dashboard</a>
            <?php else: ?>
            <h1>Failed</h1>
            <a href="<?php echo esc_url(Hushot_Pages::get_page_url('pricing')); ?>" class="hs-btn hs-btn-p hs-btn-xs">Try Again</a>
            <?php endif; ?>
        </div>
        <?php
        return ob_get_clean();
    }

    private static function render_sidebar($user, $plan, $active) {
        $initial = strtoupper(substr($user->first_name ?: $user->display_name, 0, 1));
        $plugin_url = HUSHOT_PLUGIN_URL;
        ob_start();
        ?>
        <div class="hs-app">
        <nav class="hs-nav" id="sidebar">
            <div class="hs-nav-brand">
                <img src="<?php echo $plugin_url; ?>assets/images/icon-72.png" alt="Hushot">
                <span>Hushot</span>
            </div>
            <!-- Install App Button -->
            <div class="hs-install-app" id="install-app-btn" style="margin:12px;padding:12px 14px;background:linear-gradient(135deg,#10b981,#059669);border-radius:10px;cursor:pointer;display:none;-webkit-tap-highlight-color:transparent;">
                <div style="display:flex;align-items:center;gap:10px;">
                    <span style="font-size:20px;">📲</span>
                    <div>
                        <strong style="display:block;color:#fff;font-size:12px;">Install App</strong>
                        <small style="color:rgba(255,255,255,0.8);font-size:10px;">Add to home screen</small>
                    </div>
                </div>
            </div>
            <div class="hs-nav-links">
                <div class="lbl">Main</div>
                <a href="<?php echo esc_url(Hushot_Pages::get_page_url('dashboard')); ?>" class="<?php echo $active==='dashboard'?'on':''; ?>"><span>📊</span> Dashboard</a>
                <a href="<?php echo esc_url(Hushot_Pages::get_page_url('my-pages')); ?>" class="<?php echo $active==='my-pages'?'on':''; ?>"><span>📄</span> My Pages</a>
                <a href="<?php echo esc_url(Hushot_Pages::get_page_url('create-page')); ?>" class="<?php echo $active==='create-page'?'on':''; ?>"><span>➕</span> Create Page</a>

                <div class="lbl">Seller</div>
                <a href="<?php echo esc_url(Hushot_Pages::get_page_url('seller-setup')); ?>" class="<?php echo $active==='seller-setup'?'on':''; ?>"><span>🏦</span> Seller Payout Settings</a>
                <a href="<?php echo esc_url(Hushot_Pages::get_page_url('seller-dashboard')); ?>" class="<?php echo $active==='seller-dashboard'?'on':''; ?>"><span>💰</span> Sales Dashboard</a>
                <div class="lbl">Tools</div>
                <a href="<?php echo esc_url(Hushot_Pages::get_page_url('ai-generator')); ?>" class="<?php echo $active==='ai-generator'?'on':''; ?>"><span>✨</span> AI Builder</a>
                <a href="<?php echo esc_url(Hushot_Pages::get_page_url('templates')); ?>" class="<?php echo $active==='templates'?'on':''; ?>"><span>🎨</span> Templates</a>
                <a href="<?php echo esc_url(Hushot_Pages::get_page_url('leads')); ?>" class="<?php echo $active==='leads'?'on':''; ?>"><span>👥</span> Leads</a>
                <a href="<?php echo esc_url(Hushot_Pages::get_page_url('analytics')); ?>" class="<?php echo $active==='analytics'?'on':''; ?>"><span>📈</span> Analytics</a>
                <a href="<?php echo esc_url(Hushot_Pages::get_page_url('ads-dashboard')); ?>" class="<?php echo in_array($active, array('ads-dashboard','ads-promote'))?'on':''; ?>"><span>📢</span> Ads Network</a>
                <div class="sep"></div>
                <a href="<?php echo esc_url(Hushot_Pages::get_page_url('my-account')); ?>" class="<?php echo $active==='my-account'?'on':''; ?>"><span>👤</span> Account</a>
                <a href="<?php echo esc_url(Hushot_Pages::get_page_url('billing')); ?>" class="<?php echo $active==='billing'?'on':''; ?>"><span>💳</span> Billing</a>
                <a href="<?php echo esc_url(Hushot_Pages::get_page_url('pricing')); ?>"><span>⭐</span> Upgrade</a>
                <a href="<?php echo esc_url(Hushot_Pages::get_page_url('support')); ?>" class="<?php echo $active==='support'?'on':''; ?>"><span>🛟</span> Support</a>
            </div>
            <div class="hs-nav-foot">
                <div class="hs-nav-user">
                    <span class="hs-nav-avatar"><?php echo $initial; ?></span>
                    <div>
                        <span class="hs-nav-name"><?php echo esc_html($user->display_name); ?></span>
                        <span class="hs-nav-plan"><?php echo esc_html(ucfirst($plan)); ?> Plan</span>
                    </div>
                </div>
                <a href="<?php echo wp_logout_url(home_url()); ?>" class="hs-nav-logout">↪ Sign Out</a>
            </div>
        </nav>
        <script>
        // Mobile Menu & PWA Install
        (function(){
            'use strict';
            
            // Mobile Menu
            var menuBtn = document.getElementById('hs-menu');
            var sidebar = document.getElementById('sidebar');
            var overlay = document.querySelector('.hs-overlay');
            
            function toggleMenu(e) {
                if (e) { e.preventDefault(); e.stopPropagation(); }
                var isOpen = sidebar && sidebar.classList.contains('open');
                if (sidebar) sidebar.classList.toggle('open', !isOpen);
                if (overlay) overlay.classList.toggle('show', !isOpen);
                document.body.style.overflow = isOpen ? '' : 'hidden';
            }
            
            function closeMenu() {
                if (sidebar) sidebar.classList.remove('open');
                if (overlay) overlay.classList.remove('show');
                document.body.style.overflow = '';
            }
            
            if (menuBtn) {
                // On both desktop and mobile devices, rely on click. Touch devices
                // fire click after touchend automatically, so a single listener
                // prevents double toggling which previously left the screen dimmed
                menuBtn.addEventListener('click', toggleMenu, {passive: false});
            }

            if (overlay) {
                overlay.addEventListener('click', closeMenu);
            }
            
            // Close menu when clicking nav links
            var navLinks = document.querySelectorAll('.hs-nav-links a');
            navLinks.forEach(function(link) {
                link.addEventListener('click', function() {
                    setTimeout(closeMenu, 100);
                });
            });
            
            // ===== PWA INSTALL - ALL PLATFORMS =====
            var deferredPrompt = null;
            var installBtn = document.getElementById('install-app-btn');
            var isInstalled = false;
            
            // Check if already installed
            function checkInstalled() {
                if (window.matchMedia('(display-mode: standalone)').matches) return true;
                if (window.navigator.standalone === true) return true;
                if (localStorage.getItem('hushot_pwa_installed') === 'true') return true;
                return false;
            }
            
            isInstalled = checkInstalled();
            if (isInstalled && installBtn) {
                installBtn.style.display = 'none';
                return;
            }
            
            // Listen for successful install
            window.addEventListener('appinstalled', function() {
                localStorage.setItem('hushot_pwa_installed', 'true');
                if (installBtn) installBtn.style.display = 'none';
                trackInstall('pwa-appinstalled');
            });
            
            // Android/Chrome - beforeinstallprompt
            window.addEventListener('beforeinstallprompt', function(e) {
                e.preventDefault();
                deferredPrompt = e;
                if (installBtn && !isInstalled) {
                    installBtn.style.display = 'block';
                }
            });
            
            // iOS detection
            var isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream;
            var isSafari = /^((?!chrome|android).)*safari/i.test(navigator.userAgent);
            
            // Show on iOS Safari
            if (isIOS && isSafari && installBtn && !isInstalled) {
                installBtn.style.display = 'block';
            }
            
            // Handle install button click
            if (installBtn) {
                function handleInstall(e) {
                    e.preventDefault();
                    if (deferredPrompt) {
                        deferredPrompt.prompt();
                        deferredPrompt.userChoice.then(function(result) {
                            if (result.outcome === 'accepted') {
                                localStorage.setItem('hushot_pwa_installed', 'true');
                                trackInstall('android');
                                installBtn.style.display = 'none';
                            }
                            deferredPrompt = null;
                        });
                    } else if (isIOS) {
                        showIOSInstructions();
                        trackInstall('ios-prompt');
                    }
                }
                
                installBtn.addEventListener('click', handleInstall);
                installBtn.addEventListener('touchend', function(e) {
                    e.preventDefault();
                    handleInstall(e);
                }, {passive: false});
            }
            
            // iOS install instructions modal
            function showIOSInstructions() {
                var modal = document.createElement('div');
                modal.innerHTML = '<div style="position:fixed;inset:0;background:rgba(0,0,0,0.8);z-index:9999;display:flex;align-items:center;justify-content:center;padding:20px;">' +
                    '<div style="background:#fff;border-radius:20px;padding:30px;max-width:340px;text-align:center;">' +
                    '<div style="font-size:48px;margin-bottom:16px;">📲</div>' +
                    '<h3 style="margin:0 0 12px;font-size:20px;color:#1a1a2e;">Install Hushot App</h3>' +
                    '<ol style="text-align:left;margin:0 0 20px;padding-left:24px;color:#666;font-size:14px;line-height:1.8;">' +
                    '<li>Tap <strong style="color:#007AFF;">Share</strong> <span style="font-size:18px;">📤</span> at bottom</li>' +
                    '<li>Scroll and tap <strong style="color:#007AFF;">"Add to Home Screen"</strong></li>' +
                    '<li>Tap <strong style="color:#007AFF;">"Add"</strong> to confirm</li>' +
                    '</ol>' +
                    '<button onclick="this.closest(\'div\').parentElement.remove();localStorage.setItem(\'hushot_pwa_installed\',\'true\');" style="width:100%;padding:14px;background:#10b981;color:#fff;border:none;border-radius:12px;font-size:16px;font-weight:600;cursor:pointer;">Got it!</button>' +
                    '</div></div>';
                document.body.appendChild(modal);
            }
            
            // Track install analytics
            function trackInstall(platform) {
                var fd = new FormData();
                fd.append('action', 'hushot_track_install');
                fd.append('platform', platform);
                fd.append('_wpnonce', '<?php echo wp_create_nonce("hushot_install"); ?>');
                fetch('<?php echo admin_url("admin-ajax.php"); ?>', {method:'POST',body:fd})
                .then(function(r) { return r.json(); })
                .catch(function() {});
            }
            
            // Show button on mobile after delay if not installed
            if (/Android|iPhone|iPad|iPod/i.test(navigator.userAgent) && installBtn && !isInstalled) {
                setTimeout(function() {
                    if (!checkInstalled() && installBtn.style.display !== 'block') {
                        installBtn.style.display = 'block';
                    }
                }, 3000);
            }
        })();
        </script>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Render Ads Dashboard
     */
    public static function render_ads_dashboard() {
        if (!is_user_logged_in()) {
            return '<script>window.location.href="'.esc_url(Hushot_Pages::get_page_url('login')).'";</script>';
        }
        
        $user = wp_get_current_user();
        $plan = Hushot_Membership::get_user_plan();
        
        ob_start();
        self::get_more_styles();
        echo self::render_sidebar($user, $plan, 'ads-dashboard');
        ?>
        <main class="hs-main"><button id="hs-menu">☰</button><div class="hs-overlay"></div>
            <div class="hs-head"><h1>📢 Ads Network</h1></div>
            <div class="hs-body">
                <?php echo Hushot_Ads_Dashboard::render_user_dashboard(); ?>
            </div>
        </main></div>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Render Ads Promotion Form
     */
    public static function render_ads_promote() {
        if (!is_user_logged_in()) {
            return '<script>window.location.href="'.esc_url(Hushot_Pages::get_page_url('login')).'";</script>';
        }
        
        $user = wp_get_current_user();
        $plan = Hushot_Membership::get_user_plan();
        $page_id = intval($_GET['page_id'] ?? 0);
        
        ob_start();
        self::get_more_styles();
        echo self::render_sidebar($user, $plan, 'ads-promote');
        ?>
        <main class="hs-main"><button id="hs-menu">☰</button><div class="hs-overlay"></div>
            <div class="hs-head"><h1>🚀 Boost Landing Page</h1></div>
            <div class="hs-body">
                <?php echo Hushot_Ads_Dashboard::render_promotion_form($page_id); ?>
            </div>
        </main></div>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Render Support Page with Ticket System
     */
    public static function render_support() {
        if (!is_user_logged_in()) {
            return '<script>window.location.href="'.esc_url(Hushot_Pages::get_page_url('login')).'";</script>';
        }
        
        $user = wp_get_current_user();
        $plan = Hushot_Membership::get_user_plan();
        $user_id = get_current_user_id();
        
        // Handle ticket submission
        $message = '';
        $ticket_sent = false;
        if (isset($_POST['submit_ticket']) && wp_verify_nonce($_POST['_wpnonce'], 'hushot_support_ticket')) {
            $subject = sanitize_text_field($_POST['ticket_subject'] ?? '');
            $category = sanitize_text_field($_POST['ticket_category'] ?? 'general');
            $description = sanitize_textarea_field($_POST['ticket_description'] ?? '');
            
            if (!empty($subject) && !empty($description)) {
                // Save ticket to database
                global $wpdb;
                $table = $wpdb->prefix . 'hushot_tickets';
                
                // Create table if not exists
                $wpdb->query("CREATE TABLE IF NOT EXISTS {$table} (
                    id bigint(20) NOT NULL AUTO_INCREMENT,
                    user_id bigint(20) NOT NULL,
                    subject varchar(255) NOT NULL,
                    category varchar(50) NOT NULL,
                    description text NOT NULL,
                    status varchar(20) DEFAULT 'open',
                    created_at datetime DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (id),
                    KEY user_id (user_id)
                ) " . $wpdb->get_charset_collate());
                
                $wpdb->insert($table, array(
                    'user_id' => $user_id,
                    'subject' => $subject,
                    'category' => $category,
                    'description' => $description,
                    'status' => 'open'
                ));
                
                // Send email notification to support
                $email_body = "New Support Ticket from Hushot\n\n";
                $email_body .= "From: {$user->display_name} ({$user->user_email})\n";
                $email_body .= "Plan: " . ucfirst($plan) . "\n";
                $email_body .= "Category: " . ucfirst($category) . "\n";
                $email_body .= "Subject: {$subject}\n\n";
                $email_body .= "Description:\n{$description}\n";
                
                wp_mail('support@hushot.net', '[Hushot Ticket] ' . $subject, $email_body);
                
                $message = '<div class="hs-msg success">✅ Ticket submitted successfully! We\'ll respond within 24-48 hours.</div>';
                $ticket_sent = true;
            } else {
                $message = '<div class="hs-msg error">Please fill in all required fields.</div>';
            }
        }
        
        // Get user's recent tickets
        global $wpdb;
        $table = $wpdb->prefix . 'hushot_tickets';
        $tickets = array();
        
        // Check if table exists before querying
        if ($wpdb->get_var("SHOW TABLES LIKE '{$table}'") === $table) {
            $tickets = $wpdb->get_results($wpdb->prepare(
                "SELECT * FROM {$table} WHERE user_id = %d ORDER BY created_at DESC LIMIT 10",
                $user_id
            ));
        }
        
        ob_start();
        self::get_more_styles();
        echo self::render_sidebar($user, $plan, 'support');
        ?>
        <main class="hs-main"><button id="hs-menu">☰</button><div class="hs-overlay"></div>
            <div class="hs-head"><h1>🛟 Support Center</h1></div>
            <div class="hs-body">
                <style>
                .support-wrap{max-width:800px;}
                .support-card{background:#fff;border-radius:20px;padding:28px;margin-bottom:24px;box-shadow:0 4px 20px rgba(0,0,0,0.08);}
                .support-card h3{margin:0 0 8px;font-size:20px;font-weight:700;color:#1a1a2e;}
                .support-card .sub{color:#6b7280;font-size:14px;margin-bottom:24px;}
                .support-field{margin-bottom:20px;}
                .support-field label{display:block;font-size:14px;font-weight:600;color:#374151;margin-bottom:8px;}
                .support-field input,.support-field select,.support-field textarea{width:100%;padding:14px 16px;border:2px solid #e5e7eb;border-radius:12px;font-size:15px;font-family:inherit;background:#f9fafb;transition:all 0.2s;}
                .support-field input:focus,.support-field select:focus,.support-field textarea:focus{outline:none;border-color:#667eea;background:#fff;box-shadow:0 0 0 4px rgba(102,126,234,0.1);}
                .support-field textarea{min-height:150px;resize:vertical;}
                .support-btn{width:100%;padding:16px;background:linear-gradient(135deg,#667eea,#764ba2);color:#fff;border:none;border-radius:12px;font-size:16px;font-weight:700;cursor:pointer;transition:all 0.2s;}
                .support-btn:hover{transform:translateY(-2px);box-shadow:0 8px 20px rgba(102,126,234,0.3);}
                .support-btn:disabled{opacity:0.6;cursor:not-allowed;transform:none;}
                .hs-msg{padding:16px 20px;border-radius:12px;font-size:15px;margin-bottom:24px;text-align:center;}
                .hs-msg.success{background:linear-gradient(135deg,#d1fae5,#ecfdf5);color:#065f46;border:1px solid #a7f3d0;}
                .hs-msg.error{background:linear-gradient(135deg,#fee2e2,#fef2f2);color:#991b1b;border:1px solid #fecaca;}
                .ticket-list{margin-top:20px;}
                .ticket-item{display:flex;align-items:center;justify-content:space-between;padding:16px;background:#f8fafc;border-radius:12px;margin-bottom:10px;border-left:4px solid #667eea;}
                .ticket-item.open{border-left-color:#10b981;}
                .ticket-item.closed{border-left-color:#9ca3af;}
                .ticket-info h4{margin:0 0 4px;font-size:15px;color:#1a1a2e;}
                .ticket-info p{margin:0;font-size:12px;color:#6b7280;}
                .ticket-status{padding:6px 14px;border-radius:20px;font-size:11px;font-weight:700;text-transform:uppercase;}
                .ticket-status.open{background:#d1fae5;color:#065f46;}
                .ticket-status.closed{background:#e5e7eb;color:#6b7280;}
                .ticket-status.pending{background:#fef3c7;color:#92400e;}
                .quick-links{display:grid;grid-template-columns:1fr 1fr;gap:12px;}
                .quick-link{display:flex;align-items:center;gap:12px;padding:16px;background:#f8fafc;border-radius:12px;text-decoration:none;color:#374151;font-weight:600;transition:all 0.2s;border:2px solid transparent;}
                .quick-link:hover{background:#f1f5f9;border-color:#667eea;}
                .quick-link span{font-size:24px;}
                @media(max-width:500px){
                    .quick-links{grid-template-columns:1fr;}
                }
                </style>
                
                <div class="support-wrap">
                    <?php echo $message; ?>
                    
                    <!-- Submit Ticket Form -->
                    <div class="support-card">
                        <h3>📝 Submit a Support Ticket</h3>
                        <p class="sub">Describe your issue and we'll get back to you within 24-48 hours.</p>
                        
                        <form method="post" id="ticket-form">
                            <?php wp_nonce_field('hushot_support_ticket'); ?>
                            
                            <div class="support-field">
                                <label>Category *</label>
                                <select name="ticket_category" required>
                                    <option value="general">General Question</option>
                                    <option value="technical">Technical Issue</option>
                                    <option value="billing">Billing & Payments</option>
                                    <option value="feature">Feature Request</option>
                                    <option value="bug">Bug Report</option>
                                </select>
                            </div>
                            
                            <div class="support-field">
                                <label>Subject *</label>
                                <input type="text" name="ticket_subject" placeholder="Brief description of your issue" required maxlength="255">
                            </div>
                            
                            <div class="support-field">
                                <label>Description *</label>
                                <textarea name="ticket_description" placeholder="Please describe your issue in detail. Include steps to reproduce if it's a bug." required></textarea>
                            </div>
                            
                            <button type="submit" name="submit_ticket" class="support-btn" <?php echo $ticket_sent ? 'disabled' : ''; ?>>
                                <?php echo $ticket_sent ? '✅ Ticket Submitted' : '📨 Submit Ticket'; ?>
                            </button>
                        </form>
                    </div>
                    
                    <!-- Recent Tickets -->
                    <?php if (!empty($tickets)): ?>
                    <div class="support-card">
                        <h3>📋 Your Recent Tickets</h3>
                        <p class="sub">Track the status of your support requests.</p>
                        <div class="ticket-list">
                            <?php foreach ($tickets as $ticket): ?>
                            <div class="ticket-item <?php echo esc_attr($ticket->status); ?>">
                                <div class="ticket-info">
                                    <h4><?php echo esc_html($ticket->subject); ?></h4>
                                    <p><?php echo ucfirst($ticket->category); ?> • <?php echo date('M j, Y g:ia', strtotime($ticket->created_at)); ?></p>
                                </div>
                                <span class="ticket-status <?php echo esc_attr($ticket->status); ?>"><?php echo $ticket->status; ?></span>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                    <!-- Quick Contact -->
                    <div class="support-card">
                        <h3>📞 Quick Contact</h3>
                        <p class="sub">Need immediate assistance? Reach out directly.</p>
                        <div class="quick-links">
                            <a href="mailto:support@hushot.net" class="quick-link">
                                <span>📧</span>
                                <div>support@hushot.net</div>
                            </a>
                            <a href="https://hushot.net/help" target="_blank" class="quick-link">
                                <span>📚</span>
                                <div>Help Center</div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </main></div>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Render Hushot Homepage - Mobile-First Professional Landing Page
     */
    public static function render_home() {
        $is_logged_in = is_user_logged_in();
        $login_url = Hushot_Pages::get_page_url('login');
        $register_url = Hushot_Pages::get_page_url('register');
        $dashboard_url = Hushot_Pages::get_page_url('dashboard');
        $pricing_url = Hushot_Pages::get_page_url('pricing');
        $support_url = Hushot_Pages::get_page_url('support');
        
        // Get pricing data for embedded pricing section
        $all_plans = Hushot_Membership::get_plans();
        $plan_order = array('premium', 'essential', 'free');
        $plans = array();
        foreach ($plan_order as $key) {
            if (isset($all_plans[$key])) {
                $plans[$key] = $all_plans[$key];
            }
        }
        
        // Currency info
        $currency_info = Hushot_Flutterwave::convert_usd_to_local(1);
        $currency_symbol = Hushot_Flutterwave::get_currency_symbol($currency_info['currency']);
        $rate = $currency_info['exchange_rate'];
        
        ob_start();

        ob_start();
        ?>
        <style>
        /* HUSHOT HOMEPAGE - MODERN SAAS DESIGN */
        :root{--primary:#667eea;--secondary:#FF553E;--dark:#0f172a;--gray:#64748b;--light:#f8fafc;}
        *{box-sizing:border-box;margin:0;padding:0;}
        html{scroll-behavior:smooth;}
        body{font-family:'Inter',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif!important;background:#fff!important;color:#1e293b!important;line-height:1.6;-webkit-font-smoothing:antialiased;}
        
        /* Header */
        .hp-header{position:fixed;top:0;left:0;right:0;z-index:1000;background:rgba(15,23,42,0.98);backdrop-filter:blur(20px);padding:0 20px;height:56px;display:flex;align-items:center;justify-content:space-between;}
        .hp-logo{display:flex;align-items:center;gap:8px;text-decoration:none;color:#fff;font-weight:800;font-size:18px;}
        .hp-logo span{font-size:24px;}
        .hp-nav{display:none;}
        .hp-nav a{color:rgba(255,255,255,0.8);text-decoration:none;font-size:14px;font-weight:500;padding:8px 16px;border-radius:8px;transition:all 0.2s;}
        .hp-nav a:hover{color:#fff;background:rgba(255,255,255,0.1);}
        .hp-cta{display:flex;gap:8px;}
        .hp-btn{padding:10px 20px;border-radius:8px;font-size:14px;font-weight:600;text-decoration:none;transition:all 0.2s;border:none;cursor:pointer;display:inline-flex;align-items:center;gap:6px;}
        .hp-btn-outline{color:#fff;border:1.5px solid rgba(255,255,255,0.3);background:transparent;}
        .hp-btn-outline:hover{background:rgba(255,255,255,0.1);border-color:rgba(255,255,255,0.5);}
        .hp-btn-primary{background:var(--secondary);color:#fff!important;}
        .hp-btn-primary:hover{background:#e64a32;transform:translateY(-1px);}
        .hp-menu-btn{display:flex;background:none;border:none;color:#fff;font-size:24px;cursor:pointer;}
        
        /* Mobile Menu */
        .hp-mobile-nav{display:none;position:fixed;top:56px;left:0;right:0;background:var(--dark);padding:16px;z-index:999;}
        .hp-mobile-nav.active{display:block;}
        .hp-mobile-nav a{display:block;color:#fff;text-decoration:none;padding:14px 16px;font-size:15px;border-radius:8px;}
        .hp-mobile-nav a:hover{background:rgba(255,255,255,0.1);}
        
        /* Hero */
        .hp-hero{padding:100px 20px 60px;background:linear-gradient(135deg,var(--dark) 0%,#1e293b 100%);color:#fff;text-align:center;position:relative;overflow:hidden;}
        .hp-hero::before{content:'';position:absolute;top:-50%;left:-50%;width:200%;height:200%;background:radial-gradient(circle at 30% 30%,rgba(102,126,234,0.15) 0%,transparent 50%);pointer-events:none;}
        .hp-hero-inner{max-width:640px;margin:0 auto;position:relative;z-index:1;}
        .hp-badge{display:inline-flex;align-items:center;gap:6px;background:rgba(255,255,255,0.1);border:1px solid rgba(255,255,255,0.2);border-radius:50px;padding:6px 14px;font-size:12px;font-weight:600;margin-bottom:24px;}
        .hp-badge span{background:var(--secondary);color:#fff;padding:2px 8px;border-radius:20px;font-size:10px;}
        .hp-hero h1{font-size:36px;font-weight:800;line-height:1.15;margin-bottom:20px;letter-spacing:-0.5px;}
        .hp-hero h1 em{font-style:normal;background:linear-gradient(135deg,#a5b4fc,#f9a8d4);-webkit-background-clip:text;-webkit-text-fill-color:transparent;}
        .hp-hero p{font-size:16px;color:rgba(255,255,255,0.7);margin-bottom:32px;line-height:1.7;}
        .hp-hero-btns{display:flex;flex-direction:column;gap:12px;}
        .hp-hero-btns .hp-btn{width:100%;justify-content:center;padding:14px 24px;font-size:15px;}
        .hp-btn-white{background:#fff;color:var(--dark)!important;}
        .hp-btn-white:hover{background:#f8fafc;transform:translateY(-2px);box-shadow:0 10px 40px rgba(0,0,0,0.3);}
        .hp-btn-ghost{border:1.5px solid rgba(255,255,255,0.3);color:#fff;background:transparent;}
        .hp-btn-ghost:hover{background:rgba(255,255,255,0.1);}
        
        /* Trust */
        .hp-trust{padding:32px 20px;background:var(--dark);border-top:1px solid rgba(255,255,255,0.1);}
        .hp-trust-inner{max-width:600px;margin:0 auto;display:grid;grid-template-columns:repeat(3,1fr);gap:16px;text-align:center;}
        .hp-trust-item{color:#fff;}
        .hp-trust-num{font-size:28px;font-weight:800;background:linear-gradient(135deg,#a5b4fc,#f9a8d4);-webkit-background-clip:text;-webkit-text-fill-color:transparent;}
        .hp-trust-label{font-size:11px;color:rgba(255,255,255,0.5);text-transform:uppercase;letter-spacing:0.5px;margin-top:4px;}
        
        /* Features */
        .hp-features{padding:64px 20px;background:#fff;}
        .hp-section-title{text-align:center;margin-bottom:48px;}
        .hp-section-title span{display:inline-block;background:rgba(102,126,234,0.1);color:var(--primary);font-size:11px;font-weight:700;padding:6px 12px;border-radius:20px;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:12px;}
        .hp-section-title h2{font-size:28px;font-weight:800;color:var(--dark);margin-bottom:12px;}
        .hp-section-title p{font-size:15px;color:var(--gray);max-width:500px;margin:0 auto;}
        .hp-features-grid{display:grid;grid-template-columns:1fr;gap:16px;max-width:1000px;margin:0 auto;}
        .hp-feature{background:var(--light);border-radius:16px;padding:24px;transition:all 0.3s;}
        .hp-feature:hover{transform:translateY(-4px);box-shadow:0 20px 40px rgba(0,0,0,0.08);}
        .hp-feature-icon{width:48px;height:48px;border-radius:12px;background:linear-gradient(135deg,var(--primary),#818cf8);display:flex;align-items:center;justify-content:center;font-size:22px;margin-bottom:16px;}
        .hp-feature h3{font-size:17px;font-weight:700;color:var(--dark);margin-bottom:8px;}
        .hp-feature p{font-size:14px;color:var(--gray);line-height:1.6;}
        
        /* How It Works */
        .hp-how{padding:64px 20px;background:var(--light);}
        .hp-steps{display:flex;flex-direction:column;gap:24px;max-width:600px;margin:0 auto;}
        .hp-step{display:flex;gap:16px;align-items:flex-start;}
        .hp-step-num{width:40px;height:40px;border-radius:50%;background:var(--primary);color:#fff;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:16px;flex-shrink:0;}
        .hp-step-content h4{font-size:16px;font-weight:700;color:var(--dark);margin-bottom:4px;}
        .hp-step-content p{font-size:14px;color:var(--gray);}
        
        /* Pricing */
        .hp-pricing{padding:64px 20px;background:#fff;}
        .hp-pricing-grid{display:grid;grid-template-columns:1fr;gap:20px;max-width:380px;margin:0 auto;}
        .hp-price-card{background:#fff;border:2px solid #e2e8f0;border-radius:20px;padding:28px 24px;position:relative;transition:all 0.3s;}
        .hp-price-card:hover{border-color:var(--primary);box-shadow:0 20px 50px rgba(0,0,0,0.1);}
        .hp-price-card.featured{border:2px solid var(--secondary);background:linear-gradient(180deg,#fff 0%,#fff5f4 100%);}
        .hp-price-badge{position:absolute;top:-12px;left:50%;transform:translateX(-50%);background:var(--secondary);color:#fff;font-size:10px;font-weight:700;padding:4px 14px;border-radius:20px;text-transform:uppercase;}
        .hp-price-name{font-size:20px;font-weight:700;color:var(--dark);}
        .hp-price-desc{font-size:13px;color:var(--gray);margin-bottom:16px;}
        .hp-price-amount{margin-bottom:20px;}
        .hp-price-amount .currency{font-size:16px;font-weight:700;color:var(--dark);vertical-align:top;}
        .hp-price-amount .value{font-size:42px;font-weight:800;color:var(--dark);line-height:1;}
        .hp-price-amount .period{font-size:14px;color:var(--gray);}
        .hp-price-amount .billed{font-size:11px;color:#94a3b8;margin-top:4px;}
        .hp-price-features{list-style:none;margin:0 0 24px;padding:0;}
        .hp-price-features li{display:flex;align-items:center;gap:10px;padding:8px 0;font-size:13px;color:#475569;}
        .hp-price-features li::before{content:'✓';color:#10b981;font-weight:700;}
        .hp-price-btn{display:block;width:100%;padding:14px;font-size:14px;font-weight:600;text-align:center;text-decoration:none;border-radius:10px;transition:all 0.2s;}
        .hp-price-btn-primary{background:var(--secondary);color:#fff!important;}
        .hp-price-btn-primary:hover{background:#e64a32;transform:translateY(-2px);}
        .hp-price-btn-outline{background:#f1f5f9;color:#475569!important;}
        .hp-price-btn-outline:hover{background:#e2e8f0;}
        
        /* CTA */
        .hp-cta-section{padding:64px 20px;background:linear-gradient(135deg,var(--primary) 0%,#818cf8 100%);text-align:center;color:#fff;}
        .hp-cta-section h2{font-size:28px;font-weight:800;margin-bottom:12px;}
        .hp-cta-section p{font-size:15px;opacity:0.9;margin-bottom:28px;max-width:500px;margin-left:auto;margin-right:auto;}
        
        /* Footer */
        .hp-footer{background:var(--dark);color:#fff;padding:48px 20px 24px;}
        .hp-footer-inner{max-width:1000px;margin:0 auto;}
        .hp-footer-brand{text-align:center;margin-bottom:32px;}
        .hp-footer-brand .hp-logo{justify-content:center;font-size:20px;}
        .hp-footer-brand p{font-size:13px;color:rgba(255,255,255,0.5);margin-top:8px;}
        .hp-footer-links{display:grid;grid-template-columns:repeat(3,1fr);gap:24px;margin-bottom:32px;}
        .hp-footer-col h5{font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:0.5px;color:rgba(255,255,255,0.4);margin-bottom:12px;}
        .hp-footer-col a{display:block;color:rgba(255,255,255,0.7);text-decoration:none;font-size:13px;padding:4px 0;}
        .hp-footer-col a:hover{color:#fff;}
        .hp-footer-bottom{text-align:center;padding-top:24px;border-top:1px solid rgba(255,255,255,0.1);font-size:12px;color:rgba(255,255,255,0.4);}
        
        /* Desktop */
        @media(min-width:768px){
            .hp-header{padding:0 40px;height:64px;}
            .hp-nav{display:flex;gap:8px;}
            .hp-menu-btn{display:none;}
            .hp-hero{padding:140px 40px 80px;}
            .hp-hero h1{font-size:52px;}
            .hp-hero p{font-size:18px;}
            .hp-hero-btns{flex-direction:row;justify-content:center;}
            .hp-hero-btns .hp-btn{width:auto;}
            .hp-trust-num{font-size:36px;}
            .hp-features{padding:100px 40px;}
            .hp-section-title h2{font-size:36px;}
            .hp-features-grid{grid-template-columns:repeat(2,1fr);gap:24px;}
            .hp-how{padding:100px 40px;}
            .hp-pricing{padding:100px 40px;}
            .hp-pricing-grid{grid-template-columns:repeat(3,1fr);max-width:1000px;gap:24px;}
            .hp-price-card.featured{transform:scale(1.05);}
            .hp-cta-section{padding:100px 40px;}
            .hp-cta-section h2{font-size:36px;}
            .hp-footer{padding:60px 40px 32px;}
            .hp-footer-inner{display:grid;grid-template-columns:1.5fr repeat(3,1fr);gap:48px;align-items:start;}
            .hp-footer-brand{text-align:left;margin-bottom:0;}
            .hp-footer-brand .hp-logo{justify-content:flex-start;}
            .hp-footer-links{display:contents;}
        }
        @media(min-width:1024px){
            .hp-hero h1{font-size:60px;}
            .hp-features-grid{grid-template-columns:repeat(3,1fr);}
        }
        </style>
        
        <div class="hp-wrap">
            <!-- Header -->
            <header class="hp-header">
                <a href="<?php echo esc_url(Hushot_Pages::get_page_url('home')); ?>" class="hp-logo">
                    <span>🚀</span> Hushot
                </a>
                <nav class="hp-nav">
                    <a href="#features">Features</a>
                    <a href="#pricing">Pricing</a>
                    <a href="<?php echo esc_url($support_url); ?>">Support</a>
                </nav>
                <div class="hp-cta">
                    <?php if ($is_logged_in): ?>
                    <a href="<?php echo esc_url($dashboard_url); ?>" class="hp-btn hp-btn-primary">Dashboard →</a>
                    <?php else: ?>
                    <a href="<?php echo esc_url($login_url); ?>" class="hp-btn hp-btn-outline">Log in</a>
                    <a href="<?php echo esc_url($register_url); ?>" class="hp-btn hp-btn-primary">Get Started</a>
                    <?php endif; ?>
                </div>
                <button class="hp-menu-btn" onclick="document.getElementById('hp-mobile').classList.toggle('active')">☰</button>
            </header>
            
            <!-- Mobile Nav -->
            <div class="hp-mobile-nav" id="hp-mobile">
                <a href="#features" onclick="document.getElementById('hp-mobile').classList.remove('active')">Features</a>
                <a href="#pricing" onclick="document.getElementById('hp-mobile').classList.remove('active')">Pricing</a>
                <a href="<?php echo esc_url($support_url); ?>">Support</a>
                <?php if (!$is_logged_in): ?>
                <a href="<?php echo esc_url($login_url); ?>">Log in</a>
                <a href="<?php echo esc_url($register_url); ?>" style="background:var(--secondary);text-align:center;margin-top:8px;">Get Started Free</a>
                <?php else: ?>
                <a href="<?php echo esc_url($dashboard_url); ?>" style="background:var(--secondary);text-align:center;margin-top:8px;">Dashboard</a>
                <?php endif; ?>
            </div>
            
            <!-- Hero -->
            <section class="hp-hero">
                <div class="hp-hero-inner">
                    <div class="hp-badge">
                        <span>NEW</span> Africa's #1 Landing Page Builder
                    </div>
                    <h1>Build <em>Landing Pages</em> That Convert</h1>
                    <p>Create stunning, high-converting landing pages in minutes. No coding required. Perfect for African businesses.</p>
                    <div class="hp-hero-btns">
                        <?php if ($is_logged_in): ?>
                        <a href="<?php echo esc_url($dashboard_url); ?>" class="hp-btn hp-btn-white">Go to Dashboard →</a>
                        <?php else: ?>
                        <a href="<?php echo esc_url($register_url); ?>" class="hp-btn hp-btn-white">Start Free Trial →</a>
                        <a href="#pricing" class="hp-btn hp-btn-ghost">View Pricing</a>
                        <?php endif; ?>
                    </div>
                </div>
            </section>
            
            <!-- Trust -->
            <div class="hp-trust">
                <div class="hp-trust-inner">
                    <div class="hp-trust-item">
                        <div class="hp-trust-num">10K+</div>
                        <div class="hp-trust-label">Pages Created</div>
                    </div>
                    <div class="hp-trust-item">
                        <div class="hp-trust-num">5K+</div>
                        <div class="hp-trust-label">Happy Users</div>
                    </div>
                    <div class="hp-trust-item">
                        <div class="hp-trust-num">30+</div>
                        <div class="hp-trust-label">Countries</div>
                    </div>
                </div>
            </div>
            
            <!-- Features -->
            <section class="hp-features" id="features">
                <div class="hp-section-title">
                    <span>Features</span>
                    <h2>Everything You Need</h2>
                    <p>Powerful tools designed for African businesses to create, launch, and grow online.</p>
                </div>
                <div class="hp-features-grid">
                    <div class="hp-feature">
                        <div class="hp-feature-icon">🎨</div>
                        <h3>Beautiful Templates</h3>
                        <p>Professional templates optimized for conversions and mobile devices.</p>
                    </div>
                    <div class="hp-feature">
                        <div class="hp-feature-icon">🤖</div>
                        <h3>AI Content Generator</h3>
                        <p>Let AI write compelling copy for your landing pages instantly.</p>
                    </div>
                    <div class="hp-feature">
                        <div class="hp-feature-icon">💳</div>
                        <h3>Local Payments</h3>
                        <p>Accept payments in NGN, GHS, KES, and more with Flutterwave.</p>
                    </div>
                    <div class="hp-feature">
                        <div class="hp-feature-icon">📱</div>
                        <h3>WhatsApp Integration</h3>
                        <p>Connect with customers instantly via click-to-chat buttons.</p>
                    </div>
                    <div class="hp-feature">
                        <div class="hp-feature-icon">📊</div>
                        <h3>Analytics Dashboard</h3>
                        <p>Track visits, clicks, and conversions with built-in analytics.</p>
                    </div>
                    <div class="hp-feature">
                        <div class="hp-feature-icon">🚀</div>
                        <h3>Ads Network</h3>
                        <p>Boost your pages on Facebook & Instagram with one click.</p>
                    </div>
                </div>
            </section>
            
            <!-- How It Works -->
            <section class="hp-how">
                <div class="hp-section-title">
                    <span>How It Works</span>
                    <h2>Launch in 3 Steps</h2>
                    <p>Get your landing page live in minutes, not days.</p>
                </div>
                <div class="hp-steps">
                    <div class="hp-step">
                        <div class="hp-step-num">1</div>
                        <div class="hp-step-content">
                            <h4>Choose a Template</h4>
                            <p>Pick from our collection of professionally designed templates.</p>
                        </div>
                    </div>
                    <div class="hp-step">
                        <div class="hp-step-num">2</div>
                        <div class="hp-step-content">
                            <h4>Customize Your Page</h4>
                            <p>Add your content, images, and branding. Use AI to generate copy.</p>
                        </div>
                    </div>
                    <div class="hp-step">
                        <div class="hp-step-num">3</div>
                        <div class="hp-step-content">
                            <h4>Publish & Share</h4>
                            <p>Go live instantly. Share on WhatsApp, social media, or run ads.</p>
                        </div>
                    </div>
                </div>
            </section>
            
            <!-- Pricing -->
            <section class="hp-pricing" id="pricing">
                <div class="hp-section-title">
                    <span>Pricing</span>
                    <h2>Simple, Transparent Pricing</h2>
                    <p>Start free and scale as you grow. No hidden fees.</p>
                </div>
                <div class="hp-pricing-grid">
                    <?php foreach ($plans as $key => $plan): 
                        // Read exact prices from database - NO hardcoded defaults
                        $yearly_usd = floatval($plan['pricing']['yearly'] ?? 0);
                        $yearly_per_month = $yearly_usd > 0 ? round($yearly_usd / 12, 2) : 0;
                        $monthly_local = $yearly_per_month > 0 ? round($yearly_per_month * $rate, 0) : 0;
                        $is_popular = $key === 'premium';
                        $is_free = $key === 'free';
                        
                        // Activation fee from database
                        $plan_activation_fee = floatval($plan['activation_fee'] ?? 0);
                        $activation_local = $plan_activation_fee > 0 ? round($plan_activation_fee * $rate, 2) : 0;
                    ?>
                    <div class="hp-price-card <?php echo $is_popular ? 'featured' : ''; ?>">
                        <?php if ($is_popular): ?>
                        <span class="hp-price-badge">Best Value</span>
                        <?php endif; ?>
                        <div class="hp-price-name"><?php echo esc_html($plan['name']); ?></div>
                        <div class="hp-price-desc"><?php echo esc_html($plan['description']); ?></div>
                        <div class="hp-price-amount">
                            <?php if ($is_free): ?>
                            <span class="value">Free</span>
                            <?php elseif ($monthly_local > 0): ?>
                            <span class="currency"><?php echo esc_html($currency_symbol); ?></span>
                            <span class="value"><?php echo number_format($monthly_local, 0); ?></span>
                            <span class="period">/mo</span>
                            <div class="billed">Billed yearly</div>
                            <?php else: ?>
                            <span class="value">—</span>
                            <?php endif; ?>
                        </div>
                        <ul class="hp-price-features">
                            <?php foreach (array_slice($plan['feature_list'], 0, 5) as $f): ?>
                            <li><?php echo esc_html($f); ?></li>
                            <?php endforeach; ?>
                        </ul>
                        <?php if ($is_free): ?>
                        <a href="<?php echo esc_url($register_url); ?>" class="hp-price-btn hp-price-btn-outline">Get Started Free</a>
                        <?php elseif ($is_popular && $activation_local > 0): ?>
                        <?php if (is_user_logged_in()): ?>
                        <a href="<?php echo esc_url(add_query_arg(array('plan'=>$key,'cycle'=>'yearly'),Hushot_Pages::get_page_url('checkout'))); ?>" class="hp-price-btn hp-price-btn-primary">Try for <?php echo $currency_symbol . number_format($activation_local, 2); ?></a>
                        <?php else: ?>
                        <a href="<?php echo esc_url(add_query_arg('redirect', urlencode(add_query_arg(array('plan'=>$key,'cycle'=>'yearly'),Hushot_Pages::get_page_url('checkout'))), Hushot_Pages::get_page_url('login'))); ?>" class="hp-price-btn hp-price-btn-primary">Try for <?php echo $currency_symbol . number_format($activation_local, 2); ?></a>
                        <?php endif; ?>
                        <?php else: ?>
                        <?php if (is_user_logged_in()): ?>
                        <a href="<?php echo esc_url(add_query_arg(array('plan'=>$key,'cycle'=>'yearly'),Hushot_Pages::get_page_url('checkout'))); ?>" class="hp-price-btn hp-price-btn-primary">Start Free Trial</a>
                        <?php else: ?>
                        <a href="<?php echo esc_url(add_query_arg('redirect', urlencode(add_query_arg(array('plan'=>$key,'cycle'=>'yearly'),Hushot_Pages::get_page_url('checkout'))), Hushot_Pages::get_page_url('login'))); ?>" class="hp-price-btn hp-price-btn-primary">Start Free Trial</a>
                        <?php endif; ?>
                        <?php endif; ?>
                    </div>
                    <?php endforeach; ?>
                </div>
            </section>
            
            <!-- CTA -->
            <section class="hp-cta-section">
                <h2>Ready to Grow Your Business?</h2>
                <p>Join thousands of African businesses already using Hushot.</p>
                <a href="<?php echo esc_url($register_url); ?>" class="hp-btn hp-btn-white">Start Free Trial →</a>
            </section>
            
            <!-- Footer -->
            <footer class="hp-footer">
                <div class="hp-footer-inner">
                    <div class="hp-footer-brand">
                        <a href="<?php echo esc_url(Hushot_Pages::get_page_url('home')); ?>" class="hp-logo">
                            <span>🚀</span> Hushot
                        </a>
                        <p>Africa's #1 landing page builder.</p>
                    </div>
                    <div class="hp-footer-links">
                        <div class="hp-footer-col">
                            <h5>Product</h5>
                            <a href="#features">Features</a>
                            <a href="#pricing">Pricing</a>
                        </div>
                        <div class="hp-footer-col">
                            <h5>Company</h5>
                            <a href="<?php echo esc_url($support_url); ?>">Support</a>
                            <a href="mailto:support@hushot.net">Contact</a>
                        </div>
                        <div class="hp-footer-col">
                            <h5>Account</h5>
                            <a href="<?php echo esc_url($login_url); ?>">Login</a>
                            <a href="<?php echo esc_url($register_url); ?>">Register</a>
                        </div>
                    </div>
                </div>
                <div class="hp-footer-bottom">
                    © <?php echo date('Y'); ?> Hushot. All rights reserved.
                </div>
            </footer>
        </div>
        
        <script>
        // Smooth scroll
        document.querySelectorAll('a[href^="#"]').forEach(function(a){
            a.addEventListener('click', function(e){
                var target = document.querySelector(this.getAttribute('href'));
                if(target){
                    e.preventDefault();
                    target.scrollIntoView({behavior:'smooth',block:'start'});
                    document.getElementById('hp-mobile').classList.remove('active');
                }
            });
        });
        </script>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Render Install App Public Page
     * Shareable link that triggers PWA installation
     */
    public static function render_install_app() {
        ob_start();
        $plugin_url = HUSHOT_PLUGIN_URL;
        ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0, user-scalable=yes">
            <title>Install Hushot App</title>
            <meta name="mobile-web-app-capable" content="yes">
            <meta name="apple-mobile-web-app-capable" content="yes">
            <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
            <meta name="apple-mobile-web-app-title" content="Hushot">
            <meta name="theme-color" content="#1a1a1a">
            <link rel="manifest" href="<?php echo $plugin_url; ?>manifest.json" crossorigin="use-credentials">
            <!-- Apple Touch Icons - All sizes for iOS -->
            <link rel="apple-touch-icon" href="<?php echo $plugin_url; ?>assets/images/apple-touch-icon.png">
            <link rel="apple-touch-icon" sizes="72x72" href="<?php echo $plugin_url; ?>assets/images/icon-72.png">
            <link rel="apple-touch-icon" sizes="96x96" href="<?php echo $plugin_url; ?>assets/images/icon-96.png">
            <link rel="apple-touch-icon" sizes="128x128" href="<?php echo $plugin_url; ?>assets/images/icon-128.png">
            <link rel="apple-touch-icon" sizes="144x144" href="<?php echo $plugin_url; ?>assets/images/icon-144.png">
            <link rel="apple-touch-icon" sizes="152x152" href="<?php echo $plugin_url; ?>assets/images/icon-152.png">
            <link rel="apple-touch-icon" sizes="180x180" href="<?php echo $plugin_url; ?>assets/images/icon-180.png">
            <link rel="apple-touch-icon" sizes="192x192" href="<?php echo $plugin_url; ?>assets/images/icon-192.png">
            <!-- Apple Splash Screen -->
            <link rel="apple-touch-startup-image" href="<?php echo $plugin_url; ?>assets/images/hushot-splash.png">
            <style>
            *{margin:0;padding:0;box-sizing:border-box;}
            html,body{height:100%;overflow-x:hidden;}
            body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;background:#1a1a1a;color:#fff;min-height:100vh;display:flex;flex-direction:column;}
            
            /* Sticky Header */
            .install-header{position:sticky;top:0;z-index:100;background:linear-gradient(135deg,#F7931E 0%,#e67e00 100%);padding:14px 20px;display:flex;align-items:center;justify-content:space-between;box-shadow:0 2px 20px rgba(247,147,30,0.3);}
            .install-header-left{display:flex;align-items:center;gap:12px;}
            .install-header img{width:36px;height:36px;border-radius:8px;}
            .install-header h1{font-size:16px;font-weight:700;color:#fff;margin:0;}
            .install-header-btn{padding:8px 16px;background:#fff;color:#F7931E;border:none;border-radius:8px;font-size:13px;font-weight:700;cursor:pointer;-webkit-tap-highlight-color:transparent;touch-action:manipulation;}
            
            /* Main Content */
            .install-main{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:24px 20px;text-align:center;}
            .install-logo{width:120px;height:120px;border-radius:28px;margin-bottom:24px;box-shadow:0 20px 60px rgba(0,0,0,0.5);}
            .install-title{font-size:32px;font-weight:800;margin-bottom:8px;color:#fff;letter-spacing:-0.5px;}
            .install-tagline{font-size:15px;color:#F7931E;font-weight:600;margin-bottom:24px;}
            .install-desc{font-size:14px;color:rgba(255,255,255,0.7);line-height:1.6;max-width:320px;margin-bottom:32px;}
            
            /* Big Install Button */
            .install-btn-big{display:flex;align-items:center;justify-content:center;gap:12px;width:100%;max-width:300px;padding:18px 32px;background:linear-gradient(135deg,#F7931E 0%,#e67e00 100%);color:#fff;border:none;border-radius:16px;font-size:18px;font-weight:700;cursor:pointer;transition:all 0.3s;box-shadow:0 10px 40px rgba(247,147,30,0.4);-webkit-tap-highlight-color:transparent;touch-action:manipulation;}
            .install-btn-big:hover{transform:translateY(-2px);box-shadow:0 15px 50px rgba(247,147,30,0.5);}
            .install-btn-big:active{transform:translateY(0);}
            .install-btn-big.hide{display:none;}
            
            /* Success Message */
            .installed-msg{display:none;padding:20px;background:rgba(16,185,129,0.15);border:1px solid rgba(16,185,129,0.3);border-radius:16px;color:#10b981;font-size:15px;font-weight:600;max-width:300px;}
            .installed-msg.show{display:block;}
            
            /* Features */
            .install-features{display:flex;gap:16px;margin-top:40px;flex-wrap:wrap;justify-content:center;}
            .install-feature{display:flex;align-items:center;gap:8px;padding:10px 16px;background:rgba(255,255,255,0.05);border-radius:10px;}
            .install-feature span{font-size:18px;}
            .install-feature strong{font-size:12px;color:rgba(255,255,255,0.8);}
            
            /* iOS Instructions */
            .ios-guide{display:none;width:100%;max-width:340px;margin-top:24px;text-align:left;background:rgba(255,255,255,0.08);border-radius:16px;padding:20px;border:1px solid rgba(255,255,255,0.1);}
            .ios-guide.show{display:block;}
            .ios-guide h3{font-size:14px;font-weight:700;margin-bottom:16px;color:#F7931E;display:flex;align-items:center;gap:8px;}
            .ios-guide ol{padding-left:20px;font-size:13px;line-height:2.2;color:rgba(255,255,255,0.85);}
            .ios-guide li{margin-bottom:4px;}
            .ios-guide strong{color:#fff;}
            .ios-guide .share-icon{display:inline-flex;align-items:center;justify-content:center;width:24px;height:24px;background:#007AFF;border-radius:6px;font-size:14px;vertical-align:middle;margin:0 4px;}
            
            /* Footer */
            .install-footer{padding:20px;text-align:center;border-top:1px solid rgba(255,255,255,0.1);}
            .install-footer a{color:#F7931E;text-decoration:none;font-size:13px;font-weight:500;}
            
            /* Responsive - Tablet+ */
            @media(min-width:600px){
                .install-logo{width:140px;height:140px;}
                .install-title{font-size:40px;}
                .install-features{gap:20px;}
            }
            </style>
        </head>
        <body>
            <!-- Sticky Header with Install -->
            <header class="install-header">
                <div class="install-header-left">
                    <img src="<?php echo $plugin_url; ?>assets/images/icon-192.png" alt="Hushot">
                    <h1>Install App</h1>
                </div>
                <button class="install-header-btn" id="header-install-btn">Install</button>
            </header>
            
            <!-- Main Content -->
            <main class="install-main">
                <img src="<?php echo $plugin_url; ?>assets/images/icon-512.png" alt="Hushot" class="install-logo">
                <h2 class="install-title">HUSHOT</h2>
                <p class="install-tagline">Grow Faster, Pay Less!</p>
                <p class="install-desc">Create professional landing pages, run ads, and grow your business - all from your home screen.</p>
                
                <button class="install-btn-big" id="install-btn">
                    <span>📲</span> Install Hushot App
                </button>
                
                <div class="installed-msg" id="installed-msg">
                    ✅ App installed successfully! Check your home screen.
                </div>
                
                <!-- iOS Instructions - Visual Step by Step -->
                <div class="ios-guide" id="ios-guide">
                    <h3>📱 Install on iPhone/iPad</h3>
                    <div class="ios-steps">
                        <div class="ios-step">
                            <div class="step-num">1</div>
                            <div class="step-content">
                                <span class="step-icon" style="background:#007AFF;">📤</span>
                                <strong>Tap Share Button</strong>
                                <p>Look for the share icon at the bottom of Safari</p>
                            </div>
                        </div>
                        <div class="ios-step">
                            <div class="step-num">2</div>
                            <div class="step-content">
                                <span class="step-icon" style="background:#34C759;">➕</span>
                                <strong>Add to Home Screen</strong>
                                <p>Scroll down and tap this option</p>
                            </div>
                        </div>
                        <div class="ios-step">
                            <div class="step-num">3</div>
                            <div class="step-content">
                                <span class="step-icon" style="background:#F7931E;">✓</span>
                                <strong>Tap Add</strong>
                                <p>Confirm in the top right corner</p>
                            </div>
                        </div>
                    </div>
                    <p class="ios-note">💡 <strong>Tip:</strong> The app will appear on your home screen just like a regular app!</p>
                </div>
                <style>
                .ios-steps{margin:16px 0;}
                .ios-step{display:flex;align-items:flex-start;gap:12px;margin-bottom:16px;padding:12px;background:rgba(255,255,255,0.1);border-radius:12px;}
                .step-num{width:28px;height:28px;background:#F7931E;color:#fff;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:14px;flex-shrink:0;}
                .step-content{flex:1;}
                .step-icon{display:inline-flex;align-items:center;justify-content:center;width:32px;height:32px;border-radius:8px;font-size:16px;margin-bottom:4px;}
                .step-content strong{display:block;color:#fff;font-size:14px;margin-bottom:2px;}
                .step-content p{margin:0;font-size:12px;color:rgba(255,255,255,0.7);}
                .ios-note{font-size:12px;color:rgba(255,255,255,0.8);text-align:center;margin-top:12px;padding:10px;background:rgba(247,147,30,0.2);border-radius:8px;}
                </style>
                
                <div class="install-features">
                    <div class="install-feature"><span>⚡</span><strong>Instant Access</strong></div>
                    <div class="install-feature"><span>🔔</span><strong>Notifications</strong></div>
                    <div class="install-feature"><span>📴</span><strong>Works Offline</strong></div>
                </div>
            </main>
            
            <footer class="install-footer">
                <a href="<?php echo esc_url(home_url('/hushot-register/')); ?>">Create Free Account →</a>
            </footer>
            
            <script>
            (function(){
                var installBtnBig = document.getElementById('install-btn');
                var headerBtn = document.getElementById('header-install-btn');
                var installedMsg = document.getElementById('installed-msg');
                var iosGuide = document.getElementById('ios-guide');
                var deferredPrompt = null;
                
                // Check if already installed
                var isInstalled = window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone;
                if (isInstalled) {
                    installBtnBig.classList.add('hide');
                    headerBtn.style.display = 'none';
                    installedMsg.classList.add('show');
                    return;
                }
                
                // iOS detection
                var isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream;
                if (isIOS) {
                    iosGuide.classList.add('show');
                }
                
                // Android/Chrome - capture install prompt
                window.addEventListener('beforeinstallprompt', function(e) {
                    e.preventDefault();
                    deferredPrompt = e;
                });
                
                // Handle install
                function triggerInstall() {
                    if (deferredPrompt) {
                        deferredPrompt.prompt();
                        deferredPrompt.userChoice.then(function(result) {
                            if (result.outcome === 'accepted') {
                                trackInstall('android');
                                installBtnBig.classList.add('hide');
                                headerBtn.style.display = 'none';
                                installedMsg.classList.add('show');
                            }
                            deferredPrompt = null;
                        });
                    } else if (isIOS) {
                        iosGuide.classList.add('show');
                        iosGuide.scrollIntoView({behavior:'smooth', block:'center'});
                        trackInstall('ios-prompt');
                    } else {
                        window.location.href = '<?php echo esc_url(home_url('/hushot-register/')); ?>';
                    }
                }
                
                installBtnBig.addEventListener('click', triggerInstall);
                headerBtn.addEventListener('click', triggerInstall);
                
                // Track install
                function trackInstall(platform) {
                    var fd = new FormData();
                    fd.append('action', 'hushot_track_install');
                    fd.append('platform', platform);
                    fd.append('_wpnonce', '<?php echo wp_create_nonce("hushot_install"); ?>');
                    fetch('<?php echo admin_url("admin-ajax.php"); ?>', {method:'POST',body:fd}).catch(function(){});
                }
                
                // Listen for app installed event
                window.addEventListener('appinstalled', function() {
                    trackInstall('pwa-installed');
                    installBtnBig.classList.add('hide');
                    headerBtn.style.display = 'none';
                    installedMsg.classList.add('show');
                });
            })();
            </script>
        </body>
        </html>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Render Visual Builder
     * Live preview page editing system
     */
    public static function render_visual_builder() {
        if (!is_user_logged_in()) {
            return '<script>window.location.href="' . esc_url(Hushot_Pages::get_page_url('login')) . '";</script>';
        }

        $user = wp_get_current_user();
        $plan = Hushot_Membership::get_user_plan();

        ob_start();
        self::get_more_styles();
        echo self::render_sidebar($user, $plan, 'visual-builder');
        ?>
        <main class="hs-main"><button id="hs-menu">☰</button><div class="hs-overlay"></div>
            <div class="hs-head"><h1>🎨 Visual Builder</h1></div>
            <div class="hs-body">
                <?php echo self::render_visual_builder_inline($user, $plan); ?>
            </div>
        </main></div>
        <?php
        return ob_get_clean();
    }
    /**
     * Seller Dashboard - Marketplace Earnings
     */
    public static function render_seller_dashboard() {
        if (!is_user_logged_in()) return '<script>window.location.href="'.esc_url(Hushot_Pages::get_page_url('login')).'";</script>';
        $user = wp_get_current_user();
        $plan = Hushot_Membership::get_user_plan();
        
        // Check if seller is set up
        $subaccount_id = get_user_meta($user->ID, 'hushot_flw_subaccount_id', true);
        if (!$subaccount_id) {
            return '<script>window.location.href="'.esc_url(Hushot_Pages::get_page_url('seller-setup')).'";</script>';
        }
        
        // Get seller stats
        global $wpdb;
        $table = $wpdb->prefix . 'hushot_marketplace_transactions';
        
        $stats = $wpdb->get_row($wpdb->prepare(
            "SELECT 
                COUNT(*) as total_sales,
                SUM(amount) as gross_earnings,
                SUM(commission) as total_commission,
                SUM(amount - commission) as net_payout
            FROM $table 
            WHERE seller_id = %d AND status = 'completed'",
            $user->ID
        ));
        
        // Get recent transactions
        $transactions = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $table WHERE seller_id = %d ORDER BY created_at DESC LIMIT 20",
            $user->ID
        ));
        
        // Currency breakdown
        $by_currency = $wpdb->get_results($wpdb->prepare(
            "SELECT currency, SUM(amount - commission) as total 
            FROM $table 
            WHERE seller_id = %d AND status = 'completed'
            GROUP BY currency",
            $user->ID
        ));
        
        ob_start();
        self::get_more_styles();
        echo self::render_sidebar($user, $plan, 'seller-dashboard');
        ?>
        <style>
        .seller-stats{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:20px;}
        @media(max-width:600px){.seller-stats{grid-template-columns:repeat(2,1fr);}}
        .seller-stat{background:#fff;border-radius:12px;padding:16px;text-align:center;}
        .seller-stat .num{font-size:24px;font-weight:800;color:#1a1a2e;}
        .seller-stat .lbl{font-size:11px;color:#6b7280;margin-top:4px;}
        .seller-stat.green .num{color:#10b981;}
        .seller-card{background:#fff;border-radius:12px;padding:20px;margin-bottom:16px;}
        .seller-card h3{font-size:16px;font-weight:700;margin:0 0 16px;}
        .seller-tx{padding:12px 0;border-bottom:1px solid #f0f0f0;display:flex;align-items:center;justify-content:space-between;}
        .seller-tx:last-child{border:none;}
        .seller-tx .info{flex:1;}
        .seller-tx .product{font-size:13px;font-weight:600;color:#1a1a2e;}
        .seller-tx .date{font-size:11px;color:#6b7280;}
        .seller-tx .amt{font-weight:700;color:#10b981;}
        .seller-tx .status{font-size:10px;padding:4px 8px;border-radius:6px;background:#d1fae5;color:#065f46;}
        .seller-tx .status.pending{background:#fef3c7;color:#92400e;}
        .currency-grid{display:flex;gap:12px;flex-wrap:wrap;}
        .currency-item{padding:12px 16px;background:#f9fafb;border-radius:10px;font-size:13px;}
        .currency-item strong{font-weight:700;color:#10b981;}
        </style>
        <main class="hs-main"><button id="hs-menu">☰</button><div class="hs-overlay"></div>
            <div class="hs-head"><h1>💰 Seller Dashboard</h1></div>
            <div class="hs-body">
                <div class="seller-stats">
                    <div class="seller-stat"><div class="num"><?php echo (int)($stats->total_sales ?? 0); ?></div><div class="lbl">Total Sales</div></div>
                    <div class="seller-stat"><div class="num"><?php echo number_format($stats->gross_earnings ?? 0, 2); ?></div><div class="lbl">Gross Earnings</div></div>
                    <div class="seller-stat"><div class="num"><?php echo number_format($stats->total_commission ?? 0, 2); ?></div><div class="lbl">Platform Fee</div></div>
                    <div class="seller-stat green"><div class="num"><?php echo number_format($stats->net_payout ?? 0, 2); ?></div><div class="lbl">Net Payout</div></div>
                </div>
                
                <?php if (!empty($by_currency)): ?>
                <div class="seller-card">
                    <h3>💱 Earnings by Currency</h3>
                    <div class="currency-grid">
                        <?php foreach ($by_currency as $c): ?>
                        <div class="currency-item"><?php echo esc_html($c->currency); ?>: <strong><?php echo number_format($c->total, 2); ?></strong></div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>
                
                <div class="seller-card">
                    <h3>📋 Recent Transactions</h3>
                    <?php if (empty($transactions)): ?>
                    <p style="color:#6b7280;font-size:13px;">No transactions yet. Share your landing pages to start selling!</p>
                    <?php else: ?>
                    <?php foreach ($transactions as $tx): ?>
                    <div class="seller-tx">
                        <div class="info">
                            <div class="product"><?php echo esc_html($tx->product_name); ?></div>
                            <div class="date"><?php echo date('M j, Y H:i', strtotime($tx->created_at)); ?></div>
                        </div>
                        <div class="amt"><?php echo esc_html($tx->currency); ?> <?php echo number_format($tx->amount - $tx->commission, 2); ?></div>
                        <div class="status <?php echo $tx->status === 'pending' ? 'pending' : ''; ?>"><?php echo ucfirst($tx->status); ?></div>
                    </div>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </main></div>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Seller Setup - Bank Details
     */
    public static function render_seller_setup() {
        if (!is_user_logged_in()) return '<script>window.location.href="'.esc_url(Hushot_Pages::get_page_url('login')).'";</script>';
        $user = wp_get_current_user();
        $plan = Hushot_Membership::get_user_plan();
        
        // Check if already set up
        $subaccount_id = get_user_meta($user->ID, 'hushot_flw_subaccount_id', true);
        
        // Get saved payout settings
        $payout_type = get_user_meta($user->ID, 'hushot_payout_type', true) ?: 'bank';
        $saved_bank_code = get_user_meta($user->ID, 'hushot_bank_code', true);
        $saved_account = get_user_meta($user->ID, 'hushot_account_number', true);
        $saved_account_name = get_user_meta($user->ID, 'hushot_account_name', true);
        $saved_business = get_user_meta($user->ID, 'hushot_business_name', true);
        $saved_mobile_network = get_user_meta($user->ID, 'hushot_mobile_network', true);
        $saved_mobile_number = get_user_meta($user->ID, 'hushot_mobile_number', true);
        
        ob_start();
        self::get_more_styles();
        echo self::render_sidebar($user, $plan, 'seller-setup');
        ?>
        <style>
        .seller-setup{max-width:500px;margin:0 auto;}
        .setup-card{background:#fff;border-radius:16px;padding:24px;margin-bottom:16px;}
        .setup-card h2{font-size:20px;font-weight:700;margin:0 0 8px;}
        .setup-card .sub{color:#6b7280;font-size:13px;margin-bottom:24px;}
        .setup-field{margin-bottom:18px;}
        .setup-field label{display:block;font-size:13px;font-weight:600;margin-bottom:6px;color:#374151;}
        .setup-field input,.setup-field select{width:100%;padding:14px;border:2px solid #e5e7eb;border-radius:10px;font-size:14px;box-sizing:border-box;background:#fff;}
        .setup-field input:focus,.setup-field select:focus{outline:none;border-color:#F7931E;}
        .setup-btn{width:100%;padding:16px;background:#F7931E;color:#fff;border:none;border-radius:12px;font-size:15px;font-weight:700;cursor:pointer;margin-top:8px;}
        .setup-btn:disabled{opacity:0.6;cursor:not-allowed;}
        .setup-success{background:#d1fae5;color:#065f46;padding:16px;border-radius:12px;text-align:center;font-size:14px;}
        .setup-banks{font-size:11px;color:#6b7280;margin-top:-10px;margin-bottom:18px;}
        .payout-toggle{display:flex;gap:8px;margin-bottom:20px;}
        .payout-toggle button{flex:1;padding:14px;border:2px solid #e5e7eb;border-radius:10px;background:#fff;font-size:14px;font-weight:600;cursor:pointer;transition:all 0.2s;}
        .payout-toggle button.active{border-color:#F7931E;background:#fff9f0;color:#F7931E;}
        .payout-toggle button:hover{border-color:#F7931E;}
        .payout-fields{display:none;}
        .payout-fields.active{display:block;}
        .verify-status{font-size:12px;margin-top:4px;padding:8px;border-radius:6px;}
        .verify-status.success{background:#d1fae5;color:#065f46;}
        .verify-status.error{background:#fee2e2;color:#991b1b;}
        .verify-status.loading{background:#fef3c7;color:#92400e;}
        </style>
        <main class="hs-main"><button id="hs-menu">☰</button><div class="hs-overlay"></div>
            <div class="hs-head"><h1>🏦 Seller Payout Settings</h1></div>
            <div class="hs-body">
                <div class="seller-setup">
                    <?php if ($subaccount_id): ?>
                    <div class="setup-card">
                        <div class="setup-success">
                            ✅ Your seller account is set up and ready to receive payments!
                        </div>
                        <div style="margin-top:20px;padding:16px;background:#f9fafb;border-radius:10px;">
                            <p style="margin:0 0 8px;font-size:13px;color:#6b7280;">Current payout method:</p>
                            <p style="margin:0;font-weight:600;color:#1a1a2e;">
                                <?php if ($payout_type === 'mobile'): ?>
                                📱 Mobile Money - <?php echo esc_html($saved_mobile_network); ?> (<?php echo esc_html($saved_mobile_number); ?>)
                                <?php else: ?>
                                🏦 Bank Transfer - <?php echo esc_html($saved_account_name); ?>
                                <?php endif; ?>
                            </p>
                        </div>
                        <div style="text-align:center;margin-top:20px;">
                            <a href="<?php echo esc_url(Hushot_Pages::get_page_url('seller-dashboard')); ?>" class="setup-btn" style="display:inline-block;text-decoration:none;padding:14px 28px;width:auto;">View Sales Dashboard →</a>
                        </div>
                        <p style="text-align:center;margin-top:16px;font-size:12px;color:#6b7280;">
                            Need to update your payout details? <a href="#" id="update-payout-btn" style="color:#F7931E;">Click here</a>
                        </p>
                    </div>
                    <?php endif; ?>
                    
                    <div class="setup-card" id="setup-form-card" style="<?php echo $subaccount_id ? 'display:none;' : ''; ?>">
                        <h2>💰 <?php echo $subaccount_id ? 'Update Payout Settings' : 'Start Selling'; ?></h2>
                        <p class="sub"><?php echo $subaccount_id ? 'Update your bank or mobile money details for receiving payments.' : 'Add your bank or mobile money details to receive payments directly when customers buy from your landing pages.'; ?></p>
                        
                        <div class="payout-toggle">
                            <button type="button" id="toggle-bank" class="<?php echo $payout_type !== 'mobile' ? 'active' : ''; ?>">🏦 Bank Transfer</button>
                            <button type="button" id="toggle-mobile" class="<?php echo $payout_type === 'mobile' ? 'active' : ''; ?>">📱 Mobile Money</button>
                        </div>
                        
                        <form id="seller-setup-form">
                            <input type="hidden" name="payout_type" id="payout-type" value="<?php echo esc_attr($payout_type); ?>">
                            
                            <!-- Bank Transfer Fields -->
                            <div id="bank-fields" class="payout-fields <?php echo $payout_type !== 'mobile' ? 'active' : ''; ?>">
                                <div class="setup-field">
                                    <label>Bank Name</label>
                                    <select name="bank_code" id="bank-code">
                                        <option value="">Select your bank</option>
                                    </select>
                                </div>
                                <p class="setup-banks">Supported: All Nigerian banks</p>
                                
                                <div class="setup-field">
                                    <label>Account Number</label>
                                    <input type="text" name="account_number" id="account-number" placeholder="0123456789" maxlength="10" pattern="[0-9]{10}" value="<?php echo esc_attr($saved_account); ?>">
                                </div>
                                
                                <div class="setup-field">
                                    <label>Account Name</label>
                                    <input type="text" name="account_name" id="account-name" placeholder="Will be verified automatically" readonly value="<?php echo esc_attr($saved_account_name); ?>">
                                    <div id="verify-status" class="verify-status" style="display:none;"></div>
                                </div>
                            </div>
                            
                            <!-- Mobile Money Fields -->
                            <div id="mobile-fields" class="payout-fields <?php echo $payout_type === 'mobile' ? 'active' : ''; ?>">
                                <div class="setup-field">
                                    <label>Mobile Network</label>
                                    <select name="mobile_network" id="mobile-network">
                                        <option value="">Select network</option>
                                        <option value="MTN" <?php selected($saved_mobile_network, 'MTN'); ?>>MTN Mobile Money</option>
                                        <option value="VODAFONE" <?php selected($saved_mobile_network, 'VODAFONE'); ?>>Vodafone Cash</option>
                                        <option value="TIGO" <?php selected($saved_mobile_network, 'TIGO'); ?>>AirtelTigo Money</option>
                                        <option value="MPESA" <?php selected($saved_mobile_network, 'MPESA'); ?>>M-Pesa (Kenya)</option>
                                    </select>
                                </div>
                                <p class="setup-banks">Supported: Ghana (MTN, Vodafone, AirtelTigo), Kenya (M-Pesa)</p>
                                
                                <div class="setup-field">
                                    <label>Mobile Number</label>
                                    <input type="tel" name="mobile_number" id="mobile-number" placeholder="e.g., 0241234567" value="<?php echo esc_attr($saved_mobile_number); ?>">
                                </div>
                            </div>
                            
                            <!-- Common Fields -->
                            <div class="setup-field">
                                <label>Business Name (for receipts)</label>
                                <input type="text" name="business_name" id="business-name" placeholder="Your business name" value="<?php echo esc_attr($saved_business); ?>">
                            </div>
                            
                            <?php
                            // Show platform fee dynamically from settings
                            $pf = floatval(get_option('hushot_platform_fee', 5));
                            if ($pf < 0) $pf = 0;
                            if ($pf > 100) $pf = 100;
                            ?>
                            <div style="margin-bottom:18px;padding:12px;background:#fef3c7;border-radius:10px;font-size:12px;color:#92400e;">
                                ⚠️ Platform fee: <?php echo esc_html($pf); ?>% per transaction (automatically deducted)
                            </div>
                            
                            <button type="submit" class="setup-btn" id="setup-btn">🔒 Save & Verify</button>
                            <?php if ($subaccount_id): ?>
                            <button type="button" class="setup-btn" id="cancel-update-btn" style="background:#6b7280;margin-top:8px;">Cancel</button>
                            <?php endif; ?>
                        </form>
                    </div>
                </div>
            </div>
        </main></div>
        
        <script>
        (function(){
            'use strict';
            
            var payoutType = document.getElementById('payout-type');
            var toggleBank = document.getElementById('toggle-bank');
            var toggleMobile = document.getElementById('toggle-mobile');
            var bankFields = document.getElementById('bank-fields');
            var mobileFields = document.getElementById('mobile-fields');
            var bankCode = document.getElementById('bank-code');
            var accNum = document.getElementById('account-number');
            var accName = document.getElementById('account-name');
            var verifyStatus = document.getElementById('verify-status');
            var setupForm = document.getElementById('seller-setup-form');
            var setupBtn = document.getElementById('setup-btn');
            var updateBtn = document.getElementById('update-payout-btn');
            var cancelBtn = document.getElementById('cancel-update-btn');
            var formCard = document.getElementById('setup-form-card');
            
            // Toggle between Bank and Mobile Money
            function setPayoutType(type) {
                payoutType.value = type;
                if (type === 'mobile') {
                    toggleBank.classList.remove('active');
                    toggleMobile.classList.add('active');
                    bankFields.classList.remove('active');
                    mobileFields.classList.add('active');
                } else {
                    toggleBank.classList.add('active');
                    toggleMobile.classList.remove('active');
                    bankFields.classList.add('active');
                    mobileFields.classList.remove('active');
                }
            }
            
            if (toggleBank) {
                toggleBank.addEventListener('click', function(e) {
                    e.preventDefault();
                    setPayoutType('bank');
                });
            }
            
            if (toggleMobile) {
                toggleMobile.addEventListener('click', function(e) {
                    e.preventDefault();
                    setPayoutType('mobile');
                });
            }
            
            // Show update form
            if (updateBtn) {
                updateBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    formCard.style.display = 'block';
                    this.closest('.setup-card').style.display = 'none';
                });
            }
            
            // Cancel update
            if (cancelBtn) {
                cancelBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    formCard.style.display = 'none';
                    document.querySelector('.setup-success').closest('.setup-card').style.display = 'block';
                });
            }
            
            // Load banks from Flutterwave
            fetch('<?php echo admin_url('admin-ajax.php'); ?>?action=hushot_get_banks&_wpnonce=<?php echo wp_create_nonce('hushot_banks'); ?>')
            .then(function(r){ return r.json(); })
            .then(function(d){
                if (d.success && d.data.banks) {
                    var savedBank = '<?php echo esc_js($saved_bank_code); ?>';
                    d.data.banks.forEach(function(b){
                        var opt = document.createElement('option');
                        opt.value = b.code;
                        opt.textContent = b.name;
                        if (b.code === savedBank) opt.selected = true;
                        bankCode.appendChild(opt);
                    });
                }
            }).catch(function(err){
                console.error('Failed to load banks:', err);
            });
            
            // Verify account on blur
            function verifyAccount() {
                var bank = bankCode.value;
                var num = accNum.value;
                
                if (!bank || num.length !== 10) return;
                
                accName.value = 'Verifying...';
                verifyStatus.style.display = 'block';
                verifyStatus.className = 'verify-status loading';
                verifyStatus.textContent = '⏳ Verifying account...';
                
                var fd = new FormData();
                fd.append('action', 'hushot_verify_account');
                fd.append('bank_code', bank);
                fd.append('account_number', num);
                fd.append('_wpnonce', '<?php echo wp_create_nonce('hushot_verify'); ?>');
                
                fetch('<?php echo admin_url('admin-ajax.php'); ?>', {method:'POST', body:fd})
                .then(function(r){ return r.json(); })
                .then(function(d){
                    if (d.success && d.data.account_name) {
                        accName.value = d.data.account_name;
                        verifyStatus.className = 'verify-status success';
                        verifyStatus.textContent = '✅ Account verified!';
                    } else {
                        accName.value = '';
                        verifyStatus.className = 'verify-status error';
                        verifyStatus.textContent = '❌ ' + (d.data && d.data.message ? d.data.message : 'Verification failed');
                    }
                }).catch(function(){
                    accName.value = '';
                    verifyStatus.className = 'verify-status error';
                    verifyStatus.textContent = '❌ Network error. Please try again.';
                });
            }
            
            if (accNum) {
                accNum.addEventListener('blur', verifyAccount);
            }
            if (bankCode) {
                bankCode.addEventListener('change', function() {
                    if (accNum.value.length === 10) verifyAccount();
                });
            }
            
            // Submit form
            if (setupForm) {
                setupForm.addEventListener('submit', function(e){
                    e.preventDefault();
                    
                    var type = payoutType.value;
                    var businessName = document.getElementById('business-name').value.trim();
                    
                    // Validation
                    if (!businessName) {
                        alert('Please enter your business name.');
                        return;
                    }
                    
                    if (type === 'bank') {
                        if (!bankCode.value) {
                            alert('Please select your bank.');
                            return;
                        }
                        if (accNum.value.length !== 10) {
                            alert('Please enter a valid 10-digit account number.');
                            return;
                        }
                        if (!accName.value || accName.value === 'Verifying...') {
                            alert('Please wait for account verification.');
                            return;
                        }
                    } else {
                        var mobileNetwork = document.getElementById('mobile-network').value;
                        var mobileNumber = document.getElementById('mobile-number').value.trim();
                        if (!mobileNetwork) {
                            alert('Please select your mobile network.');
                            return;
                        }
                        if (!mobileNumber) {
                            alert('Please enter your mobile number.');
                            return;
                        }
                    }
                    
                    setupBtn.disabled = true;
                    setupBtn.textContent = 'Setting up...';
                    
                    var fd = new FormData(this);
                    fd.append('action', 'hushot_seller_setup');
                    fd.append('_wpnonce', '<?php echo wp_create_nonce('hushot_seller'); ?>');
                    
                    fetch('<?php echo admin_url('admin-ajax.php'); ?>', {method:'POST', body:fd})
                    .then(function(r){ return r.json(); })
                    .then(function(d){
                        if (d.success) {
                            alert('✅ Payout settings saved successfully!');
                            window.location.reload();
                        } else {
                            alert(d.data && d.data.message ? d.data.message : 'Setup failed. Please try again.');
                            setupBtn.disabled = false;
                            setupBtn.textContent = '🔒 Save & Verify';
                        }
                    }).catch(function(err){
                        console.error('Setup error:', err);
                        alert('Network error. Please try again.');
                        setupBtn.disabled = false;
                        setupBtn.textContent = '🔒 Save & Verify';
                    });
                });
            }
        })();
        </script>
        <?php
        return ob_get_clean();
    }

}
