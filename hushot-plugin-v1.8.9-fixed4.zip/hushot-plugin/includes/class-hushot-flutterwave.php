<?php
if (!defined('ABSPATH')) exit;

class Hushot_Flutterwave {
    
    private static $public_key = '';
    private static $secret_key = '';
    
    // Flutterwave subscription plan IDs
    private static $plan_ids = array(
        'essential' => '152406',
        'premium' => '152407'
    );
    
    public static function init() {
        self::$public_key = get_option('hushot_flutterwave_public_key', '');
        self::$secret_key = get_option('hushot_flutterwave_secret_key', '');
        add_action('init', array(__CLASS__, 'handle_callback'));
        add_action('init', array(__CLASS__, 'handle_ads_callback'));
        add_action('init', array(__CLASS__, 'handle_webhook'));
    }
    
    public static function create_payment($plan, $cycle, $payment_method = 'card', $with_trial = false) {
        $user = wp_get_current_user();
        $plans = Hushot_Membership::get_plans();
        
        if (!isset($plans[$plan])) {
            return new WP_Error('invalid_plan', 'Invalid plan.');
        }
        
        // Get subscription amount from admin settings
        $subscription_amount = 0;
        if ($plan === 'premium') {
            $subscription_amount = floatval(get_option('hushot_subscription_premium', $plans[$plan]['pricing']['yearly'] ?? 9.50));
        } elseif ($plan === 'essential') {
            $subscription_amount = floatval(get_option('hushot_subscription_essential', $plans[$plan]['pricing']['yearly'] ?? 4.70));
        }
        
        // Get trial settings
        $trial_price = floatval(get_option('hushot_trial_price', $plans[$plan]['activation_fee'] ?? 0.14));
        $trial_duration = intval(get_option('hushot_trial_duration', 30));
        
        // For trial, use trial price; for direct purchase, use plan pricing
        $amount_usd = $with_trial ? $trial_price : ($plans[$plan]['pricing'][$cycle] ?? $subscription_amount);
        
        // Ensure amount is valid
        if ($amount_usd <= 0 && !$with_trial) {
            return new WP_Error('free_plan', 'This plan is free.');
        }
        
        // Convert to local currency
        $currency_info = self::convert_usd_to_local($amount_usd);
        $amount_local = max(1, round($currency_info['amount_local'])); // Ensure minimum of 1
        $currency = $currency_info['currency'];
        
        $tx_ref = 'hushot_' . $user->ID . '_' . time();
        
        update_user_meta($user->ID, 'hushot_pending_tx', array(
            'ref' => $tx_ref,
            'plan' => $plan,
            'cycle' => $cycle,
            'amount_usd' => $amount_usd,
            'amount_local' => $amount_local,
            'currency' => $currency,
            'trial' => $with_trial,
            'trial_duration' => $trial_duration,
            'subscription_amount' => $subscription_amount,
            'payment_method' => $payment_method
        ));
        
        $callback_url = add_query_arg(array('hushot_payment' => '1', 'tx_ref' => $tx_ref), home_url());
        
        // If no API keys, demo mode - activate with trial
        if (empty(self::$public_key) || empty(self::$secret_key)) {
            if ($with_trial) {
                self::activate_trial($user->ID, $plan, $cycle, $tx_ref);
            } else {
                self::activate_subscription($user->ID, $plan, $cycle, $tx_ref);
            }
            return add_query_arg('status', 'success', Hushot_Pages::get_page_url('order-confirmation'));
        }
        
        // Payment options based on method
        $payment_options = 'card';
        switch ($payment_method) {
            case 'mobilemoney':
                $payment_options = 'mobilemoneyghana,mobilemoneyuganda,mobilemoneyrwanda,mobilemoneyzambia,mobilemoneytanzania,mpesa';
                break;
            case 'ussd':
                $payment_options = 'ussd,banktransfer';
                break;
            default:
                $payment_options = 'card';
        }
        
        // Build payload
        $payload = array(
            'tx_ref' => $tx_ref,
            'amount' => $amount_local,
            'currency' => $currency,
            'redirect_url' => $callback_url,
            'payment_options' => $payment_options,
            'customer' => array(
                'email' => $user->user_email, 
                'name' => $user->display_name,
                'phonenumber' => get_user_meta($user->ID, 'hushot_phone', true) ?: ''
            ),
            'customizations' => array(
                'title' => 'Hushot ' . ucfirst($plan) . ' Plan',
                'description' => $with_trial ? "{$trial_duration} Day Trial - " . ucfirst($plan) . ' Plan' : ucfirst($plan) . ' Plan Subscription'
            ),
            'meta' => array(
                'plan' => $plan,
                'cycle' => $cycle,
                'trial' => $with_trial ? '1' : '0',
                'user_id' => $user->ID,
                'trial_duration' => $trial_duration
            )
        );
        
        // For subscriptions with trials, create a payment plan for recurring charges
        if ($with_trial && $subscription_amount > 0) {
            // Convert subscription amount to local currency
            $sub_currency_info = self::convert_usd_to_local($subscription_amount);
            $sub_amount_local = max(1, round($sub_currency_info['amount_local']));
            
            // Create or use existing payment plan
            $plan_id = self::get_or_create_payment_plan($plan, $sub_amount_local, $currency);
            if ($plan_id) {
                $payload['payment_plan'] = $plan_id;
            }
        }
        
        $response = wp_remote_post('https://api.flutterwave.com/v3/payments', array(
            'headers' => array(
                'Authorization' => 'Bearer ' . self::$secret_key,
                'Content-Type' => 'application/json',
            ),
            'body' => json_encode($payload),
            'timeout' => 30,
        ));
        
        if (is_wp_error($response)) return $response;
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if (isset($body['status']) && $body['status'] === 'success' && !empty($body['data']['link'])) {
            return $body['data']['link'];
        }
        
        // Log error for debugging
        error_log('Flutterwave Payment Error: ' . print_r($body, true));
        
        return new WP_Error('payment_error', $body['message'] ?? 'Payment failed. Please try again.');
    }
    
    /**
     * Get or create a Flutterwave payment plan for recurring subscriptions
     */
    public static function get_or_create_payment_plan($plan_name, $amount, $currency) {
        $plan_key = 'hushot_fw_plan_' . $plan_name . '_' . $currency;
        $existing_plan = get_option($plan_key);
        
        if ($existing_plan) {
            return $existing_plan;
        }
        
        // Create new payment plan
        $payload = array(
            'amount' => $amount,
            'name' => 'Hushot ' . ucfirst($plan_name) . ' Monthly',
            'interval' => 'monthly',
            'currency' => $currency
        );
        
        $response = wp_remote_post('https://api.flutterwave.com/v3/payment-plans', array(
            'headers' => array(
                'Authorization' => 'Bearer ' . self::$secret_key,
                'Content-Type' => 'application/json',
            ),
            'body' => json_encode($payload),
            'timeout' => 30,
        ));
        
        if (is_wp_error($response)) {
            return null;
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if (isset($body['status']) && $body['status'] === 'success' && !empty($body['data']['id'])) {
            update_option($plan_key, $body['data']['id']);
            return $body['data']['id'];
        }
        
        return null;
    }
    
    public static function handle_callback() {
        if (empty($_GET['hushot_payment']) || empty($_GET['tx_ref'])) return;
        
        $tx_ref = sanitize_text_field($_GET['tx_ref']);
        $status = sanitize_text_field($_GET['status'] ?? '');
        $transaction_id = sanitize_text_field($_GET['transaction_id'] ?? '');
        
        $users = get_users(array('meta_key' => 'hushot_pending_tx', 'meta_compare' => 'EXISTS'));
        $matched_user = null;
        $tx_data = null;
        
        foreach ($users as $user) {
            $pending = get_user_meta($user->ID, 'hushot_pending_tx', true);
            if ($pending && $pending['ref'] === $tx_ref) {
                $matched_user = $user;
                $tx_data = $pending;
                break;
            }
        }
        
        if (!$matched_user || !$tx_data) {
            wp_redirect(add_query_arg('status', 'failed', Hushot_Pages::get_page_url('order-confirmation')));
            exit;
        }
        
        // Verify transaction with Flutterwave
        $verified = self::verify_transaction($transaction_id);
        
        if ($status === 'successful' || $status === 'success' || $verified) {
            if (!empty($tx_data['trial'])) {
                self::activate_trial($matched_user->ID, $tx_data['plan'], $tx_data['cycle'], $tx_ref);
            } else {
                self::activate_subscription($matched_user->ID, $tx_data['plan'], $tx_data['cycle'], $tx_ref);
            }
            delete_user_meta($matched_user->ID, 'hushot_pending_tx');
            wp_redirect(add_query_arg('status', 'success', Hushot_Pages::get_page_url('order-confirmation')));
            exit;
        }
        
        wp_redirect(add_query_arg('status', 'failed', Hushot_Pages::get_page_url('order-confirmation')));
        exit;
    }
    
    public static function handle_webhook() {
        if (empty($_GET['hushot_webhook'])) return;
        
        $payload = file_get_contents('php://input');
        $data = json_decode($payload, true);
        
        if (!$data || !isset($data['event'])) {
            wp_send_json_error('Invalid webhook');
        }
        
        if ($data['event'] === 'charge.completed' && isset($data['data']['tx_ref'])) {
            $tx_ref = $data['data']['tx_ref'];
            if (strpos($tx_ref, 'hushot_') === 0) {
                $parts = explode('_', $tx_ref);
                if (isset($parts[1])) {
                    $user_id = intval($parts[1]);
                    $pending = get_user_meta($user_id, 'hushot_pending_tx', true);
                    if ($pending && $pending['ref'] === $tx_ref) {
                        if (!empty($pending['trial'])) {
                            self::activate_trial($user_id, $pending['plan'], $pending['cycle'], $tx_ref);
                        } else {
                            self::activate_subscription($user_id, $pending['plan'], $pending['cycle'], $tx_ref);
                        }
                        delete_user_meta($user_id, 'hushot_pending_tx');
                    }
                }
            }
        }
        
        wp_send_json_success('Webhook processed');
    }
    
    public static function verify_transaction($transaction_id) {
        if (empty($transaction_id) || empty(self::$secret_key)) {
            return false;
        }
        
        $response = wp_remote_get('https://api.flutterwave.com/v3/transactions/' . $transaction_id . '/verify', array(
            'headers' => array(
                'Authorization' => 'Bearer ' . self::$secret_key,
            ),
            'timeout' => 30,
        ));
        
        if (is_wp_error($response)) return false;
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        return isset($body['status']) && $body['status'] === 'success' && 
               isset($body['data']['status']) && $body['data']['status'] === 'successful';
    }
    
    public static function activate_trial($user_id, $plan, $cycle, $payment_ref) {
        global $wpdb;
        
        $wpdb->update($wpdb->prefix . 'hushot_subscriptions', array('status' => 'cancelled'), array('user_id' => $user_id, 'status' => 'active'));
        $wpdb->update($wpdb->prefix . 'hushot_trials', array('status' => 'cancelled'), array('user_id' => $user_id, 'status' => 'active'));
        
        update_user_meta($user_id, 'hushot_used_trial', '1');
        
        $trial_end = date('Y-m-d H:i:s', strtotime('+1 month'));
        
        $wpdb->insert($wpdb->prefix . 'hushot_trials', array(
            'user_id' => $user_id,
            'plan' => $plan,
            'cycle' => $cycle,
            'status' => 'active',
            'expires_at' => $trial_end,
            'payment_ref' => $payment_ref,
        ));
        
        update_user_meta($user_id, 'hushot_plan', $plan);
        update_user_meta($user_id, 'hushot_plan_expiry', $trial_end);
        update_user_meta($user_id, 'hushot_is_trial', '1');
    }
    
    public static function activate_subscription($user_id, $plan, $cycle, $payment_ref) {
        global $wpdb;
        
        $wpdb->update($wpdb->prefix . 'hushot_subscriptions', array('status' => 'cancelled'), array('user_id' => $user_id, 'status' => 'active'));
        $wpdb->update($wpdb->prefix . 'hushot_trials', array('status' => 'cancelled'), array('user_id' => $user_id, 'status' => 'active'));
        
        $plans = Hushot_Membership::get_plans();
        $amount = $plans[$plan]['pricing'][$cycle] ?? 0;
        
        $next_payment = null;
        switch ($cycle) {
            case 'monthly': $next_payment = date('Y-m-d H:i:s', strtotime('+1 month')); break;
            case 'quarterly': $next_payment = date('Y-m-d H:i:s', strtotime('+3 months')); break;
            case 'yearly': $next_payment = date('Y-m-d H:i:s', strtotime('+1 year')); break;
        }
        
        $wpdb->insert($wpdb->prefix . 'hushot_subscriptions', array(
            'user_id' => $user_id,
            'plan' => $plan,
            'cycle' => $cycle,
            'amount' => $amount,
            'currency' => 'NGN',
            'status' => 'active',
            'payment_ref' => $payment_ref,
            'next_payment' => $next_payment,
        ));
        
        delete_user_meta($user_id, 'hushot_is_trial');
        
        Hushot_Membership::set_user_plan($user_id, $plan);
    }
    
    /**
     * Get user's country from various sources
     */
    public static function detect_user_country() {
        // Try geo-location first
        $country = self::get_country_from_ip();
        if ($country) return $country;
        
        // Fallback to user meta
        $user_id = get_current_user_id();
        if ($user_id) {
            $saved_country = get_user_meta($user_id, 'hushot_country', true);
            if ($saved_country) return $saved_country;
        }
        
        // Default to Nigeria
        return 'NG';
    }
    
    /**
     * Get country from IP address
     */
    private static function get_country_from_ip() {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? '';
        if (!$ip || $ip === '127.0.0.1' || strpos($ip, '192.168.') === 0) {
            return null;
        }
        
        // Try IP geolocation API (free tier)
        $response = wp_remote_get('http://ip-api.com/json/' . $ip . '?fields=countryCode', array('timeout' => 5));
        if (!is_wp_error($response)) {
            $body = json_decode(wp_remote_retrieve_body($response), true);
            if (!empty($body['countryCode'])) {
                return $body['countryCode'];
            }
        }
        
        return null;
    }
    
    /**
     * Get currency for country
     */
    public static function get_currency_for_country($country_code) {
        $currencies = array(
            'NG' => 'NGN', 'GH' => 'GHS', 'KE' => 'KES', 'ZA' => 'ZAR',
            'TZ' => 'TZS', 'UG' => 'UGX', 'RW' => 'RWF', 'ET' => 'ETB',
            'EG' => 'EGP', 'MA' => 'MAD', 'SN' => 'XOF', 'CI' => 'XOF',
            'CM' => 'XAF', 'ZM' => 'ZMW', 'ZW' => 'USD', 'BW' => 'BWP',
            'MU' => 'MUR', 'AO' => 'AOA', 'US' => 'USD', 'GB' => 'GBP',
            'EU' => 'EUR'
        );
        return $currencies[$country_code] ?? 'USD';
    }
    
    /**
     * Get exchange rate from USD to target currency
     */
    public static function get_exchange_rate($target_currency) {
        if ($target_currency === 'USD') {
            return 1.0;
        }
        
        // ALWAYS USE RELIABLE FALLBACK RATES - API is unreliable
        $fallback_rates = array(
            'NGN' => 1600.00, 'GHS' => 15.50, 'KES' => 153.00, 'ZAR' => 18.50,
            'TZS' => 2650.00, 'UGX' => 3800.00, 'RWF' => 1350.00, 'ETB' => 130.00,
            'EGP' => 50.00, 'MAD' => 10.00, 'XOF' => 615.00, 'XAF' => 615.00,
            'ZMW' => 27.00, 'BWP' => 13.50, 'MUR' => 46.00, 'AOA' => 830.00,
            'GBP' => 0.79, 'EUR' => 0.92
        );
        
        // Return fallback rate directly - this is reliable
        return isset($fallback_rates[$target_currency]) ? $fallback_rates[$target_currency] : 1.0;
    }
    
    /**
     * Convert USD amount to local currency
     */
    public static function convert_usd_to_local($amount_usd, $country_code = null) {
        if (!$country_code) {
            $country_code = self::detect_user_country();
        }
        
        $currency = self::get_currency_for_country($country_code);
        $rate = self::get_exchange_rate($currency);
        $amount_local = round($amount_usd * $rate, 2);
        
        return array(
            'amount_usd' => $amount_usd,
            'amount_local' => $amount_local,
            'currency' => $currency,
            'exchange_rate' => $rate,
            'country' => $country_code
        );
    }
    
    /**
     * Get currency symbol
     */
    public static function get_currency_symbol($currency) {
        $symbols = array(
            'USD' => '$', 'NGN' => '₦', 'GHS' => '₵', 'KES' => 'KSh',
            'ZAR' => 'R', 'TZS' => 'TSh', 'UGX' => 'USh', 'RWF' => 'RF',
            'ETB' => 'Br', 'EGP' => '£E', 'MAD' => 'DH', 'XOF' => 'CFA',
            'XAF' => 'FCFA', 'ZMW' => 'ZK', 'BWP' => 'P', 'MUR' => '₨',
            'AOA' => 'Kz', 'GBP' => '£', 'EUR' => '€'
        );
        return $symbols[$currency] ?? $currency;
    }
    
    /**
     * Create payment for ad boost
     */
    public static function create_ads_payment($product_id, $amount_local, $currency, $payment_method = 'card') {
        $user = wp_get_current_user();
        
        if (!$user->ID || $amount_local <= 0) {
            return new WP_Error('invalid_request', 'Invalid payment request.');
        }
        
        $tx_ref = 'hushot_ads_' . $user->ID . '_' . $product_id . '_' . time();
        
        // Store pending ad payment
        update_user_meta($user->ID, 'hushot_pending_ads_tx', array(
            'ref' => $tx_ref,
            'product_id' => $product_id,
            'amount' => $amount_local,
            'currency' => $currency,
            'payment_method' => $payment_method
        ));
        
        $callback_url = add_query_arg(array('hushot_ads_payment' => '1', 'tx_ref' => $tx_ref), home_url());
        
        // If no API keys, demo mode - activate directly
        if (empty(self::$public_key) || empty(self::$secret_key)) {
            self::activate_ads_product($user->ID, $product_id, $tx_ref);
            return add_query_arg('status', 'success', Hushot_Pages::get_page_url('ads-dashboard'));
        }
        
        // Payment options based on method
        $payment_options = 'card';
        switch ($payment_method) {
            case 'mobilemoney':
                $payment_options = 'mobilemoneyghana,mobilemoneyuganda,mobilemoneyrwanda,mobilemoneyzambia,mobilemoneytanzania,mpesa';
                break;
            case 'ussd':
                $payment_options = 'ussd,banktransfer';
                break;
            default:
                $payment_options = 'card';
        }
        
        $payload = array(
            'tx_ref' => $tx_ref,
            'amount' => $amount_local,
            'currency' => $currency,
            'redirect_url' => $callback_url,
            'payment_options' => $payment_options,
            'customer' => array(
                'email' => $user->user_email, 
                'name' => $user->display_name,
                'phonenumber' => get_user_meta($user->ID, 'hushot_phone', true) ?: ''
            ),
            'customizations' => array(
                'title' => 'Hushot Ads Boost',
                'description' => 'Ad Boost Campaign Payment'
            ),
            'meta' => array(
                'product_id' => $product_id,
                'user_id' => $user->ID,
                'type' => 'ads_boost'
            )
        );
        
        $response = wp_remote_post('https://api.flutterwave.com/v3/payments', array(
            'headers' => array(
                'Authorization' => 'Bearer ' . self::$secret_key,
                'Content-Type' => 'application/json',
            ),
            'body' => json_encode($payload),
            'timeout' => 30,
        ));
        
        if (is_wp_error($response)) return $response;
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if (isset($body['status']) && $body['status'] === 'success' && !empty($body['data']['link'])) {
            return $body['data']['link'];
        }
        
        return new WP_Error('payment_error', $body['message'] ?? 'Payment failed. Please try again.');
    }
    
    /**
     * Handle ads payment callback
     */
    public static function handle_ads_callback() {
        if (empty($_GET['hushot_ads_payment']) || empty($_GET['tx_ref'])) return;
        
        $tx_ref = sanitize_text_field($_GET['tx_ref']);
        $status = sanitize_text_field($_GET['status'] ?? '');
        $transaction_id = sanitize_text_field($_GET['transaction_id'] ?? '');
        
        // Find user with pending ads tx
        $users = get_users(array('meta_key' => 'hushot_pending_ads_tx', 'meta_compare' => 'EXISTS'));
        $matched_user = null;
        $tx_data = null;
        
        foreach ($users as $user) {
            $pending = get_user_meta($user->ID, 'hushot_pending_ads_tx', true);
            if ($pending && $pending['ref'] === $tx_ref) {
                $matched_user = $user;
                $tx_data = $pending;
                break;
            }
        }
        
        if (!$matched_user || !$tx_data) {
            wp_redirect(add_query_arg('status', 'failed', Hushot_Pages::get_page_url('ads-dashboard')));
            exit;
        }
        
        // Verify transaction with Flutterwave
        $verified = self::verify_transaction($transaction_id);
        
        if ($status === 'successful' || $status === 'success' || $verified) {
            self::activate_ads_product($matched_user->ID, $tx_data['product_id'], $tx_ref);
            delete_user_meta($matched_user->ID, 'hushot_pending_ads_tx');
            wp_redirect(add_query_arg('status', 'success', Hushot_Pages::get_page_url('ads-dashboard')));
            exit;
        }
        
        wp_redirect(add_query_arg('status', 'failed', Hushot_Pages::get_page_url('ads-dashboard')));
        exit;
    }
    
    /**
     * Activate ads product after payment
     */
    public static function activate_ads_product($user_id, $product_id, $payment_ref) {
        global $wpdb;
        
        // Get product
        $product = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}hushot_ads_catalog WHERE id = %d AND user_id = %d",
            $product_id, $user_id
        ));
        
        if (!$product) return false;
        
        // Get duration days from Hushot_Ads durations
        $duration = $product->duration ?: '1week';
        $durations = array(
            '1week' => 7,
            '1month' => 30,
            '3months' => 90
        );
        $duration_days = $durations[$duration] ?? 7;
        
        // Calculate start/end dates
        $start_date = current_time('mysql');
        $end_date = date('Y-m-d H:i:s', strtotime("+{$duration_days} days"));
        
        // Update to pending for moderation
        $wpdb->update(
            $wpdb->prefix . 'hushot_ads_catalog',
            array(
                'status' => 'pending',
                'start_date' => $start_date,
                'end_date' => $end_date,
                'payment_ref' => $payment_ref
            ),
            array('id' => $product_id),
            array('%s', '%s', '%s', '%s'),
            array('%d')
        );
        
        // Run AI moderation for instant approval/rejection
        if (class_exists('Hushot_Ads_AI')) {
            Hushot_Ads_AI::moderate_product($product_id);
        } else {
            // No AI moderation - auto approve
            $wpdb->update(
                $wpdb->prefix . 'hushot_ads_catalog',
                array('status' => 'active'),
                array('id' => $product_id)
            );
        }
        
        return true;
    }
}
