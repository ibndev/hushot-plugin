<?php
if (!defined('ABSPATH')) exit;

class Hushot_Database {
    
    public static function create_tables() {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        
        // Memberships
        dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}hushot_memberships (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            user_id bigint(20) NOT NULL,
            plan varchar(50) NOT NULL DEFAULT 'free',
            status varchar(20) NOT NULL DEFAULT 'active',
            started_at datetime DEFAULT CURRENT_TIMESTAMP,
            expires_at datetime DEFAULT NULL,
            PRIMARY KEY (id),
            KEY user_id (user_id)
        ) $charset;");
        
        // Trials
        dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}hushot_trials (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            user_id bigint(20) NOT NULL,
            plan varchar(50) NOT NULL,
            cycle varchar(20) NOT NULL DEFAULT 'monthly',
            started_at datetime DEFAULT CURRENT_TIMESTAMP,
            expires_at datetime NOT NULL,
            status varchar(20) NOT NULL DEFAULT 'active',
            payment_ref varchar(100) DEFAULT NULL,
            PRIMARY KEY (id),
            KEY user_id (user_id)
        ) $charset;");
        
        // Subscriptions
        dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}hushot_subscriptions (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            user_id bigint(20) NOT NULL,
            plan varchar(50) NOT NULL,
            cycle varchar(20) NOT NULL DEFAULT 'monthly',
            amount decimal(10,2) NOT NULL,
            currency varchar(10) NOT NULL DEFAULT 'NGN',
            status varchar(20) NOT NULL DEFAULT 'active',
            payment_ref varchar(100) DEFAULT NULL,
            started_at datetime DEFAULT CURRENT_TIMESTAMP,
            next_payment datetime DEFAULT NULL,
            PRIMARY KEY (id),
            KEY user_id (user_id)
        ) $charset;");
        
        // Button clicks
        dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}hushot_clicks (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            page_id bigint(20) NOT NULL,
            button_type varchar(50) NOT NULL,
            clicked_at datetime DEFAULT CURRENT_TIMESTAMP,
            ip_address varchar(45) DEFAULT NULL,
            PRIMARY KEY (id),
            KEY page_id (page_id)
        ) $charset;");
        
        // AI generations
        dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}hushot_ai (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            user_id bigint(20) NOT NULL,
            business_type varchar(100) DEFAULT NULL,
            content longtext DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            month_year varchar(7) NOT NULL,
            PRIMARY KEY (id),
            KEY user_id (user_id)
        ) $charset;");
        
        // Analytics daily
        dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}hushot_analytics (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            page_id bigint(20) NOT NULL,
            date_recorded date NOT NULL,
            views int(11) NOT NULL DEFAULT 0,
            clicks int(11) NOT NULL DEFAULT 0,
            PRIMARY KEY (id),
            UNIQUE KEY page_date (page_id, date_recorded)
        ) $charset;");
        
        // Leads
        dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}hushot_leads (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            page_id bigint(20) NOT NULL,
            user_id bigint(20) NOT NULL,
            name varchar(100) NOT NULL,
            email varchar(100) DEFAULT NULL,
            phone varchar(50) NOT NULL,
            message text DEFAULT NULL,
            status varchar(20) DEFAULT 'new',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY page_id (page_id),
            KEY user_id (user_id)
        ) $charset;");
        
        // Marketplace Transactions
        dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}hushot_marketplace_transactions (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            tx_ref varchar(100) NOT NULL UNIQUE,
            flw_ref varchar(100) DEFAULT NULL,
            seller_id bigint(20) NOT NULL,
            page_id bigint(20) NOT NULL,
            product_name varchar(255) NOT NULL,
            customer_email varchar(100) NOT NULL,
            customer_name varchar(100) DEFAULT NULL,
            customer_phone varchar(50) DEFAULT NULL,
            amount decimal(15,2) NOT NULL,
            commission decimal(15,2) NOT NULL,
            currency varchar(10) NOT NULL DEFAULT 'NGN',
            status varchar(20) NOT NULL DEFAULT 'pending',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            completed_at datetime DEFAULT NULL,
            PRIMARY KEY (id),
            KEY seller_id (seller_id),
            KEY page_id (page_id),
            KEY status (status),
            KEY tx_ref (tx_ref)
        ) $charset;");
        
        // ==========================================
        // ADS NETWORK TABLES (Self-contained module)
        // ==========================================
        
        // Ads Catalog - Central product catalog for all advertisers
        dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}hushot_ads_catalog (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            user_id bigint(20) NOT NULL,
            page_id bigint(20) DEFAULT NULL,
            business_name varchar(255) NOT NULL,
            product_name varchar(255) NOT NULL,
            product_description text,
            product_image_url varchar(500) DEFAULT NULL,
            price decimal(15,2) DEFAULT NULL,
            currency varchar(10) DEFAULT 'USD',
            landing_page_url varchar(500) NOT NULL,
            country varchar(5) NOT NULL,
            state varchar(100) DEFAULT NULL,
            additional_countries text,
            category varchar(50) NOT NULL DEFAULT 'other',
            gender varchar(10) NOT NULL DEFAULT 'all',
            duration varchar(20) NOT NULL DEFAULT '1week',
            start_date datetime DEFAULT NULL,
            end_date datetime DEFAULT NULL,
            daily_budget decimal(10,2) DEFAULT 0,
            total_budget decimal(10,2) DEFAULT 0,
            spent decimal(10,2) DEFAULT 0,
            impressions bigint(20) DEFAULT 0,
            clicks bigint(20) DEFAULT 0,
            landing_page_views bigint(20) DEFAULT 0,
            whatsapp_clicks bigint(20) DEFAULT 0,
            cta_clicks bigint(20) DEFAULT 0,
            status varchar(20) NOT NULL DEFAULT 'pending',
            rejection_reason text,
            ai_moderation_score decimal(3,2) DEFAULT NULL,
            ai_moderation_notes text,
            meta_product_id varchar(100) DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY user_id (user_id),
            KEY page_id (page_id),
            KEY status (status),
            KEY country (country),
            KEY category (category),
            KEY end_date (end_date)
        ) $charset;");
        
        // MIGRATION: Add gender column if it doesn't exist (for existing installs)
        $table_name = $wpdb->prefix . 'hushot_ads_catalog';
        $column_exists = $wpdb->get_results("SHOW COLUMNS FROM {$table_name} LIKE 'gender'");
        if (empty($column_exists)) {
            $wpdb->query("ALTER TABLE {$table_name} ADD COLUMN gender varchar(10) NOT NULL DEFAULT 'all' AFTER category");
        }
        
        // MIGRATION: Add payment_ref column if it doesn't exist
        $payment_ref_exists = $wpdb->get_results("SHOW COLUMNS FROM {$table_name} LIKE 'payment_ref'");
        if (empty($payment_ref_exists)) {
            $wpdb->query("ALTER TABLE {$table_name} ADD COLUMN payment_ref varchar(100) DEFAULT NULL AFTER rejection_reason");
        }
        
        // Ads Campaigns - Shared campaigns by country/category
        dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}hushot_ads_campaigns (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            campaign_name varchar(255) NOT NULL,
            campaign_type varchar(50) DEFAULT 'carousel',
            country varchar(5) NOT NULL,
            state varchar(100) DEFAULT NULL,
            category varchar(50) DEFAULT NULL,
            meta_campaign_id varchar(100) DEFAULT NULL,
            meta_adset_id varchar(100) DEFAULT NULL,
            daily_budget decimal(10,2) DEFAULT 0,
            total_spent decimal(10,2) DEFAULT 0,
            status varchar(20) DEFAULT 'active',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY country (country),
            KEY status (status)
        ) $charset;");
        
        // Campaign-Product mapping for rotation
        dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}hushot_ads_campaign_products (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            campaign_id bigint(20) NOT NULL,
            product_id bigint(20) NOT NULL,
            weight decimal(5,2) DEFAULT 1.00,
            rotation_order int DEFAULT 0,
            added_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY campaign_id (campaign_id),
            KEY product_id (product_id),
            UNIQUE KEY campaign_product (campaign_id, product_id)
        ) $charset;");
        
        // Ads Daily Stats for detailed tracking
        dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}hushot_ads_stats (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            product_id bigint(20) NOT NULL,
            stat_date date NOT NULL,
            impressions int DEFAULT 0,
            clicks int DEFAULT 0,
            landing_page_views int DEFAULT 0,
            whatsapp_clicks int DEFAULT 0,
            cta_clicks int DEFAULT 0,
            spent decimal(10,2) DEFAULT 0,
            PRIMARY KEY (id),
            UNIQUE KEY product_date (product_id, stat_date),
            KEY stat_date (stat_date)
        ) $charset;");
        
        // Ads Transactions for payment tracking
        dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}hushot_ads_transactions (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            user_id bigint(20) NOT NULL,
            product_id bigint(20) DEFAULT NULL,
            amount_usd decimal(10,2) NOT NULL,
            amount_local decimal(15,2) DEFAULT NULL,
            currency_local varchar(10) DEFAULT NULL,
            exchange_rate decimal(15,6) DEFAULT NULL,
            type varchar(20) NOT NULL,
            status varchar(20) DEFAULT 'pending',
            payment_ref varchar(100) DEFAULT NULL,
            notes text,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY user_id (user_id),
            KEY product_id (product_id)
        ) $charset;");
    }
    
    public static function get_user_stats($user_id) {
        global $wpdb;
        
        $pages = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'hushot_page' AND post_author = %d AND post_status = 'publish'",
            $user_id
        ));
        
        $page_ids = $wpdb->get_col($wpdb->prepare(
            "SELECT ID FROM {$wpdb->posts} WHERE post_type = 'hushot_page' AND post_author = %d AND post_status = 'publish'",
            $user_id
        ));
        
        $views = 0;
        $clicks = 0;
        $leads = 0;
        
        if (!empty($page_ids)) {
            foreach ($page_ids as $pid) {
                $views += (int) get_post_meta($pid, '_hushot_views', true);
            }
            $clicks = $wpdb->get_var(
                "SELECT COUNT(*) FROM {$wpdb->prefix}hushot_clicks WHERE page_id IN (" . implode(',', array_map('intval', $page_ids)) . ")"
            );
        }
        
        $leads = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}hushot_leads WHERE user_id = %d",
            $user_id
        ));
        
        return array('pages' => (int)$pages, 'views' => (int)$views, 'clicks' => (int)$clicks, 'leads' => (int)$leads);
    }
    
    public static function get_user_pages($user_id, $limit = -1) {
        return get_posts(array(
            'post_type' => 'hushot_page',
            'post_status' => 'publish',
            'author' => $user_id,
            'posts_per_page' => $limit,
            'orderby' => 'date',
            'order' => 'DESC',
        ));
    }
    
    public static function record_click($page_id, $button_type) {
        global $wpdb;
        $wpdb->insert($wpdb->prefix . 'hushot_clicks', array(
            'page_id' => $page_id,
            'button_type' => $button_type,
            'ip_address' => $_SERVER['REMOTE_ADDR'] ?? '',
        ));
        $clicks = (int) get_post_meta($page_id, '_hushot_clicks', true);
        update_post_meta($page_id, '_hushot_clicks', $clicks + 1);
        
        // Update daily analytics
        $today = date('Y-m-d');
        $existing = $wpdb->get_row($wpdb->prepare(
            "SELECT id, clicks FROM {$wpdb->prefix}hushot_analytics WHERE page_id = %d AND date_recorded = %s",
            $page_id, $today
        ));
        
        if ($existing) {
            $wpdb->update($wpdb->prefix . 'hushot_analytics', 
                array('clicks' => $existing->clicks + 1),
                array('id' => $existing->id)
            );
        } else {
            $wpdb->insert($wpdb->prefix . 'hushot_analytics', array(
                'page_id' => $page_id,
                'date_recorded' => $today,
                'clicks' => 1,
            ));
        }
    }
    
    public static function get_analytics($user_id, $days = 30) {
        global $wpdb;
        
        $page_ids = $wpdb->get_col($wpdb->prepare(
            "SELECT ID FROM {$wpdb->posts} WHERE post_type = 'hushot_page' AND post_author = %d",
            $user_id
        ));
        
        if (empty($page_ids)) return array();
        
        $start_date = date('Y-m-d', strtotime("-{$days} days"));
        
        return $wpdb->get_results($wpdb->prepare(
            "SELECT date_recorded, SUM(views) as views, SUM(clicks) as clicks 
             FROM {$wpdb->prefix}hushot_analytics 
             WHERE page_id IN (" . implode(',', array_map('intval', $page_ids)) . ") 
             AND date_recorded >= %s 
             GROUP BY date_recorded 
             ORDER BY date_recorded ASC",
            $start_date
        ));
    }
}
