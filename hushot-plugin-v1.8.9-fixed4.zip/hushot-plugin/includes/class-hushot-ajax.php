<?php
/**
 * Hushot AJAX Handler v1.0.5 - FIXED
 * Login/Register working properly
 */
if (!defined('ABSPATH')) exit;

class Hushot_Ajax {
    
    public static function init() {
        $actions = array(
            'hushot_login', 'hushot_register', 'hushot_forgot_password',
            'hushot_create_page', 'hushot_update_page', 'hushot_delete_page', 'hushot_duplicate_page',
            'hushot_use_template', 'hushot_update_profile', 'hushot_generate_ai',
            'hushot_checkout', 'hushot_cancel_subscription', 'hushot_track_click',
            'hushot_upload_image', 'hushot_upload_video', 'hushot_upload_ebook', 'hushot_submit_lead', 'hushot_save_openai_key',
            'hushot_preview_page', 'hushot_export_leads', 'hushot_save_products_template', 'hushot_get_products_templates',
            'hushot_send_otp', 'hushot_reset_password', 'hushot_get_currency', 'hushot_ai_generate_page',
            'hushot_track_install', 'hushot_ai_generate_image',
            'hushot_visual_save', 'hushot_crawl_website', 'hushot_publish_page',
            // Marketplace & AI Image
            'hushot_generate_ai_image', 'hushot_seller_setup', 'hushot_verify_account', 'hushot_get_banks',
            'hushot_marketplace_checkout', 'hushot_flw_webhook'
        );
        
        foreach ($actions as $action) {
            $handler = str_replace('hushot_', 'handle_', $action);
            add_action('wp_ajax_' . $action, array(__CLASS__, $handler));
            add_action('wp_ajax_nopriv_' . $action, array(__CLASS__, $handler));
        }
    }
    
    // GET CURRENCY INFO
    public static function handle_get_currency() {
        $currency_info = Hushot_Flutterwave::convert_usd_to_local(1);
        wp_send_json_success($currency_info);
    }
    
    // LOGIN - FIXED: accepts 'login' field (email or username)
    public static function handle_login() {
        // Get the login field - can be email, username, or phone
        $login = sanitize_text_field($_POST['login'] ?? $_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        $remember = !empty($_POST['remember']);
        
        if (empty($login) || empty($password)) {
            wp_send_json_error(array('message' => 'Please enter your email/phone and password.'));
        }
        
        // Check if it's an email
        if (is_email($login)) {
            $user = get_user_by('email', $login);
            if ($user) {
                $login = $user->user_login;
            }
        }
        
        // Attempt login
        $creds = array(
            'user_login'    => $login,
            'user_password' => $password,
            'remember'      => $remember
        );
        
        $user = wp_signon($creds, is_ssl());
        
        if (is_wp_error($user)) {
            wp_send_json_error(array('message' => 'Invalid email/phone or password.'));
        }
        
        wp_send_json_success(array(
            'message' => 'Login successful!',
            'redirect' => Hushot_Pages::get_page_url('dashboard')
        ));
    }
    
    // REGISTER - WITH OTP VERIFICATION
    public static function handle_register() {
        $email = sanitize_email($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        $first_name = sanitize_text_field($_POST['first_name'] ?? '');
        $last_name = sanitize_text_field($_POST['last_name'] ?? '');
        $business_name = sanitize_text_field($_POST['business_name'] ?? '');
        $phone = sanitize_text_field($_POST['phone'] ?? '');
        $otp = sanitize_text_field($_POST['otp'] ?? '');
        $otp_token = sanitize_text_field($_POST['otp_token'] ?? '');
        
        // Clean phone
        $phone = preg_replace('/[^0-9+]/', '', $phone);
        
        if (empty($email) || empty($password) || empty($first_name)) {
            wp_send_json_error(array('message' => 'Please fill in all required fields.'));
        }
        
        if (!is_email($email)) {
            wp_send_json_error(array('message' => 'Please enter a valid email address.'));
        }
        
        if (strlen($password) < 6) {
            wp_send_json_error(array('message' => 'Password must be at least 6 characters.'));
        }
        
        if (email_exists($email)) {
            wp_send_json_error(array('message' => 'This email is already registered. Please login instead.'));
        }
        
        // Verify OTP
        if (empty($otp) || empty($otp_token)) {
            wp_send_json_error(array('message' => 'OTP verification required.'));
        }
        
        $stored_otp = get_transient('hushot_otp_' . $otp_token);
        if (!$stored_otp || $stored_otp['code'] !== $otp || $stored_otp['email'] !== $email) {
            wp_send_json_error(array('message' => 'Invalid or expired verification code.'));
        }
        
        // Delete used OTP
        delete_transient('hushot_otp_' . $otp_token);
        
        // Create the user
        $user_id = wp_create_user($email, $password, $email);
        
        if (is_wp_error($user_id)) {
            wp_send_json_error(array('message' => $user_id->get_error_message()));
        }
        
        // Update user info
        wp_update_user(array(
            'ID' => $user_id,
            'first_name' => $first_name,
            'last_name' => $last_name,
            'display_name' => trim($first_name . ' ' . $last_name)
        ));
        
        // Save meta
        if ($business_name) {
            update_user_meta($user_id, 'hushot_business_name', $business_name);
        }
        if ($phone) {
            update_user_meta($user_id, 'hushot_phone', $phone);
            update_user_meta($user_id, 'hushot_whatsapp', $phone);
        }
        
        // Mark as verified
        update_user_meta($user_id, 'hushot_email_verified', 1);
        
        // Start trial
        Hushot_Membership::start_trial($user_id);
        
        // Auto login
        wp_set_current_user($user_id);
        wp_set_auth_cookie($user_id, true);
        
        wp_send_json_success(array(
            'message' => 'Account created successfully!',
            'redirect' => Hushot_Pages::get_page_url('dashboard')
        ));
    }
    
    // SEND OTP FOR VERIFICATION
    public static function handle_send_otp() {
        $email = sanitize_email($_POST['email'] ?? '');
        $phone = sanitize_text_field($_POST['phone'] ?? '');
        
        if (empty($email)) {
            wp_send_json_error(array('message' => 'Email address is required.'));
        }
        
        if (!is_email($email)) {
            wp_send_json_error(array('message' => 'Please enter a valid email.'));
        }
        
        // Check if email already exists
        if (email_exists($email)) {
            wp_send_json_error(array('message' => 'This email is already registered.'));
        }
        
        // Generate 6-digit OTP
        $otp_code = str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);
        $otp_token = wp_generate_password(32, false);
        
        // Store OTP with 10 min expiry
        set_transient('hushot_otp_' . $otp_token, array(
            'code' => $otp_code,
            'email' => $email,
            'phone' => $phone,
            'created' => time()
        ), 600);
        
        // Send via email (primary method)
        $sent = false;
        $subject = 'Your Hushot Verification Code: ' . $otp_code;
        $message = '<!DOCTYPE html><html><body style="font-family:-apple-system,BlinkMacSystemFont,sans-serif;background:#f5f5f5;padding:40px 20px;">';
        $message .= '<div style="max-width:400px;margin:0 auto;background:#fff;border-radius:16px;padding:40px;box-shadow:0 4px 20px rgba(0,0,0,0.1);">';
        $message .= '<div style="text-align:center;margin-bottom:24px;font-size:40px;">🔐</div>';
        $message .= '<h1 style="text-align:center;font-size:24px;color:#1a1a2e;margin-bottom:8px;">Verify Your Email</h1>';
        $message .= '<p style="text-align:center;color:#666;margin-bottom:32px;">Enter this code to complete your registration:</p>';
        $message .= '<div style="background:linear-gradient(135deg,#FF553E,#ff7b5a);color:#fff;font-size:32px;font-weight:700;letter-spacing:8px;text-align:center;padding:20px;border-radius:12px;margin-bottom:24px;">' . $otp_code . '</div>';
        $message .= '<p style="text-align:center;color:#999;font-size:13px;">This code expires in 10 minutes.</p>';
        $message .= '<p style="text-align:center;color:#999;font-size:12px;margin-top:20px;">If you didn\'t request this code, please ignore this email.</p>';
        $message .= '</div></body></html>';
        
        $headers = array('Content-Type: text/html; charset=UTF-8');
        $sent = wp_mail($email, $subject, $message, $headers);
        
        if (!$sent) {
            // Log error but don't fail - demo mode
            error_log('Hushot OTP email failed to send to: ' . $email);
        }
        
        wp_send_json_success(array(
            'message' => 'Verification code sent to ' . $email,
            'token' => $otp_token,
            'method' => 'email'
        ));
    }
    
    // FORGOT PASSWORD
    public static function handle_forgot_password() {
        $login = sanitize_text_field($_POST['login'] ?? $_POST['email'] ?? '');
        
        if (empty($login)) {
            wp_send_json_error(array('message' => 'Please enter your email or phone.'));
        }
        
        // Find user by email
        $user = null;
        if (is_email($login)) {
            $user = get_user_by('email', $login);
        }
        
        if (!$user) {
            // Don't reveal if user exists
            wp_send_json_success(array('message' => 'If an account exists, you will receive reset instructions.'));
            return;
        }
        
        $key = get_password_reset_key($user);
        if (is_wp_error($key)) {
            wp_send_json_error(array('message' => 'Could not generate reset link. Please try again.'));
        }
        
        $reset_url = add_query_arg(
            array('key' => $key, 'login' => rawurlencode($user->user_login)), 
            Hushot_Pages::get_page_url('reset-password')
        );
        
        $subject = 'Reset Your Hushot Password';
        $message = "Hi {$user->first_name},\n\nClick the link below to reset your password:\n\n{$reset_url}\n\nThis link expires in 24 hours.\n\nIf you didn't request this, please ignore this email.";
        
        wp_mail($user->user_email, $subject, $message);
        
        wp_send_json_success(array('message' => 'Check your email for reset instructions.'));
    }
    
    // CREATE PAGE
    public static function handle_create_page() {
        if (!is_user_logged_in()) {
            wp_send_json_error(array('message' => 'Please log in first.'));
        }
        
        $user_id = get_current_user_id();
        
        if (!Hushot_Membership::can_create_page($user_id)) {
            wp_send_json_error(array('message' => 'Page limit reached. Please upgrade your plan.'));
        }
        
        $title = sanitize_text_field($_POST['page_title'] ?? $_POST['title'] ?? '');
        if (empty($title)) {
            wp_send_json_error(array('message' => 'Please enter a page title.'));
        }
        
        $page_id = wp_insert_post(array(
            'post_title' => $title,
            'post_type' => 'hushot_page',
            'post_status' => 'publish',
            'post_author' => $user_id
        ));
        
        if (is_wp_error($page_id)) {
            wp_send_json_error(array('message' => 'Failed to create page. Please try again.'));
        }
        
        // Save all meta fields
        $meta_fields = array(
            'business_name', 'header_title', 'header_subtitle', 'primary_color', 'image_url', 'logo_url', 'video_url',
            'video_file_url', 'video_autoplay',
            'description', 'features', 'original_price', 'sale_price', 'currency',
            'cta_type', 'cta_text', 'whatsapp', 'whatsapp_message', 'phone', 'email', 'location',
            'form_title', 'form_button', 'form_fields', 'link_url', 'link_text', 'bottom_bar_style',
            'footer_text',
            // Additional footer fields for tagline, address, disclaimer and social links
            'footer_tagline', 'footer_address', 'footer_disclaimer', 'footer_facebook', 'footer_instagram', 'footer_x', 'footer_whatsapp_url', 'footer_show_social',
            'component_order', 'headers_json', 'products_title', 'products_list', 'products_json', 'bar_phone', 'bar_whatsapp', 'bar_link_url',
            'seo_title', 'seo_description', 'seo_image', 'collection',
            // Page Customization Controls
            'page_bg_color', 'header_bg_color', 'show_header', 'btn_size', 'btn_style', 'btn_width', 'btn_position'
        );
        
        // Fields that need to preserve newlines
        $textarea_fields = array('description', 'features', 'seo_description');
        
        foreach ($meta_fields as $field) {
            if (isset($_POST[$field])) {
                if (in_array($field, $textarea_fields)) {
                    update_post_meta($page_id, '_hushot_' . $field, sanitize_textarea_field($_POST[$field]));
                } else {
                    update_post_meta($page_id, '_hushot_' . $field, sanitize_text_field($_POST[$field]));
                }
            }
        }
        
        // Handle checkbox fields specially (unchecked checkboxes don't submit)
        update_post_meta($page_id, '_hushot_show_header', isset($_POST['show_header']) ? '1' : '0');
        
        // Set defaults
        update_post_meta($page_id, '_hushot_views', 0);
        update_post_meta($page_id, '_hushot_clicks', 0);
        
        // Default: open the newly created page directly in the Visual Builder
        $redirect_url = add_query_arg('page_id', $page_id, Hushot_Pages::get_page_url('visual-builder'));
        if (!empty($_POST['promote_after_save'])) {
            $redirect_url = add_query_arg('page_id', $page_id, Hushot_Pages::get_page_url('ads-promote'));
        }
        
        flush_rewrite_rules();
        
        wp_send_json_success(array(
            'message' => 'Page created successfully!',
            'page_id' => $page_id,
            'redirect' => $redirect_url
        ));
    }
    
    // UPDATE PAGE
    public static function handle_update_page() {
        if (!is_user_logged_in()) {
            wp_send_json_error(array('message' => 'Please log in first.'));
        }
        
        $page_id = intval($_POST['page_id'] ?? 0);
        $page = get_post($page_id);
        
        if (!$page || $page->post_type !== 'hushot_page' || $page->post_author != get_current_user_id()) {
            wp_send_json_error(array('message' => 'Page not found or access denied.'));
        }
        
        // Update title if provided
        if (!empty($_POST['title'])) {
            wp_update_post(array(
                'ID' => $page_id, 
                'post_title' => sanitize_text_field($_POST['title'])
            ));
        }
        
        // Save all meta fields
        $meta_fields = array(
            'business_name', 'header_title', 'header_subtitle', 'primary_color', 'image_url', 'logo_url', 'video_url',
            'video_file_url', 'video_autoplay',
            'description', 'features', 'original_price', 'sale_price', 'currency',
            'cta_type', 'cta_text', 'whatsapp', 'whatsapp_message', 'phone', 'email', 'location',
            'form_title', 'form_button', 'form_fields', 'link_url', 'link_text', 'bottom_bar_style', 'footer_text',
            // Additional footer fields for tagline, address, disclaimer and social links
            'footer_tagline', 'footer_address', 'footer_disclaimer', 'footer_facebook', 'footer_instagram', 'footer_x', 'footer_whatsapp_url', 'footer_show_social',
            'component_order', 'headers_json', 'products_title', 'products_list', 'products_json', 'bar_phone', 'bar_whatsapp', 'bar_link_url',
            'seo_title', 'seo_description', 'seo_image', 'collection',
            // Page Customization Controls
            'page_bg_color', 'header_bg_color', 'show_header', 'btn_size', 'btn_style', 'btn_width', 'btn_position'
        );
        
        // Fields that need to preserve newlines
        $textarea_fields = array('description', 'features', 'seo_description');
        
        foreach ($meta_fields as $field) {
            if (isset($_POST[$field])) {
                if (in_array($field, $textarea_fields)) {
                    update_post_meta($page_id, '_hushot_' . $field, sanitize_textarea_field($_POST[$field]));
                } else {
                    update_post_meta($page_id, '_hushot_' . $field, sanitize_text_field($_POST[$field]));
                }
            }
        }
        
        // Handle checkbox fields specially (unchecked checkboxes don't submit)
        update_post_meta($page_id, '_hushot_show_header', isset($_POST['show_header']) ? '1' : '0');
        
        wp_send_json_success(array('message' => 'Page saved successfully!', 'page_id' => $page_id));
    }
    
    // DELETE PAGE
    public static function handle_delete_page() {
        if (!is_user_logged_in()) {
            wp_send_json_error(array('message' => 'Please log in first.'));
        }
        
        $page_id = intval($_POST['page_id'] ?? 0);
        $page = get_post($page_id);
        
        if (!$page || $page->post_author != get_current_user_id()) {
            wp_send_json_error(array('message' => 'Page not found.'));
        }
        
        wp_delete_post($page_id, true);
        
        wp_send_json_success(array('message' => 'Page deleted.'));
    }
    
    // DUPLICATE PAGE
    public static function handle_duplicate_page() {
        if (!is_user_logged_in()) {
            wp_send_json_error(array('message' => 'Please log in first.'));
        }
        
        $page_id = intval($_POST['page_id'] ?? 0);
        if (!$page_id) {
            wp_send_json_error(array('message' => 'No page ID provided.'));
        }
        
        $page = get_post($page_id);
        
        if (!$page || $page->post_type !== 'hushot_page' || (int)$page->post_author !== get_current_user_id()) {
            wp_send_json_error(array('message' => 'Page not found or access denied.'));
        }
        
        // Create new post
        $new_id = wp_insert_post(array(
            'post_title' => $page->post_title . ' (Copy)',
            'post_content' => $page->post_content,
            'post_status' => 'publish',
            'post_type' => 'hushot_page',
            'post_author' => get_current_user_id(),
        ));
        
        if (is_wp_error($new_id)) {
            wp_send_json_error(array('message' => 'Failed to create duplicate: ' . $new_id->get_error_message()));
        }
        
        // Copy all meta
        $meta_keys = array('business_name','logo_url','header_title','header_subtitle','primary_color','image_url','video_url','description','features','original_price','sale_price','currency','cta_text','cta_type','whatsapp','whatsapp_message','phone','email','location','link_url','link_text','bottom_bar_style','bar_phone','bar_whatsapp','bar_link_url','products_title','products_json','form_title','form_button','form_fields','seo_title','seo_description','seo_image','collection');
        foreach ($meta_keys as $key) {
            $value = get_post_meta($page_id, '_hushot_' . $key, true);
            if ($value !== '' && $value !== false) {
                update_post_meta($new_id, '_hushot_' . $key, $value);
            }
        }
        
        // Generate redirect URL to edit page
        $edit_url = add_query_arg('page_id', $new_id, Hushot_Pages::get_page_url('edit-page'));
        
        wp_send_json_success(array(
            'message' => 'Page duplicated!', 
            'new_id' => $new_id,
            'redirect' => $edit_url
        ));
    }
    
    // USE TEMPLATE
    public static function handle_use_template() {
        if (!is_user_logged_in()) {
            wp_send_json_error(array('message' => 'Please log in first.'));
        }
        
        $template_id = intval($_POST['template_id'] ?? 0);
        $title = sanitize_text_field($_POST['title'] ?? 'My Landing Page');
        
        // Get template data from frontend
        $primary_color = sanitize_hex_color($_POST['primary_color'] ?? '#0D9488');
        $image_url = esc_url_raw($_POST['image_url'] ?? '');
        $header_title = sanitize_text_field($_POST['header_title'] ?? '');
        $description = sanitize_textarea_field($_POST['description'] ?? '');
        $features = sanitize_textarea_field($_POST['features'] ?? '');
        
        // Check template access based on ID
        if (!Hushot_Membership::can_access_template($template_id)) {
            wp_send_json_error(array('message' => 'Please upgrade to use this template.'));
        }
        
        $user_id = get_current_user_id();
        
        // Check page limit
        if (!Hushot_Membership::can_create_page($user_id)) {
            wp_send_json_error(array('message' => 'Page limit reached. Please upgrade.'));
        }
        
        // Create new page from template
        $page_id = wp_insert_post(array(
            'post_title' => $title,
            'post_type' => 'hushot_page',
            'post_status' => 'publish',
            'post_author' => $user_id
        ));
        
        if (is_wp_error($page_id)) {
            wp_send_json_error(array('message' => 'Failed to create page.'));
        }
        
        // Set template data
        update_post_meta($page_id, '_hushot_business_name', $title);
        update_post_meta($page_id, '_hushot_primary_color', $primary_color);
        update_post_meta($page_id, '_hushot_image_url', $image_url);
        update_post_meta($page_id, '_hushot_header_title', $header_title);
        update_post_meta($page_id, '_hushot_description', $description);
        update_post_meta($page_id, '_hushot_features', $features);
        update_post_meta($page_id, '_hushot_cta_type', 'whatsapp');
        update_post_meta($page_id, '_hushot_cta_text', 'Chat on WhatsApp');
        update_post_meta($page_id, '_hushot_bottom_bar_style', 'two_buttons');
        
        // Set defaults
        update_post_meta($page_id, '_hushot_show_header', '1');
        update_post_meta($page_id, '_hushot_show_image', '1');
        update_post_meta($page_id, '_hushot_show_description', '1');
        update_post_meta($page_id, '_hushot_show_features', '1');
        update_post_meta($page_id, '_hushot_show_contact', '1');
        update_post_meta($page_id, '_hushot_show_bottom_bar', '1');
        update_post_meta($page_id, '_hushot_show_footer', '1');
        update_post_meta($page_id, '_hushot_views', 0);
        update_post_meta($page_id, '_hushot_clicks', 0);
        
        // Set user defaults
        $wa = get_user_meta($user_id, 'hushot_whatsapp', true);
        if ($wa) update_post_meta($page_id, '_hushot_whatsapp', $wa);
        
        flush_rewrite_rules();
        
        wp_send_json_success(array(
            'message' => 'Page created from template!',
            'redirect' => add_query_arg('page_id', $page_id, Hushot_Pages::get_page_url('edit-page'))
        ));
    }
    
    // UPDATE PROFILE
    public static function handle_update_profile() {
        if (!is_user_logged_in()) {
            wp_send_json_error(array('message' => 'Please log in first.'));
        }
        
        $user_id = get_current_user_id();
        
        $userdata = array('ID' => $user_id);
        if (isset($_POST['first_name'])) $userdata['first_name'] = sanitize_text_field($_POST['first_name']);
        if (isset($_POST['last_name'])) $userdata['last_name'] = sanitize_text_field($_POST['last_name']);
        
        wp_update_user($userdata);
        
        if (isset($_POST['business_name'])) {
            update_user_meta($user_id, 'hushot_business_name', sanitize_text_field($_POST['business_name']));
        }
        if (isset($_POST['phone'])) {
            update_user_meta($user_id, 'hushot_phone', sanitize_text_field($_POST['phone']));
            update_user_meta($user_id, 'hushot_whatsapp', sanitize_text_field($_POST['phone']));
        }
        
        if (!empty($_POST['new_password']) && strlen($_POST['new_password']) >= 6) {
            wp_set_password($_POST['new_password'], $user_id);
            // Re-login after password change
            wp_set_auth_cookie($user_id, true);
        }
        
        wp_send_json_success(array('message' => 'Profile updated!'));
    }
    
    // GENERATE AI
    public static function handle_generate_ai() {
        if (!is_user_logged_in()) {
            wp_send_json_error(array('message' => 'Please log in first.'));
        }
        
        if (!Hushot_Membership::can_use_ai()) {
            wp_send_json_error(array('message' => 'AI Writer requires Essential or Premium plan.'));
        }
        
        $product = sanitize_text_field($_POST['product'] ?? '');
        $business_type = sanitize_text_field($_POST['business_type'] ?? 'consulting');
        $goal = sanitize_text_field($_POST['goal'] ?? 'leads');
        
        $content = Hushot_AI::generate($business_type, $goal, $product);
        
        // Record AI usage
        global $wpdb;
        $wpdb->insert($wpdb->prefix . 'hushot_ai', array(
            'user_id' => get_current_user_id(),
            'business_type' => $product ?: $business_type,
            'created_at' => current_time('mysql'),
            'month_year' => date('Y-m')
        ));
        
        wp_send_json_success(array('content' => $content));
    }
    
    // AI GENERATE FULL PAGE
    public static function handle_ai_generate_page() {
        if (!is_user_logged_in()) {
            wp_send_json_error(array('message' => 'Please log in first.'));
        }
        
        // Verify nonce
        if (!wp_verify_nonce($_POST['_wpnonce'] ?? '', 'hushot_ai_generate')) {
            wp_send_json_error(array('message' => 'Security check failed. Please refresh and try again.'));
        }
        
        if (!Hushot_Membership::can_use_ai()) {
            wp_send_json_error(array('message' => 'AI Builder requires Essential or Premium plan.'));
        }
        
        $user_id = get_current_user_id();
        
        // Check page limit
        if (!Hushot_Membership::can_create_page($user_id)) {
            wp_send_json_error(array('message' => 'Page limit reached. Please upgrade your plan.'));
        }
        
        $prompt = sanitize_textarea_field($_POST['prompt'] ?? '');
        $style = sanitize_text_field($_POST['style'] ?? 'modern');
        
        if (empty($prompt)) {
            wp_send_json_error(array('message' => 'Please describe your business.'));
        }
        
        // Generate content using AI
        $content = Hushot_AI::generate('', 'leads', $prompt);
        
        if (!$content || empty($content['headline'])) {
            // Fallback to template-based content
            $content = array(
                'headline' => ucwords(substr($prompt, 0, 50)),
                'subheadline' => 'Quality service you can trust',
                'description' => $prompt,
                'features' => array('Quality Service', 'Fast Delivery', 'Best Prices', 'Expert Team'),
                'cta' => 'Contact Us'
            );
        }
        
        // Create the page
        $page_title = $content['headline'] ?: 'My Landing Page';
        
        $page_id = wp_insert_post(array(
            'post_title' => $page_title,
            'post_type' => 'hushot_page',
            'post_status' => 'publish',
            'post_author' => $user_id
        ));
        
        if (is_wp_error($page_id)) {
            wp_send_json_error(array('message' => 'Failed to create page. Please try again.'));
        }
        
        // Style-based colors
        $colors = array(
            'modern' => '#667eea',
            'bold' => '#e53e3e',
            'elegant' => '#1a1a2e',
            'playful' => '#f59e0b'
        );
        $primary_color = $colors[$style] ?? '#667eea';
        
        // Save meta
        update_post_meta($page_id, '_hushot_business_name', $page_title);
        update_post_meta($page_id, '_hushot_header_title', $content['headline'] ?? '');
        update_post_meta($page_id, '_hushot_header_subtitle', $content['subheadline'] ?? '');
        update_post_meta($page_id, '_hushot_description', $content['description'] ?? '');
        update_post_meta($page_id, '_hushot_features', is_array($content['features']) ? implode("\n", $content['features']) : '');
        update_post_meta($page_id, '_hushot_cta_text', $content['cta'] ?? 'Contact Us');
        update_post_meta($page_id, '_hushot_cta_type', 'whatsapp');
        update_post_meta($page_id, '_hushot_primary_color', $primary_color);
        update_post_meta($page_id, '_hushot_currency', 'NGN');
        update_post_meta($page_id, '_hushot_views', 0);
        update_post_meta($page_id, '_hushot_clicks', 0);
        update_post_meta($page_id, '_hushot_ai_generated', '1');
        update_post_meta($page_id, '_hushot_component_order', 'header,description,features,whatsapp,contact');
        
        // Copy user's WhatsApp if available
        $wa = get_user_meta($user_id, 'hushot_whatsapp', true);
        if ($wa) {
            update_post_meta($page_id, '_hushot_whatsapp', $wa);
        }
        
        // Generate AI image if requested
        $generate_image = sanitize_text_field($_POST['generate_image'] ?? '0');
        if ($generate_image === '1') {
            $image_result = self::generate_ai_image_for_page($prompt, $page_id);
            if ($image_result && !empty($image_result['image_url'])) {
                update_post_meta($page_id, '_hushot_image_url', $image_result['image_url']);
                // Update component order to include image
                update_post_meta($page_id, '_hushot_component_order', 'header,image,description,features,whatsapp,contact');
            }
        }
        
        // Record AI usage
        global $wpdb;
        $wpdb->insert($wpdb->prefix . 'hushot_ai', array(
            'user_id' => $user_id,
            'business_type' => substr($prompt, 0, 100),
            'created_at' => current_time('mysql'),
            'month_year' => date('Y-m')
        ));
        
        flush_rewrite_rules();
        
        wp_send_json_success(array(
            'message' => 'Page created successfully!',
            'page_id' => $page_id,
            'edit_url' => add_query_arg('page_id', $page_id, Hushot_Pages::get_page_url('edit-page'))
        ));
    }
    
    // SAVE OPENAI KEY
    public static function handle_save_openai_key() {
        if (!is_user_logged_in()) {
            wp_send_json_error(array('message' => 'Not logged in'));
        }
        
        $key = sanitize_text_field($_POST['key'] ?? '');
        update_user_meta(get_current_user_id(), 'hushot_openai_key', $key);
        wp_send_json_success(array('message' => 'API key saved'));
    }
    
    // CHECKOUT
    public static function handle_checkout() {
        if (!is_user_logged_in()) {
            wp_send_json_error(array('message' => 'Please log in first.'));
        }
        
        $plan = sanitize_text_field($_POST['plan'] ?? 'essential');
        $cycle = sanitize_text_field($_POST['cycle'] ?? 'monthly');
        $payment_method = sanitize_text_field($_POST['payment_method'] ?? 'card');
        $with_trial = !empty($_POST['trial']) && $_POST['trial'] === '1';
        
        // Create payment with Flutterwave
        $result = Hushot_Flutterwave::create_payment($plan, $cycle, $payment_method, $with_trial);
        
        if (is_wp_error($result)) {
            wp_send_json_error(array('message' => $result->get_error_message()));
        }
        
        // If result is a URL, redirect to payment
        if (filter_var($result, FILTER_VALIDATE_URL)) {
            wp_send_json_success(array(
                'message' => 'Redirecting to payment...',
                'redirect' => $result
            ));
        }
        
        // If result is a success URL (demo mode)
        wp_send_json_success(array(
            'message' => $with_trial ? 'Trial activated!' : 'Plan activated!',
            'redirect' => $result
        ));
    }
    
    // CANCEL SUBSCRIPTION
    public static function handle_cancel_subscription() {
        if (!is_user_logged_in()) {
            wp_send_json_error(array('message' => 'Please log in first.'));
        }
        
        $user_id = get_current_user_id();
        
        global $wpdb;
        $wpdb->update(
            $wpdb->prefix . 'hushot_subscriptions',
            array('status' => 'cancelled'),
            array('user_id' => $user_id, 'status' => 'active')
        );
        
        Hushot_Membership::set_user_plan($user_id, 'free');
        
        wp_send_json_success(array(
            'message' => 'Subscription cancelled. You are now on the Free plan.',
            'redirect' => Hushot_Pages::get_page_url('dashboard')
        ));
    }
    
    // TRACK CLICK - No auth required
    public static function handle_track_click() {
        $page_id = intval($_POST['page_id'] ?? 0);
        $button_type = sanitize_text_field($_POST['button_type'] ?? 'unknown');
        
        if (!$page_id) {
            wp_send_json_error(array('message' => 'Invalid page.'));
        }
        
        global $wpdb;
        $wpdb->insert($wpdb->prefix . 'hushot_clicks', array(
            'page_id' => $page_id,
            'button_type' => $button_type,
            'ip_address' => $_SERVER['REMOTE_ADDR'] ?? '',
            'clicked_at' => current_time('mysql')
        ));
        
        $current = (int) get_post_meta($page_id, '_hushot_clicks', true);
        update_post_meta($page_id, '_hushot_clicks', $current + 1);
        
        wp_send_json_success(array('recorded' => true));
    }
    
    // UPLOAD IMAGE
    public static function handle_upload_image() {
        if (!is_user_logged_in()) {
            wp_send_json_error(array('message' => 'Please log in first.'));
        }
        
        // Accept both 'file' and 'image' keys
        $file_key = 'file';
        if (empty($_FILES['file']) && !empty($_FILES['image'])) {
            $file_key = 'image';
        }
        
        if (empty($_FILES[$file_key])) {
            wp_send_json_error(array('message' => 'No image file received.'));
        }
        
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/media.php');
        
        $attachment_id = media_handle_upload($file_key, 0);
        
        if (is_wp_error($attachment_id)) {
            wp_send_json_error(array('message' => 'Upload failed: ' . $attachment_id->get_error_message()));
        }
        
        wp_send_json_success(array(
            'id' => $attachment_id,
            'url' => wp_get_attachment_url($attachment_id)
        ));
    }
    
    // VIDEO UPLOAD - For paid/trial users only
    public static function handle_upload_video() {
        if (!is_user_logged_in()) {
            wp_send_json_error(array('message' => 'Please log in first.'));
        }
        
        // Check if user has paid plan or trial
        $plan = Hushot_Membership::get_user_plan();
        if (!in_array($plan, array('essential', 'premium'))) {
            // Check if on trial
            $trial_end = get_user_meta(get_current_user_id(), '_hushot_trial_end', true);
            if (!$trial_end || strtotime($trial_end) < time()) {
                wp_send_json_error(array('message' => 'Video upload is only available for paid or trial users.'));
            }
        }
        
        // Accept both 'file' and 'video' keys
        $file_key = 'file';
        if (empty($_FILES['file']) && !empty($_FILES['video'])) {
            $file_key = 'video';
        }
        
        if (empty($_FILES[$file_key])) {
            wp_send_json_error(array('message' => 'No video file received.'));
        }
        
        $file = $_FILES[$file_key];
        
        // Validate file type
        $allowed_types = array('video/mp4', 'video/webm', 'video/quicktime');
        if (!in_array($file['type'], $allowed_types)) {
            wp_send_json_error(array('message' => 'Only MP4 and WebM videos are allowed.'));
        }
        
        // Validate file size (50MB max)
        if ($file['size'] > 50 * 1024 * 1024) {
            wp_send_json_error(array('message' => 'Video must be less than 50MB.'));
        }
        
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/media.php');
        
        $attachment_id = media_handle_upload($file_key, 0);
        
        if (is_wp_error($attachment_id)) {
            wp_send_json_error(array('message' => 'Upload failed: ' . $attachment_id->get_error_message()));
        }
        
        wp_send_json_success(array(
            'id' => $attachment_id,
            'url' => wp_get_attachment_url($attachment_id)
        ));
    }
    
    // EBOOK/PDF UPLOAD - For selling digital products
    public static function handle_upload_ebook() {
        if (!is_user_logged_in()) {
            wp_send_json_error(array('message' => 'Please log in first.'));
        }
        
        // Check if user has paid plan or trial
        $plan = Hushot_Membership::get_user_plan();
        if (!in_array($plan, array('essential', 'premium'))) {
            $trial_end = get_user_meta(get_current_user_id(), '_hushot_trial_end', true);
            if (!$trial_end || strtotime($trial_end) < time()) {
                wp_send_json_error(array('message' => 'Ebook upload is only available for paid users.'));
            }
        }
        
        // Accept 'ebook' or 'file' key
        $file_key = 'ebook';
        if (empty($_FILES['ebook']) && !empty($_FILES['file'])) {
            $file_key = 'file';
        }
        
        if (empty($_FILES[$file_key])) {
            wp_send_json_error(array('message' => 'No file received.'));
        }
        
        $file = $_FILES[$file_key];
        
        // Validate file type
        $allowed_types = array('application/pdf', 'application/epub+zip', 'application/x-mobipocket-ebook');
        $allowed_ext = array('pdf', 'epub', 'mobi');
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        
        if (!in_array($ext, $allowed_ext)) {
            wp_send_json_error(array('message' => 'Only PDF, EPUB, and MOBI files are allowed.'));
        }
        
        // Validate file size (20MB max)
        if ($file['size'] > 20 * 1024 * 1024) {
            wp_send_json_error(array('message' => 'File must be less than 20MB.'));
        }
        
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/media.php');
        
        // Allow PDF uploads
        add_filter('upload_mimes', function($mimes) {
            $mimes['pdf'] = 'application/pdf';
            $mimes['epub'] = 'application/epub+zip';
            $mimes['mobi'] = 'application/x-mobipocket-ebook';
            return $mimes;
        });
        
        $attachment_id = media_handle_upload($file_key, 0);
        
        if (is_wp_error($attachment_id)) {
            wp_send_json_error(array('message' => 'Upload failed: ' . $attachment_id->get_error_message()));
        }
        
        wp_send_json_success(array(
            'id' => $attachment_id,
            'url' => wp_get_attachment_url($attachment_id),
            'filename' => basename($file['name'])
        ));
    }
    
    // PREVIEW PAGE - Generate HTML preview
    public static function handle_preview_page() {
        if (!is_user_logged_in()) {
            wp_send_json_error(array('message' => 'Please log in first.'));
        }
        
        // Collect form data
        $data = array(
            'business_name' => sanitize_text_field($_POST['business_name'] ?? $_POST['page_title'] ?? 'Preview'),
            'logo_url' => esc_url_raw($_POST['logo_url'] ?? ''),
            'header_title' => sanitize_text_field($_POST['header_title'] ?? ''),
            'header_subtitle' => sanitize_text_field($_POST['header_subtitle'] ?? ''),
            'primary_color' => sanitize_hex_color($_POST['primary_color'] ?? '#000000'),
            'image_url' => esc_url_raw($_POST['image_url'] ?? ''),
            'video_url' => esc_url_raw($_POST['video_url'] ?? ''),
            'video_file_url' => esc_url_raw($_POST['video_file_url'] ?? ''),
            'description' => wp_kses_post($_POST['description'] ?? ''),
            'features' => sanitize_textarea_field($_POST['features'] ?? ''),
            'original_price' => sanitize_text_field($_POST['original_price'] ?? ''),
            'sale_price' => sanitize_text_field($_POST['sale_price'] ?? ''),
            'currency' => sanitize_text_field($_POST['currency'] ?? 'NGN'),
            'cta_type' => sanitize_text_field($_POST['cta_type'] ?? ''),
            'cta_text' => sanitize_text_field($_POST['cta_text'] ?? 'Chat on WhatsApp'),
            'whatsapp' => sanitize_text_field($_POST['whatsapp'] ?? ''),
            'whatsapp_message' => sanitize_text_field($_POST['whatsapp_message'] ?? ''),
            'phone' => sanitize_text_field($_POST['phone'] ?? ''),
            'email' => sanitize_email($_POST['email'] ?? ''),
            'location' => sanitize_text_field($_POST['location'] ?? ''),
            'form_title' => sanitize_text_field($_POST['form_title'] ?? 'Get Started'),
            'form_button' => sanitize_text_field($_POST['form_button'] ?? 'Submit'),
            'form_fields' => sanitize_text_field($_POST['form_fields'] ?? 'name,email,phone'),
            'link_url' => esc_url_raw($_POST['link_url'] ?? ''),
            'link_text' => sanitize_text_field($_POST['link_text'] ?? 'Learn More'),
            'bottom_bar_style' => sanitize_text_field($_POST['bottom_bar_style'] ?? 'disabled'),
            'bar_phone' => sanitize_text_field($_POST['bar_phone'] ?? ''),
            'bar_whatsapp' => sanitize_text_field($_POST['bar_whatsapp'] ?? ''),
            'bar_link_url' => esc_url_raw($_POST['bar_link_url'] ?? ''),
            'component_order' => sanitize_text_field($_POST['component_order'] ?? ''),
            'page_bg_color' => sanitize_hex_color($_POST['page_bg_color'] ?? '#ffffff'),
            'header_bg_color' => sanitize_hex_color($_POST['header_bg_color'] ?? '#ffffff'),
            'show_header' => sanitize_text_field($_POST['show_header'] ?? '1'),
            'btn_size' => sanitize_text_field($_POST['btn_size'] ?? 'medium'),
            'btn_style' => sanitize_text_field($_POST['btn_style'] ?? 'rounded'),
            'btn_width' => sanitize_text_field($_POST['btn_width'] ?? 'auto'),
        );
        
        // Generate preview HTML
        ob_start();
        
        $pc = $data['primary_color'];
        $bg_color = $data['page_bg_color'] ?: '#ffffff';
        $header_bg = $data['header_bg_color'] ?: '#ffffff';
        $symbols = array('NGN'=>'₦','GHS'=>'₵','KES'=>'KSh','ZAR'=>'R','USD'=>'$','EUR'=>'€','GBP'=>'£','UGX'=>'USh','TZS'=>'TSh','XOF'=>'CFA');
        $symbol = $symbols[$data['currency']] ?? '₦';
        $features = array_filter(array_map('trim', explode("\n", $data['features'])));
        $wa_number = preg_replace('/[^0-9]/', '', $data['whatsapp']);
        $wa_url = $wa_number ? "https://wa.me/{$wa_number}" : '#';
        $form_fields = array_filter(explode(',', $data['form_fields']));
        $components = array_filter(explode(',', $data['component_order']));
        $show_header = $data['show_header'] !== '0';
        
        // Button styles
        $btn_padding = $data['btn_size'] === 'large' ? '18px 32px' : ($data['btn_size'] === 'small' ? '10px 18px' : '14px 24px');
        $btn_radius = $data['btn_style'] === 'square' ? '4px' : ($data['btn_style'] === 'pill' ? '50px' : '12px');
        $btn_width = $data['btn_width'] === 'full' ? '100%' : 'auto';
        ?>
        <!DOCTYPE html>
        <html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
        <title>Preview</title>
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
        <style>
        *{box-sizing:border-box;margin:0;padding:0}
        body{font-family:'Inter',sans-serif;background:<?php echo $bg_color; ?>;color:#1e293b;line-height:1.6}
        .container{max-width:640px;margin:0 auto;padding:0 16px}
        .header{background:<?php echo $header_bg; ?>;padding:12px 0;box-shadow:0 2px 10px rgba(0,0,0,0.05);position:sticky;top:0;z-index:100}
        .header .container{display:flex;justify-content:space-between;align-items:center}
        .brand{display:flex;align-items:center;gap:10px}
        .logo{width:40px;height:40px;border-radius:10px;object-fit:cover}
        .name{font-size:18px;font-weight:700}
        .hero{background:linear-gradient(135deg,<?php echo $pc; ?>15 0%,<?php echo $pc; ?>08 100%);padding:34px 0;text-align:center}
        .hero h1{font-size:28px;font-weight:800;margin-bottom:8px;color:#1a1a2e}
        .hero p{color:#475569}
        .section{padding:24px 0}
        .img-wrap img{width:100%;border-radius:16px;box-shadow:0 10px 40px rgba(0,0,0,0.1)}
        .video-wrap{border-radius:16px;overflow:hidden;box-shadow:0 10px 40px rgba(0,0,0,0.1)}
        .video-wrap iframe,.video-wrap video{width:100%;aspect-ratio:16/9;display:block}
        .desc{font-size:15px;color:#334155;white-space:pre-wrap}
        .features{list-style:none}
        .features li{padding:12px 0;border-bottom:1px solid #f1f5f9;display:flex;align-items:center;gap:10px}
        .features li:before{content:'✓';color:<?php echo $pc; ?>;font-weight:bold;font-size:18px}
        .price{text-align:center;padding:24px;background:#f8fafc;border-radius:16px}
        .price .old{text-decoration:line-through;color:#94a3b8;font-size:14px}
        .price .new{font-size:32px;font-weight:800;color:<?php echo $pc; ?>}
        .cta-btn{display:inline-block;background:#25D366;color:#fff!important;text-align:center;padding:<?php echo $btn_padding; ?>;border-radius:<?php echo $btn_radius; ?>;font-weight:600;text-decoration:none;width:<?php echo $btn_width; ?>;transition:all 0.2s}
        .cta-btn:hover{transform:translateY(-2px);box-shadow:0 8px 20px rgba(0,0,0,0.15)}
        .link-btn{display:inline-block;background:<?php echo $pc; ?>;color:#fff!important;text-align:center;padding:<?php echo $btn_padding; ?>;border-radius:<?php echo $btn_radius; ?>;font-weight:600;text-decoration:none;width:<?php echo $btn_width; ?>}
        .contact{background:#f8fafc;padding:20px;border-radius:16px}
        .contact-item{display:flex;align-items:center;gap:10px;padding:8px 0}
        .form-card{background:#f8fafc;border-radius:16px;padding:24px}
        .form-title{font-size:20px;font-weight:700;margin-bottom:16px;text-align:center}
        .form-card input{width:100%;padding:14px;border:1px solid #e2e8f0;border-radius:10px;margin-bottom:12px;font-size:15px}
        .form-card button{width:100%;padding:<?php echo $btn_padding; ?>;background:<?php echo $pc; ?>;color:#fff;border:none;border-radius:<?php echo $btn_radius; ?>;font-size:16px;font-weight:600;cursor:pointer}
        .bottom-bar{position:fixed;bottom:0;left:0;right:0;background:#fff;padding:12px 16px;box-shadow:0 -4px 20px rgba(0,0,0,0.1);display:flex;gap:10px;justify-content:center;z-index:100}
        .bottom-bar a{flex:1;text-align:center;padding:12px;border-radius:10px;text-decoration:none;font-weight:600;font-size:14px}
        .bottom-bar .call{background:#f1f5f9;color:#334155}
        .bottom-bar .wa{background:#25D366;color:#fff}
        .preview-badge{position:fixed;top:10px;right:10px;background:<?php echo $pc; ?>;color:#fff;padding:6px 12px;border-radius:20px;font-size:11px;font-weight:600;z-index:200}
        </style></head><body>
        <div class="preview-badge">Preview Mode</div>
        <?php if($show_header): ?>
        <header class="header"><div class="container"><div class="brand">
            <?php if($data['logo_url']): ?><img src="<?php echo esc_url($data['logo_url']); ?>" class="logo"><?php endif; ?>
            <span class="name"><?php echo esc_html($data['business_name']); ?></span>
        </div></div></header>
        <?php endif; ?>
        
        <?php 
        // Render components in order
        if (!empty($components)) {
            foreach ($components as $comp) {
                $comp = trim($comp);
                switch($comp) {
                    case 'header':
                        if($data['header_title']): ?>
                        <section class="hero"><div class="container">
                            <h1><?php echo esc_html($data['header_title']); ?></h1>
                            <?php if($data['header_subtitle']): ?><p><?php echo esc_html($data['header_subtitle']); ?></p><?php endif; ?>
                        </div></section>
                        <?php endif;
                        break;
                    case 'image':
                        if($data['image_url']): ?>
                        <section class="section"><div class="container"><div class="img-wrap"><img src="<?php echo esc_url($data['image_url']); ?>"></div></div></section>
                        <?php endif;
                        break;
                    case 'video':
                        if($data['video_url'] || $data['video_file_url']): ?>
                        <section class="section"><div class="container"><div class="video-wrap">
                            <?php if($data['video_file_url']): ?>
                            <video controls><source src="<?php echo esc_url($data['video_file_url']); ?>" type="video/mp4"></video>
                            <?php elseif(preg_match('/youtube\.com\/watch\?v=([^&]+)|youtu\.be\/([^?]+)/', $data['video_url'], $m)): ?>
                            <iframe src="https://www.youtube.com/embed/<?php echo $m[1] ?: $m[2]; ?>" frameborder="0" allowfullscreen></iframe>
                            <?php endif; ?>
                        </div></div></section>
                        <?php endif;
                        break;
                    case 'description':
                        if($data['description']): ?>
                        <section class="section"><div class="container"><p class="desc"><?php echo nl2br(esc_html($data['description'])); ?></p></div></section>
                        <?php endif;
                        break;
                    case 'features':
                        if(!empty($features)): ?>
                        <section class="section"><div class="container"><ul class="features">
                            <?php foreach($features as $f): ?><li><?php echo esc_html($f); ?></li><?php endforeach; ?>
                        </ul></div></section>
                        <?php endif;
                        break;
                    case 'pricing':
                        if($data['sale_price'] || $data['original_price']): ?>
                        <section class="section"><div class="container"><div class="price">
                            <?php if($data['original_price'] && $data['sale_price']): ?><div class="old"><?php echo $symbol . number_format($data['original_price']); ?></div><?php endif; ?>
                            <div class="new"><?php echo $symbol . number_format($data['sale_price'] ?: $data['original_price']); ?></div>
                        </div></div></section>
                        <?php endif;
                        break;
                    case 'whatsapp':
                        if($wa_number): ?>
                        <section class="section"><div class="container" style="text-align:center">
                            <a href="<?php echo esc_url($wa_url); ?>" class="cta-btn"><?php echo esc_html($data['cta_text']); ?></a>
                        </div></section>
                        <?php endif;
                        break;
                    case 'link':
                        if($data['link_url']): ?>
                        <section class="section"><div class="container" style="text-align:center">
                            <a href="<?php echo esc_url($data['link_url']); ?>" class="link-btn"><?php echo esc_html($data['link_text'] ?: 'Learn More'); ?></a>
                        </div></section>
                        <?php endif;
                        break;
                    case 'form':
                        if(!empty($form_fields)): ?>
                        <section class="section"><div class="container"><div class="form-card">
                            <h3 class="form-title"><?php echo esc_html($data['form_title']); ?></h3>
                            <form>
                                <?php foreach($form_fields as $field): $field = trim($field); ?>
                                <input type="text" placeholder="<?php echo esc_attr(ucfirst($field)); ?>" readonly>
                                <?php endforeach; ?>
                                <button type="button"><?php echo esc_html($data['form_button']); ?></button>
                            </form>
                        </div></div></section>
                        <?php endif;
                        break;
                    case 'contact':
                        if($data['phone'] || $data['email'] || $data['location']): ?>
                        <section class="section"><div class="container"><div class="contact">
                            <?php if($data['phone']): ?><div class="contact-item">📞 <?php echo esc_html($data['phone']); ?></div><?php endif; ?>
                            <?php if($data['email']): ?><div class="contact-item">✉️ <?php echo esc_html($data['email']); ?></div><?php endif; ?>
                            <?php if($data['location']): ?><div class="contact-item">📍 <?php echo esc_html($data['location']); ?></div><?php endif; ?>
                        </div></div></section>
                        <?php endif;
                        break;
                }
            }
        } else {
            // Fallback: show all content in default order
            if($data['header_title']): ?>
            <section class="hero"><div class="container">
                <h1><?php echo esc_html($data['header_title']); ?></h1>
                <?php if($data['header_subtitle']): ?><p><?php echo esc_html($data['header_subtitle']); ?></p><?php endif; ?>
            </div></section>
            <?php endif;
            if($data['image_url']): ?>
            <section class="section"><div class="container"><div class="img-wrap"><img src="<?php echo esc_url($data['image_url']); ?>"></div></div></section>
            <?php endif;
            if($data['description']): ?>
            <section class="section"><div class="container"><p class="desc"><?php echo nl2br(esc_html($data['description'])); ?></p></div></section>
            <?php endif;
            if(!empty($features)): ?>
            <section class="section"><div class="container"><ul class="features">
                <?php foreach($features as $f): ?><li><?php echo esc_html($f); ?></li><?php endforeach; ?>
            </ul></div></section>
            <?php endif;
            if($data['sale_price']): ?>
            <section class="section"><div class="container"><div class="price">
                <?php if($data['original_price']): ?><div class="old"><?php echo $symbol . number_format($data['original_price']); ?></div><?php endif; ?>
                <div class="new"><?php echo $symbol . number_format($data['sale_price']); ?></div>
            </div></div></section>
            <?php endif;
            if($wa_number): ?>
            <section class="section"><div class="container" style="text-align:center">
                <a href="<?php echo esc_url($wa_url); ?>" class="cta-btn"><?php echo esc_html($data['cta_text']); ?></a>
            </div></section>
            <?php endif;
            if(!empty($form_fields)): ?>
            <section class="section"><div class="container"><div class="form-card">
                <h3 class="form-title"><?php echo esc_html($data['form_title']); ?></h3>
                <form>
                    <?php foreach($form_fields as $field): $field = trim($field); ?>
                    <input type="text" placeholder="<?php echo esc_attr(ucfirst($field)); ?>" readonly>
                    <?php endforeach; ?>
                    <button type="button"><?php echo esc_html($data['form_button']); ?></button>
                </form>
            </div></div></section>
            <?php endif;
            if($data['phone'] || $data['email'] || $data['location']): ?>
            <section class="section"><div class="container"><div class="contact">
                <?php if($data['phone']): ?><div class="contact-item">📞 <?php echo esc_html($data['phone']); ?></div><?php endif; ?>
                <?php if($data['email']): ?><div class="contact-item">✉️ <?php echo esc_html($data['email']); ?></div><?php endif; ?>
                <?php if($data['location']): ?><div class="contact-item">📍 <?php echo esc_html($data['location']); ?></div><?php endif; ?>
            </div></div></section>
            <?php endif;
        }
        
        // Bottom bar
        if($data['bottom_bar_style'] !== 'disabled'):
            $bar_phone = $data['bar_phone'] ?: $data['phone'];
            $bar_wa = $data['bar_whatsapp'] ?: $data['whatsapp'];
            $bar_wa_num = preg_replace('/[^0-9]/', '', $bar_wa);
        ?>
        <div class="bottom-bar">
            <?php if(strpos($data['bottom_bar_style'], 'call') !== false && $bar_phone): ?>
            <a href="tel:<?php echo esc_attr($bar_phone); ?>" class="call">📞 Call</a>
            <?php endif; ?>
            <?php if(strpos($data['bottom_bar_style'], 'whatsapp') !== false && $bar_wa_num): ?>
            <a href="https://wa.me/<?php echo $bar_wa_num; ?>" class="wa">💬 WhatsApp</a>
            <?php endif; ?>
        </div>
        <?php endif; ?>
        
        </body></html>
        <?php
        $html = ob_get_clean();
        
        wp_send_json_success(array('html' => $html));
    }
    
    // SUBMIT LEAD - No auth required
    public static function handle_submit_lead() {
        $page_id = intval($_POST['page_id'] ?? 0);
        $name = sanitize_text_field($_POST['name'] ?? '');
        $email = sanitize_email($_POST['email'] ?? '');
        $phone = sanitize_text_field($_POST['phone'] ?? '');
        $message = sanitize_textarea_field($_POST['message'] ?? '');
        
        if (!$page_id || !$name || !$phone) {
            wp_send_json_error(array('message' => 'Please fill in all required fields.'));
        }
        
        $page = get_post($page_id);
        if (!$page) {
            wp_send_json_error(array('message' => 'Invalid page.'));
        }
        
        $owner_id = $page->post_author;
        
        global $wpdb;
        $result = $wpdb->insert($wpdb->prefix . 'hushot_leads', array(
            'page_id' => $page_id,
            'user_id' => $owner_id,
            'name' => $name,
            'email' => $email,
            'phone' => $phone,
            'message' => $message,
            'status' => 'new',
            'created_at' => current_time('mysql')
        ));
        
        if (!$result) {
            wp_send_json_error(array('message' => 'Could not save your information. Please try again.'));
        }
        
        // Email notification
        $owner = get_user_by('ID', $owner_id);
        if ($owner && $owner->user_email) {
            $subject = 'New Lead: ' . $name;
            $body = "You have a new lead from your landing page!\n\n";
            $body .= "Name: $name\n";
            $body .= "Phone: $phone\n";
            if ($email) $body .= "Email: $email\n";
            if ($message) $body .= "Message: $message\n";
            $body .= "\n\nPage: " . get_permalink($page_id);
            
            wp_mail($owner->user_email, $subject, $body);
        }
        
        wp_send_json_success(array('message' => 'Thank you! We will contact you soon.'));
    }
    
    // CSV Export for Leads
    public static function handle_export_leads() {
        if (!is_user_logged_in()) {
            wp_die('Please log in first.');
        }
        
        $user = wp_get_current_user();
        global $wpdb;
        
        $leads = $wpdb->get_results($wpdb->prepare(
            "SELECT l.name, l.phone, l.email, l.message, l.created_at, p.post_title as page_title 
             FROM {$wpdb->prefix}hushot_leads l 
             LEFT JOIN {$wpdb->posts} p ON l.page_id = p.ID 
             WHERE l.user_id=%d 
             ORDER BY l.created_at DESC", 
            $user->ID
        ));
        
        if (empty($leads)) {
            wp_die('No leads to export.');
        }
        
        // Set headers for CSV download
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=hushot-leads-' . date('Y-m-d') . '.csv');
        header('Pragma: no-cache');
        header('Expires: 0');
        
        $output = fopen('php://output', 'w');
        
        // Add BOM for Excel compatibility
        fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));
        
        // Header row
        fputcsv($output, array('Name', 'Phone', 'Email', 'Message', 'Page', 'Date'));
        
        // Data rows
        foreach ($leads as $lead) {
            fputcsv($output, array(
                $lead->name,
                $lead->phone,
                $lead->email,
                $lead->message,
                $lead->page_title,
                date('Y-m-d H:i', strtotime($lead->created_at))
            ));
        }
        
        fclose($output);
        exit;
    }
    
    // SAVE PRODUCTS TEMPLATE
    public static function handle_save_products_template() {
        if (!is_user_logged_in()) {
            wp_send_json_error(array('message' => 'Please login first.'));
        }
        
        $user_id = get_current_user_id();
        $name = sanitize_text_field($_POST['template_name'] ?? '');
        $products_json = $_POST['products_json'] ?? '';
        
        if (empty($name)) {
            wp_send_json_error(array('message' => 'Please enter a template name.'));
        }
        
        if (empty($products_json)) {
            wp_send_json_error(array('message' => 'No products to save.'));
        }
        
        // Get existing templates
        $templates = get_user_meta($user_id, 'hushot_products_templates', true);
        if (!is_array($templates)) {
            $templates = array();
        }
        
        // Add new template
        $templates[$name] = array(
            'name' => $name,
            'products' => $products_json,
            'created' => current_time('mysql')
        );
        
        // Save
        update_user_meta($user_id, 'hushot_products_templates', $templates);
        
        wp_send_json_success(array(
            'message' => 'Products template saved!',
            'templates' => array_keys($templates)
        ));
    }
    
    // GET PRODUCTS TEMPLATES
    public static function handle_get_products_templates() {
        if (!is_user_logged_in()) {
            wp_send_json_error(array('message' => 'Please login first.'));
        }
        
        $user_id = get_current_user_id();
        $templates = get_user_meta($user_id, 'hushot_products_templates', true);
        
        if (!is_array($templates)) {
            $templates = array();
        }
        
        wp_send_json_success(array(
            'templates' => $templates
        ));
    }
    
    // TRACK APP INSTALL - Available to all users
    public static function handle_track_install() {
        if (!wp_verify_nonce($_POST['_wpnonce'] ?? '', 'hushot_install')) {
            wp_send_json_error(array('message' => 'Security check failed.'));
        }
        
        $platform = sanitize_text_field($_POST['platform'] ?? 'unknown');
        $user_id = is_user_logged_in() ? get_current_user_id() : 0;
        
        // Get user's country from IP
        $country = 'Unknown';
        $ip = $_SERVER['REMOTE_ADDR'] ?? '';
        if ($ip && $ip !== '127.0.0.1') {
            $geo = @file_get_contents("http://ip-api.com/json/{$ip}?fields=country");
            if ($geo) {
                $geo_data = json_decode($geo, true);
                $country = $geo_data['country'] ?? 'Unknown';
            }
        }
        
        global $wpdb;
        $table = $wpdb->prefix . 'hushot_installs';
        
        // Create table if not exists
        $wpdb->query("CREATE TABLE IF NOT EXISTS {$table} (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            user_id bigint(20) DEFAULT 0,
            platform varchar(20) DEFAULT 'unknown',
            country varchar(100) DEFAULT 'Unknown',
            user_agent text,
            installed_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) {$wpdb->get_charset_collate()};");
        
        // Check if this user/device already recorded
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$table} WHERE user_id = %d AND platform = %s AND installed_at > DATE_SUB(NOW(), INTERVAL 24 HOUR)",
            $user_id, $platform
        ));
        
        if (!$existing) {
            $wpdb->insert($table, array(
                'user_id' => $user_id,
                'platform' => $platform,
                'country' => $country,
                'user_agent' => sanitize_text_field($_SERVER['HTTP_USER_AGENT'] ?? ''),
                'installed_at' => current_time('mysql')
            ));
        }
        
        wp_send_json_success(array('message' => 'Install tracked'));
    }
    
    // AI GENERATE IMAGE
    public static function handle_ai_generate_image() {
        if (!is_user_logged_in()) {
            wp_send_json_error(array('message' => 'Please log in first.'));
        }
        
        if (!Hushot_Membership::can_use_ai()) {
            wp_send_json_error(array('message' => 'AI features require Essential or Premium plan.'));
        }
        
        $prompt = sanitize_text_field($_POST['prompt'] ?? '');
        if (empty($prompt)) {
            wp_send_json_error(array('message' => 'Please provide a description.'));
        }
        
        // Get OpenAI API key
        $api_key = get_option('hushot_openai_key');
        if (empty($api_key)) {
            $api_key = get_user_meta(get_current_user_id(), 'hushot_openai_key', true);
        }
        
        if (empty($api_key)) {
            wp_send_json_error(array('message' => 'OpenAI API key not configured. Please contact support.'));
        }
        
        // Generate image using DALL-E
        $image_prompt = "Professional business image for: " . $prompt . ". Clean, modern style suitable for Facebook ads. High quality product/service photo.";
        
        $response = wp_remote_post('https://api.openai.com/v1/images/generations', array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type' => 'application/json',
            ),
            'body' => json_encode(array(
                'model' => 'dall-e-3',
                'prompt' => $image_prompt,
                'n' => 1,
                'size' => '1024x1024', // Will be displayed at 1200x628 aspect
                'quality' => 'standard'
            )),
            'timeout' => 60,
        ));
        
        if (is_wp_error($response)) {
            wp_send_json_error(array('message' => 'Failed to generate image: ' . $response->get_error_message()));
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if (!empty($body['data'][0]['url'])) {
            // Download and save to media library
            $image_url = $body['data'][0]['url'];
            
            require_once(ABSPATH . 'wp-admin/includes/media.php');
            require_once(ABSPATH . 'wp-admin/includes/file.php');
            require_once(ABSPATH . 'wp-admin/includes/image.php');
            
            $tmp = download_url($image_url);
            if (!is_wp_error($tmp)) {
                $file_array = array(
                    'name' => 'ai-generated-' . time() . '.png',
                    'tmp_name' => $tmp
                );
                
                $attachment_id = media_handle_sideload($file_array, 0, $prompt);
                
                if (!is_wp_error($attachment_id)) {
                    $saved_url = wp_get_attachment_url($attachment_id);
                    wp_send_json_success(array(
                        'image_url' => $saved_url,
                        'attachment_id' => $attachment_id
                    ));
                }
                
                @unlink($tmp);
            }
            
            // Fallback - return the OpenAI URL directly
            wp_send_json_success(array('image_url' => $image_url));
        }
        
        wp_send_json_error(array('message' => 'Failed to generate image. Please try again.'));
    }
    
    // Helper function to generate AI image for a page
    private static function generate_ai_image_for_page($prompt, $page_id) {
        // Get OpenAI API key
        $api_key = get_option('hushot_openai_key');
        if (empty($api_key)) {
            $api_key = get_option('hushot_openai_api_key');
        }
        if (empty($api_key)) {
            $api_key = get_user_meta(get_current_user_id(), 'hushot_openai_key', true);
        }
        
        if (empty($api_key)) {
            return null;
        }
        
        // Generate image using DALL-E
        $image_prompt = "Professional business image for: " . $prompt . ". Clean, modern, high-quality photo suitable for Facebook ads and landing pages. Aspect ratio 1200x628, no text overlays.";
        
        $response = wp_remote_post('https://api.openai.com/v1/images/generations', array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type' => 'application/json',
            ),
            'body' => json_encode(array(
                'model' => 'dall-e-3',
                'prompt' => $image_prompt,
                'n' => 1,
                'size' => '1792x1024', // Landscape format for Facebook
                'quality' => 'standard'
            )),
            'timeout' => 60,
        ));
        
        if (is_wp_error($response)) {
            return null;
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if (!empty($body['data'][0]['url'])) {
            $image_url = $body['data'][0]['url'];
            
            // Try to save to media library
            require_once(ABSPATH . 'wp-admin/includes/media.php');
            require_once(ABSPATH . 'wp-admin/includes/file.php');
            require_once(ABSPATH . 'wp-admin/includes/image.php');
            
            $tmp = download_url($image_url);
            if (!is_wp_error($tmp)) {
                $file_array = array(
                    'name' => 'ai-page-' . $page_id . '-' . time() . '.png',
                    'tmp_name' => $tmp
                );
                
                $attachment_id = media_handle_sideload($file_array, $page_id, $prompt);
                
                if (!is_wp_error($attachment_id)) {
                    $saved_url = wp_get_attachment_url($attachment_id);
                    @unlink($tmp);
                    return array('image_url' => $saved_url, 'attachment_id' => $attachment_id);
                }
                
                @unlink($tmp);
            }
            
            // Fallback - return the OpenAI URL directly
            return array('image_url' => $image_url);
        }
        
        return null;
    }
    
    /**
     * Handle Visual Builder Save
     */
    private static function decode_json_payload($raw) {
        if ($raw === '' || $raw === null) return null;

        // Try a few safe variants first (no stripslashes).
        $candidates = array(
            (string)$raw,
            wp_unslash((string)$raw),
        );

        foreach ($candidates as $cand) {
            $cand = trim($cand);
            $cand = preg_replace('/^\xEF\xBB\xBF/', '', $cand); // Remove UTF-8 BOM if present

            $decoded = json_decode($cand, true);

            // Handle double-encoded JSON: "[{...}]"
            if (is_string($decoded)) {
                $maybe = trim($decoded);
                if ($maybe !== '' && (strpos($maybe, '[') === 0 || strpos($maybe, '{') === 0)) {
                    $decoded2 = json_decode($maybe, true);
                    if (is_array($decoded2)) $decoded = $decoded2;
                }
            }

            if (is_array($decoded)) return $decoded;
        }

        // Last-resort recovery for legacy corrupted payloads.
        // This is ONLY used if the safe variants failed.
        foreach ($candidates as $cand) {
            $cand2 = stripslashes($cand);
            $decoded = json_decode($cand2, true);
            if (is_array($decoded)) return $decoded;
        }

        return null;
    }

    private static function save_visual_sections_to_meta($page_id, $sections_raw) {
        $decoded = self::decode_json_payload($sections_raw);
        if (!is_array($decoded)) {
            return new WP_Error('hushot_invalid_sections', 'Invalid sections JSON. Please click Save again.');
        }

        // Store JSON exactly as valid JSON (do not corrupt escape sequences)
        update_post_meta($page_id, '_hushot_sections', wp_json_encode($decoded, JSON_UNESCAPED_UNICODE));

        // Extract compatibility fields used by legacy rendering / analytics
        foreach ($decoded as $section) {
            if (!is_array($section) || empty($section['type'])) continue;

            if ($section['type'] === 'hero') {
                update_post_meta($page_id, '_hushot_header_title', sanitize_text_field($section['headline'] ?? ''));
                update_post_meta($page_id, '_hushot_header_subtitle', sanitize_text_field($section['subheadline'] ?? ''));
                update_post_meta($page_id, '_hushot_image_url', esc_url_raw($section['image'] ?? ''));
                if (!empty($section['video'])) {
                    update_post_meta($page_id, '_hushot_video_file_url', esc_url_raw($section['video']));
                }
            }

            if ($section['type'] === 'features') {
                $items = $section['items'] ?? '';
                if (is_array($items)) {
                    $lines = array();
                    foreach ($items as $it) {
                        $it = trim((string)$it);
                        if ($it !== '') $lines[] = $it;
                    }
                    $items = implode("\n", $lines);
                }
                update_post_meta($page_id, '_hushot_features', sanitize_textarea_field((string)$items));
            }

            if ($section['type'] === 'cta') {
                update_post_meta($page_id, '_hushot_cta_text', sanitize_text_field($section['button'] ?? 'Get Started'));
                update_post_meta($page_id, '_hushot_description', sanitize_text_field($section['text'] ?? ''));
                $action = $section['action'] ?? 'whatsapp';
                if ($action === 'whatsapp') {
                    update_post_meta($page_id, '_hushot_whatsapp', sanitize_text_field($section['whatsapp'] ?? ''));
                    update_post_meta($page_id, '_hushot_cta_type', 'whatsapp');
                } elseif ($action === 'phone') {
                    update_post_meta($page_id, '_hushot_phone', sanitize_text_field($section['phone'] ?? ''));
                    update_post_meta($page_id, '_hushot_cta_type', 'phone');
                } elseif ($action === 'link') {
                    update_post_meta($page_id, '_hushot_link_url', esc_url_raw($section['link'] ?? ''));
                    update_post_meta($page_id, '_hushot_cta_type', 'link');
                }
            }

            // Footer section extras
            if ($section['type'] === 'footer') {
                update_post_meta($page_id, '_hushot_footer_text', sanitize_text_field($section['text'] ?? ''));
                if (isset($section['tagline'])) update_post_meta($page_id, '_hushot_footer_tagline', sanitize_text_field($section['tagline']));
                if (isset($section['address'])) update_post_meta($page_id, '_hushot_footer_address', sanitize_text_field($section['address']));
                if (isset($section['disclaimer'])) update_post_meta($page_id, '_hushot_footer_disclaimer', sanitize_textarea_field($section['disclaimer']));
                if (isset($section['facebook'])) update_post_meta($page_id, '_hushot_footer_facebook', esc_url_raw($section['facebook']));
                if (isset($section['instagram'])) update_post_meta($page_id, '_hushot_footer_instagram', esc_url_raw($section['instagram']));
                if (isset($section['x'])) update_post_meta($page_id, '_hushot_footer_x', esc_url_raw($section['x']));
                if (isset($section['waurl'])) update_post_meta($page_id, '_hushot_footer_whatsapp_url', esc_url_raw($section['waurl']));
                if (isset($section['showSocial'])) update_post_meta($page_id, '_hushot_footer_show_social', $section['showSocial'] ? '1' : '');
            }

            // Products section (More Products)
            if ($section['type'] === 'products') {
                if (isset($section['title'])) {
                    update_post_meta($page_id, '_hushot_products_title', sanitize_text_field($section['title']));
                }
                if (isset($section['currency']) && $section['currency']) {
                    update_post_meta($page_id, '_hushot_currency', sanitize_text_field($section['currency']));
                }
                $prods = $section['products'] ?? array();
                if (is_array($prods)) {
                    $clean = array();
                    foreach ($prods as $p) {
                        if (!is_array($p)) continue;
                        $name = sanitize_text_field($p['name'] ?? '');
                        if ($name === '') continue;
                        $price = isset($p['price']) ? (string)$p['price'] : '';
                        $clean[] = array(
                            'name' => $name,
                            'price' => $price,
                            'old_price' => isset($p['old_price']) ? (string)$p['old_price'] : '',
                            'new_price' => isset($p['new_price']) ? (string)$p['new_price'] : '',
                            'image' => esc_url_raw($p['image'] ?? ''),
                            'description' => sanitize_text_field($p['description'] ?? ''),
                            'show_whatsapp' => isset($p['show_whatsapp']) ? (bool)$p['show_whatsapp'] : true,
                            'show_link' => isset($p['show_link']) ? (bool)$p['show_link'] : false,
                            'link_url' => esc_url_raw($p['link_url'] ?? '')
                        );
                    }
                    if (!empty($clean)) {
                        update_post_meta($page_id, '_hushot_products_json', wp_json_encode($clean, JSON_UNESCAPED_UNICODE));
                        $list_lines = array();
                        foreach ($clean as $p) {
                            $line = $p['name'];
                            $pval = $p['new_price'] ?: ($p['price'] ?? '');
                            if ($pval !== '') $line .= ' - ' . $pval;
                            $list_lines[] = $line;
                        }
                        update_post_meta($page_id, '_hushot_products_list', implode("\n", $list_lines));
                    }
                }
            }
        }

        return true;
    }
    public static function handle_visual_save() {
        if (!is_user_logged_in()) {
            wp_send_json_error(array('message' => 'Please log in first.'));
        }
        
        if (!wp_verify_nonce($_POST['_wpnonce'] ?? '', 'hushot_visual')) {
            wp_send_json_error(array('message' => 'Security check failed.'));
        }
        
        $user = wp_get_current_user();
        $page_id = intval($_POST['page_id'] ?? 0);
        $status = sanitize_text_field($_POST['status'] ?? 'draft');
        
        // Page data
        $title = sanitize_text_field($_POST['title'] ?? '');
        if (empty($title)) {
            $title = 'My Landing Page';
        }
        
        // Create or update page
        if ($page_id) {
            $existing = get_post($page_id);
            if (!$existing || $existing->post_author != $user->ID) {
                wp_send_json_error(array('message' => 'Page not found.'));
            }
            wp_update_post(array(
                'ID' => $page_id,
                'post_title' => $title,
                'post_status' => $status
            ));
        } else {
            $page_id = wp_insert_post(array(
                'post_type' => 'hushot_page',
                'post_title' => $title,
                'post_status' => $status,
                'post_author' => $user->ID
            ));
            
            if (is_wp_error($page_id)) {
                wp_send_json_error(array('message' => 'Failed to create page.'));
            }
            
            // Initialize views
            update_post_meta($page_id, '_hushot_views', 0);
        }
        
        // Save Visual Builder sections JSON (required for live rendering)
        $sections = $_POST['sections'] ?? '';
        if ($sections !== '') {
            $res = self::save_visual_sections_to_meta($page_id, $sections);
            if (is_wp_error($res)) {
                wp_send_json_error(array('message' => $res->get_error_message()));
            }
        }
        
        // Other meta fields
        $template = sanitize_text_field($_POST['template'] ?? 'starter');
        $primary_color = sanitize_hex_color($_POST['primary_color'] ?? '#F7931E');
        
        update_post_meta($page_id, '_hushot_template', $template);
        update_post_meta($page_id, '_hushot_primary_color', $primary_color);
        update_post_meta($page_id, '_hushot_builder_type', 'visual');
        
        // Save sticky bar settings
        $sticky_bar = $_POST['sticky_bar'] ?? '';
        if ($sticky_bar && $sticky_bar !== 'null') {
            /*
             * Decode the sticky bar JSON using wp_unslash() instead of stripslashes().
             * Using stripslashes() on JSON can corrupt escape sequences like \n or \uXXXX,
             * which causes the live page to break. wp_unslash() safely reverses any
             * magic quotes added by WordPress without altering valid escapes. See Issue #1.
             */
            $bar_data = json_decode(wp_unslash($sticky_bar), true);
            if (is_array($bar_data)) {
                update_post_meta($page_id, '_hushot_sticky_bar', wp_json_encode($bar_data));
            }
        }
        
        // Set component order for compatibility
        $order = array('header', 'image', 'features', 'whatsapp', 'contact');
        update_post_meta($page_id, '_hushot_component_order', implode(',', $order));
        
        $response = array(
            'page_id' => $page_id,
            'message' => $status === 'publish' ? 'Page published!' : 'Page saved!'
        );
        
        if ($status === 'publish') {
            $response['permalink'] = get_permalink($page_id);
        }
        
        wp_send_json_success($response);
    }
    
    /**
     * Handle Publish Page
     */
    public static function handle_publish_page() {
        if (!is_user_logged_in()) {
            wp_send_json_error(array('message' => 'Please log in first.'));
        }
        
        if (!wp_verify_nonce($_POST['_wpnonce'] ?? '', 'hushot_save')) {
            wp_send_json_error(array('message' => 'Security check failed.'));
        }
        
        $user = wp_get_current_user();
        $page_id = intval($_POST['page_id'] ?? 0);
        
        if (!$page_id) {
            wp_send_json_error(array('message' => 'Page ID required.'));
        }
        
        $page = get_post($page_id);
        if (!$page || $page->post_author != $user->ID) {
            wp_send_json_error(array('message' => 'Page not found.'));
        }

        // If the client sends Visual Builder payload on Publish, save it first.
        // This prevents a common issue where the editor shows content but Publish only changes status,
        // resulting in live pages missing sections.
        if (isset($_POST['sections'])) {
            $res = self::save_visual_sections_to_meta($page_id, $_POST['sections']);
            if (is_wp_error($res)) {
                wp_send_json_error(array('message' => $res->get_error_message()));
            }
            update_post_meta($page_id, '_hushot_builder_type', 'visual');
        }

        if (isset($_POST['sticky_bar']) && $_POST['sticky_bar'] && $_POST['sticky_bar'] !== 'null') {
            $bar = self::decode_json_payload($_POST['sticky_bar']);
            if (is_array($bar)) {
                update_post_meta($page_id, '_hushot_sticky_bar', wp_json_encode($bar, JSON_UNESCAPED_UNICODE));
            }
        }
        
        wp_update_post(array(
            'ID' => $page_id,
            'post_status' => 'publish'
        ));
        
        wp_send_json_success(array(
            'url' => get_permalink($page_id),
            'message' => 'Page published!'
        ));
    }
    
    /**
     * Handle Website URL Crawl for AI Builder
     */
    public static function handle_crawl_website() {
        if (!is_user_logged_in()) {
            wp_send_json_error(array('message' => 'Please log in first.'));
        }
        
        if (!Hushot_Membership::can_use_ai()) {
            wp_send_json_error(array('message' => 'AI features require Essential or Premium plan.'));
        }
        
        $url = esc_url_raw($_POST['url'] ?? '');
        if (empty($url) || !filter_var($url, FILTER_VALIDATE_URL)) {
            wp_send_json_error(array('message' => 'Please enter a valid URL.'));
        }
        
        // Fetch the website content
        $response = wp_remote_get($url, array(
            'timeout' => 15,
            'user-agent' => 'Mozilla/5.0 (compatible; Hushot/1.0)',
            'sslverify' => false
        ));
        
        if (is_wp_error($response)) {
            wp_send_json_error(array('message' => 'Could not access the website. Please try again.'));
        }
        
        $html = wp_remote_retrieve_body($response);
        if (empty($html)) {
            wp_send_json_error(array('message' => 'Could not read website content.'));
        }
        
        // Extract text content
        $content = strip_tags(preg_replace('/<script[^>]*>.*?<\/script>/is', '', $html));
        $content = preg_replace('/\s+/', ' ', $content);
        $content = substr(trim($content), 0, 4000); // Limit content
        
        // Extract title
        preg_match('/<title>([^<]+)<\/title>/i', $html, $title_match);
        $title = $title_match[1] ?? '';
        
        // Extract meta description
        preg_match('/<meta[^>]+name=["\']description["\'][^>]+content=["\']([^"\']+)/i', $html, $desc_match);
        $description = $desc_match[1] ?? '';
        
        // Use OpenAI to analyze and generate landing page content
        $api_key = get_option('hushot_openai_api_key');
        if (empty($api_key)) {
            // Return basic extraction without AI
            wp_send_json_success(array(
                'headline' => $title,
                'description' => $description ?: substr($content, 0, 200),
                'features' => "Quality Products\nExcellent Service\nFast Delivery\nCustomer Support",
                'cta' => 'Contact Us'
            ));
        }
        
        // AI Analysis
        $prompt = "Analyze this website content and extract/generate marketing content for a landing page:\n\n" .
            "Website Title: {$title}\n" .
            "Meta Description: {$description}\n" .
            "Content: {$content}\n\n" .
            "Return ONLY a valid JSON object with these fields:\n" .
            "- headline: A catchy, marketing-focused headline (max 60 chars)\n" .
            "- subheadline: A supporting tagline (max 100 chars)\n" .
            "- description: 2-3 sentences about the business/offer\n" .
            "- features: Array of 4 key benefits/features\n" .
            "- cta: Call-to-action button text";
        
        $ai_response = wp_remote_post('https://api.openai.com/v1/chat/completions', array(
            'timeout' => 30,
            'headers' => array(
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type' => 'application/json'
            ),
            'body' => json_encode(array(
                'model' => 'gpt-4o-mini',
                'messages' => array(
                    array('role' => 'system', 'content' => 'You are a marketing expert. Extract and enhance website content for landing pages. Respond ONLY with valid JSON.'),
                    array('role' => 'user', 'content' => $prompt)
                ),
                'temperature' => 0.7,
                'max_tokens' => 500
            ))
        ));
        
        if (is_wp_error($ai_response)) {
            wp_send_json_success(array(
                'headline' => $title,
                'description' => $description,
                'features' => "Quality Products\nExcellent Service\nFast Delivery\nCustomer Support",
                'cta' => 'Contact Us'
            ));
        }
        
        $ai_body = json_decode(wp_remote_retrieve_body($ai_response), true);
        $ai_content = $ai_body['choices'][0]['message']['content'] ?? '';
        
        // Parse JSON from AI response
        $ai_content = preg_replace('/```json\s*|\s*```/', '', $ai_content);
        $parsed = json_decode($ai_content, true);
        
        if ($parsed) {
            wp_send_json_success(array(
                'headline' => $parsed['headline'] ?? $title,
                'subheadline' => $parsed['subheadline'] ?? '',
                'description' => $parsed['description'] ?? $description,
                'features' => is_array($parsed['features'] ?? null) ? implode("\n", $parsed['features']) : ($parsed['features'] ?? ''),
                'cta' => $parsed['cta'] ?? 'Contact Us'
            ));
        } else {
            wp_send_json_success(array(
                'headline' => $title,
                'description' => $description,
                'features' => "Quality Products\nExcellent Service\nFast Delivery\nCustomer Support",
                'cta' => 'Contact Us'
            ));
        }
    }
    
    /**
     * AI Image Generation Handler
     */
    public static function handle_generate_ai_image() {
        if (!is_user_logged_in()) {
            wp_send_json_error(array('message' => 'Please log in.'));
        }
        
        if (!wp_verify_nonce($_POST['_wpnonce'] ?? '', 'hushot_ai_image')) {
            wp_send_json_error(array('message' => 'Security check failed.'));
        }
        
        $user = wp_get_current_user();
        $plan = Hushot_Membership::get_user_plan();
        
        // Check plan limits
        $limits = array('free' => 0, 'essential' => 10, 'premium' => 40);
        $monthly_limit = $limits[$plan] ?? 0;
        
        if ($monthly_limit <= 0) {
            wp_send_json_error(array('message' => 'Upgrade to Essential or Premium to generate AI images.'));
        }
        
        $month_key = date('Y-m');
        $usage = (int)get_user_meta($user->ID, 'hushot_ai_images_' . $month_key, true);
        
        if ($usage >= $monthly_limit) {
            wp_send_json_error(array('message' => 'Monthly limit reached. Upgrade for more images.'));
        }
        
        // Get OpenAI API key
        $api_key = get_option('hushot_openai_api_key', '');
        if (empty($api_key)) {
            wp_send_json_error(array('message' => 'AI service not configured. Please contact admin.'));
        }
        
        $prompt = sanitize_text_field($_POST['prompt'] ?? '');
        $base_image = null;
        
        // Handle uploaded image
        if (!empty($_FILES['image'])) {
            $upload = wp_handle_upload($_FILES['image'], array('test_form' => false));
            if (!empty($upload['url'])) {
                $base_image = $upload['url'];
                // Enhance prompt with image context
                if (empty($prompt)) {
                    $prompt = 'Professional e-commerce product photo, catalog style, white background, studio lighting';
                }
            }
        }
        
        if (empty($prompt) && empty($base_image)) {
            wp_send_json_error(array('message' => 'Please provide an image or description.'));
        }
        
        // Add professional product photo context to prompt
        $full_prompt = $prompt . '. Professional product photography for Facebook catalog, 1080x1080 square format, clean background, premium look, e-commerce ready.';
        
        // Generate 3 variations using DALL-E 3
        $images = array();
        
        for ($i = 0; $i < 3; $i++) {
            $variation_prompt = $full_prompt;
            if ($i === 1) $variation_prompt .= ' Alternative angle.';
            if ($i === 2) $variation_prompt .= ' Lifestyle context.';
            
            $response = wp_remote_post('https://api.openai.com/v1/images/generations', array(
                'timeout' => 60,
                'headers' => array(
                    'Authorization' => 'Bearer ' . $api_key,
                    'Content-Type' => 'application/json',
                ),
                'body' => json_encode(array(
                    'model' => 'dall-e-3',
                    'prompt' => $variation_prompt,
                    'n' => 1,
                    'size' => '1024x1024',
                    'quality' => 'standard',
                ))
            ));
            
            if (!is_wp_error($response)) {
                $body = json_decode(wp_remote_retrieve_body($response), true);
                if (!empty($body['data'][0]['url'])) {
                    // Download and save to WordPress
                    $img_url = $body['data'][0]['url'];
                    $upload = media_sideload_image($img_url, 0, null, 'src');
                    if (!is_wp_error($upload)) {
                        $images[] = $upload;
                    } else {
                        $images[] = $img_url;
                    }
                }
            }
        }
        
        if (empty($images)) {
            wp_send_json_error(array('message' => 'Failed to generate images. Please try again.'));
        }
        
        // Update usage
        update_user_meta($user->ID, 'hushot_ai_images_' . $month_key, $usage + count($images));
        
        // Save to history
        $history = get_user_meta($user->ID, 'hushot_ai_generated_images', true) ?: array();
        foreach ($images as $img) {
            array_unshift($history, array('url' => $img, 'date' => current_time('mysql')));
        }
        $history = array_slice($history, 0, 50); // Keep last 50
        update_user_meta($user->ID, 'hushot_ai_generated_images', $history);
        
        wp_send_json_success(array('images' => $images));
    }
    
    /**
     * Get Banks List
     */
    public static function handle_get_banks() {
        if (!wp_verify_nonce($_GET['_wpnonce'] ?? '', 'hushot_banks')) {
            wp_send_json_error(array('message' => 'Security check failed.'));
        }
        
        $flw_secret = get_option('hushot_flw_secret_key', '');
        // Default set of Nigerian banks & common mobile money providers as a fallback
        $default_banks = array(
            array('code' => '044', 'name' => 'Access Bank'),
            array('code' => '050', 'name' => 'Ecobank'),
            array('code' => '070', 'name' => 'Fidelity Bank'),
            array('code' => '058', 'name' => 'Guaranty Trust Bank (GTBank)'),
            array('code' => '011', 'name' => 'First Bank of Nigeria'),
            array('code' => '221', 'name' => 'Zenith Bank'),
            array('code' => 'MTN_MOMO', 'name' => 'MTN Mobile Money'),
            array('code' => 'AIRTEL_MONEY', 'name' => 'Airtel Money'),
        );

        // If Flutterwave secret is set, attempt to fetch live banks
        if (!empty($flw_secret)) {
            $response = wp_remote_get('https://api.flutterwave.com/v3/banks/NG', array(
                'headers' => array('Authorization' => 'Bearer ' . $flw_secret),
            ));

            if (!is_wp_error($response)) {
                $body = json_decode(wp_remote_retrieve_body($response), true);
                if (!empty($body) && isset($body['status']) && $body['status'] === 'success' && !empty($body['data'])) {
                    wp_send_json_success(array('banks' => $body['data']));
                }
            }
            // If response error or invalid, fall through to default
        }

        // If we reach here, either secret missing or remote failed; return default list
        wp_send_json_success(array('banks' => $default_banks));
    }
    
    /**
     * Verify Bank Account
     */
    public static function handle_verify_account() {
        if (!is_user_logged_in()) {
            wp_send_json_error(array('message' => 'Please log in.'));
        }
        
        if (!wp_verify_nonce($_POST['_wpnonce'] ?? '', 'hushot_verify')) {
            wp_send_json_error(array('message' => 'Security check failed.'));
        }
        
        $bank_code = sanitize_text_field($_POST['bank_code'] ?? '');
        $account_number = sanitize_text_field($_POST['account_number'] ?? '');
        
        if (empty($bank_code) || empty($account_number)) {
            wp_send_json_error(array('message' => 'Missing details.'));
        }
        
        $flw_secret = get_option('hushot_flw_secret_key', '');
        
        $response = wp_remote_post('https://api.flutterwave.com/v3/accounts/resolve', array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $flw_secret,
                'Content-Type' => 'application/json',
            ),
            'body' => json_encode(array(
                'account_number' => $account_number,
                'account_bank' => $bank_code,
            ))
        ));
        
        if (is_wp_error($response)) {
            wp_send_json_error(array('message' => 'Verification failed.'));
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if ($body['status'] === 'success') {
            wp_send_json_success(array('account_name' => $body['data']['account_name']));
        } else {
            wp_send_json_error(array('message' => 'Account not found.'));
        }
    }
    
    /**
     * Seller Setup - Create Flutterwave Subaccount
     */
    public static function handle_seller_setup() {
        if (!is_user_logged_in()) {
            wp_send_json_error(array('message' => 'Please log in.'));
        }
        
        if (!wp_verify_nonce($_POST['_wpnonce'] ?? '', 'hushot_seller')) {
            wp_send_json_error(array('message' => 'Security check failed.'));
        }
        
        $user = wp_get_current_user();
        
        // Get payout type
        $payout_type = sanitize_text_field($_POST['payout_type'] ?? 'bank');
        $business_name = sanitize_text_field($_POST['business_name'] ?? '');
        
        if (empty($business_name)) {
            wp_send_json_error(array('message' => 'Please enter your business name.'));
        }
        
        // Check if already has subaccount - if so, this is an update
        $existing_subaccount = get_user_meta($user->ID, 'hushot_flw_subaccount_id', true);
        
        if ($payout_type === 'mobile') {
            // Mobile Money payout
            $mobile_network = sanitize_text_field($_POST['mobile_network'] ?? '');
            $mobile_number = sanitize_text_field($_POST['mobile_number'] ?? '');
            
            if (empty($mobile_network)) {
                wp_send_json_error(array('message' => 'Please select your mobile network.'));
            }
            if (empty($mobile_number)) {
                wp_send_json_error(array('message' => 'Please enter your mobile number.'));
            }
            
            // Save mobile money settings to user meta
            update_user_meta($user->ID, 'hushot_payout_type', 'mobile');
            update_user_meta($user->ID, 'hushot_mobile_network', $mobile_network);
            update_user_meta($user->ID, 'hushot_mobile_number', $mobile_number);
            update_user_meta($user->ID, 'hushot_business_name', $business_name);
            
            // For mobile money, we generate a placeholder subaccount ID if none exists
            // Real mobile money integration would connect to Flutterwave Mobile Money API
            if (!$existing_subaccount) {
                $placeholder_id = 'MOMO_' . $user->ID . '_' . time();
                update_user_meta($user->ID, 'hushot_flw_subaccount_id', $placeholder_id);
            }
            
            wp_send_json_success(array('message' => 'Mobile money payout settings saved!'));
            
        } else {
            // Bank Transfer payout
            $bank_code = sanitize_text_field($_POST['bank_code'] ?? '');
            $account_number = sanitize_text_field($_POST['account_number'] ?? '');
            $account_name = sanitize_text_field($_POST['account_name'] ?? '');
            
            if (empty($bank_code)) {
                wp_send_json_error(array('message' => 'Please select your bank.'));
            }
            if (empty($account_number) || strlen($account_number) !== 10) {
                wp_send_json_error(array('message' => 'Please enter a valid 10-digit account number.'));
            }
            if (empty($account_name)) {
                wp_send_json_error(array('message' => 'Account verification required.'));
            }
            
            // Save bank settings to user meta first
            update_user_meta($user->ID, 'hushot_payout_type', 'bank');
            update_user_meta($user->ID, 'hushot_bank_code', $bank_code);
            update_user_meta($user->ID, 'hushot_account_number', $account_number);
            update_user_meta($user->ID, 'hushot_account_name', $account_name);
            update_user_meta($user->ID, 'hushot_business_name', $business_name);
            
            // If already has subaccount, just update the meta and return success
            if ($existing_subaccount && strpos($existing_subaccount, 'MOMO_') === false) {
                wp_send_json_success(array('message' => 'Bank payout settings updated!'));
            }
            
            // Create Flutterwave subaccount for new users
            $flw_secret = get_option('hushot_flw_secret_key', '');
            
            if (empty($flw_secret)) {
                // No Flutterwave key - save settings but skip API call
                $placeholder_id = 'BANK_' . $user->ID . '_' . time();
                update_user_meta($user->ID, 'hushot_flw_subaccount_id', $placeholder_id);
                wp_send_json_success(array('message' => 'Bank payout settings saved!'));
            }
            
            // Determine platform fee
            $platform_fee = floatval(get_option('hushot_platform_fee', 5));
            if ($platform_fee < 0) $platform_fee = 0;
            if ($platform_fee > 100) $platform_fee = 100;
            $seller_share = max(0, 100 - $platform_fee);
            $split_value = $seller_share / 100;
            
            // Prepare payload for Flutterwave subaccount creation
            $payload = array(
                'account_bank'           => $bank_code,
                'account_number'         => $account_number,
                'business_name'          => $business_name,
                'business_email'         => $user->user_email,
                'business_contact'       => $user->display_name,
                'business_contact_mobile'=> get_user_meta($user->ID, 'hushot_phone', true),
                'business_mobile'        => get_user_meta($user->ID, 'hushot_phone', true),
                'country'                => 'NG',
                'split_type'             => 'percentage',
                'split_value'            => $split_value,
            );
            
            // Create Flutterwave subaccount
            $response = wp_remote_post('https://api.flutterwave.com/v3/subaccounts', array(
                'headers' => array(
                    'Authorization' => 'Bearer ' . $flw_secret,
                    'Content-Type'  => 'application/json',
                ),
                'body'    => json_encode($payload),
                'timeout' => 30
            ));
            
            if (is_wp_error($response)) {
                // Save anyway with placeholder
                $placeholder_id = 'BANK_' . $user->ID . '_' . time();
                update_user_meta($user->ID, 'hushot_flw_subaccount_id', $placeholder_id);
                wp_send_json_success(array('message' => 'Bank payout settings saved! (Flutterwave connection pending)'));
            }
            
            $body = json_decode(wp_remote_retrieve_body($response), true);
            
            if (isset($body['status']) && $body['status'] === 'success' && !empty($body['data']['subaccount_id'])) {
                $subaccount_id = $body['data']['subaccount_id'];
                update_user_meta($user->ID, 'hushot_flw_subaccount_id', $subaccount_id);
                wp_send_json_success(array('message' => 'Seller account created successfully!'));
            }
            
            // If Flutterwave failed, still save with placeholder
            $placeholder_id = 'BANK_' . $user->ID . '_' . time();
            update_user_meta($user->ID, 'hushot_flw_subaccount_id', $placeholder_id);
            wp_send_json_success(array('message' => 'Bank payout settings saved!'));
        }
    }
    
    /**
     * Marketplace Checkout - Collect Payment with Split
     */
    public static function handle_marketplace_checkout() {
        $page_id = intval($_POST['page_id'] ?? 0);
        $amount = floatval($_POST['amount'] ?? 0);
        $currency = sanitize_text_field($_POST['currency'] ?? 'NGN');
        $product_name = sanitize_text_field($_POST['product_name'] ?? '');
        $customer_email = sanitize_email($_POST['customer_email'] ?? '');
        $customer_name = sanitize_text_field($_POST['customer_name'] ?? '');
        $customer_phone = sanitize_text_field($_POST['customer_phone'] ?? '');
        
        if (!$page_id || !$amount || !$customer_email) {
            wp_send_json_error(array('message' => 'Missing required fields.'));
        }
        
        // Get page owner
        $page = get_post($page_id);
        if (!$page) {
            wp_send_json_error(array('message' => 'Page not found.'));
        }
        
        $seller_id = $page->post_author;
        $subaccount_id = get_user_meta($seller_id, 'hushot_flw_subaccount_id', true);
        
        if (!$subaccount_id) {
            wp_send_json_error(array('message' => 'Seller not set up for payments.'));
        }
        
        // Generate transaction reference
        $tx_ref = 'HUSHOT-MKT-' . time() . '-' . wp_rand(1000, 9999);
        
        $flw_public = get_option('hushot_flw_public_key', '');
        
        // Calculate commission based on platform fee
        $fee_percent = floatval(get_option('hushot_platform_fee', 5));
        if ($fee_percent < 0) $fee_percent = 0;
        if ($fee_percent > 100) $fee_percent = 100;
        $commission = $amount * ($fee_percent / 100.0);
        
        // Store pending transaction
        global $wpdb;
        $table = $wpdb->prefix . 'hushot_marketplace_transactions';
        
        $wpdb->insert($table, array(
            'tx_ref' => $tx_ref,
            'seller_id' => $seller_id,
            'page_id' => $page_id,
            'product_name' => $product_name,
            'customer_email' => $customer_email,
            'customer_name' => $customer_name,
            'customer_phone' => $customer_phone,
            'amount' => $amount,
            'commission' => $commission,
            'currency' => $currency,
            'status' => 'pending',
            'created_at' => current_time('mysql'),
        ));
        
        // Return Flutterwave checkout config
        // Compute split ratio for Flutterwave payment. Ratio is relative to the
        // platform fee. For example, if the platform takes 5%, the seller gets
        // 95% which maps to a ratio of 19 (95/5). If fee is 0, default ratio 1.
        $ratio = 1;
        if ($fee_percent > 0 && $fee_percent < 100) {
            $ratio = intval(round((100 - $fee_percent) / $fee_percent));
            if ($ratio < 1) $ratio = 1;
        }

        wp_send_json_success(array(
            'tx_ref'   => $tx_ref,
            'public_key' => $flw_public,
            'amount'   => $amount,
            'currency' => $currency,
            'customer' => array(
                'email'        => $customer_email,
                'name'         => $customer_name,
                'phone_number' => $customer_phone,
            ),
            'subaccounts' => array(
                array(
                    'id' => $subaccount_id,
                    'transaction_split_ratio' => $ratio,
                )
            ),
            'customizations' => array(
                'title'       => get_bloginfo('name'),
                'description' => 'Payment for ' . $product_name,
            )
        ));
    }
    
    /**
     * Flutterwave Webhook Handler
     */
    public static function handle_flw_webhook() {
        // Verify webhook signature
        $secret_hash = get_option('hushot_flw_webhook_secret', '');
        $signature = $_SERVER['HTTP_VERIF_HASH'] ?? '';
        
        if ($secret_hash && $signature !== $secret_hash) {
            http_response_code(401);
            exit('Unauthorized');
        }
        
        $payload = json_decode(file_get_contents('php://input'), true);
        
        if (!$payload || !isset($payload['event'])) {
            exit('Invalid payload');
        }
        
        // Handle charge.completed event
        if ($payload['event'] === 'charge.completed') {
            $data = $payload['data'];
            $tx_ref = $data['tx_ref'] ?? '';
            $status = $data['status'] ?? '';
            
            if (strpos($tx_ref, 'HUSHOT-MKT-') === 0 && $status === 'successful') {
                global $wpdb;
                $table = $wpdb->prefix . 'hushot_marketplace_transactions';
                
                // Verify transaction exists
                $tx = $wpdb->get_row($wpdb->prepare(
                    "SELECT * FROM $table WHERE tx_ref = %s AND status = 'pending'",
                    $tx_ref
                ));
                
                if ($tx) {
                    // Update status
                    $wpdb->update($table, 
                        array(
                            'status' => 'completed',
                            'flw_ref' => $data['flw_ref'] ?? '',
                            'completed_at' => current_time('mysql'),
                        ),
                        array('tx_ref' => $tx_ref)
                    );
                    
                    // Send notification to seller
                    $seller = get_user_by('ID', $tx->seller_id);
                    if ($seller) {
                        $seller_amount = $tx->amount - $tx->commission;
                        wp_mail(
                            $seller->user_email,
                            '💰 New Sale on Hushot!',
                            "You just made a sale!\n\n" .
                            "Product: {$tx->product_name}\n" .
                            "Amount: {$tx->currency} " . number_format($seller_amount, 2) . "\n" .
                            "Customer: {$tx->customer_name}\n\n" .
                            "View your dashboard: " . home_url('/hushot-seller-dashboard/')
                        );
                    }
                }
            }
        }
        
        exit('OK');
    }
}
