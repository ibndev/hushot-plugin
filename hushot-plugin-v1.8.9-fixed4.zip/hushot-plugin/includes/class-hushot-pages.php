<?php
if (!defined('ABSPATH')) exit;

class Hushot_Pages {
    
    // Slug mappings for pages
    private static $slug_map = array(
        'home' => 'home',
        'login' => 'login',
        'register' => 'register',
        'forgot-password' => 'forgot-password',
        'reset-password' => 'reset-password',
        'dashboard' => 'dashboard',
        'my-pages' => 'my-pages',
        'create-page' => 'create-page',
        'edit-page' => 'edit-page',
        'templates' => 'templates',
        'leads' => 'leads',
        'analytics' => 'analytics',
        'ai-generator' => 'ai-builder',
        'ai-image' => 'ai-image',
        'visual-builder' => 'visual-builder',
        'my-account' => 'my-account',
        'billing' => 'billing',
        'cancel-subscription' => 'cancel-subscription',
        'pricing' => 'pricing',
        'checkout' => 'checkout',
        'order-confirmation' => 'order-confirmation',
        'ads-dashboard' => 'ads-dashboard',
        'ads-promote' => 'boost',
        'seller-dashboard' => 'seller-dashboard',
        'seller-setup' => 'seller-setup',
        'support' => 'support',
        'install-app' => 'install-app',
    );
    
    public static function init() {
        // Nothing needed
    }
    
    public static function get_page_url($key) {
        $page_ids = get_option('hushot_page_ids', array());
        if (!empty($page_ids[$key])) {
            return get_permalink($page_ids[$key]);
        }
        // Try new slug format first
        $slug = self::$slug_map[$key] ?? $key;
        $page = get_page_by_path($slug);
        if ($page) return get_permalink($page->ID);
        // Fall back to old format
        $page = get_page_by_path('hushot-' . $key);
        if ($page) return get_permalink($page->ID);
        return home_url('/' . $slug);
    }
    
    public static function get_page_id($key) {
        $page_ids = get_option('hushot_page_ids', array());
        return $page_ids[$key] ?? 0;
    }
}
