<?php
if (!defined('ABSPATH')) exit;

class Hushot_Membership {
    
    public static function get_default_plans() {
        // ORDER: Premium FIRST, Essential, Free LAST
        return array(
            'premium' => array(
                'name' => 'Premium',
                'description' => 'For Enterprises',
                'pricing' => array(
                    'monthly' => 0.99,        // Display as $0.99/month
                    'biannual' => 5.34,       // 6 months with 10% off ($0.99 * 6 * 0.9)
                    'yearly' => 9.50,         // 12 months with 20% off ($0.99 * 12 * 0.8) - BILLED YEARLY
                ),
                'activation_fee' => 0.14,     // Trial unlock fee
                'features' => array(
                    'pages' => -1,
                    'ai_access' => true,
                    'ai_limit' => -1,
                    'templates' => array('free', 'essential', 'premium'),
                    'buttons' => 'all',
                    'watermark' => false,
                    'custom_colors' => true,
                    'analytics' => true,
                ),
                'feature_list' => array(
                    'Unlimited Pages',
                    'Unlimited AI Generations',
                    'All Premium Templates',
                    'Priority Support',
                    'Custom Branding'
                ),
                'trial_enabled' => true,
                'trial_days' => 30,
            ),
            'essential' => array(
                'name' => 'Essential',
                'description' => 'For Growing Business',
                'pricing' => array(
                    'monthly' => 0.49,
                    'biannual' => 2.65,       // 6 months with 10% off
                    'yearly' => 4.70,         // 12 months with 20% off - BILLED YEARLY
                ),
                'activation_fee' => 0.10,
                'features' => array(
                    'pages' => 5,
                    'ai_access' => true,
                    'ai_limit' => 10,
                    'templates' => array('free', 'essential'),
                    'buttons' => 'all',
                    'watermark' => false,
                    'custom_colors' => true,
                    'analytics' => true,
                ),
                'feature_list' => array(
                    '5 Landing Pages',
                    'AI Content Generator',
                    'All Button Types',
                    'No Watermark',
                    'Analytics Dashboard'
                ),
                'trial_enabled' => true,
                'trial_days' => 30,
            ),
            'free' => array(
                'name' => 'Free',
                'description' => 'For Personal Use',
                'pricing' => array('monthly' => 0, 'biannual' => 0, 'yearly' => 0),
                'features' => array(
                    'pages' => 1,
                    'ai_access' => false,
                    'ai_limit' => 0,
                    'templates' => array('free'),
                    'buttons' => array('whatsapp_chat'),
                    'watermark' => true,
                    'custom_colors' => false,
                    'analytics' => false,
                ),
                'feature_list' => array(
                    '1 Landing Page',
                    'WhatsApp Button',
                    'Basic Templates',
                    'Hushot Watermark'
                ),
                'trial_enabled' => false,
            ),
        );
    }
    
    public static function get_plans() {
        $saved = get_option('hushot_plans');
        if ($saved && is_array($saved)) {
            return $saved;
        }
        return self::get_default_plans();
    }
    
    public static function save_plans($plans) {
        update_option('hushot_plans', $plans);
    }
    
    public static function get_plan($key) {
        $plans = self::get_plans();
        return $plans[$key] ?? null;
    }
    
    public static function get_user_plan($user_id = null) {
        if (!$user_id) $user_id = get_current_user_id();
        if (!$user_id) return 'free';
        
        global $wpdb;
        
        $sub = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}hushot_subscriptions WHERE user_id = %d AND status = 'active' ORDER BY id DESC LIMIT 1",
            $user_id
        ));
        if ($sub) return $sub->plan;
        
        $trial = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}hushot_trials WHERE user_id = %d AND status = 'active' AND expires_at > NOW() ORDER BY id DESC LIMIT 1",
            $user_id
        ));
        if ($trial) return $trial->plan;
        
        $membership = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}hushot_memberships WHERE user_id = %d AND status = 'active' ORDER BY id DESC LIMIT 1",
            $user_id
        ));
        if ($membership) return $membership->plan;
        
        return 'free';
    }
    
    public static function set_user_plan($user_id, $plan) {
        global $wpdb;
        
        $wpdb->delete($wpdb->prefix . 'hushot_memberships', array('user_id' => $user_id));
        $wpdb->insert($wpdb->prefix . 'hushot_memberships', array(
            'user_id' => $user_id,
            'plan' => $plan,
            'status' => 'active',
        ));
    }
    
    public static function is_on_trial($user_id = null) {
        if (!$user_id) $user_id = get_current_user_id();
        if (!$user_id) return false;
        
        global $wpdb;
        $trial = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}hushot_trials WHERE user_id = %d AND status = 'active' AND expires_at > NOW()",
            $user_id
        ));
        return !empty($trial);
    }
    
    public static function get_trial_days_remaining($user_id = null) {
        if (!$user_id) $user_id = get_current_user_id();
        if (!$user_id) return 0;
        
        global $wpdb;
        $trial = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}hushot_trials WHERE user_id = %d AND status = 'active' AND expires_at > NOW()",
            $user_id
        ));
        if (!$trial) return 0;
        
        $now = new DateTime();
        $expires = new DateTime($trial->expires_at);
        return max(0, $now->diff($expires)->days);
    }
    
    public static function start_trial($user_id, $plan = 'essential') {
        global $wpdb;
        
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}hushot_trials WHERE user_id = %d", $user_id
        ));
        if ($existing > 0) return new WP_Error('trial_used', 'Trial already used.');
        
        $plan_data = self::get_plan($plan);
        if (!$plan_data || !$plan_data['trial_enabled']) {
            return new WP_Error('no_trial', 'Trial not available.');
        }
        
        $days = $plan_data['trial_days'] ?? 30;
        $wpdb->insert($wpdb->prefix . 'hushot_trials', array(
            'user_id' => $user_id,
            'plan' => $plan,
            'expires_at' => date('Y-m-d H:i:s', strtotime("+{$days} days")),
            'status' => 'active',
        ));
        return true;
    }
    
    public static function can_create_page($user_id = null) {
        if (!$user_id) $user_id = get_current_user_id();
        if (!$user_id) return false;
        
        $plan = self::get_user_plan($user_id);
        $plan_data = self::get_plan($plan);
        if (!$plan_data) return false;
        
        $limit = $plan_data['features']['pages'];
        if ($limit === -1) return true;
        
        global $wpdb;
        $count = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'hushot_page' AND post_author = %d AND post_status = 'publish'",
            $user_id
        ));
        return $count < $limit;
    }
    
    public static function can_access_template($template_id, $user_id = null) {
        if (!$user_id) $user_id = get_current_user_id();
        if (!$user_id) return false;
        
        $template_tier = get_post_meta($template_id, '_hushot_template_tier', true) ?: 'free';
        $plan = self::get_user_plan($user_id);
        $plan_data = self::get_plan($plan);
        if (!$plan_data) return false;
        
        return in_array($template_tier, $plan_data['features']['templates']);
    }
    
    public static function can_use_ai($user_id = null) {
        if (!$user_id) $user_id = get_current_user_id();
        $plan = self::get_user_plan($user_id);
        $plan_data = self::get_plan($plan);
        return $plan_data && $plan_data['features']['ai_access'];
    }
    
    public static function get_ai_remaining($user_id = null) {
        if (!$user_id) $user_id = get_current_user_id();
        if (!$user_id) return 0;
        
        $plan = self::get_user_plan($user_id);
        $plan_data = self::get_plan($plan);
        if (!$plan_data || !$plan_data['features']['ai_access']) return 0;
        
        $limit = $plan_data['features']['ai_limit'];
        if ($limit === -1) return -1;
        
        global $wpdb;
        $used = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}hushot_ai WHERE user_id = %d AND month_year = %s",
            $user_id, date('Y-m')
        ));
        return max(0, $limit - $used);
    }
    
    public static function get_available_buttons($user_id = null) {
        if (!$user_id) $user_id = get_current_user_id();
        $plan = self::get_user_plan($user_id);
        $plan_data = self::get_plan($plan);
        if (!$plan_data) return array('whatsapp_chat');
        
        $buttons = $plan_data['features']['buttons'];
        if ($buttons === 'all') {
            return array('whatsapp_chat', 'call_now', 'get_directions', 'pay_online', 'book_now', 'order_now');
        }
        return $buttons;
    }
    
    public static function show_watermark($user_id = null) {
        if (!$user_id) $user_id = get_current_user_id();
        
        // Show watermark for users on trial (even if plan says no watermark)
        if (self::is_on_trial($user_id)) {
            return true;
        }
        
        $plan = self::get_user_plan($user_id);
        $plan_data = self::get_plan($plan);
        return $plan_data && $plan_data['features']['watermark'];
    }
    
    public static function is_paid_user($user_id = null) {
        $plan = self::get_user_plan($user_id);
        return in_array($plan, array('essential', 'premium'));
    }
}
