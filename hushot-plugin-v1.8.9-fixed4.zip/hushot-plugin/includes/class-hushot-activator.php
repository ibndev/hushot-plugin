<?php
/**
 * Hushot Activator - v1.8.4 URL Migration
 */
if (!defined('ABSPATH')) exit;

class Hushot_Activator {
    
    private static $pages = array(
        'home' => array('title' => 'Hushot', 'shortcode' => '[hushot_home]', 'slug' => 'home'),
        'login' => array('title' => 'Login', 'shortcode' => '[hushot_login]', 'slug' => 'login'),
        'register' => array('title' => 'Register', 'shortcode' => '[hushot_register]', 'slug' => 'register'),
        'forgot-password' => array('title' => 'Forgot Password', 'shortcode' => '[hushot_forgot_password]', 'slug' => 'forgot-password'),
        'reset-password' => array('title' => 'Reset Password', 'shortcode' => '[hushot_reset_password]', 'slug' => 'reset-password'),
        'dashboard' => array('title' => 'Dashboard', 'shortcode' => '[hushot_dashboard]', 'slug' => 'dashboard'),
        'my-pages' => array('title' => 'My Pages', 'shortcode' => '[hushot_my_pages]', 'slug' => 'my-pages'),
        'create-page' => array('title' => 'Create Page', 'shortcode' => '[hushot_create_page]', 'slug' => 'create-page'),
        'edit-page' => array('title' => 'Edit Page', 'shortcode' => '[hushot_edit_page]', 'slug' => 'edit-page'),
        'templates' => array('title' => 'Templates', 'shortcode' => '[hushot_templates]', 'slug' => 'templates'),
        'leads' => array('title' => 'Leads', 'shortcode' => '[hushot_leads]', 'slug' => 'leads'),
        'analytics' => array('title' => 'Analytics', 'shortcode' => '[hushot_analytics]', 'slug' => 'analytics'),
        'ai-generator' => array('title' => 'AI Builder', 'shortcode' => '[hushot_ai_generator]', 'slug' => 'ai-builder'),
        'ai-image' => array('title' => 'AI Image', 'shortcode' => '[hushot_ai_image]', 'slug' => 'ai-image'),
        'visual-builder' => array('title' => 'Visual Builder', 'shortcode' => '[hushot_visual_builder]', 'slug' => 'visual-builder'),
        'my-account' => array('title' => 'My Account', 'shortcode' => '[hushot_my_account]', 'slug' => 'my-account'),
        'billing' => array('title' => 'Billing', 'shortcode' => '[hushot_billing]', 'slug' => 'billing'),
        'cancel-subscription' => array('title' => 'Cancel Subscription', 'shortcode' => '[hushot_cancel_subscription]', 'slug' => 'cancel-subscription'),
        'pricing' => array('title' => 'Pricing', 'shortcode' => '[hushot_pricing]', 'slug' => 'pricing'),
        'checkout' => array('title' => 'Checkout', 'shortcode' => '[hushot_checkout]', 'slug' => 'checkout'),
        'order-confirmation' => array('title' => 'Order Confirmation', 'shortcode' => '[hushot_order_confirmation]', 'slug' => 'order-confirmation'),
        'ads-dashboard' => array('title' => 'Ads Dashboard', 'shortcode' => '[hushot_ads_dashboard]', 'slug' => 'ads-dashboard'),
        'ads-promote' => array('title' => 'Boost Landing Page', 'shortcode' => '[hushot_ads_promote]', 'slug' => 'boost'),
        'seller-dashboard' => array('title' => 'Seller Dashboard', 'shortcode' => '[hushot_seller_dashboard]', 'slug' => 'seller-dashboard'),
        'seller-setup' => array('title' => 'Seller Setup', 'shortcode' => '[hushot_seller_setup]', 'slug' => 'seller-setup'),
        'support' => array('title' => 'Support', 'shortcode' => '[hushot_support]', 'slug' => 'support'),
        'install-app' => array('title' => 'Install App', 'shortcode' => '[hushot_install_app]', 'slug' => 'install-app'),
    );
    
    /**
     * Migrate old hushot-* URLs to clean URLs
     */
    public static function migrate_urls() {
        global $wpdb;
        if (get_option('hushot_urls_migrated_v184')) return;
        
        $page_ids = get_option('hushot_page_ids', array());
        
        foreach (self::$pages as $key => $data) {
            $new_slug = $data['slug'];
            $old_slug = 'hushot-' . $key;
            
            // Find and update old slug pages
            $old_page = $wpdb->get_row($wpdb->prepare(
                "SELECT ID FROM {$wpdb->posts} WHERE post_type='page' AND post_name=%s AND post_status='publish'",
                $old_slug
            ));
            
            if ($old_page) {
                wp_update_post(array('ID' => $old_page->ID, 'post_name' => $new_slug));
                $page_ids[$key] = $old_page->ID;
            }
            
            // Fix stored page slugs
            if (!empty($page_ids[$key])) {
                $page = get_post($page_ids[$key]);
                if ($page && strpos($page->post_name, 'hushot-') === 0) {
                    wp_update_post(array('ID' => $page->ID, 'post_name' => $new_slug));
                }
            }
        }
        
        // Delete duplicates with hushot- prefix
        $dups = $wpdb->get_results("SELECT ID, post_name FROM {$wpdb->posts} WHERE post_type='page' AND post_name LIKE 'hushot-%' AND post_status='publish'");
        foreach ($dups as $d) {
            $clean = str_replace('hushot-', '', $d->post_name);
            if (get_page_by_path($clean)) wp_delete_post($d->ID, true);
        }
        
        update_option('hushot_page_ids', $page_ids);
        update_option('hushot_urls_migrated_v184', true);
        flush_rewrite_rules();
    }
    
    /**
     * Redirect old URLs to new ones
     */
    public static function handle_redirects() {
        if (is_admin()) return;
        $path = trim(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH), '/');
        if (strpos($path, 'hushot-') === 0) {
            $new = str_replace('hushot-', '', $path);
            $query = $_SERVER['QUERY_STRING'] ? '?' . $_SERVER['QUERY_STRING'] : '';
            wp_redirect(home_url('/' . $new . $query), 301);
            exit;
        }
    }
    
    public static function create_pages() {
        self::migrate_urls();
        $page_ids = get_option('hushot_page_ids', array());

        // Guard against bad mappings: if multiple keys point to the same page ID,
        // later updates can overwrite slugs/shortcodes and cause duplicated content
        // (e.g. Seller Setup and Seller Dashboard showing the same page).
        if (is_array($page_ids) && !empty($page_ids)) {
            $seen = array();
            foreach ($page_ids as $k => $id) {
                $id = (int)$id;
                if ($id <= 0) continue;
                if (isset($seen[$id])) {
                    unset($page_ids[$k]);
                } else {
                    $seen[$id] = $k;
                }
            }
        }
        
        foreach (self::$pages as $key => $data) {
            $slug = $data['slug'];
            $found = false;
            
            if (!empty($page_ids[$key])) {
                $existing = get_post($page_ids[$key]);
                if ($existing && $existing->post_status !== 'trash') {
                    if ($existing->post_name !== $slug) {
                        wp_update_post(array('ID' => $existing->ID, 'post_name' => $slug));
                    }
                    if (strpos($existing->post_content, $data['shortcode']) === false) {
                        wp_update_post(array('ID' => $existing->ID, 'post_content' => $data['shortcode']));
                    }
                    $found = true;
                }
            }
            
            if (!$found) {
                $by_slug = get_page_by_path($slug);
                if ($by_slug) {
                    wp_update_post(array('ID' => $by_slug->ID, 'post_content' => $data['shortcode']));
                    $page_ids[$key] = $by_slug->ID;
                    $found = true;
                }
            }
            
            if (!$found) {
                $page_id = wp_insert_post(array(
                    'post_title' => $data['title'],
                    'post_name' => $slug,
                    'post_content' => $data['shortcode'],
                    'post_status' => 'publish',
                    'post_type' => 'page',
                    'post_author' => 1,
                ));
                if (!is_wp_error($page_id)) $page_ids[$key] = $page_id;
            }
        }
        
        update_option('hushot_page_ids', $page_ids);
    }

    /**
     * Ensure required Hushot system pages exist and mappings are valid.
     * Runs on init (idempotent). Fixes common causes of 404 for system pages
     * and duplicated seller pages.
     */
    public static function maybe_repair_pages() {
        // Avoid repeated heavy checks within a short window.
        $last = (int)get_option('hushot_pages_last_repair', 0);
        if ($last && (time() - $last) < 300) {
            return;
        }

        $page_ids = get_option('hushot_page_ids', array());
        if (!is_array($page_ids)) $page_ids = array();

        $needs_repair = false;

        // Detect duplicate IDs.
        $seen = array();
        foreach ($page_ids as $k => $id) {
            $id = (int)$id;
            if ($id <= 0) continue;
            if (isset($seen[$id])) {
                $needs_repair = true;
                break;
            }
            $seen[$id] = $k;
        }

        // Detect missing pages or missing slug/shortcode.
        foreach (self::$pages as $key => $data) {
            $slug = $data['slug'];
            $id = isset($page_ids[$key]) ? (int)$page_ids[$key] : 0;

            $page = $id ? get_post($id) : null;
            if (!$page || $page->post_type !== 'page' || $page->post_status === 'trash') {
                // Try lookup by slug
                $by_slug = get_page_by_path($slug);
                if (!$by_slug) {
                    $needs_repair = true;
                    break;
                }
            } else {
                if ($page->post_name !== $slug) {
                    $needs_repair = true;
                    break;
                }
                if (strpos((string)$page->post_content, $data['shortcode']) === false) {
                    $needs_repair = true;
                    break;
                }
            }
        }

        if ($needs_repair) {
            self::create_pages();
            flush_rewrite_rules();
        }

        update_option('hushot_pages_last_repair', time());
    }

    /**
     * Create marketplace transactions table
     */
    public static function create_tables() {
        global $wpdb;
        $table = $wpdb->prefix . 'hushot_marketplace_transactions';
        $charset = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE IF NOT EXISTS $table (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            transaction_id varchar(100) NOT NULL,
            seller_id bigint(20) NOT NULL,
            buyer_email varchar(100) NOT NULL,
            page_id bigint(20) NOT NULL,
            amount decimal(10,2) NOT NULL,
            currency varchar(10) DEFAULT 'NGN',
            seller_amount decimal(10,2) NOT NULL,
            platform_fee decimal(10,2) NOT NULL,
            status varchar(20) DEFAULT 'pending',
            payment_ref varchar(100),
            download_token varchar(64),
            file_url text,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            completed_at datetime,
            PRIMARY KEY (id),
            KEY transaction_id (transaction_id),
            KEY seller_id (seller_id),
            KEY download_token (download_token)
        ) $charset;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
    
    public static function create_templates() {
        $templates = array(
            array(
                'title' => 'Restaurant & Food',
                'category' => 'food',
                'tier' => 'free',
                'icon' => '🍽️',
                'color' => '#E63946',
                'content' => array(
                    'headline' => 'Delicious Food, Delivered Fresh',
                    'subheadline' => 'Experience the taste of authentic cuisine',
                    'description' => 'We serve the finest dishes made with fresh, locally sourced ingredients.',
                    'benefits' => array('Fresh ingredients daily', 'Fast delivery', 'Easy ordering', 'Special discounts'),
                    'cta' => 'Order Now'
                )
            ),
            array(
                'title' => 'Business & Consulting',
                'category' => 'business',
                'tier' => 'free',
                'icon' => '💼',
                'color' => '#2A9D8F',
                'content' => array(
                    'headline' => 'Grow Your Business Today',
                    'subheadline' => 'Professional consulting services',
                    'description' => 'We help businesses reach their full potential through strategic planning.',
                    'benefits' => array('Expert consultants', 'Proven strategies', 'Personalized solutions', 'Ongoing support'),
                    'cta' => 'Book Consultation'
                )
            ),
            array(
                'title' => 'Beauty & Salon',
                'category' => 'beauty',
                'tier' => 'essential',
                'icon' => '💅',
                'color' => '#E9C46A',
                'content' => array(
                    'headline' => 'Beauty That Makes You Shine',
                    'subheadline' => 'Premium beauty services',
                    'description' => 'Transform your look with our expert beauty treatments.',
                    'benefits' => array('Experienced professionals', 'Premium products', 'Relaxing atmosphere', 'Affordable luxury'),
                    'cta' => 'Book Appointment'
                )
            ),
            array(
                'title' => 'Online Shop',
                'category' => 'shop',
                'tier' => 'essential',
                'icon' => '🛍️',
                'color' => '#F4A261',
                'content' => array(
                    'headline' => 'Shop Quality Products',
                    'subheadline' => 'Best deals, fast delivery',
                    'description' => 'Discover amazing products at unbeatable prices.',
                    'benefits' => array('Quality guaranteed', 'Nationwide delivery', 'Easy returns', 'Secure payment'),
                    'cta' => 'Shop Now'
                )
            ),
            array(
                'title' => 'Digital Product',
                'category' => 'digital',
                'tier' => 'essential',
                'icon' => '📚',
                'color' => '#667eea',
                'content' => array(
                    'headline' => 'Get Instant Access',
                    'subheadline' => 'Premium digital content delivered instantly',
                    'description' => 'Download your purchase immediately after payment confirmation.',
                    'benefits' => array('Instant delivery', 'Lifetime access', 'Money-back guarantee', 'Premium quality'),
                    'cta' => 'Buy Now'
                )
            ),
            array(
                'title' => 'Real Estate',
                'category' => 'realestate',
                'tier' => 'premium',
                'icon' => '🏠',
                'color' => '#264653',
                'content' => array(
                    'headline' => 'Find Your Dream Home',
                    'subheadline' => 'Premium properties for sale & rent',
                    'description' => 'Browse our exclusive listings and find your perfect property.',
                    'benefits' => array('Verified listings', 'Expert agents', 'Virtual tours', 'Flexible payment'),
                    'cta' => 'View Properties'
                )
            ),
            array(
                'title' => 'Health & Fitness',
                'category' => 'health',
                'tier' => 'premium',
                'icon' => '💪',
                'color' => '#1D3557',
                'content' => array(
                    'headline' => 'Transform Your Body & Mind',
                    'subheadline' => 'Professional fitness training',
                    'description' => 'Achieve your health goals with personalized fitness programs.',
                    'benefits' => array('Certified trainers', 'Custom workout plans', 'Nutrition guidance', 'Progress tracking'),
                    'cta' => 'Start Now'
                )
            ),
        );
        
        foreach ($templates as $tpl) {
            $existing = get_posts(array('post_type' => 'hushot_template', 'title' => $tpl['title'], 'posts_per_page' => 1));
            if (!empty($existing)) continue;
            
            $template_id = wp_insert_post(array(
                'post_title' => $tpl['title'],
                'post_content' => '',
                'post_type' => 'hushot_template',
                'post_status' => 'publish',
            ));
            
            if (!is_wp_error($template_id)) {
                update_post_meta($template_id, '_hushot_template_category', $tpl['category']);
                update_post_meta($template_id, '_hushot_template_tier', $tpl['tier']);
                update_post_meta($template_id, '_hushot_template_icon', $tpl['icon']);
                update_post_meta($template_id, '_hushot_template_color', $tpl['color']);
                update_post_meta($template_id, '_hushot_content', $tpl['content']);
            }
        }
    }
}
