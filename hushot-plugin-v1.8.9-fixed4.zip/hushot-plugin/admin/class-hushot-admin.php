<?php
/**
 * Hushot Admin v1.0.3
 * Full admin functionality with all menu items
 */

if (!defined('ABSPATH')) exit;

class Hushot_Admin {
    
    public static function init() {
        add_action('admin_menu', array(__CLASS__, 'add_menu'));
        add_action('admin_menu', array(__CLASS__, 'hide_editor_menu'), 999);
        add_action('admin_init', array(__CLASS__, 'register_settings'));
        add_action('admin_init', array(__CLASS__, 'handle_actions'));
    }
    
    public static function add_menu() {
        // Main menu
        add_menu_page('Hushot', 'Hushot', 'manage_options', 'hushot', array(__CLASS__, 'dashboard_page'), 'dashicons-welcome-widgets-menus', 30);
        
        // Submenus
        add_submenu_page('hushot', 'Dashboard', 'Dashboard', 'manage_options', 'hushot', array(__CLASS__, 'dashboard_page'));
        add_submenu_page('hushot', 'Landing Pages', 'Landing Pages', 'manage_options', 'hushot-pages', array(__CLASS__, 'pages_page'));
        add_submenu_page('hushot', 'Templates', 'Templates', 'manage_options', 'hushot-templates', array(__CLASS__, 'templates_page'));
        add_submenu_page('hushot', 'Users', 'Users', 'manage_options', 'hushot-users', array(__CLASS__, 'users_page'));
        add_submenu_page('hushot', 'Pricing Plans', 'Pricing Plans', 'manage_options', 'hushot-pricing', array(__CLASS__, 'pricing_page'));
        add_submenu_page('hushot', 'Analytics', 'Analytics', 'manage_options', 'hushot-analytics', array(__CLASS__, 'analytics_page'));
        add_submenu_page('hushot', 'Settings', 'Settings', 'manage_options', 'hushot-settings', array(__CLASS__, 'settings_page'));
        
        // Editor page - hidden from menu but accessible via direct URL
        add_submenu_page('hushot', 'Edit Page', 'Edit Page', 'read', 'hushot-editor', array(__CLASS__, 'editor_page'));
    }
    
    public static function hide_editor_menu() {
        remove_submenu_page('hushot', 'hushot-editor');
    }
    
    public static function register_settings() {
        register_setting('hushot_settings', 'hushot_flutterwave_public_key');
        register_setting('hushot_settings', 'hushot_flutterwave_secret_key');
        register_setting('hushot_settings', 'hushot_primary_color');
        register_setting('hushot_settings', 'hushot_openai_api_key');
        // Marketplace platform fee (percentage). This controls what percentage of a seller's
        // transaction is charged as commission by the platform. Default is 5%.
        register_setting('hushot_settings', 'hushot_platform_fee');
    }
    
    public static function handle_actions() {
        // Create user
        if (isset($_POST['hushot_create_user']) && wp_verify_nonce($_POST['_wpnonce'], 'hushot_create_user')) {
            $email = sanitize_email($_POST['email']);
            $password = $_POST['password'];
            $first_name = sanitize_text_field($_POST['first_name']);
            $last_name = sanitize_text_field($_POST['last_name']);
            $plan = sanitize_text_field($_POST['plan']);
            
            if ($email && $password) {
                $user_id = wp_create_user($email, $password, $email);
                if (!is_wp_error($user_id)) {
                    wp_update_user(array(
                        'ID' => $user_id,
                        'first_name' => $first_name,
                        'last_name' => $last_name,
                        'display_name' => trim($first_name . ' ' . $last_name),
                    ));
                    if ($plan && $plan !== 'free') {
                        Hushot_Membership::set_user_plan($user_id, $plan);
                    }
                    add_settings_error('hushot', 'user_created', 'User created successfully!', 'success');
                } else {
                    add_settings_error('hushot', 'user_error', $user_id->get_error_message(), 'error');
                }
            }
        }
        
        // Update user plan
        if (isset($_POST['hushot_update_user_plan']) && wp_verify_nonce($_POST['_wpnonce'], 'hushot_update_user_plan')) {
            $user_id = intval($_POST['user_id']);
            $plan = sanitize_text_field($_POST['plan']);
            Hushot_Membership::set_user_plan($user_id, $plan);
            add_settings_error('hushot', 'plan_updated', 'User plan updated!', 'success');
        }
        
        // Delete subscriber user
        if (isset($_GET['hushot_delete_user']) && isset($_GET['_wpnonce']) && wp_verify_nonce($_GET['_wpnonce'], 'hushot_delete_user_' . intval($_GET['hushot_delete_user']))) {
            $user_id = intval($_GET['hushot_delete_user']);
            $user = get_user_by('ID', $user_id);
            
            if ($user && in_array('subscriber', $user->roles) && current_user_can('delete_users')) {
                // Delete user's hushot pages
                global $wpdb;
                $pages = get_posts(array('post_type' => 'hushot_page', 'author' => $user_id, 'posts_per_page' => -1, 'post_status' => 'any'));
                foreach ($pages as $page) {
                    wp_delete_post($page->ID, true);
                }
                // Delete user's leads
                $wpdb->delete($wpdb->prefix . 'hushot_leads', array('user_id' => $user_id));
                // Delete the user
                require_once(ABSPATH . 'wp-admin/includes/user.php');
                wp_delete_user($user_id);
                add_settings_error('hushot', 'user_deleted', 'User deleted successfully!', 'success');
            } else {
                add_settings_error('hushot', 'delete_error', 'Cannot delete this user. Only subscriber accounts can be deleted.', 'error');
            }
        }
        
        // Save plans
        if (isset($_POST['hushot_save_plans']) && wp_verify_nonce($_POST['_wpnonce'], 'hushot_save_plans')) {
            $plans = Hushot_Membership::get_plans();
            
            // Save currency symbol
            if (isset($_POST['currency_symbol'])) {
                update_option('hushot_currency_symbol', sanitize_text_field($_POST['currency_symbol']));
            }
            
            // Save Trial & Subscription settings
            if (isset($_POST['trial_price'])) {
                update_option('hushot_trial_price', floatval(str_replace(',', '', $_POST['trial_price'])));
            }
            if (isset($_POST['trial_duration'])) {
                update_option('hushot_trial_duration', intval($_POST['trial_duration']));
            }
            if (isset($_POST['subscription_premium'])) {
                update_option('hushot_subscription_premium', floatval(str_replace(',', '', $_POST['subscription_premium'])));
            }
            if (isset($_POST['subscription_essential'])) {
                update_option('hushot_subscription_essential', floatval(str_replace(',', '', $_POST['subscription_essential'])));
            }
            
            foreach (array('free', 'essential', 'premium') as $key) {
                if (isset($_POST[$key])) {
                    $plans[$key]['name'] = sanitize_text_field($_POST[$key]['name']);
                    $plans[$key]['description'] = sanitize_text_field($_POST[$key]['description']);
                    $plans[$key]['pricing']['monthly'] = floatval(str_replace(',', '', $_POST[$key]['monthly']));
                    $plans[$key]['pricing']['biannual'] = floatval(str_replace(',', '', $_POST[$key]['biannual']));
                    $plans[$key]['pricing']['yearly'] = floatval(str_replace(',', '', $_POST[$key]['yearly']));
                    // Keep quarterly for backward compat
                    $plans[$key]['pricing']['quarterly'] = $plans[$key]['pricing']['biannual'];
                    $plans[$key]['features']['pages'] = intval($_POST[$key]['pages']);
                    $plans[$key]['features']['ai_limit'] = intval($_POST[$key]['ai_limit']);
                    
                    // Activation fee
                    if (isset($_POST[$key]['activation_fee'])) {
                        $plans[$key]['activation_fee'] = floatval(str_replace(',', '', $_POST[$key]['activation_fee']));
                    }
                    
                    // Feature list
                    if (!empty($_POST[$key]['feature_list'])) {
                        $plans[$key]['feature_list'] = array_map('sanitize_text_field', explode("\n", trim($_POST[$key]['feature_list'])));
                    }
                }
            }
            
            Hushot_Membership::save_plans($plans);
            add_settings_error('hushot', 'plans_saved', 'Pricing plans saved!', 'success');
        }
    }
    
    // ===== DASHBOARD =====
    public static function dashboard_page() {
        global $wpdb;
        
        $total_users = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->users}");
        $total_pages = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'hushot_page' AND post_status = 'publish'");
        $total_views = $wpdb->get_var("SELECT SUM(meta_value) FROM {$wpdb->postmeta} WHERE meta_key = '_hushot_views'") ?: 0;
        $total_clicks = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}hushot_clicks") ?: 0;
        ?>
        <div class="wrap">
            <h1>Hushot Dashboard</h1>
            
            <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:20px;margin:20px 0;">
                <div style="background:#fff;padding:20px;border-radius:8px;box-shadow:0 1px 3px rgba(0,0,0,0.1);">
                    <h3 style="margin:0 0 5px;color:#666;font-size:13px;">Total Users</h3>
                    <p style="font-size:32px;font-weight:700;margin:0;color:#FF553E;"><?php echo number_format($total_users); ?></p>
                </div>
                <div style="background:#fff;padding:20px;border-radius:8px;box-shadow:0 1px 3px rgba(0,0,0,0.1);">
                    <h3 style="margin:0 0 5px;color:#666;font-size:13px;">Landing Pages</h3>
                    <p style="font-size:32px;font-weight:700;margin:0;color:#2C2F3E;"><?php echo number_format($total_pages); ?></p>
                </div>
                <div style="background:#fff;padding:20px;border-radius:8px;box-shadow:0 1px 3px rgba(0,0,0,0.1);">
                    <h3 style="margin:0 0 5px;color:#666;font-size:13px;">Total Views</h3>
                    <p style="font-size:32px;font-weight:700;margin:0;color:#3B82F6;"><?php echo number_format($total_views); ?></p>
                </div>
                <div style="background:#fff;padding:20px;border-radius:8px;box-shadow:0 1px 3px rgba(0,0,0,0.1);">
                    <h3 style="margin:0 0 5px;color:#666;font-size:13px;">Total Clicks</h3>
                    <p style="font-size:32px;font-weight:700;margin:0;color:#10B981;"><?php echo number_format($total_clicks); ?></p>
                </div>
            </div>
            
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;">
                <div style="background:#fff;padding:20px;border-radius:8px;box-shadow:0 1px 3px rgba(0,0,0,0.1);">
                    <h2 style="margin:0 0 15px;font-size:16px;">Quick Links</h2>
                    <p><a href="<?php echo admin_url('admin.php?page=hushot-pages'); ?>">Manage Landing Pages</a></p>
                    <p><a href="<?php echo admin_url('admin.php?page=hushot-users'); ?>">Manage Users</a></p>
                    <p><a href="<?php echo admin_url('admin.php?page=hushot-pricing'); ?>">Edit Pricing Plans</a></p>
                    <p><a href="<?php echo admin_url('admin.php?page=hushot-settings'); ?>">Settings</a></p>
                </div>
                <div style="background:#fff;padding:20px;border-radius:8px;box-shadow:0 1px 3px rgba(0,0,0,0.1);">
                    <h2 style="margin:0 0 15px;font-size:16px;">Frontend Pages</h2>
                    <p><a href="<?php echo Hushot_Pages::get_page_url('login'); ?>" target="_blank">Login Page →</a></p>
                    <p><a href="<?php echo Hushot_Pages::get_page_url('register'); ?>" target="_blank">Register Page →</a></p>
                    <p><a href="<?php echo Hushot_Pages::get_page_url('pricing'); ?>" target="_blank">Pricing Page →</a></p>
                    <p><a href="<?php echo Hushot_Pages::get_page_url('dashboard'); ?>" target="_blank">User Dashboard →</a></p>
                </div>
            </div>
        </div>
        <?php
    }
    
    // ===== LANDING PAGES =====
    public static function pages_page() {
        $pages = get_posts(array('post_type' => 'hushot_page', 'posts_per_page' => 100, 'post_status' => 'any'));
        ?>
        <div class="wrap">
            <h1>Landing Pages</h1>
            
            <table class="wp-list-table widefat fixed striped" style="margin-top:20px;">
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Author</th>
                        <th>Views</th>
                        <th>Clicks</th>
                        <th>Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($pages)): ?>
                    <tr><td colspan="6">No pages found.</td></tr>
                    <?php else: foreach ($pages as $page): 
                        $author = get_user_by('id', $page->post_author);
                        $views = get_post_meta($page->ID, '_hushot_views', true) ?: 0;
                        $clicks = get_post_meta($page->ID, '_hushot_clicks', true) ?: 0;
                    ?>
                    <tr>
                        <td><strong><?php echo esc_html($page->post_title); ?></strong></td>
                        <td><?php echo $author ? esc_html($author->display_name) : '-'; ?></td>
                        <td><?php echo number_format($views); ?></td>
                        <td><?php echo number_format($clicks); ?></td>
                        <td><?php echo get_the_date('M j, Y', $page->ID); ?></td>
                        <td>
                            <a href="<?php echo get_permalink($page->ID); ?>" target="_blank">View</a> |
                            <a href="<?php echo get_edit_post_link($page->ID); ?>">Edit</a> |
                            <a href="<?php echo get_delete_post_link($page->ID); ?>" onclick="return confirm('Delete?')">Delete</a>
                        </td>
                    </tr>
                    <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }
    
    // ===== TEMPLATES =====
    public static function templates_page() {
        $templates = get_posts(array('post_type' => 'hushot_template', 'posts_per_page' => -1, 'post_status' => 'any'));
        ?>
        <div class="wrap">
            <h1>Templates <a href="<?php echo admin_url('post-new.php?post_type=hushot_template'); ?>" class="page-title-action">Add New</a></h1>
            
            <table class="wp-list-table widefat fixed striped" style="margin-top:20px;">
                <thead>
                    <tr><th>Template</th><th>Category</th><th>Tier</th><th>Actions</th></tr>
                </thead>
                <tbody>
                    <?php if (empty($templates)): ?>
                    <tr><td colspan="4">No templates.</td></tr>
                    <?php else: foreach ($templates as $tpl): 
                        $tier = get_post_meta($tpl->ID, '_hushot_template_tier', true) ?: 'free';
                        $cat = get_post_meta($tpl->ID, '_hushot_template_category', true) ?: 'general';
                    ?>
                    <tr>
                        <td><strong><?php echo esc_html($tpl->post_title); ?></strong></td>
                        <td><?php echo ucfirst($cat); ?></td>
                        <td><span style="padding:2px 8px;background:<?php echo $tier === 'premium' ? '#F59E0B' : ($tier === 'essential' ? '#3B82F6' : '#10B981'); ?>;color:#fff;border-radius:4px;font-size:11px;"><?php echo ucfirst($tier); ?></span></td>
                        <td><a href="<?php echo get_edit_post_link($tpl->ID); ?>">Edit</a></td>
                    </tr>
                    <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }
    
    // ===== USERS =====
    public static function users_page() {
        global $wpdb;
        settings_errors('hushot');
        
        $users = get_users(array('number' => 100, 'orderby' => 'ID', 'order' => 'DESC'));
        ?>
        <div class="wrap">
            <h1>Hushot Users</h1>
            
            <!-- Create User Form -->
            <div style="background:#fff;padding:20px;border-radius:8px;margin:20px 0;max-width:500px;">
                <h2 style="margin:0 0 15px;font-size:16px;">Create New User</h2>
                <form method="post">
                    <?php wp_nonce_field('hushot_create_user'); ?>
                    <table class="form-table">
                        <tr>
                            <th><label>Email *</label></th>
                            <td><input type="email" name="email" class="regular-text" required></td>
                        </tr>
                        <tr>
                            <th><label>Password *</label></th>
                            <td><input type="text" name="password" class="regular-text" required></td>
                        </tr>
                        <tr>
                            <th><label>First Name</label></th>
                            <td><input type="text" name="first_name" class="regular-text"></td>
                        </tr>
                        <tr>
                            <th><label>Last Name</label></th>
                            <td><input type="text" name="last_name" class="regular-text"></td>
                        </tr>
                        <tr>
                            <th><label>Plan</label></th>
                            <td>
                                <select name="plan">
                                    <option value="free">Free</option>
                                    <option value="essential">Essential</option>
                                    <option value="premium">Premium</option>
                                </select>
                            </td>
                        </tr>
                    </table>
                    <p><input type="submit" name="hushot_create_user" class="button button-primary" value="Create User"></p>
                </form>
            </div>
            
            <!-- Users List -->
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr><th>User</th><th>Email</th><th>Plan</th><th>Pages</th><th>Registered</th><th>Actions</th></tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $user): 
                        $plan = Hushot_Membership::get_user_plan($user->ID);
                        $pages = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'hushot_page' AND post_author = %d", $user->ID));
                    ?>
                    <tr>
                        <td><strong><?php echo esc_html($user->display_name); ?></strong></td>
                        <td><?php echo esc_html($user->user_email); ?></td>
                        <td>
                            <form method="post" style="display:inline;">
                                <?php wp_nonce_field('hushot_update_user_plan'); ?>
                                <input type="hidden" name="user_id" value="<?php echo $user->ID; ?>">
                                <select name="plan" onchange="this.form.submit()" style="width:100px;">
                                    <option value="free" <?php selected($plan, 'free'); ?>>Free</option>
                                    <option value="essential" <?php selected($plan, 'essential'); ?>>Essential</option>
                                    <option value="premium" <?php selected($plan, 'premium'); ?>>Premium</option>
                                </select>
                                <input type="hidden" name="hushot_update_user_plan" value="1">
                            </form>
                        </td>
                        <td><?php echo $pages; ?></td>
                        <td><?php echo date('M j, Y', strtotime($user->user_registered)); ?></td>
                        <td>
                            <a href="<?php echo get_edit_user_link($user->ID); ?>">Edit</a>
                            <?php if (in_array('subscriber', $user->roles)): ?>
                            | <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=hushot-users&hushot_delete_user=' . $user->ID), 'hushot_delete_user_' . $user->ID); ?>" onclick="return confirm('Are you sure you want to permanently delete this user and all their pages? This action cannot be undone.');" style="color:#dc3232;">Delete</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php
    }
    
    // ===== PRICING PLANS =====
    public static function pricing_page() {
        settings_errors('hushot');
        $plans = Hushot_Membership::get_plans();
        $currency_symbol = get_option('hushot_currency_symbol', '$');
        
        // Trial & Subscription Settings
        $trial_price = get_option('hushot_trial_price', '0.14');
        $trial_duration = get_option('hushot_trial_duration', '30');
        $premium_price = get_option('hushot_subscription_premium', '9.50');
        $essential_price = get_option('hushot_subscription_essential', '4.70');
        ?>
        <div class="wrap">
            <h1>Pricing Plans</h1>
            <p>Edit prices and features for each plan.</p>
            
            <form method="post">
                <?php wp_nonce_field('hushot_save_plans'); ?>
                
                <!-- Currency Settings -->
                <div style="background:#fff;padding:20px;border-radius:8px;box-shadow:0 1px 3px rgba(0,0,0,0.1);margin-bottom:20px;max-width:400px;">
                    <h3 style="margin:0 0 15px;font-size:16px;color:#333;">💰 Currency Settings</h3>
                    <p><label><strong>Currency Symbol</strong></label><br>
                    <select name="currency_symbol" style="width:200px;padding:8px;">
                        <option value="$" <?php selected($currency_symbol, '$'); ?>>$ (USD - Dollar)</option>
                        <option value="₦" <?php selected($currency_symbol, '₦'); ?>>₦ (NGN - Naira)</option>
                        <option value="€" <?php selected($currency_symbol, '€'); ?>>€ (EUR - Euro)</option>
                        <option value="£" <?php selected($currency_symbol, '£'); ?>>£ (GBP - Pound)</option>
                        <option value="₵" <?php selected($currency_symbol, '₵'); ?>>₵ (GHS - Cedi)</option>
                        <option value="KSh" <?php selected($currency_symbol, 'KSh'); ?>>KSh (KES - Shilling)</option>
                        <option value="R" <?php selected($currency_symbol, 'R'); ?>>R (ZAR - Rand)</option>
                    </select></p>
                </div>
                
                <!-- Trial & Subscription Pricing -->
                <div style="background:linear-gradient(135deg,#667eea,#764ba2);padding:24px;border-radius:12px;box-shadow:0 4px 15px rgba(102,126,234,0.3);margin-bottom:20px;max-width:800px;">
                    <h3 style="margin:0 0 20px;font-size:18px;color:#fff;">🔄 Trial & Subscription Pricing (Flutterwave)</h3>
                    <p style="color:rgba(255,255,255,0.9);font-size:13px;margin:-15px 0 20px;">Configure trial activation fees and recurring subscription amounts. All amounts in USD.</p>
                    
                    <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:20px;">
                        <div style="background:rgba(255,255,255,0.15);padding:16px;border-radius:8px;">
                            <label style="display:block;font-size:12px;font-weight:600;color:#fff;margin-bottom:8px;text-transform:uppercase;">Trial Activation Fee ($)</label>
                            <input type="text" name="trial_price" value="<?php echo esc_attr($trial_price); ?>" style="width:100%;padding:10px;border:none;border-radius:6px;font-size:16px;font-weight:700;" placeholder="0.14">
                            <p style="color:rgba(255,255,255,0.7);font-size:11px;margin:8px 0 0;">One-time fee to start trial</p>
                        </div>
                        
                        <div style="background:rgba(255,255,255,0.15);padding:16px;border-radius:8px;">
                            <label style="display:block;font-size:12px;font-weight:600;color:#fff;margin-bottom:8px;text-transform:uppercase;">Trial Duration (Days)</label>
                            <input type="number" name="trial_duration" value="<?php echo esc_attr($trial_duration); ?>" style="width:100%;padding:10px;border:none;border-radius:6px;font-size:16px;font-weight:700;" placeholder="30">
                            <p style="color:rgba(255,255,255,0.7);font-size:11px;margin:8px 0 0;">Free trial period before charge</p>
                        </div>
                        
                        <div style="background:rgba(255,255,255,0.15);padding:16px;border-radius:8px;">
                            <label style="display:block;font-size:12px;font-weight:600;color:#fff;margin-bottom:8px;text-transform:uppercase;">Premium Monthly ($)</label>
                            <input type="text" name="subscription_premium" value="<?php echo esc_attr($premium_price); ?>" style="width:100%;padding:10px;border:none;border-radius:6px;font-size:16px;font-weight:700;" placeholder="9.50">
                            <p style="color:rgba(255,255,255,0.7);font-size:11px;margin:8px 0 0;">Monthly subscription after trial</p>
                        </div>
                        
                        <div style="background:rgba(255,255,255,0.15);padding:16px;border-radius:8px;">
                            <label style="display:block;font-size:12px;font-weight:600;color:#fff;margin-bottom:8px;text-transform:uppercase;">Essential Monthly ($)</label>
                            <input type="text" name="subscription_essential" value="<?php echo esc_attr($essential_price); ?>" style="width:100%;padding:10px;border:none;border-radius:6px;font-size:16px;font-weight:700;" placeholder="4.70">
                            <p style="color:rgba(255,255,255,0.7);font-size:11px;margin:8px 0 0;">Monthly subscription after trial</p>
                        </div>
                    </div>
                    
                    <div style="margin-top:16px;padding:12px;background:rgba(255,255,255,0.1);border-radius:6px;">
                        <p style="color:#fff;font-size:12px;margin:0;"><strong>📌 How it works:</strong> User pays trial fee → Gets full access for trial period → Flutterwave auto-charges monthly subscription when trial expires.</p>
                    </div>
                </div>
                
                <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:20px;margin-top:20px;">
                    <?php foreach (array('free', 'essential', 'premium') as $key): $p = $plans[$key]; ?>
                    <div style="background:#fff;padding:20px;border-radius:8px;box-shadow:0 1px 3px rgba(0,0,0,0.1);">
                        <h2 style="margin:0 0 15px;text-transform:capitalize;color:#FF553E;"><?php echo $key; ?></h2>
                        
                        <p><label><strong>Plan Name</strong></label><br>
                        <input type="text" name="<?php echo $key; ?>[name]" value="<?php echo esc_attr($p['name']); ?>" class="regular-text"></p>
                        
                        <p><label><strong>Description</strong></label><br>
                        <input type="text" name="<?php echo $key; ?>[description]" value="<?php echo esc_attr($p['description']); ?>" class="regular-text"></p>
                        
                        <hr style="margin:15px 0;">
                        <h4 style="margin:0 0 10px;">Pricing (<span id="currency-preview"><?php echo esc_html($currency_symbol); ?></span>)</h4>
                        <p style="font-size:11px;color:#666;margin:-5px 0 10px;">Accepts decimals like 9.99, 0.00, 19.50</p>
                        
                        <p><label>Monthly</label><br>
                        <input type="text" name="<?php echo $key; ?>[monthly]" value="<?php echo esc_attr(number_format(floatval($p['pricing']['monthly'] ?? 0), 2, '.', '')); ?>" class="small-text" pattern="[0-9]*\.?[0-9]*" inputmode="decimal"></p>
                        
                        <p><label>6 Months (Biannual)</label><br>
                        <input type="text" name="<?php echo $key; ?>[biannual]" value="<?php echo esc_attr(number_format(floatval($p['pricing']['biannual'] ?? 0), 2, '.', '')); ?>" class="small-text" pattern="[0-9]*\.?[0-9]*" inputmode="decimal"></p>
                        
                        <p><label>Yearly</label><br>
                        <input type="text" name="<?php echo $key; ?>[yearly]" value="<?php echo esc_attr(number_format(floatval($p['pricing']['yearly'] ?? 0), 2, '.', '')); ?>" class="small-text" pattern="[0-9]*\.?[0-9]*" inputmode="decimal"></p>
                        
                        <?php if ($key !== 'free'): ?>
                        <p><label>Activation/Trial Fee</label><br>
                        <input type="text" name="<?php echo $key; ?>[activation_fee]" value="<?php echo esc_attr(number_format(floatval($p['activation_fee'] ?? 0), 2, '.', '')); ?>" class="small-text" pattern="[0-9]*\.?[0-9]*" inputmode="decimal"></p>
                        <?php endif; ?>
                        
                        <hr style="margin:15px 0;">
                        <h4 style="margin:0 0 10px;">Limits</h4>
                        
                        <p><label>Max Pages (-1 = unlimited)</label><br>
                        <input type="number" name="<?php echo $key; ?>[pages]" value="<?php echo $p['features']['pages']; ?>" class="small-text"></p>
                        
                        <p><label>AI Limit/Month (-1 = unlimited)</label><br>
                        <input type="number" name="<?php echo $key; ?>[ai_limit]" value="<?php echo $p['features']['ai_limit']; ?>" class="small-text"></p>
                        
                        <hr style="margin:15px 0;">
                        <h4 style="margin:0 0 10px;">Feature List (one per line)</h4>
                        <textarea name="<?php echo $key; ?>[feature_list]" rows="5" style="width:100%;"><?php echo esc_textarea(implode("\n", $p['feature_list'] ?? array())); ?></textarea>
                    </div>
                    <?php endforeach; ?>
                </div>
                
                <p style="margin-top:20px;">
                    <input type="submit" name="hushot_save_plans" class="button button-primary button-large" value="Save Plans">
                </p>
            </form>
        </div>
        <script>
        document.querySelector('[name="currency_symbol"]').addEventListener('change', function() {
            document.getElementById('currency-preview').textContent = this.value;
        });
        </script>
        <?php
    }
    
    // ===== ANALYTICS =====
    public static function analytics_page() {
        global $wpdb;
        
        $top_pages = $wpdb->get_results("
            SELECT p.ID, p.post_title, pm1.meta_value as views, pm2.meta_value as clicks
            FROM {$wpdb->posts} p
            LEFT JOIN {$wpdb->postmeta} pm1 ON p.ID = pm1.post_id AND pm1.meta_key = '_hushot_views'
            LEFT JOIN {$wpdb->postmeta} pm2 ON p.ID = pm2.post_id AND pm2.meta_key = '_hushot_clicks'
            WHERE p.post_type = 'hushot_page' AND p.post_status = 'publish'
            ORDER BY CAST(pm1.meta_value AS UNSIGNED) DESC
            LIMIT 20
        ");
        
        $recent_clicks = $wpdb->get_results("
            SELECT c.*, p.post_title 
            FROM {$wpdb->prefix}hushot_clicks c
            LEFT JOIN {$wpdb->posts} p ON c.page_id = p.ID
            ORDER BY c.clicked_at DESC
            LIMIT 50
        ");
        ?>
        <div class="wrap">
            <h1>Analytics</h1>
            
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-top:20px;">
                <div style="background:#fff;padding:20px;border-radius:8px;">
                    <h2 style="margin:0 0 15px;font-size:16px;">Top Pages by Views</h2>
                    <table class="wp-list-table widefat fixed striped">
                        <thead><tr><th>Page</th><th>Views</th><th>Clicks</th><th>CTR</th></tr></thead>
                        <tbody>
                            <?php foreach ($top_pages as $page): 
                                $v = intval($page->views);
                                $c = intval($page->clicks);
                                $ctr = $v > 0 ? round(($c / $v) * 100, 1) : 0;
                            ?>
                            <tr>
                                <td><?php echo esc_html($page->post_title); ?></td>
                                <td><?php echo number_format($v); ?></td>
                                <td><?php echo number_format($c); ?></td>
                                <td><?php echo $ctr; ?>%</td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
                <div style="background:#fff;padding:20px;border-radius:8px;">
                    <h2 style="margin:0 0 15px;font-size:16px;">Recent Button Clicks</h2>
                    <table class="wp-list-table widefat fixed striped">
                        <thead><tr><th>Page</th><th>Button</th><th>Time</th></tr></thead>
                        <tbody>
                            <?php foreach ($recent_clicks as $click): ?>
                            <tr>
                                <td><?php echo esc_html($click->post_title ?: '#' . $click->page_id); ?></td>
                                <td><?php echo esc_html($click->button_type); ?></td>
                                <td><?php echo human_time_diff(strtotime($click->clicked_at)) . ' ago'; ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <?php
    }
    
    // ===== SETTINGS =====
    public static function settings_page() {
        if (isset($_POST['hushot_save_settings']) && wp_verify_nonce($_POST['_wpnonce'], 'hushot_settings')) {
            update_option('hushot_flutterwave_public_key', sanitize_text_field($_POST['flutterwave_public_key'] ?? ''));
            update_option('hushot_flutterwave_secret_key', sanitize_text_field($_POST['flutterwave_secret_key'] ?? ''));
            update_option('hushot_primary_color', sanitize_hex_color($_POST['primary_color'] ?? '#FF553E'));
            update_option('hushot_openai_api_key', sanitize_text_field($_POST['openai_api_key'] ?? ''));
            // Integrations
            update_option('hushot_webhook_url', esc_url_raw($_POST['webhook_url'] ?? ''));
            update_option('hushot_email_api_key', sanitize_text_field($_POST['email_api_key'] ?? ''));
            update_option('hushot_email_list_id', sanitize_text_field($_POST['email_list_id'] ?? ''));
            // Ads Service Fee
            update_option('hushot_ads_service_fee', floatval($_POST['ads_service_fee'] ?? 10));

            // Marketplace Platform Fee
            // Store the commission percentage taken from sellers on marketplace transactions.  Accept only numeric
            // values between 0 and 100. If invalid or not supplied default to 5.
            $platform_fee = isset($_POST['platform_fee']) ? floatval($_POST['platform_fee']) : get_option('hushot_platform_fee', 5);
            if ($platform_fee < 0) {
                $platform_fee = 0;
            }
            if ($platform_fee > 100) {
                $platform_fee = 100;
            }
            update_option('hushot_platform_fee', $platform_fee);
            // PWA App Settings
            if (!empty($_FILES['app_icon']['tmp_name'])) {
                $upload = wp_handle_upload($_FILES['app_icon'], array('test_form' => false));
                if (!empty($upload['url'])) {
                    update_option('hushot_app_icon', $upload['url']);
                }
            }
            if (!empty($_FILES['splash_screen']['tmp_name'])) {
                $upload = wp_handle_upload($_FILES['splash_screen'], array('test_form' => false));
                if (!empty($upload['url'])) {
                    update_option('hushot_splash_screen', $upload['url']);
                }
            }
            echo '<div class="notice notice-success"><p>Settings saved!</p></div>';
        }
        
        if (isset($_GET['flush_rules'])) {
            flush_rewrite_rules();
            echo '<div class="notice notice-success"><p>Rewrite rules flushed!</p></div>';
        }
        
        // Regenerate pages handler - force update all shortcodes
        if (isset($_GET['regenerate_pages']) && wp_verify_nonce($_GET['_wpnonce'], 'hushot_regenerate')) {
            // Force update all existing pages with correct shortcodes
            $page_ids = get_option('hushot_page_ids', array());
            $pages_config = array(
                'home' => '[hushot_home]',
                'login' => '[hushot_login]',
                'register' => '[hushot_register]',
                'forgot-password' => '[hushot_forgot_password]',
                'reset-password' => '[hushot_reset_password]',
                'dashboard' => '[hushot_dashboard]',
                'my-pages' => '[hushot_my_pages]',
                'create-page' => '[hushot_create_page]',
                'edit-page' => '[hushot_edit_page]',
                'templates' => '[hushot_templates]',
                'ai-generator' => '[hushot_ai_generator]',
                'my-account' => '[hushot_my_account]',
                'billing' => '[hushot_billing]',
                'analytics' => '[hushot_analytics]',
                'leads' => '[hushot_leads]',
                'pricing' => '[hushot_pricing]',
                'checkout' => '[hushot_checkout]',
                'support' => '[hushot_support]',
                'ads-dashboard' => '[hushot_ads_dashboard]',
                'ads-promote' => '[hushot_ads_promote]',
            );
            foreach ($pages_config as $slug => $shortcode) {
                if (!empty($page_ids[$slug])) {
                    wp_update_post(array('ID' => $page_ids[$slug], 'post_content' => $shortcode));
                }
            }
            // Then run create to ensure any missing pages are added
            Hushot_Activator::create_pages();
            echo '<div class="notice notice-success"><p>All system pages updated with correct shortcodes!</p></div>';
        }
        
        // Get install stats
        global $wpdb;
        $install_table = $wpdb->prefix . 'hushot_installs';
        $total_installs = $wpdb->get_var("SELECT COUNT(*) FROM {$install_table}") ?: 0;
        $android_installs = $wpdb->get_var("SELECT COUNT(*) FROM {$install_table} WHERE platform = 'android'") ?: 0;
        $ios_installs = $wpdb->get_var("SELECT COUNT(*) FROM {$install_table} WHERE platform = 'ios'") ?: 0;
        $countries = $wpdb->get_results("SELECT country, COUNT(*) as cnt FROM {$install_table} GROUP BY country ORDER BY cnt DESC LIMIT 5");
        ?>
        <div class="wrap">
            <h1>Hushot Settings</h1>
            
            <form method="post" enctype="multipart/form-data">
                <?php wp_nonce_field('hushot_settings'); ?>
                
                <h2>General Settings</h2>
                <table class="form-table">
                    <tr>
                        <th><label>Primary Brand Color</label></th>
                        <td><input type="color" name="primary_color" value="<?php echo esc_attr(get_option('hushot_primary_color', '#FF553E')); ?>"></td>
                    </tr>
                </table>
                
                <h2>AI Writer (OpenAI)</h2>
                <table class="form-table">
                    <tr>
                        <th><label>OpenAI API Key</label></th>
                        <td>
                            <input type="password" name="openai_api_key" value="<?php echo esc_attr(get_option('hushot_openai_api_key')); ?>" class="regular-text">
                            <p class="description">Enter your OpenAI API key to enable AI content and image generation. Get one at <a href="https://platform.openai.com/api-keys" target="_blank">platform.openai.com</a></p>
                        </td>
                    </tr>
                </table>
                
                <h2>Payment Gateway (Flutterwave)</h2>
                <table class="form-table">
                    <tr>
                        <th><label>Flutterwave Public Key</label></th>
                        <td><input type="text" name="flutterwave_public_key" value="<?php echo esc_attr(get_option('hushot_flutterwave_public_key')); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label>Flutterwave Secret Key</label></th>
                        <td><input type="password" name="flutterwave_secret_key" value="<?php echo esc_attr(get_option('hushot_flutterwave_secret_key')); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label>Marketplace Fee (%)</label></th>
                        <td>
                            <?php $pf = get_option('hushot_platform_fee', 5); ?>
                            <input type="number" name="platform_fee" value="<?php echo esc_attr($pf); ?>" min="0" max="100" step="0.1" style="width:100px;">
                            <span>%</span>
                            <p class="description">Commission percentage taken from each marketplace sale. For example, 5 means you earn 5% and sellers receive 95%.</p>
                        </td>
                    </tr>
                </table>
                
                <h2>📢 Ads Network Settings</h2>
                <table class="form-table">
                    <tr>
                        <th><label>Service Fee (%)</label></th>
                        <td>
                            <input type="number" name="ads_service_fee" value="<?php echo esc_attr(get_option('hushot_ads_service_fee', 10)); ?>" min="0" max="100" step="0.1" style="width:100px;">
                            <span>%</span>
                            <p class="description">Service fee percentage applied to user ad spend. E.g., 10% means a $100 ad budget costs the user $110 total.</p>
                        </td>
                    </tr>
                </table>
                
                <h2>📲 PWA App Settings</h2>
                <table class="form-table">
                    <tr>
                        <th><label>App Icon (512x512)</label></th>
                        <td>
                            <?php $icon = get_option('hushot_app_icon'); ?>
                            <?php if ($icon): ?>
                            <img src="<?php echo esc_url($icon); ?>" style="width:64px;height:64px;border-radius:12px;margin-right:10px;vertical-align:middle;">
                            <?php endif; ?>
                            <input type="file" name="app_icon" accept="image/png,image/jpeg">
                            <p class="description">PNG or JPG, 512x512px recommended for best quality on all devices.</p>
                        </td>
                    </tr>
                    <tr>
                        <th><label>Splash Screen</label></th>
                        <td>
                            <?php $splash = get_option('hushot_splash_screen'); ?>
                            <?php if ($splash): ?>
                            <img src="<?php echo esc_url($splash); ?>" style="width:100px;height:auto;border-radius:8px;margin-right:10px;vertical-align:middle;">
                            <?php endif; ?>
                            <input type="file" name="splash_screen" accept="image/png,image/jpeg">
                            <p class="description">Full screen image shown during app load. Recommended 1242x2688px (iPhone) or 1080x1920px (Android).</p>
                        </td>
                    </tr>
                </table>
                
                <h2>🔗 Integrations (Webhooks & Email Marketing)</h2>
                <table class="form-table">
                    <tr>
                        <th><label>Webhook URL</label></th>
                        <td>
                            <input type="url" name="webhook_url" value="<?php echo esc_attr(get_option('hushot_webhook_url')); ?>" class="regular-text" placeholder="https://hook.make.com/...">
                            <p class="description">Lead data will be sent to this URL when someone submits a form on landing pages. Works with Make.com, Zapier, etc.</p>
                        </td>
                    </tr>
                    <tr>
                        <th><label>Email Marketing API Key</label></th>
                        <td>
                            <input type="text" name="email_api_key" value="<?php echo esc_attr(get_option('hushot_email_api_key')); ?>" class="regular-text" placeholder="Your API key">
                            <p class="description">From Mailchimp, ConvertKit, Sendinblue, etc.</p>
                        </td>
                    </tr>
                    <tr>
                        <th><label>Email List/Audience ID</label></th>
                        <td>
                            <input type="text" name="email_list_id" value="<?php echo esc_attr(get_option('hushot_email_list_id')); ?>" class="regular-text" placeholder="List ID">
                            <p class="description">The list where leads will be added.</p>
                        </td>
                    </tr>
                </table>
                
                <p><input type="submit" name="hushot_save_settings" class="button button-primary" value="Save Settings"></p>
            </form>
            
            <hr>
            
            <h2>📲 App Install Analytics</h2>
            <div style="display:flex;gap:20px;margin-bottom:20px;">
                <div style="background:#fff;padding:20px;border-radius:10px;box-shadow:0 2px 8px rgba(0,0,0,0.1);min-width:150px;text-align:center;">
                    <div style="font-size:32px;font-weight:700;color:#10b981;"><?php echo number_format($total_installs); ?></div>
                    <div style="color:#666;font-size:13px;">Total Installs</div>
                </div>
                <div style="background:#fff;padding:20px;border-radius:10px;box-shadow:0 2px 8px rgba(0,0,0,0.1);min-width:150px;text-align:center;">
                    <div style="font-size:32px;font-weight:700;color:#3b82f6;"><?php echo number_format($android_installs); ?></div>
                    <div style="color:#666;font-size:13px;">📱 Android</div>
                </div>
                <div style="background:#fff;padding:20px;border-radius:10px;box-shadow:0 2px 8px rgba(0,0,0,0.1);min-width:150px;text-align:center;">
                    <div style="font-size:32px;font-weight:700;color:#6b7280;"><?php echo number_format($ios_installs); ?></div>
                    <div style="color:#666;font-size:13px;">🍎 iOS</div>
                </div>
            </div>
            <?php if (!empty($countries)): ?>
            <h4>Top Countries</h4>
            <ul>
                <?php foreach ($countries as $c): ?>
                <li><?php echo esc_html($c->country); ?>: <?php echo number_format($c->cnt); ?> installs</li>
                <?php endforeach; ?>
            </ul>
            <?php endif; ?>
            
            <hr>
            
            <h2>Troubleshooting</h2>
            <p><strong>Edit page showing published view instead of form?</strong> Click Regenerate Pages below.</p>
            <p>
                <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=hushot-settings&regenerate_pages=1'), 'hushot_regenerate'); ?>" class="button button-primary" onclick="return confirm('This will recreate all system pages. Continue?');">Regenerate Pages</a>
                <a href="<?php echo admin_url('admin.php?page=hushot-settings&flush_rules=1'); ?>" class="button">Flush Rewrite Rules</a>
            </p>
            
            <h3>System Pages</h3>
            <ul>
                <li>Login: <a href="<?php echo Hushot_Pages::get_page_url('login'); ?>" target="_blank"><?php echo Hushot_Pages::get_page_url('login'); ?></a></li>
                <li>Register: <a href="<?php echo Hushot_Pages::get_page_url('register'); ?>" target="_blank"><?php echo Hushot_Pages::get_page_url('register'); ?></a></li>
                <li>Dashboard: <a href="<?php echo Hushot_Pages::get_page_url('dashboard'); ?>" target="_blank"><?php echo Hushot_Pages::get_page_url('dashboard'); ?></a></li>
                <li>Edit Page: <a href="<?php echo Hushot_Pages::get_page_url('edit-page'); ?>" target="_blank"><?php echo Hushot_Pages::get_page_url('edit-page'); ?></a></li>
                <li>Pricing: <a href="<?php echo Hushot_Pages::get_page_url('pricing'); ?>" target="_blank"><?php echo Hushot_Pages::get_page_url('pricing'); ?></a></li>
            </ul>
        </div>
        <?php
    }
    
    // EDITOR PAGE - Dedicated admin editor for landing pages
    public static function editor_page() {
        if (!is_user_logged_in()) {
            wp_die('Please log in to edit pages.');
        }
        
        $page_id = intval($_GET['page_id'] ?? 0);
        if (!$page_id) {
            echo '<div class="wrap"><h1>Error</h1><p>No page ID specified. <a href="' . admin_url('admin.php?page=hushot-pages') . '">Go back to pages</a></p></div>';
            return;
        }
        
        $page = get_post($page_id);
        $user = wp_get_current_user();
        
        // Check ownership (allow admins to edit any page)
        if (!$page || $page->post_type !== 'hushot_page') {
            echo '<div class="wrap"><h1>Error</h1><p>Page not found. <a href="' . admin_url('admin.php?page=hushot-pages') . '">Go back to pages</a></p></div>';
            return;
        }
        
        if (!current_user_can('manage_options') && (int)$page->post_author !== (int)$user->ID) {
            echo '<div class="wrap"><h1>Error</h1><p>You do not have permission to edit this page.</p></div>';
            return;
        }
        
        // Get all meta
        $m = array();
        $fields = array('business_name','logo_url','header_title','header_subtitle','primary_color','image_url','video_url','description','features','original_price','sale_price','currency','cta_text','cta_type','whatsapp','whatsapp_message','phone','email','location','link_url','link_text','bottom_bar_style','bar_phone','bar_whatsapp','bar_link_url','products_title','products_json','form_title','form_button','form_fields');
        foreach ($fields as $f) {
            $m[$f] = get_post_meta($page_id, '_hushot_'.$f, true);
        }
        
        ?>
        <div class="wrap hushot-editor-wrap">
            <h1>Edit: <?php echo esc_html($page->post_title); ?></h1>
            <p>
                <a href="<?php echo get_permalink($page_id); ?>" target="_blank" class="button">View Live Page</a>
                <a href="<?php echo admin_url('admin.php?page=hushot-pages'); ?>" class="button">Back to Pages</a>
            </p>
            
            <form id="hushot-admin-editor" method="post" class="hushot-editor-form">
                <input type="hidden" name="page_id" value="<?php echo $page_id; ?>">
                <?php wp_nonce_field('hushot_admin_edit', 'hushot_nonce'); ?>
                
                <table class="form-table">
                    <tr>
                        <th><label for="title">Page Title</label></th>
                        <td><input type="text" name="title" id="title" value="<?php echo esc_attr($page->post_title); ?>" class="regular-text" required></td>
                    </tr>
                    <tr>
                        <th><label for="business_name">Business Name</label></th>
                        <td><input type="text" name="business_name" id="business_name" value="<?php echo esc_attr($m['business_name']); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label for="primary_color">Brand Color</label></th>
                        <td>
                            <select name="primary_color" id="primary_color">
                                <option value="#000000" <?php selected($m['primary_color'],'#000000'); ?>>Black</option>
                                <option value="#FF553E" <?php selected($m['primary_color'],'#FF553E'); ?>>Orange</option>
                                <option value="#dc2626" <?php selected($m['primary_color'],'#dc2626'); ?>>Red</option>
                                <option value="#059669" <?php selected($m['primary_color'],'#059669'); ?>>Green</option>
                                <option value="#2563eb" <?php selected($m['primary_color'],'#2563eb'); ?>>Blue</option>
                                <option value="#7c3aed" <?php selected($m['primary_color'],'#7c3aed'); ?>>Purple</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="logo_url">Logo URL</label></th>
                        <td><input type="url" name="logo_url" id="logo_url" value="<?php echo esc_attr($m['logo_url']); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label for="header_title">Headline</label></th>
                        <td><input type="text" name="header_title" id="header_title" value="<?php echo esc_attr($m['header_title']); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label for="header_subtitle">Subtitle</label></th>
                        <td><input type="text" name="header_subtitle" id="header_subtitle" value="<?php echo esc_attr($m['header_subtitle']); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label for="image_url">Hero Image URL</label></th>
                        <td><input type="url" name="image_url" id="image_url" value="<?php echo esc_attr($m['image_url']); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label for="video_url">Video URL (YouTube/Vimeo)</label></th>
                        <td><input type="url" name="video_url" id="video_url" value="<?php echo esc_attr($m['video_url']); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label for="description">Description</label></th>
                        <td><textarea name="description" id="description" rows="4" class="large-text"><?php echo esc_textarea($m['description']); ?></textarea></td>
                    </tr>
                    <tr>
                        <th><label for="features">Features (one per line)</label></th>
                        <td><textarea name="features" id="features" rows="4" class="large-text"><?php echo esc_textarea($m['features']); ?></textarea></td>
                    </tr>
                </table>
                
                <h2>Pricing</h2>
                <table class="form-table">
                    <tr>
                        <th><label for="currency">Currency</label></th>
                        <td>
                            <select name="currency" id="currency">
                                <option value="NGN" <?php selected($m['currency'],'NGN'); ?>>₦ NGN</option>
                                <option value="GHS" <?php selected($m['currency'],'GHS'); ?>>₵ GHS</option>
                                <option value="KES" <?php selected($m['currency'],'KES'); ?>>KSh KES</option>
                                <option value="ZAR" <?php selected($m['currency'],'ZAR'); ?>>R ZAR</option>
                                <option value="USD" <?php selected($m['currency'],'USD'); ?>>$ USD</option>
                                <option value="EUR" <?php selected($m['currency'],'EUR'); ?>>€ EUR</option>
                                <option value="GBP" <?php selected($m['currency'],'GBP'); ?>>£ GBP</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="original_price">Original Price</label></th>
                        <td><input type="number" name="original_price" id="original_price" value="<?php echo esc_attr($m['original_price']); ?>" class="small-text"></td>
                    </tr>
                    <tr>
                        <th><label for="sale_price">Sale Price</label></th>
                        <td><input type="number" name="sale_price" id="sale_price" value="<?php echo esc_attr($m['sale_price']); ?>" class="small-text"></td>
                    </tr>
                </table>
                
                <h2>WhatsApp & CTA</h2>
                <table class="form-table">
                    <tr>
                        <th><label for="whatsapp">WhatsApp Number</label></th>
                        <td><input type="text" name="whatsapp" id="whatsapp" value="<?php echo esc_attr($m['whatsapp']); ?>" class="regular-text" placeholder="+234..."></td>
                    </tr>
                    <tr>
                        <th><label for="whatsapp_message">WhatsApp Message</label></th>
                        <td><input type="text" name="whatsapp_message" id="whatsapp_message" value="<?php echo esc_attr($m['whatsapp_message']); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label for="cta_text">Button Text</label></th>
                        <td><input type="text" name="cta_text" id="cta_text" value="<?php echo esc_attr($m['cta_text'] ?: 'Chat on WhatsApp'); ?>" class="regular-text"></td>
                    </tr>
                </table>
                
                <h2>Contact Info</h2>
                <table class="form-table">
                    <tr>
                        <th><label for="phone">Phone</label></th>
                        <td><input type="text" name="phone" id="phone" value="<?php echo esc_attr($m['phone']); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label for="email">Email</label></th>
                        <td><input type="email" name="email" id="email" value="<?php echo esc_attr($m['email']); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label for="location">Location</label></th>
                        <td><input type="text" name="location" id="location" value="<?php echo esc_attr($m['location']); ?>" class="regular-text"></td>
                    </tr>
                </table>
                
                <h2>Sticky Bottom Bar</h2>
                <table class="form-table">
                    <tr>
                        <th><label for="bottom_bar_style">Style</label></th>
                        <td>
                            <select name="bottom_bar_style" id="bottom_bar_style">
                                <option value="disabled" <?php selected($m['bottom_bar_style'],'disabled'); ?>>Disabled</option>
                                <option value="call_whatsapp" <?php selected($m['bottom_bar_style'],'call_whatsapp'); ?>>Call | WhatsApp</option>
                                <option value="call_link" <?php selected($m['bottom_bar_style'],'call_link'); ?>>Call | Link</option>
                                <option value="whatsapp_link" <?php selected($m['bottom_bar_style'],'whatsapp_link'); ?>>WhatsApp | Link</option>
                                <option value="call_only" <?php selected($m['bottom_bar_style'],'call_only'); ?>>Call Only</option>
                                <option value="whatsapp_only" <?php selected($m['bottom_bar_style'],'whatsapp_only'); ?>>WhatsApp Only</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="bar_phone">Bar Phone</label></th>
                        <td><input type="text" name="bar_phone" id="bar_phone" value="<?php echo esc_attr($m['bar_phone']); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label for="bar_whatsapp">Bar WhatsApp</label></th>
                        <td><input type="text" name="bar_whatsapp" id="bar_whatsapp" value="<?php echo esc_attr($m['bar_whatsapp']); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label for="bar_link_url">Bar Link URL</label></th>
                        <td><input type="url" name="bar_link_url" id="bar_link_url" value="<?php echo esc_attr($m['bar_link_url']); ?>" class="regular-text"></td>
                    </tr>
                </table>
                
                <p class="submit">
                    <button type="submit" class="button button-primary button-large">Save Changes</button>
                </p>
            </form>
            
            <script>
            jQuery(document).ready(function($) {
                $('#hushot-admin-editor').on('submit', function(e) {
                    e.preventDefault();
                    var $btn = $(this).find('button[type="submit"]');
                    $btn.text('Saving...').prop('disabled', true);
                    
                    $.post(ajaxurl, {
                        action: 'hushot_update_page',
                        page_id: $('input[name="page_id"]').val(),
                        title: $('#title').val(),
                        business_name: $('#business_name').val(),
                        primary_color: $('#primary_color').val(),
                        logo_url: $('#logo_url').val(),
                        header_title: $('#header_title').val(),
                        header_subtitle: $('#header_subtitle').val(),
                        image_url: $('#image_url').val(),
                        video_url: $('#video_url').val(),
                        description: $('#description').val(),
                        features: $('#features').val(),
                        currency: $('#currency').val(),
                        original_price: $('#original_price').val(),
                        sale_price: $('#sale_price').val(),
                        whatsapp: $('#whatsapp').val(),
                        whatsapp_message: $('#whatsapp_message').val(),
                        cta_text: $('#cta_text').val(),
                        phone: $('#phone').val(),
                        email: $('#email').val(),
                        location: $('#location').val(),
                        bottom_bar_style: $('#bottom_bar_style').val(),
                        bar_phone: $('#bar_phone').val(),
                        bar_whatsapp: $('#bar_whatsapp').val(),
                        bar_link_url: $('#bar_link_url').val()
                    }, function(response) {
                        if (response.success) {
                            $btn.text('Saved!');
                            setTimeout(function() { $btn.text('Save Changes').prop('disabled', false); }, 2000);
                        } else {
                            alert(response.data?.message || 'Save failed');
                            $btn.text('Save Changes').prop('disabled', false);
                        }
                    });
                });
            });
            </script>
            
            <style>
            .hushot-editor-wrap { max-width: 800px; }
            .hushot-editor-wrap h2 { margin-top: 30px; padding-top: 20px; border-top: 1px solid #ccc; }
            </style>
        </div>
        <?php
    }
}
