/**
 * Hushot Admin JS
 */
(function($) {
    'use strict';
    
    $(document).ready(function() {
        // Confirm delete
        $('.hushot-delete').on('click', function(e) {
            if (!confirm('Are you sure?')) {
                e.preventDefault();
            }
        });
    });
    
})(jQuery);
