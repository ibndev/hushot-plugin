/**
 * Hushot v1.5.4 - Complete JavaScript
 */
(function($) {
    'use strict';
    
    $(document).ready(function() {
        initMobileMenu();
        initSidebarToggle();
        initBlocks();
        initComponentPicker();
        initMoveRemove();
        initImageUpload();
        initFormFields();
        initAIWriter();
        initAIBuilderPage();
        initForms();
        initPageActions();
        initBottomBarToggle();
        initProducts();
        loadSavedProducts();
        initPWA();
    });
    
    // PWA Support
    function initPWA() {
        // Register service worker
        if ('serviceWorker' in navigator) {
            navigator.serviceWorker.register(hushot.plugin_url + 'sw.js')
                .then(function(reg) {
                    console.log('Hushot SW registered');
                })
                .catch(function(err) {
                    // SW not critical, fail silently
                });
        }
        
        // Handle PWA install prompt
        var deferredPrompt;
        window.addEventListener('beforeinstallprompt', function(e) {
            e.preventDefault();
            deferredPrompt = e;
            
            // Show install button if on dashboard
            if ($('.hs-nav').length) {
                var $installBtn = $('<a href="#" class="hs-pwa-install" style="display:block;padding:10px 15px;background:linear-gradient(135deg,#667eea,#764ba2);color:#fff;text-align:center;border-radius:8px;margin:10px 15px;font-size:13px;font-weight:600;text-decoration:none;">📲 Install App</a>');
                $('.hs-nav-links').append($installBtn);
                
                $installBtn.on('click', function(e) {
                    e.preventDefault();
                    if (deferredPrompt) {
                        deferredPrompt.prompt();
                        deferredPrompt.userChoice.then(function(result) {
                            if (result.outcome === 'accepted') {
                                $installBtn.hide();
                            }
                            deferredPrompt = null;
                        });
                    }
                });
            }
        });
        
        // Handle successful install
        window.addEventListener('appinstalled', function() {
            $('.hs-pwa-install').hide();
        });
    }
    
    // Sidebar Toggle (Desktop)
    function initSidebarToggle() {
        $(document).on('click', '#hs-sidebar-toggle', function(e) {
            e.preventDefault();
            var $nav = $('.hs-nav');
            var $main = $('.hs-main');
            $nav.toggleClass('collapsed');
            $main.toggleClass('expanded');
            $(this).html($nav.hasClass('collapsed') ? '▶ Expand' : '◀ Collapse');
        });
    }
    
    // AI Builder Page
    function initAIBuilderPage() {
        var draftCount = 0;
        
        // Generate page button
        $(document).on('click', '#ai-generate-page-btn', function() {
            var prompt = $('#ai-business-prompt').val().trim();
            if (!prompt) {
                alert('Please describe your business first.');
                $('#ai-business-prompt').focus();
                return;
            }
            
            var $btn = $(this);
            var origText = $btn.html();
            $btn.prop('disabled', true).html('🤖 Generating...');
            
            console.log('AI Builder: Sending request with prompt:', prompt);
            
            $.post(hushot.ajax_url, {
                action: 'hushot_generate_ai',
                product: prompt,
                goal: 'leads'
            }, function(response) {
                console.log('AI Builder: Response received:', response);
                $btn.prop('disabled', false).html(origText);
                
                if (response.success && response.data && response.data.content) {
                    var content = response.data.content;
                    console.log('AI Builder: Content generated:', content);
                    draftCount++;
                    
                    // Hide empty state
                    $('#ai-empty-state').hide();
                    
                    // Create editable draft card
                    var draftHtml = '<div class="hs-ai-draft" id="ai-draft-' + draftCount + '">' +
                        '<div class="hs-ai-draft-head">' +
                        '<h4>Draft Page #' + draftCount + '</h4>' +
                        '<span class="hs-ai-draft-status">Not Published</span>' +
                        '</div>' +
                        '<div class="hs-ai-field">' +
                        '<label>Headline</label>' +
                        '<input type="text" class="draft-headline" value="' + (content.headline || '').replace(/"/g, '&quot;') + '">' +
                        '</div>' +
                        '<div class="hs-ai-field">' +
                        '<label>Subtitle</label>' +
                        '<input type="text" class="draft-subtitle" value="' + (content.subheadline || '').replace(/"/g, '&quot;') + '">' +
                        '</div>' +
                        '<div class="hs-ai-field">' +
                        '<label>Description</label>' +
                        '<textarea class="draft-description">' + (content.description || '') + '</textarea>' +
                        '</div>' +
                        '<div class="hs-ai-field">' +
                        '<label>Features (one per line)</label>' +
                        '<textarea class="draft-features">' + (content.features ? content.features.join('\n') : '') + '</textarea>' +
                        '</div>' +
                        '<div class="hs-ai-images">' +
                        '<div class="hs-ai-img-box" data-img="img1"><span>📷</span><input type="file" class="draft-img" accept="image/*"><img src="" style="display:none;"></div>' +
                        '<div class="hs-ai-img-box" data-img="img2"><span>📷</span><input type="file" class="draft-img" accept="image/*"><img src="" style="display:none;"></div>' +
                        '<span style="font-size:12px;color:#888;align-self:center;">Add images (click to upload)</span>' +
                        '</div>' +
                        '<div class="hs-ai-draft-actions">' +
                        '<button type="button" class="save-btn draft-save">💾 Save as Page</button>' +
                        '<button type="button" class="edit-btn draft-edit">✏️ Edit in Builder</button>' +
                        '<button type="button" class="discard-btn draft-discard">🗑️ Discard</button>' +
                        '</div>' +
                        '</div>';
                    
                    $('#ai-results').prepend(draftHtml);
                } else {
                    console.error('AI Builder: Generation failed', response);
                    var errorMsg = 'AI generation failed.';
                    if (response.data && response.data.message) {
                        errorMsg = response.data.message;
                    }
                    alert(errorMsg);
                }
            }).fail(function(xhr, status, error) {
                console.error('AI Builder: Request failed', status, error);
                $btn.prop('disabled', false).html(origText);
                alert('Connection error: ' + error);
            });
        });
        
        // Image upload in draft
        $(document).on('change', '.hs-ai-draft .draft-img', function() {
            var $input = $(this);
            var $box = $input.closest('.hs-ai-img-box');
            var file = this.files[0];
            
            if (file) {
                var formData = new FormData();
                formData.append('file', file);
                formData.append('action', 'hushot_upload_image');
                
                $box.find('span').text('⏳');
                
                $.ajax({
                    url: hushot.ajax_url,
                    type: 'POST',
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        if (response.success && response.data.url) {
                            $box.find('img').attr('src', response.data.url).show();
                            $box.find('span').hide();
                            $box.data('url', response.data.url);
                        } else {
                            $box.find('span').text('📷');
                        }
                    },
                    error: function() {
                        $box.find('span').text('📷');
                    }
                });
            }
        });
        
        // Save draft as page
        $(document).on('click', '.draft-save', function() {
            var $draft = $(this).closest('.hs-ai-draft');
            var $btn = $(this);
            
            var headline = $draft.find('.draft-headline').val();
            if (!headline) {
                alert('Please enter a headline.');
                return;
            }
            
            $btn.prop('disabled', true).text('Saving...');
            
            var img1 = $draft.find('.hs-ai-img-box[data-img="img1"]').data('url') || '';
            
            $.post(hushot.ajax_url, {
                action: 'hushot_create_page',
                page_title: headline,
                header_title: headline,
                header_subtitle: $draft.find('.draft-subtitle').val(),
                description: $draft.find('.draft-description').val(),
                features: $draft.find('.draft-features').val(),
                image_url: img1,
                cta_type: 'whatsapp',
                cta_text: 'Contact Us',
                primary_color: '#FF553E'
            }, function(response) {
                if (response.success) {
                    $draft.find('.hs-ai-draft-status').text('✓ Saved').css('background', '#d1fae5').css('color', '#065f46');
                    $btn.text('✓ Saved').css('background', '#10b981');
                    setTimeout(function() {
                        if (response.data.redirect) {
                            window.location.href = response.data.redirect;
                        }
                    }, 500);
                } else {
                    alert(response.data?.message || 'Failed to save.');
                    $btn.prop('disabled', false).text('💾 Save as Page');
                }
            }).fail(function() {
                alert('Connection error.');
                $btn.prop('disabled', false).text('💾 Save as Page');
            });
        });
        
        // Edit in builder
        $(document).on('click', '.draft-edit', function() {
            var $draft = $(this).closest('.hs-ai-draft');
            
            // Store draft data in session storage
            var draftData = {
                headline: $draft.find('.draft-headline').val(),
                subtitle: $draft.find('.draft-subtitle').val(),
                description: $draft.find('.draft-description').val(),
                features: $draft.find('.draft-features').val(),
                img1: $draft.find('.hs-ai-img-box[data-img="img1"]').data('url') || '',
                img2: $draft.find('.hs-ai-img-box[data-img="img2"]').data('url') || ''
            };
            sessionStorage.setItem('hushotAIDraft', JSON.stringify(draftData));
            
            // Redirect to create page
            window.location.href = hushot.create_url || $('.hs-nav-links a:contains("Create")').attr('href');
        });
        
        // Discard draft
        $(document).on('click', '.draft-discard', function() {
            if (confirm('Discard this draft?')) {
                $(this).closest('.hs-ai-draft').slideUp(300, function() {
                    $(this).remove();
                    if ($('.hs-ai-draft').length === 0) {
                        $('#ai-empty-state').show();
                    }
                });
            }
        });
        
        // Load draft from session storage if on create page
        if ($('#hs-create').length) {
            var savedDraft = sessionStorage.getItem('hushotAIDraft');
            if (savedDraft) {
                try {
                    var draft = JSON.parse(savedDraft);
                    sessionStorage.removeItem('hushotAIDraft');
                    
                    // Fill in the form
                    $('input[name="page_title"]').val(draft.headline || '');
                    
                    // Add components and fill them
                    setTimeout(function() {
                        // Add header
                        if (draft.headline || draft.subtitle) {
                            $('.hs-pick[data-comp="header"]').click();
                            setTimeout(function() {
                                $('input[name="header_title"]').val(draft.headline || '');
                                $('input[name="header_subtitle"]').val(draft.subtitle || '');
                            }, 100);
                        }
                        
                        // Add description
                        if (draft.description) {
                            $('.hs-pick[data-comp="description"]').click();
                            setTimeout(function() {
                                $('textarea[name="description"]').val(draft.description);
                            }, 150);
                        }
                        
                        // Add features
                        if (draft.features) {
                            $('.hs-pick[data-comp="features"]').click();
                            setTimeout(function() {
                                $('textarea[name="features"]').val(draft.features);
                            }, 200);
                        }
                        
                        // Add image
                        if (draft.img1) {
                            $('.hs-pick[data-comp="image"]').click();
                            setTimeout(function() {
                                $('#image_url').val(draft.img1);
                                $('#img-box img').attr('src', draft.img1).show();
                                $('#img-box .ico').hide();
                            }, 250);
                        }
                        
                        // Add WhatsApp
                        $('.hs-pick[data-comp="whatsapp"]').click();
                    }, 100);
                } catch(e) {}
            }
        }
    }
    
    // Bottom bar conditional inputs
    function initBottomBarToggle() {
        function updateBarFields() {
            var style = $('#bar-style-select').val();
            if (!style) return;
            
            // Determine which fields to show based on style
            var showPhone = ['call_whatsapp', 'call_link', 'call_only'].indexOf(style) !== -1;
            var showWa = ['call_whatsapp', 'whatsapp_link', 'whatsapp_only'].indexOf(style) !== -1;
            var showLink = ['call_link', 'whatsapp_link', 'link_only'].indexOf(style) !== -1;
            
            $('#bar-phone-fld').toggle(showPhone);
            $('#bar-wa-fld').toggle(showWa);
            $('#bar-link-fld').toggle(showLink);
        }
        $(document).on('change', '#bar-style-select', updateBarFields);
        setTimeout(updateBarFields, 100);
    }
    
    // Mobile Menu - Simple and reliable
    function initMobileMenu() {
        // Toggle menu on hamburger tap/click (delegated for reliability)
        $(document).off('click.hushotMenu', '#hs-menu');
        $(document).on('click.hushotMenu', '#hs-menu', function(e) {
            e.preventDefault();
            e.stopPropagation();
            var $nav = $('.hs-nav');
            var $overlay = $('.hs-overlay');
            if ($nav.hasClass('open')) {
                $nav.removeClass('open');
                $overlay.removeClass('show');
            } else {
                $nav.addClass('open');
                $overlay.addClass('show');
            }
        });

        // Close when a menu link is clicked (mobile UX)
        $(document).off('click.hushotMenuClose', '.hs-nav-links a');
        $(document).on('click.hushotMenuClose', '.hs-nav-links a', function(){
            $('.hs-nav').removeClass('open');
            $('.hs-overlay').removeClass('show');
        });
        
        // Close on overlay click
        $('.hs-overlay').on('click', function() {
            $('.hs-nav').removeClass('open');
            $(this).removeClass('show');
        });
        
        // Close on ESC
        $(document).on('keydown', function(e) {
            if (e.key === 'Escape') {
                $('.hs-nav').removeClass('open');
                $('.hs-overlay').removeClass('show');
            }
        });
    }
    
    // Collapsible Blocks
    function initBlocks() {
        $(document).on('click', '.hs-block-head', function(e) {
            if ($(e.target).closest('.hs-block-acts, button').length) return;
            $(this).closest('.hs-block').toggleClass('open');
        });
    }
    
    // Component Picker - allows adding multiple components
    var componentCounter = 0;
    
    function initComponentPicker() {
        $(document).on('click', '.hs-pick', function() {
            // Check if locked
            if ($(this).data('locked') === 1 || $(this).hasClass('locked')) {
                alert('This feature requires a paid plan. Please upgrade to unlock.');
                return;
            }
            
            var comp = $(this).data('comp');
            var $template = $('#tpl-' + comp);
            
            if (!$template.length) {
                console.log('Template not found: tpl-' + comp);
                return;
            }
            
            componentCounter++;
            var uniqueId = Date.now() + '_' + componentCounter;
            
            // Get template HTML and replace IDs to make them unique
            var html = $template.html();
            
            // Replace common IDs with unique ones
            html = html.replace(/id="img-box"/g, 'id="img-box-' + uniqueId + '"');
            html = html.replace(/id="img-file"/g, 'id="img-file-' + uniqueId + '"');
            html = html.replace(/id="image_url"/g, 'id="image_url-' + uniqueId + '"');
            html = html.replace(/id="logo-box"/g, 'id="logo-box-' + uniqueId + '"');
            html = html.replace(/id="logo-file"/g, 'id="logo-file-' + uniqueId + '"');
            
            var $clone = $(html);
            $clone.attr('data-uid', uniqueId);
            
            $('#components-area').append($clone);
            
            // Visual feedback
            $(this).css('transform', 'scale(0.95)');
            var self = this;
            setTimeout(function() { $(self).css('transform', ''); }, 150);
            
            // Scroll to new component
            $('html, body').animate({
                scrollTop: $clone.offset().top - 100
            }, 400);
        });
    }
    
    // Move Up/Down/Remove
    function initMoveRemove() {
        $(document).on('click', '.mv-up', function(e) {
            e.preventDefault();
            e.stopPropagation();
            var $block = $(this).closest('.hs-block');
            var $prev = $block.prev('.hs-block');
            if ($prev.length && $prev.data('b') !== 'title') {
                $block.insertBefore($prev);
            }
        });
        
        $(document).on('click', '.mv-dn', function(e) {
            e.preventDefault();
            e.stopPropagation();
            var $block = $(this).closest('.hs-block');
            var $next = $block.next('.hs-block');
            if ($next.length) $block.insertAfter($next);
        });
        
        $(document).on('click', '.rem', function(e) {
            e.preventDefault();
            e.stopPropagation();
            var $block = $(this).closest('.hs-block');
            if (confirm('Remove this section?')) {
                $block.slideUp(200, function() {
                    $(this).remove();
                });
            }
        });
    }
    
    // Image Upload
    function initImageUpload() {
        // Logo upload
        $(document).on('change', '#logo-file', function() {
            handleImageUpload(this, '#logo-box', '#logo_url');
        });
        
        // Hero image upload - handle both original ID and unique IDs from component picker
        $(document).on('change', '[id^="img-file"]', function() {
            var $input = $(this);
            var $block = $input.closest('.hs-block[data-b="image"]');
            if ($block.length) {
                // Component picker image
                var uid = $block.attr('data-uid') || '';
                var boxId = uid ? '#img-box-' + uid : '#img-box';
                var hiddenId = uid ? '#image_url-' + uid : '#image_url';
                handleImageUploadDynamic($input, boxId, hiddenId);
            } else {
                // Original single image
                handleImageUpload(this, '#img-box', '#image_url', '#img-url');
            }
        });
        
        // URL input
        $(document).on('change blur', '#img-url', function() {
            var url = $(this).val().trim();
            if (url) {
                $('#image_url').val(url);
                showImagePreview('#img-box', url, 'img-file');
            }
        });
    }
    
    // Dynamic image upload handler for components with unique IDs
    function handleImageUploadDynamic($input, boxSelector, hiddenSelector) {
        if (!$input[0].files || !$input[0].files[0]) return;
        
        var file = $input[0].files[0];
        if (!file.type.match(/image.*/)) {
            alert('Please select an image file.');
            return;
        }
        if (file.size > 5 * 1024 * 1024) {
            alert('Image must be less than 5MB.');
            return;
        }
        
        var $box = $(boxSelector);
        var inputId = $input.attr('id');
        var originalContent = $box.html();
        $box.html('<div style="padding:20px;text-align:center;"><span style="font-size:20px;">⏳</span><p style="font-size:12px;color:#888;margin-top:8px;">Uploading...</p></div>');
        
        var formData = new FormData();
        formData.append('action', 'hushot_upload_image');
        formData.append('file', file);
        formData.append('nonce', hushot.nonce);
        
        $.ajax({
            url: hushot.ajax_url,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                if (response.success && response.data.url) {
                    $(hiddenSelector).val(response.data.url);
                    $box.html('<img src="' + response.data.url + '" style="max-width:100%;max-height:100px;border-radius:6px;"><input type="file" id="' + inputId + '" accept="image/*">');
                } else {
                    alert(response.data?.message || 'Upload failed.');
                    $box.html(originalContent);
                }
            },
            error: function() {
                alert('Upload failed.');
                $box.html(originalContent);
            }
        });
    }
    
    function handleImageUpload(input, boxSelector, hiddenSelector, urlSelector) {
        if (!input.files || !input.files[0]) return;
        
        var file = input.files[0];
        if (!file.type.match(/image.*/)) {
            alert('Please select an image file.');
            return;
        }
        if (file.size > 5 * 1024 * 1024) {
            alert('Image must be less than 5MB.');
            return;
        }
        
        var $box = $(boxSelector);
        var originalContent = $box.html();
        $box.html('<div style="padding:20px;text-align:center;"><span style="font-size:20px;">⏳</span><p style="font-size:12px;color:#888;margin-top:8px;">Uploading...</p></div>');
        
        var formData = new FormData();
        formData.append('action', 'hushot_upload_image');
        formData.append('file', file);
        formData.append('nonce', hushot.nonce);
        
        $.ajax({
            url: hushot.ajax_url,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                if (response.success && response.data.url) {
                    $(hiddenSelector).val(response.data.url);
                    if (urlSelector) $(urlSelector).val(response.data.url);
                    var inputId = boxSelector === '#logo-box' ? 'logo-file' : 'img-file';
                    showImagePreview(boxSelector, response.data.url, inputId);
                } else {
                    alert(response.data?.message || 'Upload failed.');
                    $box.html(originalContent);
                }
            },
            error: function() {
                alert('Upload failed.');
                $box.html(originalContent);
            }
        });
    }
    
    function showImagePreview(boxSelector, url, inputId) {
        var $box = $(boxSelector);
        $box.html('<img src="' + url + '" style="max-width:100%;max-height:100px;border-radius:6px;"><input type="file" id="' + inputId + '" accept="image/*">');
    }
    
    // Form Fields
    function initFormFields() {
        $(document).on('click', '#add-field-btn', function() {
            var fieldName = prompt('Enter field name:', 'Custom Field');
            if (fieldName && fieldName.trim()) {
                var slug = fieldName.toLowerCase().replace(/[^a-z0-9]/g, '_');
                var $field = $('<div class="hs-ff" data-field="' + slug + '"><span>' + fieldName + '</span><button type="button">×</button></div>');
                $('#form-fields').append($field);
                updateFormFieldsInput();
            }
        });
        $(document).on('click', '.hs-ff button', function(e) {
            e.preventDefault();
            $(this).closest('.hs-ff').remove();
            updateFormFieldsInput();
        });
    }
    
    function updateFormFieldsInput() {
        var fields = [];
        $('#form-fields .hs-ff').each(function() { fields.push($(this).data('field')); });
        $('#form_fields').val(fields.join(','));
    }
    
    // AI Writer
    function initAIWriter() {
        // Full page AI generator
        $(document).on('click', '#ai-gen-btn', function() {
            var prompt = $('#ai-prompt').val().trim();
            if (!prompt) { alert('Please describe your business first.'); return; }
            var $btn = $(this);
            var originalText = $btn.html();
            $btn.prop('disabled', true).html('🤖 Generating...');
            $.post(hushot.ajax_url, { action: 'hushot_generate_ai', product: prompt, goal: 'leads' }, function(response) {
                $btn.prop('disabled', false).html(originalText);
                if (response.success && response.data.content) {
                    var content = response.data.content;
                    
                    // Fill in page title
                    if (content.headline) {
                        $('input[name="page_title"]').val(content.headline);
                    }
                    
                    // Add header component and fill
                    var $headerPick = $('.hs-pick[data-comp="header"]');
                    if ($headerPick.length && !$('[data-b="header"]').length) {
                        $headerPick.click();
                    }
                    setTimeout(function() {
                        if (content.headline) $('input[name="header_title"]').val(content.headline);
                        if (content.subheadline) $('input[name="header_subtitle"]').val(content.subheadline);
                    }, 100);
                    
                    // Add description component and fill
                    var $descPick = $('.hs-pick[data-comp="description"]');
                    if ($descPick.length && !$('[data-b="description"]').length) {
                        $descPick.click();
                    }
                    setTimeout(function() {
                        if (content.description) $('textarea[name="description"]').val(content.description);
                    }, 200);
                    
                    // Add features component and fill
                    var $featPick = $('.hs-pick[data-comp="features"]');
                    if ($featPick.length && !$('[data-b="features"]').length) {
                        $featPick.click();
                    }
                    setTimeout(function() {
                        if (content.features && Array.isArray(content.features)) {
                            $('textarea[name="features"]').val(content.features.join('\n'));
                        }
                    }, 300);
                    
                    // Add WhatsApp component
                    var $waPick = $('.hs-pick[data-comp="whatsapp"]');
                    if ($waPick.length && !$('[data-b="whatsapp"]').length) {
                        $waPick.click();
                    }
                    setTimeout(function() {
                        if (content.cta) $('input[name="cta_text"]').val(content.cta);
                    }, 400);
                    
                    alert('✅ Page content generated! Review and edit as needed.');
                } else {
                    alert(response.data?.message || 'AI generation failed.');
                }
            }).fail(function() {
                $btn.prop('disabled', false).html(originalText);
                alert('Connection error.');
            });
        });
        
        // Field-specific AI write buttons
        $(document).on('click', '.hs-ai-write', function(e) {
            e.preventDefault();
            var $btn = $(this);
            var field = $btn.data('field');
            var $block = $btn.closest('.hs-block');
            var $textarea = $btn.closest('.hs-fld').find('textarea');
            
            // Get context from business context input first, then fall back to description/page title
            var businessContext = $block.find('.hs-ai-context').val() || '';
            var pageTitle = $('input[name="page_title"]').val() || $('input[name="title"]').val() || '';
            var businessName = $('input[name="business_name"]').val() || '';
            var description = $('textarea[name="description"]').val() || '';
            
            // For features field, prioritize description over page title
            var context;
            if (field === 'features') {
                context = businessContext || description || pageTitle || businessName || '';
            } else {
                context = businessContext || pageTitle || businessName || '';
            }
            
            if (!context || context.length < 2) {
                if (field === 'features') {
                    alert('Please enter a Description or Business Context first so AI knows what features to generate.');
                } else {
                    alert('Please enter a Business Context or Page Title first so AI knows what to write about.');
                }
                return;
            }
            
            var origText = $btn.html();
            $btn.prop('disabled', true).html('✨...');
            
            $.post(hushot.ajax_url, { 
                action: 'hushot_generate_ai', 
                product: context, 
                field: field,
                goal: 'leads' 
            }, function(response) {
                $btn.prop('disabled', false).html(origText);
                if (response.success && response.data.content) {
                    var content = response.data.content;
                    if (field === 'description' && content.description) {
                        $textarea.val(content.description);
                    } else if (field === 'features' && content.features) {
                        var features = Array.isArray(content.features) ? content.features.join('\n') : content.features;
                        $textarea.val(features);
                    } else if (field === 'product_desc' && content.description) {
                        $textarea.val(content.description);
                    }
                } else {
                    alert(response.data?.message || 'AI generation failed.');
                }
            }).fail(function() {
                $btn.prop('disabled', false).html(origText);
                alert('Connection error.');
            });
        });
        
        // Product-specific AI write button
        $(document).on('click', '.hs-ai-write-prod', function(e) {
            e.preventDefault();
            var $btn = $(this);
            var $item = $btn.closest('.hs-product-item');
            var $textarea = $item.find('.prod-desc');
            var $contextInput = $item.find('.prod-ai-context');
            var businessContext = $contextInput.val().trim();
            var productName = $item.find('.prod-name').val().trim();
            
            // Use business context if provided, otherwise use product name
            var prompt = businessContext || productName;
            
            if (!prompt || prompt.length < 2) {
                alert('Please enter your business type (e.g. bakery, salon) or product name first.');
                $contextInput.focus();
                return;
            }
            
            // If both are provided, combine them for better AI output
            if (businessContext && productName) {
                prompt = productName + ' - ' + businessContext;
            }
            
            var origText = $btn.html();
            $btn.prop('disabled', true).html('⏳...');
            
            $.post(hushot.ajax_url, { 
                action: 'hushot_generate_ai', 
                product: prompt, 
                field: 'product_desc',
                goal: 'sales' 
            }, function(response) {
                $btn.prop('disabled', false).html(origText);
                if (response.success && response.data.content && response.data.content.description) {
                    $textarea.val(response.data.content.description);
                    updateProductsJson();
                } else {
                    alert(response.data?.message || 'AI generation failed.');
                }
            }).fail(function() {
                $btn.prop('disabled', false).html(origText);
                alert('Connection error.');
            });
        });
    }
    
    // Products Section
    function initProducts() {
        var productCount = 0;
        
        $(document).on('click', '#add-product-btn', function() {
            // Check limit
            var limitText = $('.hs-product-limit').text();
            var currentProducts = $('.hs-product-item').length;
            
            if (limitText.indexOf('3') !== -1 && currentProducts >= 3) {
                alert('Essential plan allows maximum 3 products. Upgrade to Premium for unlimited.');
                return;
            }
            if (limitText.indexOf('0') !== -1) {
                alert('Products feature requires a paid plan. Please upgrade.');
                return;
            }
            
            productCount++;
            var html = '<div class="hs-product-item" data-index="' + productCount + '">' +
                '<div class="hs-product-row">' +
                '<div class="hs-product-img-box"><span>📷</span><input type="file" class="prod-img-file" accept="image/*"><img src="" style="display:none;"></div>' +
                '<div class="hs-product-fields">' +
                '<input type="text" class="prod-name" placeholder="Product Name">' +
                '<div class="hs-product-prices">' +
                '<input type="number" class="prod-old-price" placeholder="Old Price">' +
                '<input type="number" class="prod-new-price" placeholder="New Price">' +
                '</div>' +
                '<div class="hs-prod-desc-row">' +
                '<label style="font-size:12px;color:#333;font-weight:600;display:block;margin-bottom:4px;">Description</label>' +
                '<div style="display:flex;gap:4px;margin-bottom:6px;">' +
                '<input type="text" class="prod-ai-context" placeholder="Your business type (e.g. bakery, salon)" style="flex:1;padding:6px 8px;font-size:11px;border:1px solid #ddd;border-radius:4px;">' +
                '<button type="button" class="hs-ai-write-prod" style="background:linear-gradient(135deg,#667eea,#764ba2);color:#fff;border:none;padding:6px 10px;border-radius:4px;font-size:10px;cursor:pointer;white-space:nowrap;">✨ AI Write</button>' +
                '</div>' +
                '<textarea class="prod-desc" rows="2" placeholder="Short description of this product..."></textarea>' +
                '</div>' +
                '<div class="hs-product-cta-config" style="margin-top:12px;padding:12px;background:#f0f7ff;border-radius:8px;border:1px solid #dbeafe;">' +
                '<label style="font-size:12px;color:#1e40af;font-weight:600;display:block;margin-bottom:10px;">📱 CTA Buttons (View Detail)</label>' +
                '<p style="font-size:11px;color:#666;margin:0 0 10px;">Select which buttons appear when customer taps "View Details":</p>' +
                '<div style="display:flex;flex-wrap:wrap;gap:12px;align-items:center;">' +
                '<label style="display:flex;align-items:center;gap:6px;font-size:13px;cursor:pointer;padding:6px 10px;background:#fff;border-radius:6px;border:1px solid #ddd;"><input type="checkbox" class="prod-cta-wa-check" checked> 💬 WhatsApp</label>' +
                '<label style="display:flex;align-items:center;gap:6px;font-size:13px;cursor:pointer;padding:6px 10px;background:#fff;border-radius:6px;border:1px solid #ddd;"><input type="checkbox" class="prod-cta-link-check"> 🔗 Link</label>' +
                '<input type="text" class="prod-cta-link" placeholder="Enter link URL" style="flex:1;min-width:180px;padding:8px 10px;font-size:12px;border:1px solid #ddd;border-radius:6px;">' +
                '</div>' +
                '</div>' +
                '</div></div>' +
                '<button type="button" class="hs-product-remove" style="margin-top:10px;">🗑️ Remove Product</button>' +
                '</div>';
            $('#products-list').append(html);
            updateProductsJson();
        });
        
        // Update JSON when CTA checkboxes change
        $(document).on('change', '.prod-cta-wa-check, .prod-cta-link-check', function() {
            updateProductsJson();
        });
        
        // Remove product
        $(document).on('click', '.hs-product-remove', function() {
            $(this).closest('.hs-product-item').remove();
            updateProductsJson();
        });
        
        // Product image upload
        $(document).on('change', '.prod-img-file', function() {
            var $item = $(this).closest('.hs-product-item');
            var file = this.files[0];
            if (!file) return;
            
            var $imgBox = $(this).closest('.hs-product-img-box');
            $imgBox.find('span').text('⏳');
            
            var formData = new FormData();
            formData.append('action', 'hushot_upload_image');
            formData.append('file', file);
            formData.append('nonce', hushot.nonce);
            
            $.ajax({
                url: hushot.ajax_url,
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    if (response.success && response.data.url) {
                        $imgBox.find('img').attr('src', response.data.url).show();
                        $imgBox.find('span').hide();
                        $item.data('img', response.data.url);
                        updateProductsJson();
                    } else {
                        $imgBox.find('span').text('📷');
                        alert('Upload failed.');
                    }
                },
                error: function() {
                    $imgBox.find('span').text('📷');
                }
            });
        });
        
        // Update JSON on field change
        $(document).on('change keyup', '.prod-name, .prod-old-price, .prod-new-price, .prod-desc', function() {
            updateProductsJson();
        });
    }
    
    function updateProductsJson() {
        var products = [];
        $('.hs-product-item').each(function() {
            var $item = $(this);
            products.push({
                name: $item.find('.prod-name').val() || '',
                old_price: $item.find('.prod-old-price').val() || '',
                new_price: $item.find('.prod-new-price').val() || '',
                description: $item.find('.prod-desc').val() || '',
                image: $item.data('img') || $item.find('.hs-product-img-box img').attr('src') || '',
                show_whatsapp: $item.find('.prod-cta-wa-check').is(':checked'),
                show_link: $item.find('.prod-cta-link-check').is(':checked'),
                cta_link: $item.find('.prod-cta-link').val() || ''
            });
        });
        $('#products_json').val(JSON.stringify(products));
    }
    
    // Update JSON on CTA field change too
    $(document).on('change', '.prod-cta-link', function() {
        updateProductsJson();
    });
    
    // Save products as template
    $(document).on('click', '.save-products-tpl', function() {
        var productsJson = $('#products_json').val();
        if (!productsJson || productsJson === '[]') {
            alert('Add some products first before saving as template.');
            return;
        }
        
        var name = prompt('Enter a name for this products template:');
        if (!name || !name.trim()) return;
        
        var $btn = $(this);
        $btn.prop('disabled', true).text('Saving...');
        
        $.post(hushot.ajax_url, {
            action: 'hushot_save_products_template',
            template_name: name.trim(),
            products_json: productsJson
        }, function(response) {
            $btn.prop('disabled', false).text('💾 Save');
            if (response.success) {
                alert('Products template saved!');
                // Refresh templates dropdown
                loadProductsTemplates();
            } else {
                alert(response.data?.message || 'Failed to save template.');
            }
        }).fail(function() {
            $btn.prop('disabled', false).text('💾 Save');
            alert('Connection error.');
        });
    });
    
    // Load products from template
    $(document).on('change', '.load-products-tpl', function() {
        var selected = $(this).val();
        if (!selected) return;
        
        if ($('.hs-product-item').length > 0) {
            if (!confirm('This will replace your current products. Continue?')) {
                $(this).val('');
                return;
            }
        }
        
        $.post(hushot.ajax_url, {
            action: 'hushot_get_products_templates'
        }, function(response) {
            if (response.success && response.data.templates && response.data.templates[selected]) {
                var tpl = response.data.templates[selected];
                var products = JSON.parse(tpl.products);
                
                // Clear current products
                $('#products-list').empty();
                
                // Load template products
                window.hushotSavedProducts = products;
                loadSavedProducts();
                updateProductsJson();
            }
        });
    });
    
    // Load products templates into dropdown
    function loadProductsTemplates() {
        $.post(hushot.ajax_url, {
            action: 'hushot_get_products_templates'
        }, function(response) {
            if (response.success && response.data.templates) {
                var $select = $('.load-products-tpl');
                $select.find('option:not(:first)').remove();
                
                Object.keys(response.data.templates).forEach(function(name) {
                    $select.append('<option value="' + name + '">' + name + '</option>');
                });
            }
        });
    }
    
    // Load templates on page load
    $(document).ready(function() {
        if ($('.load-products-tpl').length) {
            loadProductsTemplates();
        }
    });
    
    function loadSavedProducts() {
        if (window.hushotSavedProducts && Array.isArray(window.hushotSavedProducts)) {
            var products = window.hushotSavedProducts;
            products.forEach(function(p, i) {
                // Handle both old format (cta_type) and new format (show_whatsapp, show_link)
                var showWa = p.show_whatsapp !== undefined ? p.show_whatsapp : (p.cta_type === 'whatsapp' || !p.cta_type);
                var showLink = p.show_link !== undefined ? p.show_link : (p.cta_type === 'link');
                
                var html = '<div class="hs-product-item" data-index="' + i + '" data-img="' + (p.image || '') + '">' +
                    '<div class="hs-product-row">' +
                    '<div class="hs-product-img-box">' + 
                    (p.image ? '<img src="' + p.image + '" style="display:block;">' : '<span>📷</span>') +
                    '<input type="file" class="prod-img-file" accept="image/*"></div>' +
                    '<div class="hs-product-fields">' +
                    '<input type="text" class="prod-name" placeholder="Product Name" value="' + (p.name || '').replace(/"/g, '&quot;') + '">' +
                    '<div class="hs-product-prices">' +
                    '<input type="number" class="prod-old-price" placeholder="Old Price" value="' + (p.old_price || '') + '">' +
                    '<input type="number" class="prod-new-price" placeholder="New Price" value="' + (p.new_price || '') + '">' +
                    '</div>' +
                    '<div class="hs-prod-desc-row">' +
                    '<label style="font-size:12px;color:#333;font-weight:600;display:block;margin-bottom:4px;">Description</label>' +
                    '<div style="display:flex;gap:4px;margin-bottom:6px;">' +
                    '<input type="text" class="prod-ai-context" placeholder="Your business type (e.g. bakery, salon)" style="flex:1;padding:6px 8px;font-size:11px;border:1px solid #ddd;border-radius:4px;">' +
                    '<button type="button" class="hs-ai-write-prod" style="background:linear-gradient(135deg,#667eea,#764ba2);color:#fff;border:none;padding:6px 10px;border-radius:4px;font-size:10px;cursor:pointer;white-space:nowrap;">✨ AI Write</button>' +
                    '</div>' +
                    '<textarea class="prod-desc" rows="2" placeholder="Short description of this product...">' + (p.description || '') + '</textarea>' +
                    '</div>' +
                    '<div class="hs-product-cta-config" style="margin-top:12px;padding:12px;background:#f0f7ff;border-radius:8px;border:1px solid #dbeafe;">' +
                    '<label style="font-size:12px;color:#1e40af;font-weight:600;display:block;margin-bottom:10px;">📱 CTA Buttons (View Detail)</label>' +
                    '<p style="font-size:11px;color:#666;margin:0 0 10px;">Select which buttons appear when customer taps "View Details":</p>' +
                    '<div style="display:flex;flex-wrap:wrap;gap:12px;align-items:center;">' +
                    '<label style="display:flex;align-items:center;gap:6px;font-size:13px;cursor:pointer;padding:6px 10px;background:#fff;border-radius:6px;border:1px solid #ddd;"><input type="checkbox" class="prod-cta-wa-check"' + (showWa ? ' checked' : '') + '> 💬 WhatsApp</label>' +
                    '<label style="display:flex;align-items:center;gap:6px;font-size:13px;cursor:pointer;padding:6px 10px;background:#fff;border-radius:6px;border:1px solid #ddd;"><input type="checkbox" class="prod-cta-link-check"' + (showLink ? ' checked' : '') + '> 🔗 Link</label>' +
                    '<input type="text" class="prod-cta-link" placeholder="Enter link URL" value="' + (p.cta_link || '').replace(/"/g, '&quot;') + '" style="flex:1;min-width:180px;padding:8px 10px;font-size:12px;border:1px solid #ddd;border-radius:6px;">' +
                    '</div>' +
                    '</div>' +
                    '</div></div>' +
                    '<button type="button" class="hs-product-remove" style="margin-top:10px;">🗑️ Remove Product</button>' +
                    '</div>';
                $('#products-list').append(html);
            });
        }
    }
    
    // Form Submissions
    function initForms() {
        var formMappings = {
            '#hs-login': 'hushot_login',
            '#hs-register': 'hushot_register',
            '#hs-forgot': 'hushot_forgot_password',
            '#hs-reset': 'hushot_reset_password',
            '#hs-create': 'hushot_create_page',
            '#hs-edit': 'hushot_update_page',
            '#hs-profile': 'hushot_update_profile',
            '#hs-checkout': 'hushot_checkout',
            '#hs-cancel': 'hushot_cancel_subscription'
        };
        $.each(formMappings, function(selector, action) {
            $(document).on('submit', selector, function(e) {
                e.preventDefault();
                submitForm($(this), action);
            });
        });
    }
    
    function submitForm($form, action) {
        var $btn = $form.find('button[type="submit"]');
        var $msg = $form.find('.hs-msg');
        $btn.addClass('loading').prop('disabled', true);
        $msg.removeClass('ok err').hide();
        
        var data = { action: action };
        
        // Handle form serialization
        $form.serializeArray().forEach(function(item) {
            data[item.name] = item.value;
        });
        
        // Save component order
        if (action === 'hushot_create_page' || action === 'hushot_update_page') {
            var componentOrder = [];
            $('#components-area .hs-block').each(function() {
                var blockType = $(this).attr('data-b');
                if (blockType) {
                    componentOrder.push(blockType);
                }
            });
            data.component_order = componentOrder.join(',');
            
            // Update products JSON
            updateProductsJson();
            data.products_json = $('#products_json').val();
            
            // Collect all headers as JSON array
            var headers = [];
            $('#components-area .hs-block[data-b="header"]').each(function() {
                headers.push({
                    title: $(this).find('.header-title-input').val() || '',
                    subtitle: $(this).find('.header-subtitle-input').val() || ''
                });
            });
            data.headers_json = JSON.stringify(headers);
        }
        
        $.post(hushot.ajax_url, data, function(response) {
            $btn.removeClass('loading').prop('disabled', false);
            if (response.success) {
                // Check if promote checkbox is checked (for both create and edit)
                var promoteChecked = $('#promote-checkbox').is(':checked');
                var pageId = response.data?.page_id;
                
                if (promoteChecked && pageId && hushot.ads_promote_url) {
                    // Redirect to ads promote page
                    window.location.href = hushot.ads_promote_url + '?page_id=' + pageId;
                    return;
                }
                
                // Special handling for edit page
                if (action === 'hushot_update_page') {
                    // Scroll to top
                    $('html, body').animate({ scrollTop: 0 }, 400);
                    // Show success message
                    $('#save-success').slideDown(200);
                    // Hide after 5 seconds
                    setTimeout(function() {
                        $('#save-success').slideUp(200);
                    }, 5000);
                } else {
                    $msg.addClass('ok').text(response.data?.message || 'Success!').show();
                    if (response.data?.redirect) {
                        setTimeout(function() { window.location.href = response.data.redirect; }, 1000);
                    }
                }
            } else {
                $msg.addClass('err').text(response.data?.message || 'Error occurred.').show();
            }
        }).fail(function() {
            $btn.removeClass('loading').prop('disabled', false);
            $msg.addClass('err').text('Connection error.').show();
        });
    }
    
    // Page Actions
    function initPageActions() {
        // Delete page
        $(document).on('click', '.hs-del', function() {
            var pageId = $(this).data('id');
            if (!pageId) return;
            if (confirm('Delete this page? This cannot be undone.')) {
                var $row = $(this).closest('.hs-pg, .hs-recent-item');
                $.post(hushot.ajax_url, { action: 'hushot_delete_page', page_id: pageId }, function(response) {
                    if (response.success) {
                        $row.slideUp(200, function() { $(this).remove(); });
                    } else {
                        alert(response.data?.message || 'Delete failed.');
                    }
                });
            }
        });
        
        // Duplicate page
        $(document).on('click', '.hs-dup', function(e) {
            e.preventDefault();
            e.stopPropagation();
            var pageId = $(this).data('id');
            if (!pageId) {
                alert('Error: No page ID found');
                return;
            }
            if (!confirm('Duplicate this page?')) return;
            var $btn = $(this);
            var origText = $btn.text() || $btn.html();
            $btn.prop('disabled', true).text('...');
            $.ajax({
                url: hushot.ajax_url,
                type: 'POST',
                data: { 
                    action: 'hushot_duplicate_page', 
                    page_id: pageId
                },
                success: function(response) {
                    console.log('Duplicate response:', response);
                    if (response.success) {
                        alert('Page duplicated successfully!');
                        if (response.data && response.data.redirect) {
                            window.location.href = response.data.redirect;
                        } else {
                            location.reload();
                        }
                    } else {
                        alert(response.data?.message || 'Duplicate failed.');
                        $btn.prop('disabled', false).html(origText);
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Duplicate error:', xhr.responseText);
                    alert('Request failed: ' + error);
                    $btn.prop('disabled', false).html(origText);
                }
            });
        });
        
        // Use template
        $(document).on('click', '.hs-use-tpl', function() {
            var $btn = $(this);
            var tplData = {
                color: $btn.data('color'),
                img: $btn.data('img'),
                headline: $btn.data('headline'),
                desc: $btn.data('desc'),
                features: $btn.data('features')
            };
            
            var title = prompt('Enter a title for your new page:', tplData.headline || 'My Landing Page');
            if (!title) return;
            
            $btn.text('Creating...');
            
            $.post(hushot.ajax_url, {
                action: 'hushot_use_template',
                title: title,
                template_id: $btn.data('id'),
                primary_color: tplData.color,
                image_url: tplData.img,
                header_title: tplData.headline,
                description: tplData.desc,
                features: tplData.features
            }, function(response) {
                if (response.success && response.data?.redirect) {
                    window.location.href = response.data.redirect;
                } else {
                    $btn.text('Use template');
                    alert(response.data?.message || 'Failed to create page.');
                }
            }).fail(function() {
                $btn.text('Use template');
                alert('Connection error.');
            });
        });
        
        // Lead form submission
        $(document).on('submit', '#hs-lead-form', function(e) {
            e.preventDefault();
            var $form = $(this);
            var $btn = $form.find('button[type="submit"]');
            var $msg = $form.find('.hs-lead-msg');
            
            $btn.prop('disabled', true).text('Sending...');
            $msg.hide();
            
            var data = { action: 'hushot_submit_lead' };
            $form.serializeArray().forEach(function(item) { data[item.name] = item.value; });
            
            $.post(hushot.ajax_url, data, function(response) {
                $btn.prop('disabled', false).text('Submit');
                if (response.success) {
                    $msg.removeClass('err').addClass('ok').text(response.data?.message || 'Thank you!').show();
                    $form[0].reset();
                } else {
                    $msg.removeClass('ok').addClass('err').text(response.data?.message || 'Error occurred.').show();
                }
            }).fail(function() {
                $btn.prop('disabled', false).text('Submit');
                $msg.addClass('err').text('Connection error.').show();
            });
        });
    }
    
    // Form fields checkboxes handler
    $(document).on('change', '#ff-checks input[type="checkbox"]', updateFormFields);
    $(document).on('click', '#ff-add', function() {
        var name = $('#ff-new').val().trim();
        if (!name) return;
        var slug = name.toLowerCase().replace(/[^a-z0-9]/g, '_');
        var $list = $('#ff-custom');
        if ($list.find('[data-slug="'+slug+'"]').length) { alert('Field already exists'); return; }
        $list.append('<div class="hs-custom-field" data-slug="'+slug+'"><input type="checkbox" data-ff="'+slug+'" checked> '+name+' <button type="button" class="rem-cf">×</button></div>');
        $('#ff-new').val('');
        updateFormFields();
    });
    $(document).on('click', '.rem-cf', function() {
        $(this).closest('.hs-custom-field').remove();
        updateFormFields();
    });
    function updateFormFields() {
        var fields = [];
        $('#ff-checks input:checked, #ff-custom input:checked').each(function() {
            fields.push($(this).data('ff'));
        });
        $('#ff-val').val(fields.join(','));
    }
    
    // Video source switching
    $(document).on('change', '.video-source-radio', function() {
        var $block = $(this).closest('.hs-block');
        var source = $(this).val();
        if (source === 'url') {
            $block.find('.hs-video-url-field').show();
            $block.find('.hs-video-upload-field').hide();
        } else {
            $block.find('.hs-video-url-field').hide();
            $block.find('.hs-video-upload-field').show();
        }
    });
    
    // Video upload box click
    $(document).on('click', '.hs-video-upload-box', function() {
        $(this).find('.video-file-input').click();
    });
    
    // Video file upload
    $(document).on('change', '.video-file-input', function() {
        var file = this.files[0];
        if (!file) return;
        
        // Validate file type
        if (!file.type.match(/video\/(mp4|webm)/)) {
            alert('Please select an MP4 or WebM video file.');
            return;
        }
        
        // Validate file size (50MB max)
        if (file.size > 50 * 1024 * 1024) {
            alert('Video must be less than 50MB.');
            return;
        }
        
        var $box = $(this).closest('.hs-video-upload-box');
        var $hidden = $box.find('input[name="video_file_url"]');
        var originalContent = $box.html();
        
        $box.html('<div style="padding:20px;text-align:center;"><span style="font-size:24px;">⏳</span><p style="font-size:12px;color:#888;margin-top:8px;">Uploading video...</p></div>');
        
        var formData = new FormData();
        formData.append('action', 'hushot_upload_video');
        formData.append('file', file);
        formData.append('nonce', hushot.nonce);
        
        $.ajax({
            url: hushot.ajax_url,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                if (response.success && response.data.url) {
                    $hidden.val(response.data.url);
                    $box.html('<div style="padding:20px;text-align:center;position:relative;"><span style="font-size:32px;">✅</span><p style="font-size:12px;color:#10b981;margin-top:8px;">Video uploaded!</p><video src="'+response.data.url+'" style="max-width:100%;max-height:100px;margin-top:10px;" controls></video><p style="font-size:11px;color:#666;margin-top:8px;">Click to upload a different video</p><input type="file" class="video-file-input" accept="video/mp4,video/webm" style="position:absolute;inset:0;opacity:0;cursor:pointer;"><input type="hidden" name="video_file_url" value="'+response.data.url+'"></div>');
                } else {
                    alert(response.data?.message || 'Upload failed.');
                    $box.html(originalContent);
                }
            },
            error: function() {
                alert('Upload failed. Please try again.');
                $box.html(originalContent);
            }
        });
    });
    
    // Copy URL helpers (My Pages / Recent Pages)
    function hushotCopyText(text) {
        text = (text || '').toString();
        if (!text) return;
        if (navigator.clipboard && window.isSecureContext) {
            navigator.clipboard.writeText(text).catch(function(){});
            return;
        }
        // Fallback
        var ta = document.createElement('textarea');
        ta.value = text;
        ta.setAttribute('readonly', '');
        ta.style.position = 'absolute';
        ta.style.left = '-9999px';
        document.body.appendChild(ta);
        ta.select();
        try { document.execCommand('copy'); } catch(e) {}
        document.body.removeChild(ta);
    }

    $(document).on('click', '.hs-copy-url', function(e){
        e.preventDefault();
        var url = $(this).data('url') || '';
        hushotCopyText(url);
        // lightweight feedback
        var $btn = $(this);
        var old = $btn.text();
        $btn.text('✅');
        setTimeout(function(){ $btn.text(old); }, 900);
    });

    $(document).on('click', '.hs-url-input', function(){
        try { this.select(); } catch(e) {}
    });

    // Payment button (Flutterwave) on published landing pages
    function ensureFlutterwaveLoaded(cb){
        if (window.FlutterwaveCheckout) return cb();
        var existing = document.querySelector('script[data-hushot-fw]');
        if (existing){
            existing.addEventListener('load', cb, {once:true});
            return;
        }
        var s = document.createElement('script');
        s.src = 'https://checkout.flutterwave.com/v3.js';
        s.async = true;
        s.setAttribute('data-hushot-fw', '1');
        s.onload = cb;
        document.head.appendChild(s);
    }

    function parseAmount(raw){
        if(raw === null || raw === undefined) return 0;
        var s = raw.toString();
        // Strip currency symbols/letters and keep digits + dot
        s = s.replace(/\\\\?u[0-9a-fA-F]{4}/g, '').replace(/[^0-9.]/g, '');
        var n = parseFloat(s);
        if (isNaN(n)) return 0;
        return n;
    }

    $(document).on('click', '.hs-pay-btn', function(e){
        e.preventDefault();
        var $btn = $(this);
        var pageId = $btn.data('pageId') || $btn.data('page-id');
        var amountRaw = $btn.data('amount') || $btn.data('price') || $btn.attr('data-amount');
        var currency = $btn.data('currency') || 'NGN';
        var amount = parseAmount(amountRaw);
        if (!pageId || !amount){
            alert('Payment is not configured for this page.');
            return;
        }

        // Collect buyer details (minimal)
        var email = window.prompt('Enter your email to receive your receipt:', '');
        if(!email) return;

        $btn.prop('disabled', true).css('opacity', 0.7);
        $.post(hushot.ajax_url, {
            action: 'hushot_marketplace_checkout',
            nonce: hushot.nonce,
            page_id: pageId,
            amount: amount,
            currency: currency,
            customer_email: email
        }).done(function(res){
            if(!res || !res.success || !res.data){
                alert((res && res.data && res.data.message) || 'Unable to start payment.');
                return;
            }
            ensureFlutterwaveLoaded(function(){
                try {
                    window.FlutterwaveCheckout({
                        public_key: res.data.public_key,
                        tx_ref: res.data.tx_ref,
                        amount: res.data.amount,
                        currency: res.data.currency,
                        redirect_url: res.data.redirect_url,
                        customer: { email: email },
                        meta: res.data.meta || {},
                        customizations: { title: res.data.title || 'Payment', description: res.data.description || '' }
                    });
                } catch(err){
                    alert('Payment popup could not be opened.');
                }
            });
        }).fail(function(){
            alert('Payment request failed.');
        }).always(function(){
            $btn.prop('disabled', false).css('opacity', 1);
        });
    });

})(jQuery);
