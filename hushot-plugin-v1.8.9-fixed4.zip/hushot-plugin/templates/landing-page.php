<?php
/**
 * Hushot Landing Page v1.8.9 - Visual Builder Compatible
 * Renders pages from _hushot_sections JSON (visual builder)
 * Falls back to component meta fields for legacy pages
 */
if (!defined('ABSPATH')) exit;

$page_id = get_the_ID();
$owner_id = get_post_field('post_author', $page_id);

// Check if this is a visual builder page
$sections_json = get_post_meta($page_id, '_hushot_sections', true);
$is_visual_builder = !empty($sections_json);

// Get primary color
$primary_color = get_post_meta($page_id, '_hushot_primary_color', true) ?: '#F7931E';

// Watermark
$show_watermark = true;
if (class_exists('Hushot_Membership')) {
    $show_watermark = Hushot_Membership::show_watermark($owner_id);
}

// Track view - Session-based deduplication
$views = (int)get_post_meta($page_id, '_hushot_views', true);
$session_key = 'hushot_viewed_' . $page_id;
$should_count = true;
if (isset($_COOKIE[$session_key])) {
    $last_view = (int)$_COOKIE[$session_key];
    if (time() - $last_view < 1800) $should_count = false;
}
if ($should_count) {
    update_post_meta($page_id, '_hushot_views', $views + 1);
    setcookie($session_key, time(), time() + 1800, '/');
}

// If visual builder page, render sections
if ($is_visual_builder) {
        // Try to decode JSON safely.
    // IMPORTANT: do NOT use stripslashes() on JSON because it can corrupt valid escape sequences like \n or \uXXXX.
    $sections = json_decode($sections_json, true);

    // If decoding failed, try wp_unslash (reverses WP slashes without breaking JSON escapes).
    if (!is_array($sections) && !empty($sections_json)) {
        $sections = json_decode(wp_unslash($sections_json), true);
    }

    // Handle double-encoded JSON (JSON string that contains JSON array/object).
    if (is_string($sections)) {
        $maybe = trim($sections);
        if ($maybe !== '' && (strpos($maybe, '[') === 0 || strpos($maybe, '{') === 0)) {
            $sections2 = json_decode($maybe, true);
            if (is_array($sections2)) $sections = $sections2;
        }
    }

    // If still failing, try trimming BOM/whitespace (common copy/paste/storage issues).
    if (!is_array($sections) && !empty($sections_json)) {
        $trimmed = trim($sections_json);
        $trimmed = preg_replace('/^\xEF\xBB\xBF/', '', $trimmed); // Remove UTF-8 BOM if present
        $sections = json_decode($trimmed, true);
    }

    // Recovery for legacy corrupted JSON stored with extra escaping.
    // Only attempted if the safe decode variants failed.
    if (!is_array($sections) && !empty($sections_json)) {
        $recovered = json_decode(stripslashes($sections_json), true);
        if (!is_array($recovered)) {
            $recovered = json_decode(stripslashes(wp_unslash($sections_json)), true);
        }
        if (is_array($recovered)) {
            $sections = $recovered;
        }
    }

    // Ensure sections is always an array
    if (!is_array($sections)) {
        $sections = array();
        // Log for debugging
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('Hushot: Failed to decode sections JSON for page ' . $page_id . ': ' . json_last_error_msg());
        }
    }

// Decode common escaped sequences that sometimes get stored as literal text (e.g. "u20a6", "\u20a6", "\n").
if (!function_exists('hushot_vb_decode')) {
    function hushot_vb_decode($s) {
        if (!is_string($s)) return $s;
        $s = preg_replace_callback('/\\u([0-9a-fA-F]{4})/', function($m){
            $cp = hexdec($m[1]);
            return mb_convert_encoding('&#'.$cp.';', 'UTF-8', 'HTML-ENTITIES');
        }, $s);
        $s = preg_replace_callback('/(?<!\\)u([0-9a-fA-F]{4})/', function($m){
            $cp = hexdec($m[1]);
            return mb_convert_encoding('&#'.$cp.';', 'UTF-8', 'HTML-ENTITIES');
        }, $s);
        $s = str_replace(array('\\r\\n','\\n','\\r'), "\n", $s);
        if (strpos($s, "\n") === false && preg_match('/\w+n[A-Z0-9]/', $s)) {
            $s = preg_replace('/(?<=\w)n(?=[A-Z0-9])/', "\n", $s);
        }
        return $s;
    }
}

    if (!is_array($sections)) $sections = array();

    // Helpers (Visual Builder)
    if (!function_exists('hushot_currency_symbol')) {
        function hushot_currency_symbol($code){
            $map = array(
                'NGN' => '₦', 'GHS' => '₵', 'KES' => 'KSh', 'UGX' => 'USh', 'TZS' => 'TSh',
                'ZAR' => 'R', 'RWF' => 'FRw', 'XOF' => 'CFA', 'XAF' => 'CFA', 'ETB' => 'Br',
                'MAD' => 'د.م.', 'EGP' => 'E£', 'DZD' => 'دج', 'TND' => 'د.ت', 'LYD' => 'ل.د', 'SDG' => 'ج.س', 'ZMW' => 'ZK', 'BWP' => 'P', 'NAD' => '$', 'AOA' => 'Kz', 'MZN' => 'MT', 'MWK' => 'MK', 'GMD' => 'D', 'SLL' => 'Le', 'LRD' => '$', 'GNF' => 'FG', 'CDF' => 'FC',
                'USD' => '$', 'EUR' => '€', 'GBP' => '£'
            );
            $code = strtoupper((string)$code);
            return $map[$code] ?? $code;
        }
    }

    if (!function_exists('hushot_decode_unicode_escapes')) {
        function hushot_decode_unicode_escapes($str){
            return hushot_vb_decode((string)$str);
        }
    }

if (!function_exists('hushot_format_price')) {
        function hushot_format_price($raw, $currency_code = 'NGN'){
            $raw = hushot_decode_unicode_escapes($raw);
            $raw = html_entity_decode($raw, ENT_QUOTES | ENT_HTML5, 'UTF-8');
            $cur = hushot_currency_symbol($currency_code);
            $trim = trim((string)$raw);
            if ($trim === '') return '';
            // If already contains currency letters/symbols, keep as-is but ensure unicode is decoded
            if (preg_match('/[A-Za-z₦₵€£$]|CFA|KSh|USh|TSh|FRw|DH|E£/u', $trim)) {
                return $trim;
            }
            // Numeric formatting
            $num = preg_replace('/[^0-9.]/', '', $trim);
            if ($num === '') return $trim;
            $val = (float)$num;
            $fmt = number_format($val, 0, '.', ',');
            return $cur . $fmt;
        }
    }
    
    // Get sticky bar settings
    $sticky_bar = get_post_meta($page_id, '_hushot_sticky_bar', true);
    $sticky_bar_data = $sticky_bar ? json_decode($sticky_bar, true) : null;
    
    ?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0">
    <title><?php echo esc_html(get_the_title()); ?></title>
    <?php
    $seo_desc = get_post_meta($page_id, '_hushot_seo_description', true);
    if (!$seo_desc) {
        foreach ($sections as $sec) {
            if ($sec['type'] === 'hero' && !empty($sec['subheadline'])) {
                $seo_desc = $sec['subheadline'];
                break;
            }
        }
    }
    ?>
    <meta name="description" content="<?php echo esc_attr($seo_desc); ?>">
    <style>
    :root{--pc:<?php echo esc_attr($primary_color); ?>;}
    *{margin:0;padding:0;box-sizing:border-box;}
    html,body{min-height:100vh;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;font-size:16px;line-height:1.5;color:#1a1a2e;background:#fff;}
    img,video{max-width:100%;height:auto;display:block;}
    
    /* Section Base */
    .hs-sec{width:100%;}
    
    /* Hero Section */
    .hs-hero{padding:48px 24px;text-align:center;}
    .hs-hero.style-gradient{background:linear-gradient(135deg,var(--pc) 0%,#1a1a2e 100%);color:#fff;}
    .hs-hero.style-bold{background:#1a1a2e;color:#fff;}
    .hs-hero.style-minimal{background:#fff;color:#1a1a2e;}
    .hs-hero h1{font-size:28px;font-weight:800;margin:0 0 12px;line-height:1.2;}
    .hs-hero p{font-size:16px;opacity:0.9;margin:0 0 20px;}
    .hs-hero img,.hs-hero video{max-width:100%;border-radius:12px;margin-top:16px;}
    
    /* Banner Section (Combined) */
    .hs-banner{padding:40px 24px;text-align:center;background:linear-gradient(135deg,var(--pc),#1a1a2e);}
    .hs-banner.style-light{background:#f9fafb;color:#1a1a2e;}
    .hs-banner.style-dark{background:#1a1a2e;color:#fff;}
    .hs-banner h2{font-size:26px;font-weight:800;margin:0 0 10px;color:inherit;}
    .hs-banner p{font-size:15px;opacity:0.9;margin:0 0 20px;}
    .hs-banner img{max-width:100%;border-radius:12px;margin:16px auto;}
    .hs-banner .btn{display:inline-block;padding:14px 32px;background:#fff;color:var(--pc);border-radius:12px;font-weight:700;font-size:16px;text-decoration:none;transition:transform 0.2s;}
    .hs-banner.style-light .btn{background:var(--pc);color:#fff;}
    .hs-banner .btn:hover{transform:translateY(-2px);}
    
    /* Features Section */
    .hs-features{padding:32px 24px;background:#f9fafb;}
    .hs-features.style-dark{background:#1a1a2e;color:#fff;}
    .hs-features.style-cards{background:#fff;}
    .hs-features h3{font-size:20px;font-weight:700;margin:0 0 20px;text-align:center;}
    .hs-features ul{list-style:none;max-width:500px;margin:0 auto;}
    .hs-features li{display:flex;align-items:flex-start;gap:12px;padding:14px 0;font-size:15px;border-bottom:1px solid rgba(0,0,0,0.08);color:#374151;}
    .hs-features.style-dark li{border-color:rgba(255,255,255,0.1);color:#e5e7eb;}
    .hs-features li:last-child{border:none;}
    .hs-features li::before{content:'✓';color:var(--pc);font-weight:bold;font-size:18px;flex-shrink:0;}
    .hs-features.style-dark li::before{color:#10b981;}
    
    /* CTA Section */
    .hs-cta{padding:22px 16px;text-align:center;}
    .hs-cta.style-full{background:var(--pc);color:#fff;}
    .hs-cta.style-light{background:#fff;color:#111;}
    .hs-cta.style-gradient{background:linear-gradient(135deg,var(--pc),#1a1a2e);color:#fff;}
    .hs-cta.style-dark{background:#1a1a2e;color:#fff;}

    .hs-cta.style-dark{background:#1a1a2e;color:#fff;}
    .hs-cta p{font-size:16px;margin:0 0 20px;opacity:0.9;}
    .hs-cta .btn{display:inline-block;padding:16px 40px;background:var(--pc);color:#fff;border-radius:12px;font-weight:700;font-size:17px;text-decoration:none;transition:all 0.2s;box-shadow:0 4px 20px rgba(0,0,0,0.2);}
    .hs-cta.style-full .btn{background:#fff;color:var(--pc);}
    .hs-cta .btn:hover{transform:translateY(-2px);box-shadow:0 8px 30px rgba(0,0,0,0.25);}
    
    /* Media Section */
    .hs-media{padding:24px;}
    .hs-media.style-full{padding:0;}
    .hs-media img,.hs-media video{width:100%;border-radius:12px;}
    .hs-media.style-full img,.hs-media.style-full video{border-radius:0;}
    
    /* Text Section */
    .hs-text{padding:32px 24px;background:#fff;}
    .hs-text h3{font-size:22px;font-weight:800;margin:0 0 12px;text-align:center;}
    .hs-text.style-gradient{background:linear-gradient(135deg,var(--pc),#1a1a2e);color:#fff;}
    .hs-text.style-gradient p{color:#fff;}
    .hs-text.style-gradient h3,.hs-text.style-dark h3{color:#fff;}
    .hs-text.style-dark{background:#1a1a2e;color:#fff;}
    .hs-text.style-dark p{color:#fff;}
    .hs-text p{font-size:15px;line-height:1.8;color:#374151;max-width:600px;margin:0 auto;}
    
    /* Payment Section */
    .hs-payment{padding:22px 16px;text-align:center;background:#fff;}
    .hs-payment.style-light{background:#fff;}
    .hs-payment.style-gradient{background:linear-gradient(135deg,var(--pc),#1a1a2e);}
    .hs-payment.style-dark{background:#1a1a2e;}

    .hs-pay-btn{display:inline-block;padding:18px 48px;background:var(--pc);color:#fff;border-radius:12px;font-weight:700;font-size:18px;text-decoration:none;transition:all 0.2s;box-shadow:0 4px 20px rgba(0,0,0,0.15);}
    .hs-pay-btn:hover{transform:translateY(-2px);box-shadow:0 8px 30px rgba(0,0,0,0.2);}
    .hs-pay-price{font-size:14px;color:#6b7280;margin-top:12px;}
    
    /* Separator Section */
    /* Divider: straight line only, no extra whitespace */
    .hs-separator{padding:0;background:transparent;}
    .hs-sep-line{height:1px;background:#e5e7eb;max-width:100%;margin:0;}
    .hs-separator.style-thick .hs-sep-line{height:3px;background:#d1d5db;}
    .hs-separator.style-dotted .hs-sep-line{height:0;border-bottom:2px dotted #d1d5db;background:none;}
    
    /* Form Section */
    .hs-form-sec{padding:40px 24px;background:#f9fafb;}
    .hs-form-sec.style-gradient{background:linear-gradient(135deg,var(--pc),#1a1a2e);color:#fff;}
    .hs-form-sec.style-dark{background:#1a1a2e;color:#fff;}
    .hs-form-sec h3{font-size:20px;font-weight:700;margin:0 0 20px;text-align:center;}
    .hs-form-sec form{max-width:400px;margin:0 auto;}
    .hs-form-sec .field{margin-bottom:16px;}
    .hs-form-sec label{display:block;font-size:13px;font-weight:600;margin-bottom:6px;color:#374151;}
    .hs-form-sec.style-gradient label,.hs-form-sec.style-dark label{color:rgba(255,255,255,0.9);}
    .hs-form-sec input,.hs-form-sec select,.hs-form-sec textarea{width:100%;padding:14px 16px;font-size:15px;border:2px solid #e5e7eb;border-radius:10px;font-family:inherit;background:#fff;}
    .hs-form-sec input:focus,.hs-form-sec select:focus,.hs-form-sec textarea:focus{outline:none;border-color:var(--pc);}
    .hs-form-sec button{width:100%;padding:16px;background:var(--pc);color:#fff;border:none;border-radius:10px;font-size:16px;font-weight:700;cursor:pointer;transition:all 0.2s;}
    /* Keep form button visible on live pages */
    .hs-form-sec.style-gradient button,.hs-form-sec.style-dark button{background:var(--pc);color:#fff;}
    .hs-form-sec button:hover{opacity:0.9;}
    .hs-form-sec .success{display:none;padding:20px;background:#d1fae5;color:#065f46;border-radius:10px;text-align:center;}
    
    /* Products Section */
    .hs-products{padding:40px 24px;background:#fff;}
    .hs-products.style-gradient{background:linear-gradient(135deg,var(--pc),#1a1a2e);}
    .hs-products.style-gradient h3{color:#fff;}
    .hs-products.style-dark{background:#1a1a2e;}
    .hs-products.style-dark h3{color:#fff;}
    .hs-products h3{font-size:22px;font-weight:700;margin:0 0 24px;text-align:center;}
    .hs-products-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:16px;max-width:500px;margin:0 auto;}
    .hs-product{background:#f9fafb;border-radius:14px;overflow:hidden;transition:transform 0.2s;}
    .hs-product:hover{transform:translateY(-4px);}
    .hs-product-img{height:140px;background:#e5e7eb;display:flex;align-items:center;justify-content:center;font-size:48px;color:#9ca3af;}
    .hs-product-img img{width:100%;height:100%;object-fit:cover;}
    .hs-product-info{padding:16px;text-align:center;}
    .hs-product-name{font-size:14px;font-weight:600;color:#1a1a2e;margin:0 0 6px;}
    .hs-product-price{font-size:18px;font-weight:800;color:var(--pc);}
    @media(min-width:500px){.hs-products-grid{grid-template-columns:repeat(3,1fr);}}
    
    /* Ebook Section */
    .hs-ebook{padding:48px 24px;text-align:center;background:linear-gradient(135deg,#667eea,#764ba2);color:#fff;}
    .hs-ebook.style-light{background:#f9fafb;color:#1a1a2e;}
    .hs-ebook.style-dark{background:#1a1a2e;color:#fff;}
    .hs-ebook-preview{width:100px;height:130px;background:rgba(255,255,255,0.2);border-radius:10px;margin:0 auto 20px;display:flex;align-items:center;justify-content:center;font-size:48px;}
    .hs-ebook.style-light .hs-ebook-preview{background:#e5e7eb;}
    .hs-ebook h3{font-size:24px;font-weight:800;margin:0 0 12px;}
    .hs-ebook p{font-size:15px;opacity:0.9;margin:0 0 24px;max-width:400px;margin-left:auto;margin-right:auto;}
    .hs-ebook .btn{display:inline-block;padding:16px 36px;background:#fff;color:#667eea;border-radius:12px;font-weight:700;font-size:16px;text-decoration:none;transition:all 0.2s;}
    .hs-ebook.style-light .btn{background:#667eea;color:#fff;}
    .hs-ebook.style-dark .btn{background:#fff;color:#1a1a2e;}
    .hs-ebook .btn:hover{transform:translateY(-2px);}
    .hs-ebook .price{font-size:14px;margin-top:12px;opacity:0.8;}
    
    /* Footer Section */
    .hs-footer{padding:24px;background:#1a1a2e;color:#fff;text-align:center;}
    .hs-footer.style-modern{padding:40px 24px;background:linear-gradient(135deg,#1a1a2e,#0f172a);}
    .hs-footer.style-light{background:#f9fafb;color:#1a1a2e;}
    .hs-footer p{margin:0;font-size:13px;opacity:0.7;}
    .hs-footer.style-modern p{font-size:14px;opacity:1;margin-bottom:16px;}
    .hs-footer-links{display:flex;justify-content:center;gap:20px;margin-top:16px;}
    .hs-footer-links a{color:rgba(255,255,255,0.7);font-size:13px;text-decoration:none;transition:color 0.2s;}
    .hs-footer-links a:hover{color:#fff;}
    .hs-footer.style-light .hs-footer-links a{color:#6b7280;}
    .hs-footer.style-light .hs-footer-links a:hover{color:#1a1a2e;}
    
    /* WhatsApp Button Style */
    .btn-wa{background:#25D366!important;color:#fff!important;display:inline-flex;align-items:center;gap:8px;}
    .wa-icon{display:inline-block;width:20px;height:20px;vertical-align:middle;background:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='white'%3E%3Cpath d='M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z'/%3E%3C/svg%3E") no-repeat center/contain;}
    
    /* CTA Button Width */
    .hs-cta .btn.btn-full{display:block;width:100%;text-align:center;box-sizing:border-box;}
    
            /* Sticky Bottom Bar */
.hs-sticky-bar{position:fixed;bottom:0;left:0;right:0;padding:10px 14px;box-shadow:0 -4px 20px rgba(0,0,0,0.12);display:flex;gap:10px;z-index:100;border-top-left-radius:18px;border-top-right-radius:18px;}
.hs-sticky-bar.bar-light{background:#ffffff;}
.hs-sticky-bar.bar-dark{background:#0b1220;}
.hs-sticky-bar.bar-gradient{background:linear-gradient(135deg, rgba(15,23,42,1) 0%, rgba(30,41,59,1) 100%);}
.hs-sticky-bar a{flex:1;padding:12px 12px;display:flex;align-items:center;justify-content:center;gap:8px;text-align:center;border-radius:14px;font-weight:700;font-size:14px;text-decoration:none;transition:transform 0.08s ease;}
.hs-sticky-bar a:active{transform:scale(0.98);}
.hs-sticky-bar .btn-wa{background:#25D366;color:#fff;}
.hs-sticky-bar .btn-call{background:var(--pc);color:#fff;}
.hs-sticky-bar .btn-link{background:#1a1a2e;color:#fff;}
body.has-sticky{padding-bottom:84px;}
    
    /* Watermark */
    .hs-watermark{text-align:center;padding:16px;background:#f5f5f5;}
    .hs-watermark a{color:#999;font-size:11px;text-decoration:none;}
    
    /* Responsive */
    @media(min-width:600px){
        .hs-hero h1{font-size:36px;}
        .hs-banner h2{font-size:32px;}
        .hs-hero,.hs-banner,.hs-cta{padding:60px 32px;}
    }
    </style>
</head>
<body<?php echo $sticky_bar_data ? ' class="has-sticky"' : ''; ?>>
<?php
    // Render each section
    foreach ($sections as $section) {
        $type = $section['type'] ?? '';
        $style = $section['style'] ?? '';
        $style_class = $style ? ' style-' . esc_attr($style) : '';
        
        switch ($type) {
            case 'hero':
                ?>
                <section class="hs-sec hs-hero<?php echo $style_class; ?>">
                    <h1><?php echo esc_html($section['headline'] ?? 'Your Headline'); ?></h1>
                    <p><?php echo esc_html($section['subheadline'] ?? ''); ?></p>
                    <?php if (!empty($section['video'])): ?>
                    <video src="<?php echo esc_url($section['video']); ?>" autoplay muted loop playsinline></video>
                    <?php elseif (!empty($section['image'])): ?>
                    <img src="<?php echo esc_url($section['image']); ?>" alt="">
                    <?php endif; ?>
                </section>
                <?php
                break;
                
            case 'banner':
                $headline = hushot_vb_decode($section['headline'] ?? '');
                $sub = hushot_vb_decode($section['subheadline'] ?? '');
                ?>
                <section class="hs-sec hs-banner<?php echo $style_class; ?>">
                    <?php if (!empty($headline)): ?>
                    <h2><?php echo esc_html($headline); ?></h2>
                    <?php endif; ?>
                    <?php if (!empty($sub)): ?>
                    <p><?php echo esc_html($sub); ?></p>
                    <?php endif; ?>
                    <?php if (!empty($section['image'])): ?>
                    <img src="<?php echo esc_url($section['image']); ?>" alt="" class="hs-img">
                    <?php endif; ?>
                    <?php if (!empty($section['button'])):
                        $action = $section['action'] ?? 'whatsapp';
                        $btn_url = '#';
                        if ($action === 'whatsapp') {
                            $wa = preg_replace('/\D+/', '', hushot_vb_decode($section['whatsapp'] ?? ''));
                            if ($wa) $btn_url = 'https://wa.me/' . $wa;
                        } elseif ($action === 'phone') {
                            $ph = preg_replace('/\s+/', '', hushot_vb_decode($section['phone'] ?? ''));
                            if ($ph) $btn_url = 'tel:' . $ph;
                        } elseif ($action === 'link') {
                            $btn_url = $section['link'] ?? '#';
                        }
                        $btn_class = 'btn';
                        if ($action === 'whatsapp') $btn_class .= ' btn-wa';
                    ?>
                    <a href="<?php echo esc_url($btn_url); ?>" class="<?php echo esc_attr($btn_class); ?>">
                        <?php if ($action === 'whatsapp'): ?><span class="wa-icon" aria-hidden="true"></span><?php endif; ?>
                        <?php echo esc_html(hushot_vb_decode($section['button'])); ?>
                    </a>
                    <?php endif; ?>
                </section>
                <?php
                break;
                
            case 'features':
                $items = $section['items'] ?? '';
                if (is_array($items)) {
                    $raw_items = array();
                    foreach ($items as $it) {
                        $it = trim((string)hushot_vb_decode($it));
                        if ($it !== '') $raw_items[] = $it;
                    }
                    $items = $raw_items;
                } else {
                    $raw_items = hushot_vb_decode((string)$items);
                    $raw_items = str_replace(array("\r\n","\r"), "\n", $raw_items);
                    $items = array_filter(array_map('trim', explode("\n", $raw_items)));
                }
                $title = hushot_vb_decode($section['title'] ?? '');
                ?>
                <section class="hs-sec hs-features<?php echo $style_class; ?>">
                    <?php if (!empty($title)): ?>
                    <h3><?php echo esc_html($title); ?></h3>
                    <?php endif; ?>
                    <ul class="hs-feature-list">
                        <?php foreach ($items as $item): ?>
                            <li><span class="tick">✓</span><?php echo esc_html($item); ?></li>
                        <?php endforeach; ?>
                    </ul>
                </section>
                <?php
                break;
                
            case 'cta':
                $btn_url = '#';
                $action = $section['action'] ?? 'whatsapp';
                $btn_class = 'btn';
                $btn_width = $section['btnWidth'] ?? 'inline';
                if ($btn_width === 'full') $btn_class .= ' btn-full';
                if ($action === 'whatsapp' && !empty($section['whatsapp'])) {
                    $msg = rawurlencode("Hi, I'm interested in " . get_the_title());
                    $btn_url = 'https://wa.me/' . preg_replace('/[^0-9]/', '', $section['whatsapp']) . '?text=' . $msg;
                    $btn_class .= ' btn-wa';
                } elseif ($action === 'phone' && !empty($section['phone'])) {
                    $btn_url = 'tel:' . $section['phone'];
                } elseif ($action === 'link' && !empty($section['link'])) {
                    $btn_url = $section['link'];
                }
                $btn_text = $action === 'whatsapp' ? 'WhatsApp' : ($section['button'] ?? 'Get Started');
                $wa_icon = $action === 'whatsapp' ? '<span class="wa-icon"></span> ' : '';
                ?>
                <section class="hs-sec hs-cta<?php echo $style_class; ?>">
                    <?php if (!empty($section['text'])): ?>
                    <p><?php echo esc_html($section['text']); ?></p>
                    <?php endif; ?>
                    <a href="<?php echo esc_url($btn_url); ?>" class="<?php echo $btn_class; ?>"><?php echo $wa_icon; ?><?php echo esc_html($btn_text); ?></a>
                </section>
                <?php
                break;
            
            case 'products':
                $products = isset($section['products']) ? $section['products'] : array();
                $currency_code = $section['currency'] ?? 'NGN';
                ?>
                <section class="hs-sec hs-products<?php echo $style_class; ?>">
                    <?php if (!empty($section['title'])): ?>
                    <h3><?php echo esc_html($section['title']); ?></h3>
                    <?php endif; ?>
                    <div class="hs-products-grid">
                        <?php foreach ($products as $product): ?>
                        <div class="hs-product">
                            <div class="hs-product-img">
                                <?php if (!empty($product['image'])): ?>
                                <img src="<?php echo esc_url($product['image']); ?>" alt="<?php echo esc_attr($product['name'] ?? ''); ?>">
                                <?php else: ?>
                                🛍️
                                <?php endif; ?>
                            </div>
                            <div class="hs-product-info">
                                <div class="hs-product-name"><?php echo esc_html($product['name'] ?? 'Product'); ?></div>
                                <div class="hs-product-price"><?php echo esc_html(hushot_format_price($product['price'] ?? '', $currency_code)); ?></div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </section>
                <?php
                break;
            
            case 'payment':
                ?>
                <section class="hs-sec hs-payment<?php echo $style_class; ?>">
                    <?php
                        $pay_amount = $section['amount'] ?? ($section['price'] ?? '5000');
                        $pay_currency = $section['currency'] ?? 'NGN';
                        $pay_label = ($section['button'] ?? 'Pay Now') . ': ' . hushot_format_price($pay_amount, $pay_currency);
                    ?>
                    <a href="#" class="hs-pay-btn" data-page-id="<?php echo (int)$page_id; ?>" data-amount="<?php echo esc_attr($pay_amount); ?>" data-currency="<?php echo esc_attr($pay_currency); ?>"><?php echo esc_html($pay_label); ?></a>
                </section>
                <?php
                break;
            
            case 'separator':
                $sep_color = hushot_vb_decode($section['color'] ?? '');
                $sep_width = $section['width'] ?? 'full'; // full|content
                $line_style = '';
                if ($sep_color) $line_style .= 'background:' . esc_attr($sep_color) . ';';
                $line_style .= ($sep_width === 'content') ? 'max-width:520px;margin-left:auto;margin-right:auto;' : '';
                ?>
                <section class="hs-sec hs-separator<?php echo $style_class; ?>">
                    <div class="hs-sep-line" style="<?php echo esc_attr($line_style); ?>"></div>
                </section>
                <?php
                break;
            
            case 'ebook':
                $ebook_url = $section['file'] ?? '#';
                $price = $section['price'] ?? '';
                ?>
                <section class="hs-sec hs-ebook<?php echo $style_class; ?>">
                    <div class="hs-ebook-preview">📚</div>
                    <h3><?php echo esc_html($section['title'] ?? 'Free Ebook'); ?></h3>
                    <?php if (!empty($section['description'])): ?>
                    <p><?php echo esc_html($section['description']); ?></p>
                    <?php endif; ?>
                    <a href="<?php echo esc_url($ebook_url); ?>" class="btn" download><?php echo esc_html($section['button'] ?? 'Download Now'); ?></a>
                    <?php if ($price): ?>
                    <div class="price"><?php echo esc_html($price); ?></div>
                    <?php endif; ?>
                </section>
                <?php
                break;
                
            case 'media':
                ?>
                <section class="hs-sec hs-media<?php echo $style_class; ?>">
                    <?php if (!empty($section['video'])): ?>
                    <video src="<?php echo esc_url($section['video']); ?>" controls playsinline></video>
                    <?php elseif (!empty($section['image'])): ?>
                    <img src="<?php echo esc_url($section['image']); ?>" alt="">
                    <?php endif; ?>
                </section>
                <?php
                break;
                
            case 'text':
                $bigTitle = hushot_vb_decode($section['bigTitle'] ?? '');
                $title    = hushot_vb_decode($section['title'] ?? '');
                $content  = hushot_vb_decode($section['content'] ?? '');
                $bigW = isset($section['bigTitleWeight']) ? intval($section['bigTitleWeight']) : 800;
                $titleW = isset($section['titleWeight']) ? intval($section['titleWeight']) : 700;
                ?>
                <section class="hs-sec hs-text<?php echo $style_class; ?>">
                    <?php if (!empty($bigTitle)): ?>
                        <h2 class="hs-text-big" style="font-weight:<?php echo esc_attr($bigW); ?>;"><?php echo esc_html($bigTitle); ?></h2>
                    <?php endif; ?>
                    <?php if (!empty($title)): ?>
                        <h3 class="hs-text-title" style="font-weight:<?php echo esc_attr($titleW); ?>;"><?php echo esc_html($title); ?></h3>
                    <?php endif; ?>
                    <?php if (!empty($content)): ?>
                        <p class="hs-text-body"><?php echo nl2br(esc_html($content)); ?></p>
                    <?php endif; ?>
                </section>
                <?php
                break;
                
            case 'form':
                $form_fields = isset($section['fields']) ? $section['fields'] : array('name', 'email', 'phone');
                if (is_string($form_fields)) $form_fields = explode(',', $form_fields);
                ?>
                <section class="hs-sec hs-form-sec<?php echo $style_class; ?>">
                    <?php if (!empty($section['title'])): ?>
                    <h3><?php echo esc_html($section['title']); ?></h3>
                    <?php endif; ?>
                    <form id="hs-lead-form" method="post">
                        <?php foreach ($form_fields as $field): 
                            $field = trim($field);
                            $label = ucfirst($field);
                            $type = ($field === 'email') ? 'email' : (($field === 'phone') ? 'tel' : 'text');
                        ?>
                        <div class="field">
                            <label><?php echo esc_html($label); ?></label>
                            <input type="<?php echo $type; ?>" name="<?php echo esc_attr($field); ?>" required>
                        </div>
                        <?php endforeach; ?>
                        <input type="hidden" name="page_id" value="<?php echo $page_id; ?>">
                        <button type="submit"><?php echo esc_html($section['button'] ?? 'Submit'); ?></button>
                        <div class="success">Thank you! We'll be in touch soon.</div>
                    </form>
                </section>
                <script>
                document.getElementById('hs-lead-form').addEventListener('submit', function(e) {
                    e.preventDefault();
                    var form = this;
                    var fd = new FormData(form);
                    fd.append('action', 'hushot_submit_lead');
                    fetch('<?php echo admin_url("admin-ajax.php"); ?>', {method:'POST', body:fd})
                    .then(r => r.json())
                    .then(d => {
                        if (d.success) {
                            form.style.display = 'none';
                            form.nextElementSibling.style.display = 'block';
                        }
                    });
                });
                </script>
                <?php
                break;
                
            case 'footer':
                $show_social = !empty($section['showSocial']);
                $footer_text = hushot_vb_decode($section['text'] ?? '© ' . date('Y'));
                $tagline = hushot_vb_decode($section['tagline'] ?? '');
                $address = hushot_vb_decode($section['address'] ?? '');
                $disclaimer = hushot_vb_decode($section['disclaimer'] ?? '');
                $fb = isset($section['facebook']) ? hushot_vb_decode($section['facebook']) : '';
                $ig = isset($section['instagram']) ? hushot_vb_decode($section['instagram']) : '';
                $x  = isset($section['x']) ? hushot_vb_decode($section['x']) : '';
                $wa = isset($section['waurl']) ? hushot_vb_decode($section['waurl']) : '';
                ?>
                <footer class="hs-sec hs-footer<?php echo $style_class; ?>">
                    <p><?php echo esc_html($footer_text); ?></p>
                    <?php if (!empty($tagline)): ?><div class="hs-footer-tagline"><?php echo esc_html($tagline); ?></div><?php endif; ?>
                    <?php if (!empty($address)): ?><div class="hs-footer-address"><?php echo esc_html($address); ?></div><?php endif; ?>

                    <?php if ($show_social && ($fb || $ig || $x || $wa)): ?>
                    <div class="hs-footer-links">
                        <?php if ($fb): ?><a href="<?php echo esc_url($fb); ?>" target="_blank" rel="noopener">Facebook</a><?php endif; ?>
                        <?php if ($ig): ?><a href="<?php echo esc_url($ig); ?>" target="_blank" rel="noopener">Instagram</a><?php endif; ?>
                        <?php if ($x): ?><a href="<?php echo esc_url($x); ?>" target="_blank" rel="noopener">X</a><?php endif; ?>
                        <?php if ($wa): ?><a href="<?php echo esc_url($wa); ?>" target="_blank" rel="noopener">WhatsApp</a><?php endif; ?>
                    </div>
                    <?php endif; ?>

                    <?php if (!empty($disclaimer)): ?><div class="hs-footer-disclaimer"><?php echo esc_html($disclaimer); ?></div><?php endif; ?>
                </footer>
                <?php
                break;
        }
    }
    
    // Watermark
    if ($show_watermark) {
        echo '<div class="hs-watermark"><a href="https://hushot.net" target="_blank">Made with Hushot</a></div>';
    }
    
    // Sticky Bottom Bar
    if ($sticky_bar_data && !empty($sticky_bar_data['enabled'])) {
        $bar_style = $sticky_bar_data['barStyle'] ?? ($sticky_bar_data['style'] ?? 'light'); // backward compat
        $bar_class = 'hs-sticky-bar ' . 'bar-' . esc_attr($bar_style);
        $wa_num = hushot_vb_decode($sticky_bar_data['whatsapp'] ?? '');
        $wa_num = preg_replace('/\D+/', '', $wa_num);
        $call_num = hushot_vb_decode($sticky_bar_data['phone'] ?? '');
        $link_url = hushot_vb_decode($sticky_bar_data['link_url'] ?? ($sticky_bar_data['link'] ?? ''));
        ?>
        <div class="<?php echo esc_attr($bar_class); ?>">
            <?php if (!empty($wa_num)): ?>
                <a href="https://wa.me/<?php echo esc_attr($wa_num); ?>" class="btn-wa"><span class="wa-icon" aria-hidden="true"></span> WhatsApp</a>
            <?php endif; ?>
            <?php if (!empty($call_num)): ?>
                <a href="tel:<?php echo esc_attr($call_num); ?>" class="btn-call">📞 Call</a>
            <?php endif; ?>
            <?php
                $link_enabled = !empty($sticky_bar_data['showLink']) || !empty($link_url);
                if ($link_enabled && !empty($link_url)):
            ?>
                <a href="<?php echo esc_url($link_url); ?>" class="btn-link">🔗 Link</a>
            <?php endif; ?>
        </div>
        <?php
    }
    ?>
</body>
</html>
    <?php
    exit;
}

// ========================================
// LEGACY COMPONENT-BASED RENDERING BELOW
// ========================================

// Default values - WhatsApp/Bottom bar only show when explicitly set
$defaults = array(
    'business_name' => get_the_title(),
    'logo_url' => '',
    'header_title' => '',
    'header_subtitle' => '',
    'primary_color' => '#0D9488',
    'image_url' => '',
    'video_url' => '',
    'video_file_url' => '',
    'video_autoplay' => '',
    'description' => '',
    'features' => '',
    'original_price' => '',
    'sale_price' => '',
    'currency' => 'NGN',
    'cta_type' => '',
    'cta_text' => 'Chat on WhatsApp',
    'whatsapp' => '',
    'whatsapp_message' => '',
    'phone' => '',
    'email' => '',
    'location' => '',
    'form_title' => 'Get Started Today',
    'form_button' => 'Submit',
    'form_fields' => 'name,phone,email',
    'link_url' => '',
    'link_text' => 'Learn More',
    'bottom_bar_style' => 'disabled',
    'footer_text' => '',
    'headers_json' => '',
    'products_title' => 'More Products',
    'products_list' => '',
    'products_json' => '',
    'bar_phone' => '',
    'bar_whatsapp' => '',
    'bar_link_url' => '',
    'seo_title' => '',
    'seo_description' => '',
    'seo_image' => '',
    'collection' => '',
    'component_order' => '',
    'page_bg_color' => '#ffffff',
    'header_bg_color' => '#ffffff',
    'show_header' => '1',
    'btn_size' => 'medium',
    'btn_style' => 'rounded',
    'btn_width' => 'auto',
    'btn_position' => 'center',
    // Footer extras
    'footer_tagline' => '',
    'footer_address' => '',
    'footer_disclaimer' => '',
    'footer_facebook' => '',
    'footer_instagram' => '',
    'footer_x' => '',
    'footer_whatsapp_url' => '',
    'footer_show_social' => '',
);

// Get meta values
$m = array();
foreach ($defaults as $key => $default) {
    $val = get_post_meta($page_id, '_hushot_' . $key, true);
    $m[$key] = ($val !== '' && $val !== false) ? $val : $default;
}

// Fallback to user meta
if (!$m['whatsapp']) $m['whatsapp'] = get_user_meta($owner_id, 'hushot_whatsapp', true);
if (!$m['phone']) $m['phone'] = get_user_meta($owner_id, 'hushot_phone', true);

// Currency symbols - All African currencies
$symbols = array(
    'NGN' => '₦', 'GHS' => '₵', 'KES' => 'KSh', 'ZAR' => 'R', 
    'UGX' => 'USh', 'TZS' => 'TSh', 'XOF' => 'CFA', 'XAF' => 'FCFA',
    'EGP' => 'E£', 'MAD' => 'DH', 'BWP' => 'P', 'MUR' => '₨',
    'ZMW' => 'ZK', 'RWF' => 'FRw', 'ETB' => 'Br', 'AOA' => 'Kz',
    'USD' => '$', 'EUR' => '€', 'GBP' => '£'
);
$symbol = $symbols[$m['currency']] ?? '₦';

// Features array - handle both \r\n and \n
$features = array();
if (trim($m['features'])) {
    $feat_text = str_replace("\r\n", "\n", $m['features']);
    $feat_text = str_replace("\r", "\n", $feat_text);
    $features = array_filter(array_map('trim', explode("\n", $feat_text)));
}

// WhatsApp URL - Auto-generate message with product context
$wa_number = preg_replace('/[^0-9]/', '', $m['whatsapp']);
$page_title = get_the_title() ?: $m['header_title'] ?: $m['business_name'];
$page_url = get_permalink($page_id);
$price_text = '';
if ($m['sale_price']) {
    $price_text = "\nPrice: " . $symbol . number_format($m['sale_price']);
} elseif ($m['original_price']) {
    $price_text = "\nPrice: " . $symbol . number_format($m['original_price']);
}
// Format message with link on separate line for WhatsApp to auto-detect
$wa_message = rawurlencode("Hello, I'm interested in this product:\n\nProduct: " . $page_title . $price_text . "\n\nView here:\n" . $page_url);
$wa_url = $wa_number ? "https://wa.me/{$wa_number}?text={$wa_message}" : '#';

// Video embed or uploaded file
$video_embed = '';
$video_file = $m['video_file_url'];
$video_autoplay = $m['video_autoplay'];
if ($m['video_url']) {
    if (preg_match('/youtube\.com\/watch\?v=([^&]+)/', $m['video_url'], $match) || preg_match('/youtu\.be\/([^?]+)/', $m['video_url'], $match)) {
        $video_embed = 'https://www.youtube.com/embed/' . $match[1];
        if ($video_autoplay) {
            $video_embed .= '?autoplay=1&mute=0&enablejsapi=1';
        }
    } elseif (preg_match('/vimeo\.com\/(\d+)/', $m['video_url'], $match)) {
        $video_embed = 'https://player.vimeo.com/video/' . $match[1];
        if ($video_autoplay) {
            $video_embed .= '?autoplay=1';
        }
    }
}

// Form fields
$form_fields = array_filter(explode(',', $m['form_fields']));
if (empty($form_fields)) $form_fields = array('name', 'phone', 'email');

// Bottom bar
$show_bottom = ($m['bottom_bar_style'] !== 'disabled');

// Watermark
$show_watermark = true;
if (class_exists('Hushot_Membership')) {
    $show_watermark = Hushot_Membership::show_watermark($owner_id);
}

// Track view - Session-based deduplication to prevent double counting
$views = (int)get_post_meta($page_id, '_hushot_views', true);
$session_key = 'hushot_viewed_' . $page_id;
$should_count = true;

// Check if this page was already viewed in this session
if (isset($_COOKIE[$session_key])) {
    $last_view = (int)$_COOKIE[$session_key];
    // Only count if more than 30 minutes since last view
    if (time() - $last_view < 1800) {
        $should_count = false;
    }
}

if ($should_count) {
    update_post_meta($page_id, '_hushot_views', $views + 1);
    // Set cookie for 30 minutes
    setcookie($session_key, time(), time() + 1800, '/');
}

// Primary color
$pc = esc_attr($m['primary_color']);
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0">
    <title><?php echo esc_html($m['seo_title'] ?: $m['business_name']); ?></title>
    <meta name="description" content="<?php echo esc_attr($m['seo_description'] ?: wp_trim_words($m['description'], 30)); ?>">
    
    <!-- Open Graph / Social -->
    <meta property="og:type" content="website">
    <meta property="og:title" content="<?php echo esc_attr($m['seo_title'] ?: $m['business_name']); ?>">
    <meta property="og:description" content="<?php echo esc_attr($m['seo_description'] ?: wp_trim_words($m['description'], 30)); ?>">
    <?php if ($m['seo_image'] || $m['image_url']): ?>
    <meta property="og:image" content="<?php echo esc_url($m['seo_image'] ?: $m['image_url']); ?>">
    <?php endif; ?>
    <meta property="og:url" content="<?php echo esc_url(get_permalink($page_id)); ?>">
    
    <!-- Twitter Card -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?php echo esc_attr($m['seo_title'] ?: $m['business_name']); ?>">
    <meta name="twitter:description" content="<?php echo esc_attr($m['seo_description'] ?: wp_trim_words($m['description'], 30)); ?>">
    <?php if ($m['seo_image'] || $m['image_url']): ?>
    <meta name="twitter:image" content="<?php echo esc_url($m['seo_image'] ?: $m['image_url']); ?>">
    <?php endif; ?>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: <?php echo $pc; ?>;
            --primary-dark: <?php echo $pc; ?>dd;
            --primary-light: <?php echo $pc; ?>15;
            --page-bg: <?php echo esc_attr($m['page_bg_color'] ?: '#ffffff'); ?>;
            --header-bg: <?php echo esc_attr($m['header_bg_color'] ?: '#ffffff'); ?>;
            --btn-size-padding: <?php 
                $btn_size = $m['btn_size'] ?: 'medium';
                echo $btn_size === 'large' ? '18px 32px' : ($btn_size === 'small' ? '10px 18px' : '14px 24px');
            ?>;
            --btn-radius: <?php 
                $btn_style = $m['btn_style'] ?: 'rounded';
                echo $btn_style === 'pill' ? '50px' : ($btn_style === 'square' ? '4px' : ($btn_style === 'outline' ? '12px' : '12px'));
            ?>;
            --btn-width: <?php echo ($m['btn_width'] ?: 'auto') === 'full' ? '100%' : 'auto'; ?>;
            --btn-align: <?php 
                $btn_pos = $m['btn_position'] ?: 'center';
                echo $btn_pos === 'left' ? 'flex-start' : ($btn_pos === 'right' ? 'flex-end' : 'center');
            ?>;
        }
        
        /* Hide ALL theme-injected elements including Bricks loader */
        .loader, .loading, .spinner, .preloader, .page-loader,
        [class*="loader"], [class*="spinner"], [class*="preload"],
        .bricks-loading, #bricks-loading, .brx-body::before, .brx-body::after,
        #bricks-admin-bar, .bricks-lazy-hidden,
        .site-header, .site-footer, #masthead, #colophon,
        header:not(.lp-header), footer:not(.lp-footer):not(.lp-pro-footer),
        .elementor-widget-theme-site-logo, .brxe-nav-menu,
        nav.main-nav, .main-navigation, aside, .sidebar,
        .wp-block-template-part, .has-global-padding > .alignfull,
        [class*="bricks-"][class*="loader"], .brxe-container:empty,
        .site-branding, #site-header, .header-wrapper {
            display: none !important;
            visibility: hidden !important;
            opacity: 0 !important;
            width: 0 !important;
            height: 0 !important;
            position: absolute !important;
            left: -9999px !important;
            pointer-events: none !important;
        }
        
        /* Hide Bricks loader dots and any injected elements */
        .bricks-loading-dots,
        .bricks-dots,
        [class*="bricks-loading"],
        .brxe-block:empty,
        .brxe-section:empty,
        .brxe-container:empty,
        .brxe-div:empty,
        #brx-content > div:not(:first-child),
        body > div:not(.lp-wrapper):not(.lp-watermark):not(.lp-bottom-bar):not(#wpadminbar):last-of-type {
            display: none !important;
            visibility: hidden !important;
            height: 0 !important;
            width: 0 !important;
            overflow: hidden !important;
        }
        
        /* Reset */
        *, *::before, *::after {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        
        html {
            scroll-behavior: smooth;
            -webkit-text-size-adjust: 100%;
        }
        
        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            background: var(--page-bg);
            color: #1e293b;
            line-height: 1.6;
            min-height: 100vh;
            padding-bottom: <?php echo $show_bottom ? '80px' : '0'; ?>;
            -webkit-font-smoothing: antialiased;
        }
        
        a { color: var(--primary); text-decoration: none; }
        img { max-width: 100%; height: auto; display: block; }
        
        /* Container */
        .container {
            width: 100%;
            max-width: 640px;
            margin: 0 auto;
            padding: 0 16px;
        }
        
        /* Header */
        .lp-header {
            background: var(--header-bg);
            padding: 12px 0;
            position: sticky;
            top: 0;
            z-index: 100;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        .lp-header .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .lp-brand {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .lp-logo {
            width: 40px;
            height: 40px;
            border-radius: 10px;
            object-fit: cover;
        }
        .lp-name {
            font-size: 18px;
            font-weight: 700;
            color: #0f172a;
        }
        .lp-header-btn {
            display: flex;
            align-items: center;
            gap: 6px;
            padding: 10px 16px;
            background: #25D366;
            color: #fff !important;
            border-radius: 25px;
            font-size: 14px;
            font-weight: 600;
            transition: transform 0.2s;
        }
        .lp-header-btn:hover { transform: scale(1.02); }
        .lp-header-btn svg { width: 18px; height: 18px; fill: currentColor; }
        
        /* Hero Section - Reduced height 30% */
        .lp-hero {
            background: linear-gradient(135deg, #f0fdf4 0%, #ecfeff 50%, #f0f9ff 100%);
            padding: 34px 0;
            text-align: center;
            margin-bottom: 0;
        }
        .lp-hero h1 {
            font-size: 32px;
            font-weight: 800;
            color: #0f172a;
            margin-bottom: 8px;
            line-height: 1.2;
        }
        .lp-hero p {
            font-size: 16px;
            color: #475569;
            max-width: 480px;
            margin: 0 auto;
        }
        
        /* Image Section - No top gap */
        .lp-image {
            padding: 16px 0;
            margin-top: 0;
        }
        .lp-image img {
            width: 100%;
            border-radius: 16px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
        }
        
        /* Video Section */
        .lp-video {
            padding: 24px 0;
        }
        .lp-video-wrapper {
            position: relative;
            padding-bottom: 56.25%;
            border-radius: 16px;
            overflow: hidden;
            background: #000;
            box-shadow: 0 10px 40px rgba(0,0,0,0.15);
        }
        .lp-video-wrapper iframe,
        .lp-video-wrapper video {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            border: 0;
        }
        
        /* Section Styling */
        .lp-section {
            padding: 32px 0;
        }
        .lp-card {
            background: #ffffff;
            border-radius: 20px;
            padding: 28px 24px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.06);
        }
        .lp-card.mint { background: linear-gradient(135deg, #f0fdf4, #ffffff); }
        .lp-card.sky { background: linear-gradient(135deg, #ecfeff, #ffffff); }
        .lp-card.cream { background: linear-gradient(135deg, #fffbeb, #ffffff); }
        .lp-card.rose { background: linear-gradient(135deg, #fff1f2, #ffffff); }
        .lp-card.lavender { background: linear-gradient(135deg, #f5f3ff, #ffffff); }
        
        .lp-section-title {
            font-size: 20px;
            font-weight: 700;
            color: #0f172a;
            margin-bottom: 16px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .lp-section-title::before {
            content: '';
            width: 4px;
            height: 24px;
            background: var(--primary);
            border-radius: 2px;
        }
        .lp-section p {
            font-size: 15px;
            color: #475569;
            line-height: 1.8;
        }
        
        /* Features List */
        .lp-features {
            list-style: none;
        }
        .lp-features li {
            display: flex;
            align-items: flex-start;
            gap: 14px;
            padding: 14px 16px;
            margin-bottom: 10px;
            background: linear-gradient(135deg, rgba(240,253,244,0.8), rgba(254,252,232,0.5));
            border-radius: 14px;
            font-size: 15px;
            color: #334155;
        }
        .lp-features li::before {
            content: '✓';
            width: 26px;
            height: 26px;
            min-width: 26px;
            background: var(--primary);
            color: #fff;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 12px;
            font-weight: 700;
        }
        
        /* Pricing - Inline style with green badge */
        .lp-pricing {
            padding: 20px 0;
            text-align: center;
        }
        .lp-price-inline {
            display: inline-flex;
            align-items: center;
            gap: 12px;
            background: #fff;
            padding: 12px 20px;
            border-radius: 30px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        .lp-price-old {
            font-size: 16px;
            color: #999;
            text-decoration: line-through;
        }
        .lp-price-new {
            display: inline-flex;
            align-items: center;
            background: linear-gradient(135deg, #10b981 0%, #059669 100%);
            color: #fff;
            padding: 8px 16px;
            border-radius: 20px;
            font-size: 20px;
            font-weight: 700;
        }
        
        /* CTA Button */
        .lp-cta {
            padding: 24px 0;
            text-align: var(--btn-align);
            display: flex;
            justify-content: var(--btn-align);
        }
        .lp-cta-btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            width: var(--btn-width);
            max-width: 400px;
            padding: var(--btn-size-padding);
            background: #25D366;
            color: #fff !important;
            border-radius: var(--btn-radius);
            font-size: 18px;
            font-weight: 700;
            box-shadow: 0 8px 30px rgba(37,211,102,0.4);
            transition: transform 0.2s, box-shadow 0.2s;
        }
        .lp-cta-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 40px rgba(37,211,102,0.5);
        }
        .lp-cta-btn svg { width: 24px; height: 24px; fill: currentColor; }
        .lp-cta-btn.link-btn {
            background: var(--primary);
            box-shadow: 0 8px 30px rgba(13,148,136,0.4);
        }
        /* Outline button style */
        .btn-style-outline .lp-cta-btn {
            background: transparent;
            border: 2px solid #25D366;
            color: #25D366 !important;
            box-shadow: none;
        }
        .btn-style-outline .lp-cta-btn.link-btn {
            border-color: var(--primary);
            color: var(--primary) !important;
        }
        
        /* Lead Form */
        .lp-form-card {
            background: linear-gradient(135deg, #ffffff, #f0fdf4);
            border-radius: 20px;
            padding: 32px 24px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.08);
        }
        .lp-form-title {
            font-size: 22px;
            font-weight: 700;
            text-align: center;
            margin-bottom: 20px;
            color: #0f172a;
        }
        .lp-form input,
        .lp-form textarea {
            width: 100%;
            padding: 16px 18px;
            border: 2px solid #e2e8f0;
            border-radius: 14px;
            font-size: 16px;
            font-family: inherit;
            margin-bottom: 12px;
            background: #fff;
            transition: border-color 0.2s, box-shadow 0.2s;
        }
        .lp-form input:focus,
        .lp-form textarea:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 4px var(--primary-light);
        }
        .lp-form button {
            width: 100%;
            padding: 18px;
            background: var(--primary);
            color: #fff;
            border: none;
            border-radius: 14px;
            font-size: 18px;
            font-weight: 700;
            cursor: pointer;
            box-shadow: 0 6px 24px rgba(13,148,136,0.35);
            transition: transform 0.2s;
        }
        .lp-form button:hover { transform: translateY(-2px); }
        .lp-form button:disabled { opacity: 0.7; cursor: not-allowed; }
        
        /* Contact Info */
        .lp-contact-item {
            display: flex;
            align-items: center;
            gap: 14px;
            padding: 14px 16px;
            margin-bottom: 10px;
            background: linear-gradient(135deg, rgba(236,254,255,0.7), rgba(255,255,255,0.9));
            border-radius: 14px;
        }
        .lp-contact-icon {
            width: 44px;
            height: 44px;
            background: var(--primary);
            color: #fff;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            flex-shrink: 0;
        }
        .lp-contact-item a {
            color: #334155;
            font-size: 15px;
        }
        
        /* Footer */
        .lp-footer {
            padding: 24px 0;
            text-align: center;
            font-size: 13px;
            color: #94a3b8;
        }
        
        /* Watermark */
        .lp-watermark {
            padding: 16px 0;
            text-align: center;
            font-size: 12px;
            color: #94a3b8;
        }
        .lp-watermark a {
            color: #64748b;
            font-weight: 600;
        }
        
        /* Bottom Bar - FIX #2 */
        .lp-bottom {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: rgba(255,255,255,0.98);
            backdrop-filter: blur(10px);
            padding: 12px 16px;
            display: flex;
            gap: 10px;
            z-index: 99;
            box-shadow: 0 -4px 20px rgba(0,0,0,0.1);
        }
        .lp-bottom a {
            flex: 1;
            padding: 14px 12px;
            text-align: center;
            border-radius: 12px;
            font-size: 14px;
            font-weight: 700;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            color: #fff !important;
            transition: transform 0.2s;
        }
        .lp-bottom a:hover { transform: scale(0.98); }
        .lp-bottom-call { background: var(--primary); }
        .lp-bottom-wa { background: #25D366; }
        .lp-bottom-link { background: #1a1a1a; }
        
        /* Pro Footer - FIX #11 */
        .lp-pro-footer {
            background: linear-gradient(180deg, #1a1a1a 0%, #0a0a0a 100%);
            color: #fff;
            padding: 48px 0 0;
            margin-top: 32px;
        }
        .lp-footer-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 32px;
            margin-bottom: 32px;
        }
        .lp-footer-brand h3 {
            font-size: 18px;
            font-weight: 700;
            margin-bottom: 12px;
        }
        .lp-footer-brand p {
            font-size: 13px;
            color: #9ca3af;
            line-height: 1.6;
        }
        .lp-footer-logo {
            width: 50px;
            height: 50px;
            border-radius: 12px;
            margin-bottom: 12px;
            object-fit: cover;
        }
        .lp-footer-contact h4,
        .lp-footer-social h4 {
            font-size: 14px;
            font-weight: 600;
            margin-bottom: 16px;
            color: #fff;
        }
        .lp-footer-contact a,
        .lp-footer-contact span,
        .lp-footer-social a {
            display: block;
            font-size: 13px;
            color: #9ca3af;
            margin-bottom: 10px;
            text-decoration: none;
            transition: color 0.2s;
        }
        .lp-footer-contact a:hover,
        .lp-footer-social a:hover {
            color: #fff;
        }
        .lp-footer-bottom {
            border-top: 1px solid #333;
            padding: 20px 0;
            text-align: center;
        }
        .lp-footer-bottom p {
            font-size: 12px;
            color: #6b7280;
            margin: 0;
        }
        
        /* Success Message */
        .lp-success {
            text-align: center;
            padding: 32px;
            background: #d1fae5;
            border-radius: 16px;
            color: #065f46;
        }
        .lp-success h3 {
            font-size: 20px;
            margin-bottom: 8px;
        }
        
        /* Products Grid - v1.2.3 with accordion */
        .lp-products-grid {
            display: grid;
            grid-template-columns: 1fr;
            gap: 14px;
        }
        .lp-product-card {
            background: #fff;
            border-radius: 14px;
            overflow: hidden;
            box-shadow: 0 2px 12px rgba(0,0,0,0.08);
        }
        .lp-product-main {
            display: flex;
            gap: 12px;
            padding: 12px;
        }
        .lp-product-thumb {
            width: 80px;
            height: 80px;
            border-radius: 10px;
            background-size: cover;
            background-position: center;
            background-color: #f5f5f5;
            flex-shrink: 0;
            cursor: pointer;
            transition: transform 0.2s;
        }
        .lp-product-thumb:active {
            transform: scale(0.95);
        }
        .lp-product-info {
            flex: 1;
            min-width: 0;
        }
        .lp-product-info h4 {
            font-size: 14px;
            font-weight: 600;
            margin: 0 0 6px;
            color: #1a1a1a;
        }
        .lp-product-prices {
            display: flex;
            align-items: center;
            gap: 8px;
            margin-bottom: 8px;
        }
        .lp-product-old-price {
            font-size: 13px;
            color: #999;
            text-decoration: line-through;
        }
        .lp-product-new-price {
            font-size: 16px;
            font-weight: 700;
            color: var(--primary);
        }
        .lp-product-details-toggle {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            font-size: 12px;
            color: var(--primary);
            cursor: pointer;
            font-weight: 500;
            background: none;
            border: none;
            padding: 0;
        }
        .lp-product-details-toggle .arrow {
            transition: transform 0.2s;
        }
        .lp-product-card.open .lp-product-details-toggle .arrow {
            transform: rotate(180deg);
        }
        .lp-product-details {
            display: none;
            padding: 0 12px 12px;
            font-size: 13px;
            color: #555;
            line-height: 1.5;
            border-top: 1px solid #eee;
            margin-top: 8px;
            padding-top: 10px;
        }
        .lp-product-card.open .lp-product-details {
            display: block;
        }
        .lp-product-desc {
            margin-bottom: 12px;
        }
        .lp-product-cta-row {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
            margin-top: 10px;
        }
        .lp-product-cta-btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            padding: 8px 14px;
            border-radius: 6px;
            font-size: 12px;
            font-weight: 600;
            text-decoration: none;
            transition: transform 0.15s, opacity 0.15s;
            flex: 1;
            min-width: 80px;
        }
        .lp-product-cta-btn:active {
            transform: scale(0.98);
        }
        .lp-product-cta-btn.whatsapp {
            background: #25D366;
            color: #fff;
        }
        .lp-product-cta-btn.call {
            background: <?php echo esc_attr($primary); ?>;
            color: #fff;
        }
        .lp-product-cta-btn.link {
            background: #374151;
            color: #fff;
        }
        .lp-product-cta-btn svg {
            flex-shrink: 0;
        }
        /* Image Modal */
        .lp-img-modal {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(0,0,0,0.9);
            z-index: 9999;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .lp-img-modal.show {
            display: flex;
        }
        .lp-img-modal img {
            max-width: 100%;
            max-height: 90vh;
            border-radius: 12px;
        }
        .lp-img-modal-close {
            position: absolute;
            top: 16px;
            right: 16px;
            width: 40px;
            height: 40px;
            background: #fff;
            border: none;
            border-radius: 50%;
            font-size: 24px;
            cursor: pointer;
        }
        
        /* Responsive */
        @media (max-width: 480px) {
            .lp-hero h1 { font-size: 26px; }
            .lp-price-amount { font-size: 40px; }
            .lp-cta-btn { font-size: 16px; padding: 16px 24px; }
            .lp-form-title { font-size: 20px; }
            .lp-section-title { font-size: 18px; }
            .lp-product-thumb { width: 70px; height: 70px; }
            .lp-product-info h4 { font-size: 13px; }
            .lp-product-new-price { font-size: 15px; }
        }
        
        @media (min-width: 768px) {
            .container { padding: 0 24px; }
            .lp-hero { padding: 64px 0; }
            .lp-hero h1 { font-size: 40px; }
            .lp-section { padding: 40px 0; }
        }
    </style>
</head>
<body>

<!-- Header -->
<?php $show_header = ($m['show_header'] ?? '1') !== '0'; ?>
<?php if ($show_header): ?>
<header class="lp-header">
    <div class="container">
        <div class="lp-brand">
            <?php if ($m['logo_url']): ?>
                <img src="<?php echo esc_url($m['logo_url']); ?>" alt="Logo" class="lp-logo">
            <?php endif; ?>
            <span class="lp-name"><?php echo esc_html($m['business_name']); ?></span>
        </div>
        <?php if ($wa_number): ?>
        <a href="<?php echo esc_url($wa_url); ?>" class="lp-header-btn">
            <svg viewBox="0 0 24 24"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
            Chat
        </a>
        <?php endif; ?>
    </div>
</header>
<?php endif; ?>

<?php
// ============================================
// DYNAMIC SECTION RENDERING FUNCTIONS
// ============================================

// Title & Subtitle Section (formerly Hero/Header)
function render_section_header($m) {
    if (!$m['header_title']) return;
    ?>
    <section class="lp-hero">
        <div class="container">
            <h1><?php echo esc_html($m['header_title']); ?></h1>
            <?php if ($m['header_subtitle']): ?>
                <p><?php echo esc_html($m['header_subtitle']); ?></p>
            <?php endif; ?>
        </div>
    </section>
    <?php
}

// Image Section
function render_section_image($m) {
    if (!$m['image_url']) return;
    ?>
    <section class="lp-image">
        <div class="container">
            <img src="<?php echo esc_url($m['image_url']); ?>" alt="<?php echo esc_attr($m['business_name']); ?>">
        </div>
    </section>
    <?php
}

// Video Section
function render_section_video($m, $video_embed, $video_file, $video_autoplay) {
    if (!$video_embed && !$video_file) return;
    ?>
    <section class="lp-video" id="lp-video-section">
        <div class="container">
            <div class="lp-video-wrapper">
                <?php if ($video_file): ?>
                <video id="lp-video-player" <?php echo $video_autoplay ? 'data-autoplay="1"' : ''; ?> controls playsinline>
                    <source src="<?php echo esc_url($video_file); ?>" type="video/mp4">
                    Your browser does not support the video tag.
                </video>
                <?php else: ?>
                <iframe src="<?php echo esc_url($video_embed); ?>" allowfullscreen allow="autoplay"></iframe>
                <?php endif; ?>
            </div>
        </div>
    </section>
    <?php if ($video_file && $video_autoplay): ?>
    <script>
    (function() {
        var video = document.getElementById('lp-video-player');
        if (!video) return;
        var played = false;
        function checkVisible() {
            if (played) return;
            var rect = video.getBoundingClientRect();
            var viewHeight = window.innerHeight || document.documentElement.clientHeight;
            if (rect.top >= 0 && rect.top < viewHeight * 0.75) {
                video.play().catch(function(e) { console.log('Autoplay blocked:', e); });
                played = true;
            }
        }
        window.addEventListener('scroll', checkVisible);
        window.addEventListener('load', checkVisible);
    })();
    </script>
    <?php endif;
}

// Description Section
function render_section_description($m) {
    if (!$m['description']) return;
    ?>
    <section class="lp-section">
        <div class="container">
            <div class="lp-card mint">
                <h2 class="lp-section-title">Details</h2>
                <p><?php echo nl2br(esc_html($m['description'])); ?></p>
            </div>
        </div>
    </section>
    <?php
}

// Features Section
function render_section_features($features) {
    if (empty($features)) return;
    ?>
    <section class="lp-section">
        <div class="container">
            <div class="lp-card sky">
                <h2 class="lp-section-title">What You Get</h2>
                <ul class="lp-features">
                    <?php foreach ($features as $feature): ?>
                        <li><?php echo esc_html($feature); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
    </section>
    <?php
}

// Pricing Section
function render_section_pricing($m, $symbol) {
    if (!$m['original_price'] && !$m['sale_price']) return;
    ?>
    <section class="lp-pricing">
        <div class="container">
            <div class="lp-price-inline">
                <?php if ($m['original_price'] && $m['sale_price']): ?>
                    <span class="lp-price-old"><?php echo $symbol . number_format($m['original_price']); ?></span>
                <?php endif; ?>
                <span class="lp-price-new"><?php echo $symbol . number_format($m['sale_price'] ?: $m['original_price']); ?></span>
            </div>
        </div>
    </section>
    <?php
}

// WhatsApp CTA Section
function render_section_whatsapp($m, $wa_number, $wa_url) {
    if ($m['cta_type'] !== 'whatsapp' || !$wa_number) return;
    ?>
    <section class="lp-cta">
        <div class="container">
            <a href="<?php echo esc_url($wa_url); ?>" class="lp-cta-btn">
                <svg viewBox="0 0 24 24"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
                <?php echo esc_html($m['cta_text'] ?: 'Chat on WhatsApp'); ?>
            </a>
        </div>
    </section>
    <?php
}

// Link CTA Section
function render_section_link($m) {
    if ($m['cta_type'] !== 'link' || !$m['link_url']) return;
    ?>
    <section class="lp-cta">
        <div class="container">
            <a href="<?php echo esc_url($m['link_url']); ?>" class="lp-cta-btn link-btn" target="_blank">
                🔗 <?php echo esc_html($m['link_text'] ?: 'Learn More'); ?>
            </a>
        </div>
    </section>
    <?php
}

// Lead Form Section
function render_section_form($m, $form_fields, $page_id) {
    // Always render form when form component is in component_order
    ?>
    <section class="lp-section lp-form-section">
        <div class="container">
            <div class="lp-form-card">
                <h3 class="lp-form-title"><?php echo esc_html($m['form_title'] ?: 'Get Started Today'); ?></h3>
                <form class="lp-form" id="lp-lead-form">
                    <input type="hidden" name="page_id" value="<?php echo $page_id; ?>">
                    <?php foreach ($form_fields as $field): 
                        $field = trim($field);
                        $required = in_array($field, array('name', 'phone')) ? 'required' : '';
                        $type = ($field === 'email') ? 'email' : (($field === 'phone') ? 'tel' : 'text');
                        $label = ucfirst(str_replace('_', ' ', $field));
                    ?>
                    <input type="<?php echo $type; ?>" name="<?php echo esc_attr($field); ?>" placeholder="<?php echo esc_attr($label); ?>" <?php echo $required; ?>>
                    <?php endforeach; ?>
                    <button type="submit"><?php echo esc_html($m['form_button'] ?: 'Submit'); ?></button>
                </form>
            </div>
        </div>
    </section>
    <?php
}

// Products Section
function render_section_products($m, $symbol, $wa_url) {
    $products = array();
    if (!empty($m['products_json'])) {
        $json_products = json_decode($m['products_json'], true);
        if (is_array($json_products)) {
            foreach ($json_products as $p) {
                if (!empty($p['name'])) {
                    $products[] = array(
                        'name'      => $p['name'],
                        // Preserve both old and new price fields. If the new format
                        // only provides a single price value, map it into new_price
                        // so that it shows correctly on the live page. Old price is
                        // left empty unless explicitly provided.
                        'old_price' => isset($p['old_price']) ? $p['old_price'] : '',
                        'new_price' => isset($p['new_price']) ? $p['new_price'] : (isset($p['price']) ? $p['price'] : ''),
                        'image' => isset($p['image']) ? $p['image'] : '',
                        'desc' => isset($p['description']) ? $p['description'] : '',
                        'show_whatsapp' => isset($p['show_whatsapp']) ? $p['show_whatsapp'] : true,
                        'show_link' => isset($p['show_link']) ? $p['show_link'] : false,
                        'link_url' => isset($p['link_url']) ? $p['link_url'] : ''
                    );
                }
            }
        }
    }

    // Fallback: parse legacy products_list (one item per line).
    // Supported formats:
    // - Name - 5000
    // - Name: 5000
    // - Name|5000
    if (empty($products) && !empty($m['products_list'])) {
        $lines = preg_split('/\r\n|\r|\n/', (string)$m['products_list']);
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '') continue;

            $name = $line;
            $price = '';

            if (strpos($line, '|') !== false) {
                list($name, $price) = array_map('trim', explode('|', $line, 2));
            } elseif (strpos($line, ' - ') !== false) {
                list($name, $price) = array_map('trim', explode(' - ', $line, 2));
            } elseif (strpos($line, ':') !== false) {
                list($name, $price) = array_map('trim', explode(':', $line, 2));
            }

            if ($name !== '') {
                $products[] = array(
                    'name' => $name,
                    'old_price' => '',
                    'new_price' => $price,
                    'image' => '',
                    'desc' => '',
                    'show_whatsapp' => true,
                    'show_link' => false,
                    'link_url' => ''
                );
            }
        }
    }

    // Helper: display price (supports numeric strings with commas/currency, or free text).
    $format_price = function($raw) use ($symbol) {
        if ($raw === null) return '';
        $raw = is_string($raw) ? trim($raw) : $raw;
        if ($raw === '' || $raw === false) return '';

        // Allow "Free" or any non-numeric label.
        if (is_string($raw)) {
            $clean = preg_replace('/[^0-9.]/', '', $raw);
            if ($clean !== '' && is_numeric($clean)) {
                $num = (float)$clean;
                return $symbol . number_format($num);
            }
            return esc_html($raw);
        }

        if (is_numeric($raw)) {
            return $symbol . number_format((float)$raw);
        }

        return '';
    };

    if (empty($products)) return;
    ?>
    <section class="lp-section">
        <div class="container">
            <h2 class="lp-section-title" style="text-align:center;margin-bottom:20px;"><?php echo esc_html($m['products_title'] ?: 'More Products'); ?></h2>
            <div class="lp-products-grid">
                <?php foreach ($products as $idx => $prod): 
                    $show_whatsapp = $prod['show_whatsapp'];
                    $show_link = $prod['show_link'];
                    $prod_link = $prod['link_url'];
                    $prod_wa_url = str_replace(rawurlencode(get_the_title()), rawurlencode($prod['name']), $wa_url);
                ?>
                <div class="lp-product-card">
                    <?php if ($prod['image']): ?>
                    <div class="lp-product-thumb" data-img="<?php echo esc_url($prod['image']); ?>">
                        <img src="<?php echo esc_url($prod['image']); ?>" alt="<?php echo esc_attr($prod['name']); ?>">
                    </div>
                    <?php endif; ?>
                    <div class="lp-product-info">
                        <h4><?php echo esc_html($prod['name']); ?></h4>
                        <div class="lp-product-price">
                            <?php if ($prod['old_price']): ?>
                            <span class="old"><?php echo $format_price($prod['old_price']); ?></span>
                            <?php endif; ?>
                            <?php if ($prod['new_price']): ?>
                            <span class="new"><?php echo $format_price($prod['new_price']); ?></span>
                            <?php endif; ?>
                        </div>
                        <?php if ($prod['desc']): ?>
                        <button class="lp-product-details-toggle">Details ▼</button>
                        <div class="lp-product-details">
                            <p><?php echo nl2br(esc_html($prod['desc'])); ?></p>
                        </div>
                        <?php endif; ?>
                        <div class="lp-product-actions">
                            <?php if ($show_whatsapp): ?>
                            <a href="<?php echo esc_url($prod_wa_url); ?>" class="lp-product-btn wa">💬 Order</a>
                            <?php endif; ?>
                            <?php if ($show_link && $prod_link): ?>
                            <a href="<?php echo esc_url($prod_link); ?>" class="lp-product-btn link" target="_blank">🔗 View</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <!-- Image Modal -->
    <div class="lp-img-modal" id="lp-img-modal">
        <button class="lp-img-modal-close" onclick="document.getElementById('lp-img-modal').classList.remove('show')">×</button>
        <img src="" id="lp-img-modal-src">
    </div>
    <script>
    document.querySelectorAll('.lp-product-details-toggle').forEach(function(btn) {
        btn.addEventListener('click', function() {
            this.closest('.lp-product-card').classList.toggle('open');
        });
    });
    document.querySelectorAll('.lp-product-thumb').forEach(function(thumb) {
        thumb.addEventListener('click', function() {
            var img = this.getAttribute('data-img');
            if (img) {
                document.getElementById('lp-img-modal-src').src = img;
                document.getElementById('lp-img-modal').classList.add('show');
            }
        });
    });
    document.getElementById('lp-img-modal').addEventListener('click', function(e) {
        if (e.target === this) this.classList.remove('show');
    });
    </script>
    <?php
}

// ============================================
// DYNAMIC SECTION RENDERING BASED ON ORDER
// ============================================

// Get component order - if empty, use default order
$component_order = $m['component_order'];
if (empty($component_order)) {
    // Default order for backward compatibility
    $sections = array('header', 'image', 'video', 'description', 'features', 'pricing', 'products', 'whatsapp', 'link', 'form');
} else {
    $sections = array_filter(array_map('trim', explode(',', $component_order)));
}

// Parse headers JSON for multiple independent headers
$headers_array = array();
if (!empty($m['headers_json'])) {
    $headers_array = json_decode($m['headers_json'], true);
    if (!is_array($headers_array)) $headers_array = array();
}
// Backward compat: if no headers_json but has header_title
if (empty($headers_array) && ($m['header_title'] || $m['header_subtitle'])) {
    $headers_array = array(array('title' => $m['header_title'], 'subtitle' => $m['header_subtitle']));
}
$header_index = 0;

// Render each section in order
foreach ($sections as $section) {
    switch ($section) {
        case 'header':
            // Render next header from array
            if (isset($headers_array[$header_index])) {
                $h = $headers_array[$header_index];
                if (!empty($h['title']) || !empty($h['subtitle'])) {
                    ?>
                    <section class="lp-hero">
                        <div class="container">
                            <?php if (!empty($h['title'])): ?>
                            <h1><?php echo esc_html($h['title']); ?></h1>
                            <?php endif; ?>
                            <?php if (!empty($h['subtitle'])): ?>
                            <p><?php echo esc_html($h['subtitle']); ?></p>
                            <?php endif; ?>
                        </div>
                    </section>
                    <?php
                }
                $header_index++;
            } else {
                // Fallback to old method
                render_section_header($m);
            }
            break;
        case 'image':
            render_section_image($m);
            break;
        case 'video':
            render_section_video($m, $video_embed, $video_file, $video_autoplay);
            break;
        case 'description':
            render_section_description($m);
            break;
        case 'features':
            render_section_features($features);
            break;
        case 'pricing':
            render_section_pricing($m, $symbol);
            break;
        case 'whatsapp':
            render_section_whatsapp($m, $wa_number, $wa_url);
            break;
        case 'link':
            render_section_link($m);
            break;
        case 'form':
            render_section_form($m, $form_fields, $page_id);
            break;
        case 'products':
            render_section_products($m, $symbol, $wa_url);
            break;
    }
}
?>

<!-- Contact - FIX #11: Pro Footer Design -->
<?php if ($m['phone'] || $m['email'] || $m['location']): ?>
<footer class="lp-pro-footer">
    <div class="container">
        <div class="lp-footer-grid">
            <div class="lp-footer-brand">
                <?php if ($m['logo_url']): ?>
                <img src="<?php echo esc_url($m['logo_url']); ?>" alt="Logo" class="lp-footer-logo">
                <?php endif; ?>
                <h3><?php echo esc_html($m['business_name']); ?></h3>
                <?php if ($m['description']): ?>
                <p><?php echo esc_html(wp_trim_words($m['description'], 15)); ?></p>
                <?php endif; ?>
            </div>
            <div class="lp-footer-contact">
                <h4>Contact Us</h4>
                <?php if ($m['phone']): ?>
                <a href="tel:<?php echo esc_attr($m['phone']); ?>">📞 <?php echo esc_html($m['phone']); ?></a>
                <?php endif; ?>
                <?php if ($m['email']): ?>
                <a href="mailto:<?php echo esc_attr($m['email']); ?>">✉️ <?php echo esc_html($m['email']); ?></a>
                <?php endif; ?>
                <?php if ($m['location']): ?>
                <span>📍 <?php echo esc_html($m['location']); ?></span>
                <?php endif; ?>
            </div>
            <div class="lp-footer-social">
                <h4>Connect</h4>
                <?php
                // Show contact social links: fallback to WhatsApp and website if social links disabled
                $show_social = !empty($m['footer_show_social']);
                if ($show_social) {
                    if (!empty($m['footer_facebook'])) {
                        echo '<a href="' . esc_url($m['footer_facebook']) . '" target="_blank">👍 Facebook</a>';
                    }
                    if (!empty($m['footer_instagram'])) {
                        echo '<a href="' . esc_url($m['footer_instagram']) . '" target="_blank">📸 Instagram</a>';
                    }
                    if (!empty($m['footer_x'])) {
                        echo '<a href="' . esc_url($m['footer_x']) . '" target="_blank">🐦 X</a>';
                    }
                    if (!empty($m['footer_whatsapp_url'])) {
                        echo '<a href="' . esc_url($m['footer_whatsapp_url']) . '" target="_blank">💬 WhatsApp</a>';
                    }
                } else {
                    if ($wa_number) {
                        echo '<a href="' . esc_url($wa_url) . '">💬 WhatsApp</a>';
                    }
                    if ($m['link_url']) {
                        echo '<a href="' . esc_url($m['link_url']) . '" target="_blank">🔗 ' . esc_html($m['link_text'] ?: 'Website') . '</a>';
                    }
                }
                ?>
            </div>
        </div>
        <div class="lp-footer-bottom">
            <?php
            // Build footer bottom text: tagline, address, main text, disclaimer
            $parts = array();
            if (!empty($m['footer_tagline'])) {
                $parts[] = '<span class="lp-footer-tagline">' . esc_html($m['footer_tagline']) . '</span>';
            }
            if (!empty($m['footer_address'])) {
                $parts[] = '<span class="lp-footer-address">' . esc_html($m['footer_address']) . '</span>';
            }
            // Main footer text (copyright)
            $main_text = $m['footer_text'] ?: ('© ' . date('Y') . ' ' . $m['business_name'] . '. All rights reserved.');
            $parts[] = '<span class="lp-footer-main">' . esc_html($main_text) . '</span>';
            if (!empty($m['footer_disclaimer'])) {
                $parts[] = '<span class="lp-footer-disclaimer">' . esc_html($m['footer_disclaimer']) . '</span>';
            }
            echo '<p>' . implode(' · ', $parts) . '</p>';
            ?>
        </div>
    </div>
</footer>
<?php else: ?>
<!-- Simple Footer -->
<footer class="lp-footer">
    <div class="container">
        <?php
        // Build simple footer with tagline/address/copyright/disclaimer if provided
        $parts = array();
        if (!empty($m['footer_tagline'])) {
            $parts[] = esc_html($m['footer_tagline']);
        }
        if (!empty($m['footer_address'])) {
            $parts[] = esc_html($m['footer_address']);
        }
        $main_text = $m['footer_text'] ?: ('© ' . date('Y') . ' ' . $m['business_name'] . '. All rights reserved.');
        $parts[] = esc_html($main_text);
        if (!empty($m['footer_disclaimer'])) {
            $parts[] = esc_html($m['footer_disclaimer']);
        }
        echo '<p>' . implode(' · ', $parts) . '</p>';
        ?>
    </div>
</footer>
<?php endif; ?>

<!-- Watermark -->
<?php if ($show_watermark): ?>
<div class="lp-watermark">
    <div class="container">
        Built with <a href="https://hushot.com" target="_blank" rel="noopener">Hushot</a> – <a href="<?php echo esc_url(home_url('/pricing/')); ?>" target="_blank" rel="noopener">Try for Free</a>
    </div>
</div>
<?php endif; ?>

<!-- Bottom Bar - FIX #5: WhatsApp icon and bar fields -->
<?php if ($show_bottom): 
    $bar_style = $m['bottom_bar_style'];
    // Use bar-specific fields if set, otherwise fall back to general fields
    $bar_phone = $m['bar_phone'] ?: $m['phone'];
    $bar_wa = $m['bar_whatsapp'] ?: $m['whatsapp'];
    $bar_link = $m['bar_link_url'] ?: $m['link_url'];
    $bar_wa_num = preg_replace('/[^0-9]/', '', $bar_wa);
    $bar_wa_url = $bar_wa_num ? "https://wa.me/{$bar_wa_num}?text={$wa_message}" : '#';
    
    $show_call = in_array($bar_style, array('call_whatsapp', 'call_link', 'all_three', 'call_only')) && $bar_phone;
    $show_wa = in_array($bar_style, array('call_whatsapp', 'whatsapp_link', 'all_three', 'whatsapp_only')) && $bar_wa_num;
    $show_link = in_array($bar_style, array('whatsapp_link', 'call_link', 'all_three', 'link_only')) && $bar_link;
?>
<nav class="lp-bottom">
    <?php if ($show_call): ?>
    <a href="tel:<?php echo esc_attr($bar_phone); ?>" class="lp-bottom-call">
        📞 Call
    </a>
    <?php endif; ?>
    <?php if ($show_wa): ?>
    <a href="<?php echo esc_url($bar_wa_url); ?>" class="lp-bottom-wa">
        <svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
        WhatsApp
    </a>
    <?php endif; ?>
    <?php if ($show_link): ?>
    <a href="<?php echo esc_url($bar_link); ?>" class="lp-bottom-link" target="_blank">
        🔗 <?php echo esc_html($m['link_text'] ?: 'Link'); ?>
    </a>
    <?php endif; ?>
</nav>
<?php endif; ?>

<!-- Lead Form Script -->
<script>
(function() {
    // Click Tracking for Analytics
    var pageId = <?php echo intval($page_id); ?>;
    var ajaxUrl = '<?php echo admin_url('admin-ajax.php'); ?>';
    
    function trackClick(buttonType) {
        var formData = new FormData();
        formData.append('action', 'hushot_track_click');
        formData.append('page_id', pageId);
        formData.append('button_type', buttonType);
        
        fetch(ajaxUrl, {
            method: 'POST',
            body: formData
        }).catch(function() {});
    }
    
    // Track WhatsApp button clicks
    document.querySelectorAll('a[href*="wa.me"], a[href*="whatsapp"], .lp-cta, .lp-bottom-wa').forEach(function(el) {
        el.addEventListener('click', function() {
            trackClick('whatsapp');
        });
    });
    
    // Track call button clicks
    document.querySelectorAll('a[href^="tel:"], .lp-bottom-call').forEach(function(el) {
        el.addEventListener('click', function() {
            trackClick('call');
        });
    });
    
    // Track link button clicks
    document.querySelectorAll('.lp-bottom-link, .lp-link-btn').forEach(function(el) {
        el.addEventListener('click', function() {
            trackClick('link');
        });
    });
    
    // Track email clicks
    document.querySelectorAll('a[href^="mailto:"]').forEach(function(el) {
        el.addEventListener('click', function() {
            trackClick('email');
        });
    });
    
    // Track any CTA button
    document.querySelectorAll('.lp-cta-btn, .lp-btn, [class*="cta"]').forEach(function(el) {
        if (!el.dataset.tracked) {
            el.dataset.tracked = '1';
            el.addEventListener('click', function() {
                trackClick('cta');
            });
        }
    });

    // Lead Form Handler
    var form = document.getElementById('lp-lead-form');
    if (!form) return;
    
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Track form submission
        trackClick('form_submit');
        
        var btn = form.querySelector('button');
        var originalText = btn.textContent;
        btn.textContent = 'Sending...';
        btn.disabled = true;
        
        var formData = new FormData(form);
        formData.append('action', 'hushot_submit_lead');
        
        fetch(ajaxUrl, {
            method: 'POST',
            body: formData
        })
        .then(function(response) { return response.json(); })
        .then(function(data) {
            if (data.success) {
                form.parentElement.innerHTML = '<div class="lp-success"><h3>✓ Thank You!</h3><p>We\'ll be in touch soon.</p></div>';
            } else {
                btn.textContent = 'Error - Try Again';
                btn.disabled = false;
                setTimeout(function() { btn.textContent = originalText; }, 3000);
            }
        })
        .catch(function() {
            btn.textContent = 'Error - Try Again';
            btn.disabled = false;
            setTimeout(function() { btn.textContent = originalText; }, 3000);
        });
    });
})();

// Remove any theme loaders/spinners/dot grids
(function() {
    function removeLoaders() {
        var selectors = [
            '.loader', '.loading', '.spinner', '.preloader',
            '[class*="loader"]', '[class*="spinner"]', 
            '[class*="bricks-loading"]', '[class*="dots"]',
            '[class*="dot-grid"]', '[class*="dot-loader"]',
            '.bricks-loading-dots', '.bricks-dots'
        ];
        var loaders = document.querySelectorAll(selectors.join(','));
        loaders.forEach(function(el) {
            el.style.display = 'none';
            el.remove();
        });
        // Also remove empty brx elements before our content
        var brxContent = document.querySelector('#brx-content');
        if (brxContent) {
            var firstChild = brxContent.firstElementChild;
            if (firstChild && !firstChild.classList.contains('lp-wrapper')) {
                firstChild.remove();
            }
        }
    }
    removeLoaders();
    window.addEventListener('load', removeLoaders);
    setTimeout(removeLoaders, 100);
    setTimeout(removeLoaders, 500);
    setTimeout(removeLoaders, 1500);
})();
</script>

<?php wp_footer(); ?>
<script>
(function(){
    function killDots() {
        // Remove any element that looks like the dot grid
        var all = document.body.querySelectorAll('*');
        for (var i = 0; i < all.length; i++) {
            var el = all[i];
            // Skip our elements
            if (el.closest('.lp-header, .lp-hero, .lp-section, .lp-footer, .lp-watermark, .lp-bottom-bar, .container')) continue;
            // Check if it's a small grid/dot pattern
            var style = window.getComputedStyle(el);
            var w = el.offsetWidth;
            var h = el.offsetHeight;
            // Target small square elements that might be dots
            if (w > 0 && w < 200 && h > 0 && h < 200 && el.tagName !== 'SCRIPT' && el.tagName !== 'STYLE' && el.tagName !== 'LINK') {
                var text = el.innerText || '';
                if (text.length === 0 && el.children.length > 5) {
                    el.style.display = 'none';
                }
            }
        }
        // Brute force: hide anything after footer that isn't our stuff
        var footer = document.querySelector('.lp-footer');
        if (footer) {
            var next = footer.nextElementSibling;
            while (next) {
                if (!next.classList.contains('lp-watermark') && 
                    !next.classList.contains('lp-bottom-bar') && 
                    next.tagName !== 'SCRIPT' && 
                    next.tagName !== 'STYLE') {
                    next.style.cssText = 'display:none!important;visibility:hidden!important;height:0!important;overflow:hidden!important;';
                }
                next = next.nextElementSibling;
            }
        }
    }
    killDots();
    setTimeout(killDots, 100);
    setTimeout(killDots, 500);
    setTimeout(killDots, 1000);
    setTimeout(killDots, 2000);
})();
</script>
</body>
</html>
